// LeftDockablePane.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "LeftDockablePane.h"


// CLeftDockablePane

IMPLEMENT_DYNAMIC(CLeftDockablePane, CDockablePane)

CLeftDockablePane::CLeftDockablePane()
{

}

CLeftDockablePane::~CLeftDockablePane()
{
}


BEGIN_MESSAGE_MAP(CLeftDockablePane, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
END_MESSAGE_MAP()



// CLeftDockablePane ��Ϣ��������

void CLeftDockablePane::LoadXml(const CString &csSelDirectoryName,const CString &csSelFileName)
{
	m_leftDialog.LoadXml(csSelDirectoryName,csSelFileName);
}

CString CLeftDockablePane::GetSelDirectoryName() const
{
	return m_leftDialog.GetSelDirectoryName();
}

CString CLeftDockablePane::GetSelFileName() const
{
	return m_leftDialog.GetSelFileName();
}

CString CLeftDockablePane::GetXmlPath() const
{
	return m_leftDialog.GetXmlPath();
}

CString CLeftDockablePane::GetLuaPath() const
{
	return m_leftDialog.GetLuaPath();
}

int CLeftDockablePane::SaveXml()
{
	return m_leftDialog.SaveXml();
}

int CLeftDockablePane::GenLua()
{
	return m_leftDialog.GenLua();
}

int CLeftDockablePane::GenConfigLua(const CString &csFilePath,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode)
{
	return m_leftDialog.GenConfigLua(csFilePath,emDrawingTypeArr,bLeafNode);
}

void CLeftDockablePane::ChangeEditorDrawingId()
{
	m_leftDialog.ChangeEditorDrawingId();
}

int CLeftDockablePane::GetTreeSelectItemDrawingId() const
{
	return m_leftDialog.GetTreeSelectItemDrawingId();
}

void CLeftDockablePane::ChangeEditorDrawingSeat(double dX,double dY,double dWidth,double dHeight,BOOL bLButtonUp)
{
	return m_leftDialog.ChangeEditorDrawingSeat(dX,dY,dWidth,dHeight,bLButtonUp);
}

void CLeftDockablePane::ChangeUIProp(const CDrawingBase *pDrawingBase,WPARAM wParam,LPARAM lParam,BOOL bAddHistory)
{
	m_leftDialog.ChangeUIProp(pDrawingBase,wParam,lParam,bAddHistory);
}

int CLeftDockablePane::AddNewNode(EM_DRAWING_TYPE type,CString csDrawingTypeName,BOOL bControl,int x,int y)
{
	return m_leftDialog.AddNewNode(type,csDrawingTypeName,bControl,x,y);
}

void CLeftDockablePane::Cut()
{
	m_leftDialog.Cut();
}

void CLeftDockablePane::Copy()
{
	m_leftDialog.Copy();
}

void CLeftDockablePane::Paste()
{
	m_leftDialog.Paste();
}

void CLeftDockablePane::Undo()
{
	m_leftDialog.Undo();
}

void CLeftDockablePane::Redo()
{
	m_leftDialog.Redo();
}

void CLeftDockablePane::Delete()
{
	m_leftDialog.Delete();
}

BOOL CLeftDockablePane::IsCanCut()
{
	return m_leftDialog.IsCanCut();
}

BOOL CLeftDockablePane::IsCanCopy()
{
	return m_leftDialog.IsCanCopy();
}

BOOL CLeftDockablePane::IsCanPaste()
{
	return m_leftDialog.IsCanPaste();
}

BOOL CLeftDockablePane::IsCanUndo()
{
	return m_leftDialog.IsCanUndo();
}

BOOL CLeftDockablePane::IsCanRedo()
{
	return m_leftDialog.IsCanRedo();
}

BOOL CLeftDockablePane::IsCanDelete()
{
	return m_leftDialog.IsCanDelete();
}

void CLeftDockablePane::SetHistory(int iCommandHistoryPos)
{
	m_leftDialog.SetHistory(iCommandHistoryPos);
}

BOOL CLeftDockablePane::IsModifyData()
{
	return m_leftDialog.IsModifyData();
}

void CLeftDockablePane::ReleaseAllData()
{
	m_leftDialog.ReleaseAllData();
}

const CDrawingBase* CLeftDockablePane::GetSelDrawingBase()
{
	return m_leftDialog.GetSelDrawingBase();
}

bool CLeftDockablePane::GetTreeTimeMap(map<long,bool> &lTimeMap)
{
	return m_leftDialog.GetTreeTimeMap(lTimeMap);
}

int CLeftDockablePane::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_leftDialog.Create(IDD_LEFT_DIALOG,this);
	m_leftDialog.ShowWindow(SW_SHOW);

	return 0;
}


void CLeftDockablePane::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);

	if(m_leftDialog.m_hWnd != NULL)
	{
		CRect clientRect;
		GetClientRect(clientRect);
		m_leftDialog.MoveWindow(clientRect);
	}
}
