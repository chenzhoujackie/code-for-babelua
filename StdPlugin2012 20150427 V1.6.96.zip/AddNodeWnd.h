#pragma once

#include "OleDropTargetEx.h"

#define DROP_ADD_NODE_FORMAT		_T("DROP_ADD_NODE_FORMAT")

//���ӽڵ㷢����Ϣ
#define WM_ADD_NODE					(WM_USER+1801)
#define WM_RCLICK_NODE				(WM_USER+1802)

//��߾� �ұ߾� �ϱ߾� �±߾�
#define ADD_NODE_LEFT_DIS			10
#define ADD_NODE_RIGHT_DIS			5
#define ADD_NODE_TOP_DIS			10
#define ADD_NODE_BOTTOM_DIS			5
//X,Y������
#define ADD_NODE_X_DIS				5
#define ADD_NODE_Y_DIS				5

//��ʾ���Ⱥ͸߶�
#define ADD_NODE_WIDTH				100
#define ADD_NODE_HEIGHT				60


enum EM_RESOURCE_TYPE
{
	RESOURCE_TYPE_PNG
};
Bitmap* BitmapFromIDResource(UINT nID,EM_RESOURCE_TYPE emResourceType);

//�ڵ�Item
class CAddNodeItem
{
public:
	void SetItemName(const CString &csItemName);
	void SetItemData(DWORD_PTR dwData);
	CString GetItemName() const;
	DWORD_PTR GetItemData() const;
	void LoadImage(int nViewID,int nMouseID);
	Bitmap* GetViewBitmap() const;
	Bitmap* GetMouseBitmap() const;
public:
	CAddNodeItem();
	~CAddNodeItem();
private:
	Bitmap *m_pViewBitmap;
	Bitmap *m_pMouseBitmap;
	CString m_csItemName;
	DWORD_PTR m_dwData;
};

// CAddNodeWnd

class CAddNodeWnd : public CWnd
{
public:
	void AddNodeItem(CString csItemName,DWORD_PTR dwData,int nViewID,int nMouseID);
	void ChangeDrawingBase(const CDrawingBase *pDrawingBase);
	DWORD_PTR GetSelectItemData() const;
	CString GetSelectItemName() const;
	BOOL DeleteSelectItem();
private:
	BOOL UpdateScroll();
	int GetSelectItem(CPoint point);
	BOOL IsDisable(DWORD_PTR data);
	void UpdateToolTipRect();
private:
	CArray <CAddNodeItem*,CAddNodeItem*> m_addNodeItemArray;
	int m_iSelectItem;
	int m_iMoveSelectItem;

	const CDrawingBase *m_pDrawingBase;

	BOOL m_bLButtonDown;
	BOOL m_bDragAddNode;

	HCURSOR m_hCursor;

	CToolTipCtrl m_toolTipCtrl;

	BOOL m_bRegeister;
	COleDropTargetEx m_oleTarget;
	BOOL m_bDraging;

	BOOL m_bTracking;

	DECLARE_DYNAMIC(CAddNodeWnd)

public:
	CAddNodeWnd();
	virtual ~CAddNodeWnd();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnSize(UINT nType, int cx, int cy);

	virtual BOOL Regeister();
	virtual LRESULT OnDrop(WPARAM pDropInfoClass, LPARAM lParm);
	virtual LRESULT OnDropEx(WPARAM pDropInfoClass, LPARAM lParm);
	virtual LRESULT OnDragOver(WPARAM pDropInfoClass,LPARAM lParm);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/);
	afx_msg void OnMouseHover(UINT nFlags, CPoint point);
	afx_msg void OnMouseLeave();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};


