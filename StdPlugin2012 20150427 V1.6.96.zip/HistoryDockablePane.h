#pragma once

#include "HistoryDialog.h"

// CHistoryDockablePane

class CHistoryDockablePane : public CDockablePane
{
public:
	void UpdateHistory(int iCommandHistoryUndoPos,int iCommandHistoryUndoCount,int iCommandHistoryRedoCount,const CArray<int,int> &iTypeArr,const CStringArray &csHistoryNameArr);
private:
	CHistoryDialog m_historyDialog;

	DECLARE_DYNAMIC(CHistoryDockablePane)

public:
	CHistoryDockablePane();
	virtual ~CHistoryDockablePane();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


