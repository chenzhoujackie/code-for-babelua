// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// MainFrm.cpp : CMainFrame ���ʵ��
//

#include "stdafx.h"
#include "StdPlugin.h"

#include "MainFrm.h"
#include "StdPluginDoc.h"
#include "StdPluginView.h"

#include "afxdatarecovery.h"

#include "FileManageDialog.h"

#include "DialogBkSetting.h"
#include "DialogBorderSetting.h"
#include "DialogGridSetting.h"
#include "DialogWellSetting.h"
#include "DialogAllSetting.h"

#include "PromptDialog.h"
#include "OutputConfigDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#define MY_RADIO_BUTTON_DEFAULT_SIZE (afxGlobalData.GetRibbonImageScale() == 1. ? 12 : 16)

const int nTextMarginLeft = 4;
const int nTextMarginRight = 6;

class CMFCRibbonRadio : public CMFCRibbonCheckBox
{
public:
	CMFCRibbonRadio(UINT nID, LPCTSTR lpszText) : CMFCRibbonCheckBox(nID, lpszText) {}
	virtual void OnDraw(CDC* pDC)
	{
		ASSERT_VALID(this);
		ASSERT_VALID(pDC);

		if (m_rect.IsRectEmpty())
		{
			return;
		}

		const CSize sizeCheckBox = CSize(MY_RADIO_BUTTON_DEFAULT_SIZE, MY_RADIO_BUTTON_DEFAULT_SIZE);

		// Draw check box:
		CRect rectCheck = m_rect;
		rectCheck.DeflateRect(m_szMargin);
		rectCheck.left++;
		rectCheck.right = rectCheck.left + sizeCheckBox.cx;
		rectCheck.top = rectCheck.CenterPoint().y - sizeCheckBox.cx / 2;

		rectCheck.bottom = rectCheck.top + sizeCheckBox.cy;

		const BOOL bIsHighlighted = (IsHighlighted() || IsFocused()) && !IsDisabled();

		pDC->DrawFrameControl(rectCheck, DFC_BUTTON, DFCS_BUTTONRADIO | (IsChecked() ||(IsPressed() && bIsHighlighted) ? DFCS_CHECKED : 0));
		//CMFCVisualManager::GetInstance()->OnDrawCheckBoxEx(pDC, rectCheck, IsChecked() ||(IsPressed() && bIsHighlighted) ? 1 : 0,
		//	bIsHighlighted, IsPressed() && bIsHighlighted, !IsDisabled());

		// Draw text:
		COLORREF clrTextOld = (COLORREF)-1;

		if (m_bIsDisabled)
		{
			if (m_bQuickAccessMode)
			{
				clrTextOld = pDC->SetTextColor(CMFCVisualManager::GetInstance()->GetRibbonQuickAccessToolBarTextColor(TRUE));
			}
			else
			{
				clrTextOld = pDC->SetTextColor(CMFCVisualManager::GetInstance()->GetToolbarDisabledTextColor());
			}
		}

		CRect rectText = m_rect;
		rectText.left = rectCheck.right + nTextMarginLeft;

		DrawRibbonText(pDC, m_strText, rectText, DT_SINGLELINE | DT_VCENTER);

		if (clrTextOld != (COLORREF)-1)
		{
			pDC->SetTextColor(clrTextOld);
		}
	}
};

class CMFCRibbonCheckBoxEx : public CMFCRibbonCheckBox
{
public:
	void SetCheck(BOOL bCheck)
	{
		m_bIsChecked = bCheck;
	}
	void SetDisabled(BOOL bDisabled)
	{
		m_bIsDisabled = bDisabled;
	}
};

// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWndEx)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWndEx)
	ON_WM_CREATE()
	ON_COMMAND_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnApplicationLook)
	ON_UPDATE_COMMAND_UI_RANGE(ID_VIEW_APPLOOK_WIN_2000, ID_VIEW_APPLOOK_WINDOWS_7, &CMainFrame::OnUpdateApplicationLook)
	ON_COMMAND(ID_XMLMAG_FOLDER,&CMainFrame::OnXmlmagFolder)
	ON_COMMAND(ID_GEN_LUA_FINAL,&CMainFrame::OnGenLuaFinal)
	ON_COMMAND(ID_SAVE_XML,&CMainFrame::OnSaveXml)
	ON_COMMAND(ID_GEN_CONFIG_LUA,&CMainFrame::OnGenConfigLua)
	ON_COMMAND(ID_EDIT_CUT,&CMainFrame::OnEditCut)
	ON_COMMAND(ID_EDIT_COPY,&CMainFrame::OnEditCopy)
	ON_COMMAND(ID_EDIT_PASTE,&CMainFrame::OnEditPaste)
	ON_COMMAND(ID_EDIT_DELETE,&CMainFrame::OnEditDelete)
	ON_COMMAND(ID_EDIT_UNDO,&CMainFrame::OnEditUndo)
	ON_COMMAND(ID_EDIT_REDO,&CMainFrame::OnEditRedo)
	ON_COMMAND(ID_XMLMAG_XML,&CMainFrame::OnXmlmagXml)
	ON_COMMAND(ID_EXIT,&CMainFrame::OnExit)
	ON_COMMAND(ID_EDIT_MODE,&CMainFrame::OnEditMode)
	ON_COMMAND(ID_VIEW_MODE,&CMainFrame::OnViewMode)
	ON_COMMAND(ID_GRID_SHOW,&CMainFrame::OnGridShow)
	ON_COMMAND(ID_GRID_SETTING,&CMainFrame::OnGridSetting)
	ON_COMMAND(ID_CROSS_SHOW,&CMainFrame::OnCrossShow)
	ON_COMMAND(ID_CROSS_SETTING,&CMainFrame::OnCrossSetting)
	ON_COMMAND(ID_BORDER_SHOW,&CMainFrame::OnBorderShow)
	ON_COMMAND(ID_ALL_BORDER_SHOW,&CMainFrame::OnAllBorderShow)
	ON_COMMAND(ID_BORDER_SETTING,&CMainFrame::OnBorderSetting)
	ON_COMMAND(ID_BK_SETTING,&CMainFrame::OnBkSetting)
	ON_COMMAND(ID_ALL_SETTING,&CMainFrame::OnAllSetting)
	ON_COMMAND(ID_CONSOLE_SHOW,&CMainFrame::OnConsoleShow)
	ON_COMMAND(ID_CONSOLE_CLEAR,&CMainFrame::OnConsoleClear)
	ON_COMMAND(ID_VIEW_LEFT_PANE,&CMainFrame::OnViewLeftPane)
	ON_COMMAND(ID_VIEW_RIGHT_PANE,&CMainFrame::OnViewRightPane)
	ON_COMMAND(ID_VIEW_UI_PROP_PANE,&CMainFrame::OnViewUiPropPane)
	ON_COMMAND(ID_VIEW_HISTORY_PANE,&CMainFrame::OnViewHistoryPane)
	ON_COMMAND(ID_HELP,&CMainFrame::OnHelp)
	ON_COMMAND(ID_ABOUT,&CMainFrame::OnAbout)
	ON_UPDATE_COMMAND_UI(ID_XMLMAG_FOLDER,&CMainFrame::OnUpdateXmlmagFolder)
	ON_UPDATE_COMMAND_UI(ID_GEN_LUA_FINAL,&CMainFrame::OnUpdateGenLuaFinal)
	ON_UPDATE_COMMAND_UI(ID_SAVE_XML,&CMainFrame::OnUpdateSaveXml)
	ON_UPDATE_COMMAND_UI(ID_GEN_CONFIG_LUA,&CMainFrame::OnUpdateGenConfigLua)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT,&CMainFrame::OnUpdateEditCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY,&CMainFrame::OnUpdateEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE,&CMainFrame::OnUpdateEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_DELETE,&CMainFrame::OnUpdateEditDelete)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO,&CMainFrame::OnUpdateEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REDO,&CMainFrame::OnUpdateEditRedo)
	ON_UPDATE_COMMAND_UI(ID_XMLMAG_XML,&CMainFrame::OnUpdateXmlmagXml)
	ON_UPDATE_COMMAND_UI(ID_EXIT,&CMainFrame::OnUpdateExit)
	ON_UPDATE_COMMAND_UI(ID_EDIT_MODE,&CMainFrame::OnUpdateEditMode)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MODE,&CMainFrame::OnUpdateViewMode)
	ON_UPDATE_COMMAND_UI(ID_GRID_SHOW,&CMainFrame::OnUpdateGridShow)
	ON_UPDATE_COMMAND_UI(ID_GRID_SETTING,&CMainFrame::OnUpdateGridSetting)
	ON_UPDATE_COMMAND_UI(ID_CROSS_SHOW,&CMainFrame::OnUpdateCrossShow)
	ON_UPDATE_COMMAND_UI(ID_CROSS_SETTING,&CMainFrame::OnUpdateCrossSetting)
	ON_UPDATE_COMMAND_UI(ID_BORDER_SHOW,&CMainFrame::OnUpdateBorderShow)
	ON_UPDATE_COMMAND_UI(ID_BORDER_SETTING,&CMainFrame::OnUpdateBorderSetting)
	ON_UPDATE_COMMAND_UI(ID_BK_SETTING,&CMainFrame::OnUpdateBkSetting)
	ON_UPDATE_COMMAND_UI(ID_ALL_SETTING,&CMainFrame::OnUpdateAllSetting)
	ON_UPDATE_COMMAND_UI(ID_CONSOLE_SHOW,&CMainFrame::OnUpdateConsoleShow)
	ON_UPDATE_COMMAND_UI(ID_CONSOLE_CLEAR,&CMainFrame::OnUpdateConsoleClear)
	ON_UPDATE_COMMAND_UI(ID_VIEW_LEFT_PANE,&CMainFrame::OnUpdateViewLeftPane)
	ON_UPDATE_COMMAND_UI(ID_VIEW_RIGHT_PANE,&CMainFrame::OnUpdateViewRightPane)
	ON_UPDATE_COMMAND_UI(ID_VIEW_UI_PROP_PANE,&CMainFrame::OnUpdateViewUiPropPane)
	ON_UPDATE_COMMAND_UI(ID_VIEW_HISTORY_PANE,&CMainFrame::OnUpdateViewHistoryPane)
	ON_UPDATE_COMMAND_UI(ID_HELP,&CMainFrame::OnUpdateHelp)
	ON_UPDATE_COMMAND_UI(ID_ABOUT,&CMainFrame::OnUpdateAbout)
	ON_WM_CLOSE()
	ON_WM_TIMER()

	ON_MESSAGE(WM_ADD_NODE,MessageAddNode)
	ON_MESSAGE(WM_CHANGE_DRAWING_BASE,MessageChangeDrawingBase)
	ON_MESSAGE(WM_TREE_SELCHANGING,MessageTreeSelchanging)
	ON_MESSAGE(WM_GET_TREE_DRAWING_TIMES,MessageGetTreeDrawingTimes)
	ON_MESSAGE(WM_CHANGE_UI_PROP,MessageChangeUIProp)
	ON_MESSAGE(WM_UPDATE_UI_PROP,MessageUpdateUIProp)
END_MESSAGE_MAP()

// CMainFrame ����/����

CMainFrame::CMainFrame()
{
	// TODO: �ڴ����ӳ�Ա��ʼ������
	theApp.m_nAppLook = theApp.GetInt(_T("ApplicationLook"), ID_VIEW_APPLOOK_OFF_2007_BLUE);
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWndEx::OnCreate(lpCreateStruct) == -1)
		return -1;

	BOOL bNameValid;
	// ���ڳ־�ֵ�����Ӿ�����������ʽ
	OnApplicationLook(theApp.m_nAppLook);

	m_fileLargeImages.SetImageSize(CSize(32,32));
	m_fileLargeImages.Load(IDB_FILELARGE);

	m_writeSmallImages.SetImageSize(CSize(16,16));
	m_writeSmallImages.Load(IDB_WRITESMALL);

	m_wndRibbonBar.Create(this);
//	m_wndRibbonBar.LoadFromResource(IDR_RIBBON);
	CMFCRibbonCategory *pStartRibbonCategory = m_wndRibbonBar.AddCategory(_T("��ʼ"),IDB_PNG_MENU16,IDB_PNG_MENU32);
	if(pStartRibbonCategory != NULL)
	{
		CMFCRibbonPanel *pSystemRibbonPanel = pStartRibbonCategory->AddPanel(_T("ϵͳ"));
		if(pSystemRibbonPanel != NULL)
		{
			pSystemRibbonPanel->Add(new CMFCRibbonButton(ID_XMLMAG_FOLDER, _T("�ļ�����"), 0, 0));
//			pSystemRibbonPanel->Add(new CMFCRibbonButton(ID_XMLMAG_XML, _T("xml����"), m_fileLageImages.ExtractIcon(1)));
//			pSystemRibbonPanel->Add(new CMFCRibbonButton(ID_EXIT, _T("�˳�"), m_fileLageImages.ExtractIcon(2)));
			pSystemRibbonPanel->Add(new CMFCRibbonButton(ID_GEN_LUA_FINAL, _T("����lua"), 1, 1));
			pSystemRibbonPanel->Add(new CMFCRibbonButton(ID_SAVE_XML, _T("����xml"), 2, 2));
			pSystemRibbonPanel->Add(new CMFCRibbonButton(ID_GEN_CONFIG_LUA, _T("����config"), 3, 3));
		}
		CMFCRibbonPanel *pEditRibbonPanel = pStartRibbonCategory->AddPanel(_T("�༭"));
		if(pEditRibbonPanel != NULL)
		{
			pEditRibbonPanel->Add(new CMFCRibbonButton(ID_EDIT_CUT, _T("����"), 4));
			pEditRibbonPanel->Add(new CMFCRibbonButton(ID_EDIT_COPY, _T("����"), 5));
			pEditRibbonPanel->Add(new CMFCRibbonButton(ID_EDIT_PASTE, _T("ճ��"), 6));
			pEditRibbonPanel->Add(new CMFCRibbonButton(ID_EDIT_DELETE, _T("ɾ��"), 7));
			pEditRibbonPanel->Add(new CMFCRibbonButton(ID_EDIT_UNDO, _T("����"), 8));
			pEditRibbonPanel->Add(new CMFCRibbonButton(ID_EDIT_REDO, _T("����"), 9));
		}
		CMFCRibbonPanel *pSetRibbonPanel = pStartRibbonCategory->AddPanel(_T("����"));
		if(pSetRibbonPanel != NULL)
		{
			pSetRibbonPanel->Add(new CMFCRibbonButton(ID_ALL_SETTING,_T("����"), 11));
//			pSetRibbonPanel->Add(new CMFCRibbonButton(ID_GRID_SETTING,_T("��������"), 10));
//			pSetRibbonPanel->Add(new CMFCRibbonButton(ID_CROSS_SETTING,_T("����#"), 11));
//			pSetRibbonPanel->Add(new CMFCRibbonButton(ID_BORDER_SETTING,_T("����UI�߿�"), 12));
//			pSetRibbonPanel->Add(new CMFCRibbonButton(ID_BK_SETTING,_T("���ñ���ɫ"), 13));
			pSetRibbonPanel->Add(new CMFCRibbonButton(ID_CONSOLE_CLEAR,_T("��տ���̨"), 14));
		}
		CMFCRibbonPanel *pRunModeRibbonPanel = pStartRibbonCategory->AddPanel(_T("����ģʽ"));
		if(pRunModeRibbonPanel != NULL)
		{
			pRunModeRibbonPanel->Add(new CMFCRibbonCheckBox(ID_EDIT_MODE,_T("�༭ģʽ")));
			pRunModeRibbonPanel->Add(new CMFCRibbonCheckBox(ID_VIEW_MODE,_T("Ԥ��ģʽ")));
		}
		CMFCRibbonPanel *pShowRibbonPanel = pStartRibbonCategory->AddPanel(_T("��ʾ"));
		if(pShowRibbonPanel != NULL)
		{
			pShowRibbonPanel->Add(new CMFCRibbonCheckBox(ID_GRID_SHOW,_T("��ʾ����")));
			pShowRibbonPanel->Add(new CMFCRibbonCheckBox(ID_CROSS_SHOW,_T("��ʾ#")));
			pShowRibbonPanel->Add(new CMFCRibbonCheckBox(ID_BORDER_SHOW,_T("��ʾUI�߿�")));
//			pShowRibbonPanel->Add(new CMFCRibbonCheckBox(ID_ALL_BORDER_SHOW,_T("��ʾ���б߿�")));
			pShowRibbonPanel->Add(new CMFCRibbonCheckBox(ID_CONSOLE_SHOW,_T("��ʾ����̨")));
		}
		CMFCRibbonPanel *pViewRibbonPanel = pStartRibbonCategory->AddPanel(_T("������"));
		if(pViewRibbonPanel != NULL)
		{
			pViewRibbonPanel->Add(new CMFCRibbonCheckBox(ID_VIEW_LEFT_PANE,_T("��ʾUI��")));
			pViewRibbonPanel->Add(new CMFCRibbonCheckBox(ID_VIEW_RIGHT_PANE,_T("��ʾUI���")));
			pViewRibbonPanel->Add(new CMFCRibbonCheckBox(ID_VIEW_UI_PROP_PANE,_T("��ʾUI����")));
			pViewRibbonPanel->Add(new CMFCRibbonCheckBox(ID_VIEW_HISTORY_PANE,_T("��ʾ��ʷ��¼")));
		}
	}
	CMFCRibbonCategory *pHelpRibbonCategory = m_wndRibbonBar.AddCategory(_T("����"),IDB_PNG_MENU16,IDB_PNG_MENU32);
	if(pHelpRibbonCategory != NULL)
	{
		CMFCRibbonPanel *pHelpRibbonPanel = pHelpRibbonCategory->AddPanel(_T("����"));
		if(pHelpRibbonPanel != NULL)
		{
			pHelpRibbonPanel->Add(new CMFCRibbonButton(ID_HELP, _T("����"), 15, 15));
			pHelpRibbonPanel->Add(new CMFCRibbonButton(ID_ABOUT, _T("����"), 16, 16));
		}
	}
	
	CFont dockablePaneFont;
	dockablePaneFont.CreateFont(12,0,0,0,FW_NORMAL,FALSE,FALSE,0,GB2312_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH | FF_SWISS,_T("����"));
	LOGFONT logFont;
	dockablePaneFont.GetLogFont(&logFont);
	afxGlobalData.SetMenuFont(&logFont,true);

	DWORD rightDockStyle = WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_BOTTOM | CBRS_FLOAT_MULTI;
	if(!m_rightDockablePane.Create(_T(" UI���"),this,CRect(0, 590, 250, 590+400),TRUE,ID_VIEW_RIGHT_PANE,rightDockStyle))
	{
		return -1;
	}

	DWORD uiPropDockStyle = WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_TOP | CBRS_FLOAT_MULTI;
	if(!m_uiPropDockablePane.Create(_T(" UI����"),this,CRect(250,150,250+1100,150+150),TRUE,ID_VIEW_UI_PROP_PANE,uiPropDockStyle))//CRect(200, 200, 200+260, 200+500)
	{
		return -1;
	}

//	CDockablePane *pTabbedBar = NULL; 
//	m_uiPropDockablePane.AttachToTabWnd(&m_leftDockablePane, DM_SHOW, FALSE, &pTabbedBar);
//	m_uiPropDockablePane.DockToWindow(&m_leftDockablePane,CBRS_ALIGN_BOTTOM);

	DWORD leftDockStyle = WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_LEFT | CBRS_FLOAT_MULTI;
	if(!m_leftDockablePane.Create(_T(" UI��"),this,CRect(0, 150, 250, 150+400),TRUE,ID_VIEW_LEFT_PANE,leftDockStyle))
	{
		return -1;
	}

	DWORD historyDockStyle = WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_CLIPCHILDREN | CBRS_RIGHT | CBRS_FLOAT_MULTI;
	if(!m_historyDockablePane.Create(_T("��ʷ��¼"),this,CRect(1000, 300, 1000+245, 300+600),TRUE,ID_VIEW_HISTORY_PANE,historyDockStyle))
	{
		return -1;
	}

	m_leftDockablePane.EnableDocking(CBRS_ALIGN_ANY);
	m_rightDockablePane.EnableDocking(CBRS_ALIGN_ANY);
	m_historyDockablePane.EnableDocking(CBRS_ALIGN_ANY);
	m_uiPropDockablePane.EnableDocking(CBRS_ALIGN_ANY);
	
	DockPane(&m_leftDockablePane);
	m_rightDockablePane.DockToWindow(&m_leftDockablePane,CBRS_ALIGN_BOTTOM);
	DockPane(&m_historyDockablePane);
	DockPane(&m_uiPropDockablePane);
	/*
	BOOL bShowLeftPane = ::GetPrivateProfileInt(_T("setting"),_T("ShowLeftPane"),TRUE,SETTING_FILE_PATH);
	BOOL bShowRightPane = ::GetPrivateProfileInt(_T("setting"),_T("ShowRightPane"),TRUE,SETTING_FILE_PATH);
	BOOL bShowUIPropPane = ::GetPrivateProfileInt(_T("setting"),_T("ShowUIPropPane"),TRUE,SETTING_FILE_PATH);
	BOOL bShowHistoryPane = ::GetPrivateProfileInt(_T("setting"),_T("ShowHistoryPane"),TRUE,SETTING_FILE_PATH);
	m_leftDockablePane.ShowPane(bShowLeftPane,FALSE,TRUE);
	m_rightDockablePane.ShowPane(bShowRightPane,FALSE,TRUE);
	m_uiPropDockablePane.ShowPane(bShowUIPropPane,FALSE,TRUE);
	m_historyDockablePane.ShowPane(bShowHistoryPane,FALSE,TRUE);*/
	
/*	UpdateRibbonCheckBox(ID_VIEW_LEFT_PANE,m_leftDockablePane.IsWindowVisible());
	UpdateRibbonCheckBox(ID_VIEW_RIGHT_PANE,m_rightDockablePane.IsWindowVisible());
	UpdateRibbonCheckBox(ID_VIEW_UI_PROP_PANE,m_uiPropDockablePane.IsWindowVisible());
	UpdateRibbonCheckBox(ID_VIEW_HISTORY_PANE,m_historyDockablePane.IsWindowVisible());*/

	m_MainButton.SetImage(IDB_MAIN);
	m_MainButton.SetText(_T(""));
	m_MainButton.SetToolTipText(_T(""));
	m_wndRibbonBar.SetApplicationButton(&m_MainButton, CSize (45, 45));

	m_PanelImages.SetImageSize(CSize(16, 16));
	m_PanelImages.Load(IDB_PNG_MENU16);

	CMFCRibbonButton* pVisualStyleButton = new CMFCRibbonButton(-1, _T("��ʽ"), -1, -1);
	pVisualStyleButton->SetMenu(IDR_THEME_MENU, FALSE , TRUE);
	m_wndRibbonBar.AddToTabs(pVisualStyleButton);

	CMFCRibbonButton* pHelpButton = new CMFCRibbonButton(ID_HELP,_T(""),m_PanelImages.ExtractIcon(15),-1);
	pHelpButton->SetToolTipText(_T("����"));
	m_wndRibbonBar.AddToTabs(pHelpButton);

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("δ�ܴ���״̬��\n");
		return -1;      // δ�ܴ���
	}

	CString strTitlePane1;
	CString strTitlePane2;
	bNameValid = strTitlePane1.LoadString(IDS_STATUS_PANE1);
	ASSERT(bNameValid);
	bNameValid = strTitlePane2.LoadString(IDS_STATUS_PANE2);
	ASSERT(bNameValid);
	m_wndStatusBar.AddElement(new CMFCRibbonStatusBarPane(ID_STATUSBAR_PANE1, strTitlePane1, TRUE), strTitlePane1);
	m_wndStatusBar.AddExtendedElement(new CMFCRibbonStatusBarPane(ID_STATUSBAR_PANE2, strTitlePane2, TRUE), strTitlePane2);
	UpdateStatusBarPane1(_T(""));
	UpdateStatusBarPane2(_T(""));

	// ���� Visual Studio 2005 ��ʽͣ��������Ϊ
	CDockingManager::SetDockingMode(DT_SMART);
	// ���� Visual Studio 2005 ��ʽͣ�������Զ�������Ϊ
	EnableAutoHidePanes(CBRS_ALIGN_ANY);

	UpdateXml();

	SetTimer(TIMER_UPDATE_DOCKPANE_STATE,1000,NULL);
	SetTimer(TIMER_INIT_GRID_TEXT,1000,NULL);

	return 0;
}

BOOL CMainFrame::LoadMainFrmState()
{
	CString strSectionPath = _T("WorkSpace");
	BOOL bLoadState = m_dockManager.LoadState(strSectionPath, IDR_MAINFRAME);
	m_dockManager.SetDockState();

	BOOL bShowLeftPane = ::GetPrivateProfileInt(_T("setting"),_T("ShowLeftPane"),TRUE,SETTING_FILE_PATH);
	BOOL bShowRightPane = ::GetPrivateProfileInt(_T("setting"),_T("ShowRightPane"),TRUE,SETTING_FILE_PATH);
	BOOL bShowUIPropPane = ::GetPrivateProfileInt(_T("setting"),_T("ShowUIPropPane"),TRUE,SETTING_FILE_PATH);
	BOOL bShowHistoryPane = ::GetPrivateProfileInt(_T("setting"),_T("ShowHistoryPane"),TRUE,SETTING_FILE_PATH);
	m_leftDockablePane.ShowPane(bShowLeftPane,FALSE,TRUE);
	m_rightDockablePane.ShowPane(bShowRightPane,FALSE,TRUE);
	m_uiPropDockablePane.ShowPane(bShowUIPropPane,FALSE,TRUE);
	m_historyDockablePane.ShowPane(bShowHistoryPane,FALSE,TRUE);

	return TRUE;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWndEx::PreCreateWindow(cs) )
		return FALSE;
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ
	cs.style &= ~(LONG)FWS_ADDTOTITLE;

	return TRUE;
}

void CMainFrame::UpdateXml()
{
	CString csSelDirectoryName = m_leftDockablePane.GetSelDirectoryName();
	CString csSelFileName = m_leftDockablePane.GetSelFileName();

	CString csAppTitle;
	csAppTitle.LoadString(AFX_IDS_APP_TITLE);
	CString csTitle = csAppTitle+_T(" ")+APP_VERSION;
	if(!csSelDirectoryName.IsEmpty())
		csTitle += _T(" - ")+EDITOR_DIRECTORY+_T("\\")+csSelDirectoryName;
	SetWindowText(csTitle);

	CString csPaneTitle = _T(" UI��");
	csPaneTitle += _T(" [")+csSelFileName+_T("]");
	if(m_leftDockablePane.m_hWnd != NULL)
	{
		m_leftDockablePane.SetWindowText(csPaneTitle);
	}
}

void CMainFrame::UpdateDockablePane()
{
	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_FRAME | RDW_ERASE);
}

void CMainFrame::GetCustomData(CString csCustomName,CArray <CCustomData,CCustomData> &customDataArray)
{
	m_rightDockablePane.GetCustomData(csCustomName,customDataArray);
}

const CDrawingBase* CMainFrame::GetSelDrawingBase()
{
	return m_leftDockablePane.GetSelDrawingBase();
}

// CMainFrame ���

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWndEx::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWndEx::Dump(dc);
}
#endif //_DEBUG


// CMainFrame ��Ϣ��������

void CMainFrame::OnApplicationLook(UINT id)
{
	CWaitCursor wait;

	theApp.m_nAppLook = id;

	switch (theApp.m_nAppLook)
	{
	case ID_VIEW_APPLOOK_WIN_2000:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManager));
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_OFF_XP:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOfficeXP));
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_WIN_XP:
		CMFCVisualManagerWindows::m_b3DTabsXPTheme = TRUE;
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows));
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_OFF_2003:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2003));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_VS_2005:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2005));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_VS_2008:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerVS2008));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(FALSE);
		break;

	case ID_VIEW_APPLOOK_WINDOWS_7:
		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerWindows7));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(TRUE);
		break;

	default:
		switch (theApp.m_nAppLook)
		{
		case ID_VIEW_APPLOOK_OFF_2007_BLUE:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_LunaBlue);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_BLACK:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_ObsidianBlack);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_SILVER:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Silver);
			break;

		case ID_VIEW_APPLOOK_OFF_2007_AQUA:
			CMFCVisualManagerOffice2007::SetStyle(CMFCVisualManagerOffice2007::Office2007_Aqua);
			break;
		}

		CMFCVisualManager::SetDefaultManager(RUNTIME_CLASS(CMFCVisualManagerOffice2007));
		CDockingManager::SetDockingMode(DT_SMART);
		m_wndRibbonBar.SetWindows7Look(FALSE);
	}

	RedrawWindow(NULL, NULL, RDW_ALLCHILDREN | RDW_INVALIDATE | RDW_UPDATENOW | RDW_FRAME | RDW_ERASE);

	theApp.WriteInt(_T("ApplicationLook"), theApp.m_nAppLook);
}

void CMainFrame::OnUpdateApplicationLook(CCmdUI* pCmdUI)
{
	pCmdUI->SetRadio(theApp.m_nAppLook == pCmdUI->m_nID);
}


void CMainFrame::OnClose()
{
	if(m_leftDockablePane.IsModifyData())
	{
		int iRet = MessageBox(_T("��ǰ�������޸ģ��Ƿ񱣴����ݺ��˳���"),NULL,MB_ICONWARNING | MB_YESNOCANCEL);
		if(iRet == IDYES)
		{
			m_leftDockablePane.SaveXml();
		}
		else if(iRet == IDNO)
		{
		}
		else
			return;
	}

	m_leftDockablePane.ReleaseAllData();

	CString strSectionPath = _T("WorkSpace");
    BOOL bSaveState = m_dockManager.SaveState(strSectionPath ,IDR_MAINFRAME);

//	AfxPostQuitMessage(0);

	CWinApp* pApp = AfxGetApp();
	if (pApp != NULL && pApp->m_pMainWnd == this)
	{
		CDataRecoveryHandler *pHandler = pApp->GetDataRecoveryHandler();
		if ((pHandler != NULL) && (pHandler->GetShutdownByRestartManager()))
		{
			// If the application is being shut down by the Restart Manager, do
			// a final autosave.  This will mark all the documents as not dirty,
			// so the SaveAllModified call below won't prompt for save.
			pHandler->AutosaveAllDocumentInfo();
			pHandler->SaveOpenDocumentList();
		}

		if ((pHandler != NULL) && (!pHandler->GetShutdownByRestartManager()))
		{
			// If the application is not being shut down by the Restart Manager,
			// delete any autosaved documents since everything is now fully saved.
			pHandler->DeleteAllAutosavedFiles();
		}

		// hide the application's windows before closing all the documents
		pApp->HideApplication();

		// close all documents first
		pApp->CloseAllDocuments(FALSE);

		// don't exit if there are outstanding component objects
		if (!AfxOleCanExitApp())
		{
			// take user out of control of the app
			AfxOleSetUserCtrl(FALSE);

			// don't destroy the main window and close down just yet
			//  (there are outstanding component (OLE) objects)
			return;
		}

		// there are cases where destroying the documents may destroy the
		//  main window of the application.

		if (afxContextIsDLL && pApp->m_pMainWnd == NULL)
		{
			CWinThread *pThread=AfxGetThread();
			_AFX_THREAD_STATE* pState = AfxGetThreadState();
			pThread->PostThreadMessage(WM_QUIT,pState->m_msgCur.wParam,pState->m_msgCur.lParam);
//			AfxPostQuitMessage(0);
			return;
		}
	}

	CFrameWndEx::OnClose();
}

void CMainFrame::OnTimer(UINT_PTR nIDEvent)
{
	switch(nIDEvent)
	{
	case TIMER_UPDATE_DOCKPANE_STATE:
		{
/*			if(m_leftDockablePane.m_hWnd != NULL)
			{
				UpdateRibbonCheckBox(ID_VIEW_LEFT_PANE,m_leftDockablePane.IsWindowVisible());

				UpdateRibbonDisabled(ID_EDIT_CUT,!m_leftDockablePane.IsCanCut());
				UpdateRibbonDisabled(ID_EDIT_COPY,!m_leftDockablePane.IsCanCopy());
				UpdateRibbonDisabled(ID_EDIT_PASTE,!m_leftDockablePane.IsCanPaste());
				UpdateRibbonDisabled(ID_EDIT_UNDO,!m_leftDockablePane.IsCanUndo());
				UpdateRibbonDisabled(ID_EDIT_REDO,!m_leftDockablePane.IsCanRedo());
			}
			if(m_rightDockablePane.m_hWnd != NULL)
			{
				UpdateRibbonCheckBox(ID_VIEW_RIGHT_PANE,m_rightDockablePane.IsWindowVisible());
			}
			if(m_uiPropDockablePane.m_hWnd != NULL)
			{
				UpdateRibbonCheckBox(ID_VIEW_UI_PROP_PANE,m_uiPropDockablePane.IsWindowVisible());
			}
			if(m_historyDockablePane.m_hWnd != NULL)
			{
				UpdateRibbonCheckBox(ID_VIEW_HISTORY_PANE,m_historyDockablePane.IsWindowVisible());
			}*/
		}
		break;
	case TIMER_INIT_GRID_TEXT:
		{
			KillTimer(TIMER_INIT_GRID_TEXT);

			ReCreateGridText(::GetGridHSkip(),::GetGridVSkip(),::GetGridRed(),::GetGridGreen(),::GetGridBlue(),::GetShowGrid() ? false : true);
		}
		break;
	case TIMER_CONSOLE_DISABLE_TOPMOST:
		{
			KillTimer(TIMER_CONSOLE_DISABLE_TOPMOST);
			HWND hConsole = GetConsoleWindow();
			::SetWindowPos(hConsole,HWND_NOTOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
/*
			HWND hConsole = GetConsoleWindow();
			if(::IsWindowVisible(hConsole) && ::IsIconic(hConsole))
			{
				::ShowWindow(hConsole,SW_HIDE);
			}
*/
		}
		break;
	default:
		break;
	}

	CFrameWndEx::OnTimer(nIDEvent);
}

void CMainFrame::ChangeEditorDrawingId()
{
	m_leftDockablePane.ChangeEditorDrawingId();
}

int CMainFrame::GetTreeSelectItemDrawingId() const
{
	return m_leftDockablePane.GetTreeSelectItemDrawingId();
}

void CMainFrame::ChangeEditorDrawingSeat(double dX,double dY,double dWidth,double dHeight,BOOL bLButtonUp)
{
	m_leftDockablePane.ChangeEditorDrawingSeat(dX,dY,dWidth,dHeight,bLButtonUp);
}

void CMainFrame::UpdateStatusBarPane1(LPCTSTR lpszText)
{
	if(m_wndStatusBar.m_hWnd == NULL)
		return;

	CMFCRibbonStatusBarPane *pMFCRibbonStatusBarPane = (CMFCRibbonStatusBarPane*)m_wndStatusBar.GetElement(0);
	if(pMFCRibbonStatusBarPane != NULL)
	{
		pMFCRibbonStatusBarPane->SetText(lpszText);
		CRect rect = pMFCRibbonStatusBarPane->GetRect();
		rect.right = rect.left+500;
		pMFCRibbonStatusBarPane->SetRect(rect);
	}
	m_wndStatusBar.RedrawWindow();
}

void CMainFrame::UpdateStatusBarPane2(LPCTSTR lpszText)
{
	if(m_wndStatusBar.m_hWnd == NULL)
		return;

	CMFCRibbonStatusBarPane *pMFCRibbonStatusBarPane = (CMFCRibbonStatusBarPane*)m_wndStatusBar.GetExElement(0);
	if(pMFCRibbonStatusBarPane != NULL)
	{
		pMFCRibbonStatusBarPane->SetText(lpszText);
		CRect rect = pMFCRibbonStatusBarPane->GetRect();
		rect.left = rect.right-300;
		pMFCRibbonStatusBarPane->SetRect(rect);
	}
	m_wndStatusBar.RedrawWindow();
}

void CMainFrame::UpdateHistory(int iCommandHistoryUndoPos,int iCommandHistoryUndoCount,int iCommandHistoryRedoCount,const CArray<int,int> &iTypeArr,const CStringArray &csHistoryNameArr)
{
	m_historyDockablePane.UpdateHistory(iCommandHistoryUndoPos,iCommandHistoryUndoCount,iCommandHistoryRedoCount,iTypeArr,csHistoryNameArr);
}

void CMainFrame::SetHistory(int iCommandHistoryPos)
{
	m_leftDockablePane.SetHistory(iCommandHistoryPos);
}

void CMainFrame::UpdateRibbonCheckBox(UINT nID,BOOL bCheck)
{
	CArray <CMFCRibbonBaseElement*,CMFCRibbonBaseElement*> arElements;
	m_wndRibbonBar.GetElementsByID(nID,arElements);
	int i;
	for(i=0; i<arElements.GetSize(); i++)
	{
		CMFCRibbonCheckBoxEx *pMFCRibbonCheckBoxEx = static_cast <CMFCRibbonCheckBoxEx *>(arElements.GetAt(i));
		if(pMFCRibbonCheckBoxEx != NULL)
		{
			pMFCRibbonCheckBoxEx->SetCheck(bCheck);
		}
	}
	m_wndRibbonBar.RedrawWindow();
}

void CMainFrame::UpdateRibbonDisabled(UINT nID,BOOL bDisabled)
{
	CArray <CMFCRibbonBaseElement*,CMFCRibbonBaseElement*> arElements;
	m_wndRibbonBar.GetElementsByID(nID,arElements);
	int i;
	for(i=0; i<arElements.GetSize(); i++)
	{
		CMFCRibbonCheckBoxEx *pMFCRibbonCheckBoxEx = static_cast <CMFCRibbonCheckBoxEx *>(arElements.GetAt(i));
		if(pMFCRibbonCheckBoxEx != NULL)
		{
			pMFCRibbonCheckBoxEx->SetDisabled(bDisabled);
		}
	}
	m_wndRibbonBar.RedrawWindow();
}

BOOL CMainFrame::OnCloseMiniFrame(CPaneFrameWnd* pWnd)
{
	CWnd *ptWnd = pWnd->GetWindow(GW_CHILD);

	return TRUE;
}

BOOL CMainFrame::OnCloseDockingPane(CDockablePane* pWnd)
{
	return TRUE;
}

void CMainFrame::OnXmlmagFolder()
{
	if(m_leftDockablePane.IsModifyData())
	{
		int iRet = MessageBox(_T("��ǰ�������޸ģ��Ƿ񱣴浱ǰ���ݣ�"),NULL,MB_ICONWARNING | MB_YESNOCANCEL);
		if(iRet == IDYES)
		{
			m_leftDockablePane.SaveXml();
		}
		else if(iRet == IDNO)
		{
		}
		else
			return;
	}

	CString csSelDirectoryName;
	CString csSelFileName;
	csSelDirectoryName = ((CStdPluginApp*)AfxGetApp())->m_Config.m_group.c_str();
	csSelFileName = ((CStdPluginApp*)AfxGetApp())->m_Config.m_xml.c_str();

	CFileManageDialog fileManageDialog;
	fileManageDialog.InitData(csSelDirectoryName,csSelFileName);
	if(fileManageDialog.DoModal() != IDOK)
		return;

	csSelDirectoryName = fileManageDialog.GetSelDirectoryName();
	csSelFileName = fileManageDialog.GetSelFileName();

	((CStdPluginApp*)AfxGetApp())->m_Config.setGroup(CCharArr(csSelDirectoryName));
	((CStdPluginApp*)AfxGetApp())->m_Config.setXml(CCharArr(csSelFileName));

	m_leftDockablePane.LoadXml(csSelDirectoryName,csSelFileName);
}

void CMainFrame::OnGenLuaFinal()
{
	//����ǰԤ�ȱ�������޸ĵ�UI����
	m_uiPropDockablePane.SaveChangeUIProp();

	int iRet = m_leftDockablePane.GenLua();
	CString strFile = m_leftDockablePane.GetLuaPath();
	if ( iRet < 0 )
	{
		CPromptDialog promptDialog;
		promptDialog.SetStaticText1(_T("����ʧ��"));
		promptDialog.SetEditText(strFile);
		promptDialog.DoModal();
	}
	else
	{
		CFileStatus FS;
		CFile::GetStatus(strFile,FS);

		CString strMsg;
		strMsg.Format(_T("�ļ���СΪ%d�ֽ�"),FS.m_size);

		CPromptDialog promptDialog;
		promptDialog.SetStaticText1(_T("���ɳɹ�"));
		promptDialog.SetStaticText2(strMsg);
		promptDialog.SetEditText(strFile);
		promptDialog.DoModal();
	}
}

void CMainFrame::OnSaveXml()
{
	//����ǰԤ�ȱ�������޸ĵ�UI����
	m_uiPropDockablePane.SaveChangeUIProp();

	int iRet = m_leftDockablePane.SaveXml();
	CString strFile = m_leftDockablePane.GetXmlPath();
	if ( iRet < 0 )
	{
		CPromptDialog promptDialog;
		promptDialog.SetStaticText1(_T("����ʧ��"));
		promptDialog.SetEditText(strFile);
		promptDialog.DoModal();
	}
	else
	{
		CPromptDialog promptDialog;
		promptDialog.SetStaticText1(_T("����ɹ�"));
		promptDialog.SetEditText(strFile);
		promptDialog.DoModal();
	}
}

void CMainFrame::OnGenConfigLua()
{
	COutputConfigDialog outputConfigDialog;

	CString csScriptsDirectory = SCRIPTS_DIRECTORY;
	CString csXmlPath = m_leftDockablePane.GetXmlPath();
	CString csOutputPath = csScriptsDirectory+_T("\\")+::GetFileName(csXmlPath,FALSE)+_T("_config.lua");
	outputConfigDialog.InitData(csOutputPath);
	if(outputConfigDialog.DoModal() != IDOK)
		return;

	CString strFile = outputConfigDialog.GetOutputPath();
	BOOL bLeafNode = outputConfigDialog.GetLeafNode();
	CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> emDrawingTypeArr;
	outputConfigDialog.GetDrawingTypeArr(emDrawingTypeArr);

	int iRet = m_leftDockablePane.GenConfigLua(strFile,emDrawingTypeArr,bLeafNode);
	if ( iRet < 0 )
	{
		CPromptDialog promptDialog;
		promptDialog.SetStaticText1(_T("����ʧ��"));
		promptDialog.SetEditText(strFile);
		promptDialog.DoModal();
	}
	else
	{
		CFileStatus FS;
		CFile::GetStatus(strFile,FS);

		CString strMsg;
		strMsg.Format(_T("�ļ���СΪ%d�ֽ�"),FS.m_size);

		CPromptDialog promptDialog;
		promptDialog.SetStaticText1(_T("���ɳɹ�"));
		promptDialog.SetStaticText2(strMsg);
		promptDialog.SetEditText(strFile);
		promptDialog.DoModal();
	}
}

void CMainFrame::OnEditCut()
{
	m_leftDockablePane.Cut();
}

void CMainFrame::OnEditCopy()
{
	m_leftDockablePane.Copy();
}

void CMainFrame::OnEditPaste()
{
	m_leftDockablePane.Paste();
}

void CMainFrame::OnEditDelete()
{
	m_leftDockablePane.Delete();
}

void CMainFrame::OnEditUndo()
{
	m_leftDockablePane.Undo();
}

void CMainFrame::OnEditRedo()
{
	m_leftDockablePane.Redo();
}

void CMainFrame::OnXmlmagXml()
{
}

void CMainFrame::OnExit()
{
}

void CMainFrame::OnEditMode()
{
	::SetEditMode(TRUE);
//	UpdateRibbonCheckBox(ID_EDIT_MODE,::GetEditMode());
//	UpdateRibbonCheckBox(ID_VIEW_MODE,!::GetEditMode());

	::WritePrivateProfileString(_T("setting"),_T("EditMode"),::IntToCString(::GetEditMode()),SETTING_FILE_PATH);;
}

void CMainFrame::OnViewMode()
{
	::SetEditMode(FALSE);
	if( ::GetShowWell() )
	{
		DeleteWellText();
	}
//	UpdateRibbonCheckBox(ID_EDIT_MODE,::GetEditMode());
//	UpdateRibbonCheckBox(ID_VIEW_MODE,!::GetEditMode());

	::WritePrivateProfileString(_T("setting"),_T("EditMode"),::IntToCString(::GetEditMode()),SETTING_FILE_PATH);;
}

void CMainFrame::OnGridShow()
{
	::SetShowGrid(!::GetShowGrid());
//	UpdateRibbonCheckBox(ID_GRID_SHOW,::GetShowGrid());

	ReCreateGridText(::GetGridHSkip(),::GetGridVSkip(),::GetGridRed(),::GetGridGreen(),::GetGridBlue(),::GetShowGrid() ? false : true);

	::WritePrivateProfileString(_T("setting"),_T("ShowGrid"),::IntToCString(::GetShowGrid()),SETTING_FILE_PATH);;
}

void CMainFrame::OnGridSetting()
{
	CDialogGridSetting dlg;
	if ( IDOK == dlg.DoModal())
	{
		if ( ::GetShowGrid() )
		{
			ReCreateGridText(::GetGridHSkip(),::GetGridVSkip(),::GetGridRed(),::GetGridGreen(),::GetGridBlue(),false);
		}
	}
}

void CMainFrame::OnCrossShow()
{
	if ( ::GetShowWell() )
	{
		DeleteWellText();
	}
	else
	{
		ReCreateWellText();
	}
	::SetShowWell(!::GetShowWell());
//	UpdateRibbonCheckBox(ID_CROSS_SHOW,::GetShowWell());

	::WritePrivateProfileString(_T("setting"),_T("ShowWell"),::IntToCString(::GetShowWell()),SETTING_FILE_PATH);;
}

void CMainFrame::OnCrossSetting()
{
	CDialogWellSetting dlg;
	dlg.DoModal();
}

void CMainFrame::OnBorderShow()
{
	::SetShowBorder(!::GetShowBorder());
//	UpdateRibbonCheckBox(ID_BORDER_SHOW,::GetShowBorder());

	::WritePrivateProfileString(_T("setting"),_T("ShowBorder"),::IntToCString(::GetShowBorder()),SETTING_FILE_PATH);;
}

void CMainFrame::OnAllBorderShow()
{
	GetAnimInterface()->sys_set_int("show_image_rect",1);
}

void CMainFrame::OnBkSetting()
{
	CDialogBkSetting dlg;
	dlg.DoModal();

	((CStdPluginView*)((CMainFrame*)AfxGetMainWnd())->GetActiveView())->Invalidate(FALSE);
}

void CMainFrame::OnAllSetting()
{
	CDialogAllSetting dlg;
	dlg.DoModal();

	((CStdPluginView*)((CMainFrame*)AfxGetMainWnd())->GetActiveView())->Invalidate(FALSE);
}

void CMainFrame::ShowConsole()
{
	HWND hConsole = GetConsoleWindow();
	RECT rc;
	::GetWindowRect(hConsole,&rc);
	::MoveWindow(hConsole,rc.left,48,rc.right-rc.left,rc.bottom-rc.top-48,TRUE);
	if(::IsIconic(hConsole))
	{
		::ShowWindow(hConsole,SW_RESTORE);
	}
	::ShowWindow(hConsole,SW_SHOW);

	::SetForegroundWindow(hConsole);
}

void CMainFrame::SetConsoleTopMost()
{
	HWND hConsole = GetConsoleWindow();
	::SetWindowPos(hConsole,HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE);
	SetTimer(TIMER_CONSOLE_DISABLE_TOPMOST,500,NULL);
}

void CMainFrame::OnConsoleShow()
{
	HWND hConsole = GetConsoleWindow();
	if(::IsWindowVisible(hConsole))
	{
		::ShowWindow(hConsole,SW_HIDE);

//		UpdateRibbonCheckBox(ID_CONSOLE_SHOW,FALSE);
	}
	else
	{
		ShowConsole();

//		UpdateRibbonCheckBox(ID_CONSOLE_SHOW,TRUE);
	}
}

void CMainFrame::OnBorderSetting()
{
	CDialogBorderSetting dlg;
	dlg.DoModal();
}

void CMainFrame::OnConsoleClear()
{

	int BackC = 0;
	int ForgC = FOREGROUND_RED|FOREGROUND_GREEN|FOREGROUND_BLUE;

	WORD wColor = ((BackC & 0x0F) << 4) + (ForgC & 0x0F);
	//Get the handle to the current output buffer...
	HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	//This is used to reset the carat/cursor to the top left.
	COORD coord = {0, 0};
	//A return value... indicating how many chars were written
	//   not used but we need to capture this since it will be
	//   written anyway (passing NULL causes an access violation).
	DWORD count;

	//This is a structure containing all of the console info
	// it is used here to find the size of the console.
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	//Here we will set the current color
	SetConsoleTextAttribute(hStdOut, wColor);
	if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
	{
		//This fills the buffer with a given character (in this case 32=space).
		FillConsoleOutputCharacter(hStdOut, (TCHAR) 32, csbi.dwSize.X * csbi.dwSize.Y, coord, &count);

		FillConsoleOutputAttribute(hStdOut, csbi.wAttributes, csbi.dwSize.X * csbi.dwSize.Y, coord, &count );
		//This will set our cursor position for the next print statement.
		SetConsoleCursorPosition(hStdOut, coord);
	}
}

void CMainFrame::OnViewLeftPane()
{
	m_leftDockablePane.ShowPane(!m_leftDockablePane.IsWindowVisible(),FALSE,TRUE);

//	UpdateRibbonCheckBox(ID_VIEW_LEFT_PANE,m_leftDockablePane.IsWindowVisible());

	::WritePrivateProfileString(_T("setting"),_T("ShowLeftPane"),::IntToCString(m_leftDockablePane.IsWindowVisible()),SETTING_FILE_PATH);
}

void CMainFrame::OnViewRightPane()
{
	m_rightDockablePane.ShowPane(!m_rightDockablePane.IsWindowVisible(),FALSE,TRUE);

//	UpdateRibbonCheckBox(ID_VIEW_RIGHT_PANE,m_rightDockablePane.IsWindowVisible());

	::WritePrivateProfileString(_T("setting"),_T("ShowRightPane"),::IntToCString(m_rightDockablePane.IsWindowVisible()),SETTING_FILE_PATH);
}

void CMainFrame::OnViewUiPropPane()
{
	m_uiPropDockablePane.ShowPane(!m_uiPropDockablePane.IsWindowVisible(),FALSE,TRUE);

//	UpdateRibbonCheckBox(ID_VIEW_UI_PROP_PANE,m_uiPropDockablePane.IsWindowVisible());

	::WritePrivateProfileString(_T("setting"),_T("ShowUIPropPane"),::IntToCString(m_uiPropDockablePane.IsWindowVisible()),SETTING_FILE_PATH);
}

void CMainFrame::OnViewHistoryPane()
{
	m_historyDockablePane.ShowPane(!m_historyDockablePane.IsWindowVisible(),FALSE,TRUE);

//	UpdateRibbonCheckBox(ID_VIEW_HISTORY_PANE,m_historyDockablePane.IsWindowVisible());

	::WritePrivateProfileString(_T("setting"),_T("ShowHistoryPane"),::IntToCString(m_historyDockablePane.IsWindowVisible()),SETTING_FILE_PATH);
}

void CMainFrame::OnHelp()
{
	CString csHelpPath = ::GetUpFileDirectory(MODULE_FILE_DIRECTORY)+_T("\\docs\\��̳ܽ�.docx");
	ShellExecute(NULL,_T("open"),csHelpPath,NULL,NULL,SW_SHOWNORMAL);
}

void CMainFrame::OnAbout()
{
	((CStdPluginApp*)AfxGetApp())->OnAppAbout();
}

void CMainFrame::OnUpdateXmlmagFolder(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateGenLuaFinal(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateSaveXml(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateGenConfigLua(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateEditCut(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_leftDockablePane.IsCanCut());
}

void CMainFrame::OnUpdateEditCopy(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_leftDockablePane.IsCanCopy());
}

void CMainFrame::OnUpdateEditPaste(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_leftDockablePane.IsCanPaste());
}

void CMainFrame::OnUpdateEditDelete(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_leftDockablePane.IsCanDelete());
}

void CMainFrame::OnUpdateEditUndo(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_leftDockablePane.IsCanUndo());
}

void CMainFrame::OnUpdateEditRedo(CCmdUI* pCmdUI)
{
	pCmdUI->Enable(m_leftDockablePane.IsCanRedo());
}

void CMainFrame::OnUpdateXmlmagXml(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateExit(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateEditMode(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(::GetEditMode());
}

void CMainFrame::OnUpdateViewMode(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(!::GetEditMode());
}

void CMainFrame::OnUpdateGridShow(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(::GetShowGrid());
}

void CMainFrame::OnUpdateGridSetting(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateCrossShow(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(::GetShowWell());
}

void CMainFrame::OnUpdateCrossSetting(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateBorderShow(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(::GetShowBorder());
}

void CMainFrame::OnUpdateBorderSetting(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateBkSetting(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateAllSetting(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateConsoleShow(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
	
	HWND hConsole = GetConsoleWindow();
	pCmdUI->SetCheck(::IsWindowVisible(hConsole));
}

void CMainFrame::OnUpdateConsoleClear(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateViewLeftPane(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(m_leftDockablePane.m_hWnd != NULL && m_leftDockablePane.IsWindowVisible());
}

void CMainFrame::OnUpdateViewRightPane(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(m_rightDockablePane.m_hWnd != NULL && m_rightDockablePane.IsWindowVisible());
}

void CMainFrame::OnUpdateViewUiPropPane(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(m_uiPropDockablePane.m_hWnd != NULL && m_uiPropDockablePane.IsWindowVisible());
}

void CMainFrame::OnUpdateViewHistoryPane(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
	pCmdUI->SetCheck(m_historyDockablePane.m_hWnd != NULL && m_historyDockablePane.IsWindowVisible());
}

void CMainFrame::OnUpdateHelp(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

void CMainFrame::OnUpdateAbout(CCmdUI* pCmdUI)
{
	pCmdUI->Enable();
}

LRESULT CMainFrame::MessageAddNode(WPARAM wParam,LPARAM lParam)
{
	EM_DRAWING_TYPE type = (EM_DRAWING_TYPE)wParam;
	CString *pItemName = (CString*)lParam;
	if(pItemName == NULL)
		return -1;

	CPoint point;
	::GetCursorPos(&point);

	CPoint uiPoint = point;
	HWND hUIWnd = ((CStdPluginView*)((CMainFrame*)AfxGetMainWnd())->GetActiveView())->GetUIWnd();
	::ScreenToClient(hUIWnd,&uiPoint);

	BOOL bControl = (GetAsyncKeyState(VK_CONTROL) < 0);
	m_leftDockablePane.AddNewNode(type,*pItemName,bControl,uiPoint.x,uiPoint.y);

	return 0;
}

LRESULT CMainFrame::MessageChangeDrawingBase(WPARAM wParam,LPARAM lParam)
{
	m_uiPropDockablePane.ChangeDrawingBase((CDrawingBase*)wParam);
	m_rightDockablePane.ChangeDrawingBase((CDrawingBase*)wParam);
	return 0;
}

LRESULT CMainFrame::MessageTreeSelchanging(WPARAM wParam,LPARAM lParam)
{
	m_uiPropDockablePane.SaveChangeUIProp();

	return 0;
}

LRESULT CMainFrame::MessageGetTreeDrawingTimes(WPARAM wParam,LPARAM lParam)
{
	map<long,bool> *pTimeMap = (map<long,bool> *)wParam;

	if(pTimeMap != NULL)
	{
		m_leftDockablePane.GetTreeTimeMap(*pTimeMap);
	}

	return 0;
}

LRESULT CMainFrame::MessageChangeUIProp(WPARAM wParam,LPARAM lParam)
{
	m_leftDockablePane.ChangeUIProp(m_uiPropDockablePane.GetDrawingBase(),wParam,lParam,TRUE);
	return 0;
}

LRESULT CMainFrame::MessageUpdateUIProp(WPARAM wParam,LPARAM lParam)
{
	m_leftDockablePane.ChangeUIProp(m_uiPropDockablePane.GetDrawingBase(),wParam,lParam,FALSE);
	return 0;
}

void KeyMoveNode(int iDx,int iDy)
{
	AnimInterface *pAnimInterface = ::GetAnimInterface();
	if(pAnimInterface == NULL)
		return;

	int iEditorDrawingId = ::GetEditorDrawingId();
	if(iEditorDrawingId == -1)
		return;

	double dX,dY;
	pAnimInterface->drawing_get_position(iEditorDrawingId,dX,dY);
	pAnimInterface->drawing_set_position(iEditorDrawingId,dX+iDx,dY+iDy);

	double dWidth,dHeight;
	if(!(pAnimInterface->drawing_get_rect(iEditorDrawingId,dX,dY,dWidth,dHeight) < 0) )
	{
		((CMainFrame*)AfxGetMainWnd())->ChangeEditorDrawingSeat(dX,dY,dWidth,dHeight,TRUE);
	}
}

BOOL CMainFrame::PreTranslateMessage(MSG* pMsg)
{
	switch(pMsg->message)
	{
	case WM_KEYDOWN:
		{
			BOOL bControl = (GetAsyncKeyState(VK_CONTROL) < 0);
			switch(pMsg->wParam)
			{
			case VK_LEFT:
				KeyMoveNode(-1,0);
				break;
			case VK_RIGHT:
				KeyMoveNode(1,0);
				break;
			case VK_UP:
				KeyMoveNode(0,-1);
				break;
			case VK_DOWN:
				KeyMoveNode(0,1);
				break;
/*			case 'x':
			case 'X':
				if(bCtrl)
				{
					m_leftDockablePane.Cut();
				}
				break;
			case 'c':
			case 'C':
				if(bCtrl)
				{
					m_leftDockablePane.Copy();
				}
				break;
			case 'v':
			case 'V':
				if(bCtrl)
				{
					m_leftDockablePane.Paste();
				}
				break;
			case 'z':
			case 'Z':
				if(bCtrl)
				{
					m_leftDockablePane.Undo();
				}
				break;*/
			case 'y':
			case 'Y':
				if(bControl)
				{
					m_leftDockablePane.Redo();
				}
				break;
			case VK_DELETE:
				{
					m_leftDockablePane.Delete();
				}
				break;
			default:
				break;
			}
		}
		break;
	default:
		break;
	}

	return CFrameWndEx::PreTranslateMessage(pMsg);
}

