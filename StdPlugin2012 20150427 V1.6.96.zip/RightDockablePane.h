#pragma once

#include "RightDialog.h"

// CRightDockablePane

class CRightDockablePane : public CDockablePane
{
public:
	void ChangeDrawingBase(const CDrawingBase *pDrawingBase);
	void GetCustomData(CString csCustomName,CArray <CCustomData,CCustomData> &customDataArray) const;
private:
	CRightDialog m_rightDialog;

	DECLARE_DYNAMIC(CRightDockablePane)

public:
	CRightDockablePane();
	virtual ~CRightDockablePane();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


