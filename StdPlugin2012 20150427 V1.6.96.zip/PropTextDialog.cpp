// PropTextDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "PropTextDialog.h"
#include "afxdialogex.h"

#include "MainFrm.h"

// CPropTextDialog �Ի���

IMPLEMENT_DYNAMIC(CPropTextDialog, CDialogEx)

CPropTextDialog::CPropTextDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CPropTextDialog::IDD, pParent)
{
	m_pDrawingBase = NULL;

	m_bEditData = TRUE;

	m_bChangeUIProp = FALSE;
	m_emUIPropType = (EM_UI_PROP_TYPE)-1;
}

CPropTextDialog::~CPropTextDialog()
{
}

void CPropTextDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_PROP_TEXT, m_propTextStatic);
	DDX_Control(pDX, IDC_EDIT_NODE_FONT_SIZE, m_nodeFontSizeEdit);
	DDX_Control(pDX, IDC_EDIT_TEXT_COLOR, m_textColorEdit);
	DDX_Control(pDX, IDC_BUTTON_GET_COLOR, m_getColorButton);
	DDX_Control(pDX, IDC_COMBO_FONT_NAME, m_fontComboBox);
}


BEGIN_MESSAGE_MAP(CPropTextDialog, CDialogEx)
	ON_BN_CLICKED(IDOK, &CPropTextDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CPropTextDialog::OnBnClickedCancel)
	ON_WM_TIMER()
	ON_EN_CHANGE(IDC_EDIT_NODE_TEXT, &CPropTextDialog::OnEnChangeEditNodeText)
	ON_EN_CHANGE(IDC_EDIT_NODE_FONT_SIZE, &CPropTextDialog::OnEnChangeEditNodeFontSize)
	ON_CBN_SELCHANGE(IDC_COMBO_NODE_ALIGN, &CPropTextDialog::OnCbnSelchangeComboNodeAlign)
//	ON_BN_CLICKED(IDC_BUTTON_GET_COLOR, &CPropTextDialog::OnBnClickedButtonGetColor)
	ON_BN_COLORCHANGE(IDC_BUTTON_GET_COLOR, &CPropTextDialog::OnBnClickedButtonGetColor)
	ON_BN_CLICKED(IDC_MFCCOLORBUTTON_TEXT, &CPropTextDialog::OnBnClickedMfccolorbuttonText)
	ON_EN_CHANGE(IDC_EDIT_TEXT_COLOR, &CPropTextDialog::OnEnChangeEditTextColor)
	ON_WM_CONTEXTMENU()
	ON_MESSAGE(WM_EDIT_KILLFOCUS,MessageEditKillFocus)
	ON_EN_KILLFOCUS(IDC_EDIT_NODE_TEXT, &CPropTextDialog::OnEnKillfocusEditNodeText)
	ON_CBN_SELCHANGE(IDC_COMBO_FONT_NAME, &CPropTextDialog::OnCbnSelchangeComboFontName)
END_MESSAGE_MAP()


// CPropTextDialog ��Ϣ��������

void CPropTextDialog::InitData(const CDrawingBase *pDrawingBase)
{
	m_pDrawingBase = pDrawingBase;

	ChangeDrawingBase(m_pDrawingBase);
}

void CPropTextDialog::SaveChangeUIProp()
{
	EndChangeUIProp();
}

void CPropTextDialog::ChangeDrawingBase(const CDrawingBase *pDrawingBase)
{
	m_bEditData = FALSE;

	EM_DRAWING_TYPE type = (EM_DRAWING_TYPE)-1;
	if(pDrawingBase != NULL)
		type = pDrawingBase->GetDrawingType();

	CStringW csStr;
	CStringW csFontName;
	int iFontSize = 0;
	int iTextAlign = 0;
	COLORREF color = 0;
	if(type == DRAWING_TYPE_Text || type == DRAWING_TYPE_EditText)
	{
		CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(const_cast<CDrawingBase*>(pDrawingBase));
		if(pDrawingText != NULL)
		{
			pDrawingText->GetStr(csStr);
			pDrawingText->GetFontName(csFontName);
			pDrawingText->GetFontSize(iFontSize);
			pDrawingText->GetTextAlign(iTextAlign);
			pDrawingText->GetColor(color);
		}
	}
	else if(type == DRAWING_TYPE_TextView || type == DRAWING_TYPE_EditTextView)
	{
		CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(const_cast<CDrawingBase*>(pDrawingBase));
		if(pDrawingTextView != NULL)
		{
			pDrawingTextView->GetStr(csStr);
			pDrawingTextView->GetFontName(csFontName);
			pDrawingTextView->GetFontSize(iFontSize);
			pDrawingTextView->GetTextAlign(iTextAlign);
			pDrawingTextView->GetColor(color);
		}
	}

	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_NODE_TEXT),csStr);
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_NODE_FONT_SIZE),::IntToCString(iFontSize));
	((CComboBox*)GetDlgItem(IDC_COMBO_NODE_ALIGN))->SetCurSel(iTextAlign);
	CString csColor = ::COLORREFToCString(color);
	m_getColorButton.SetColor(color);
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_TEXT_COLOR),csColor);
	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_TEXT))->SetColor(color);
	m_fontComboBox.SetCurSel(-1);
	m_fontComboBox.SelectString(-1,CCharArr(csFontName));

	m_bEditData = TRUE;

	m_bChangeUIProp = FALSE;
	m_emUIPropType = (EM_UI_PROP_TYPE)-1;
}

int CALLBACK NEnumFontNameProc(LOGFONT *plf, TEXTMETRIC* /*ptm*/, INT /*nFontType*/, LPARAM lParam)
{
	CComboBox *pComboBox = (CComboBox*)lParam;
	pComboBox->AddString(plf->lfFaceName);

	return TRUE;
}

BOOL CPropTextDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	m_propTextStatic.SetTextColor(RGB(0,0,255));
	m_propTextStatic.SetBorderColor(RGB(0,0,255));//107,143,246));

	LPCTSTR values[] = {
		_T("Center"),
		_T("Top"),
		_T("TopRight"),
		_T("Right"),
		_T("BottomRight"),
		_T("Bottom"),
		_T("BottomLeft"),
		_T("Left"),
		_T("TopLeft")
	};

	for(int i=0;i<sizeof(values)/sizeof(LPCTSTR);++i)
	{
		((CComboBox*)GetDlgItem(IDC_COMBO_NODE_ALIGN))->InsertString(-1,values[i]);
	}
	((CComboBox*)GetDlgItem(IDC_COMBO_NODE_ALIGN))->SetCurSel(0);

//	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_TEXT))->EnableAutomaticButton(_T("�Զ�"), RGB(0, 0, 0));
//	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_TEXT))->EnableOtherButton(_T("����"));
//	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_TEXT))->SetColumnsNumber(10);

	m_fontComboBox.AddString(_T(""));
	::EnumFontFamilies(GetDC()->m_hDC, (LPTSTR) NULL, (FONTENUMPROC)NEnumFontNameProc, (LPARAM)&(m_fontComboBox));

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPropTextDialog::OnBnClickedOk()
{
}


void CPropTextDialog::OnBnClickedCancel()
{
}


void CPropTextDialog::OnEnChangeEditNodeText()
{
	CStringW csValue;
//	GetDlgItem(IDC_EDIT_NODE_TEXT)->GetWindowText(csValue);
	csValue = ::GetWindowTextW(GetDlgItem(IDC_EDIT_NODE_TEXT));
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_csStr,(LPARAM)&csValue);
		ChangeUIProp(UI_PROP_csStr);
	}
}


void CPropTextDialog::OnEnChangeEditNodeFontSize()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_FONT_SIZE)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_iFontSize,::CStringToInt(csValue));
		ChangeUIProp(UI_PROP_iFontSize);
	}
}


void CPropTextDialog::OnCbnSelchangeComboNodeAlign()
{
	int iTextAlign = ((CComboBox*)GetDlgItem(IDC_COMBO_NODE_ALIGN))->GetCurSel();
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_iTextAlign,iTextAlign);
	}
}


void CPropTextDialog::OnBnClickedButtonGetColor()
{
	COLORREF newColor = m_getColorButton.GetColor();
	BOOL bChange = TRUE;
	if(m_pDrawingBase != NULL)
	{
		COLORREF color;
		m_pDrawingBase->GetColor(color);
		if(color == newColor)
			bChange = FALSE;
	}
	if(!m_bEditData)
		bChange = FALSE;
	if(bChange)
	{
//		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_color,newColor);
		GetDlgItem(IDC_EDIT_TEXT_COLOR)->SetWindowText(::COLORREFToCString(newColor));
	}
/*	if(m_pDrawingBase != NULL)
	{
		COLORREF color;
		m_pDrawingBase->GetColor(color);
		CColorDialog cdlg(color, CC_FULLOPEN | CC_RGBINIT); // ����Ĭ����ɫ
		EnableKeyHook(false);
		if(cdlg.DoModal() == IDOK)
		{
			color = cdlg.GetColor();
			CString csColor = ::COLORREFToCString(color);
			GetDlgItem(IDC_BUTTON_GET_COLOR)->SetWindowText(csColor);
			GetDlgItem(IDC_EDIT_NODE_TEXT)->RedrawWindow();
			::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_color,color);
		}
		EnableKeyHook(true);
	}*/
}


void CPropTextDialog::OnBnClickedMfccolorbuttonText()
{
	COLORREF newColor = ((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_TEXT))->GetColor();
	BOOL bChange = TRUE;
	if(m_pDrawingBase != NULL)
	{
		COLORREF color;
		m_pDrawingBase->GetColor(color);
		if(color == newColor)
			bChange = FALSE;
	}
	if(bChange)
	{
//		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_color,newColor);
		GetDlgItem(IDC_EDIT_TEXT_COLOR)->SetWindowText(::COLORREFToCString(newColor));
	}
}

void CPropTextDialog::OnEnChangeEditTextColor()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_TEXT_COLOR)->GetWindowText(csValue);
	if(m_bEditData)
	{
		COLORREF newColor;
		if(::CStringToCOLORREF(csValue,newColor))
		{
			::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_color,newColor);
			m_getColorButton.SetColor(newColor);
			((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_TEXT))->SetColor(newColor);
		}
	}
}


void CPropTextDialog::OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/)
{
}

LRESULT CPropTextDialog::MessageEditKillFocus(WPARAM wParam,LPARAM lParam)
{
	CEdit *pEdit = (CEdit*)wParam;
	CWnd *pNewWnd = (CWnd*)lParam;

	EndChangeUIProp();

	return 0;
}

void CPropTextDialog::ChangeUIProp(EM_UI_PROP_TYPE emUIPropType)
{
	m_bChangeUIProp = TRUE;
	m_emUIPropType = emUIPropType;

	SetTimer(TIMER_CHANGE_UI_PROP,CHANGE_UI_PROP_DELAY,NULL);
}

void CPropTextDialog::EndChangeUIProp()
{
	KillTimer(TIMER_CHANGE_UI_PROP);
	if(!m_bChangeUIProp)
		return;

	switch(m_emUIPropType)
	{
	case UI_PROP_csStr:
		{
			CStringW csValue;
//			GetDlgItem(IDC_EDIT_NODE_TEXT)->GetWindowText(csValue);
			csValue = ::GetWindowTextW(GetDlgItem(IDC_EDIT_NODE_TEXT));
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_csStr,(LPARAM)&csValue);
			}
		}
		break;
	case UI_PROP_iFontSize:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_NODE_FONT_SIZE)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_iFontSize,::CStringToInt(csValue));
			}
		}
		break;
	default:
		break;
	}

	m_bChangeUIProp = FALSE;
	m_emUIPropType = (EM_UI_PROP_TYPE)-1;
}

void CPropTextDialog::OnTimer(UINT_PTR nIDEvent)
{
	switch(nIDEvent)
	{
	case TIMER_CHANGE_UI_PROP:
		{
			EndChangeUIProp();
		}
		break;
	default:
		break;
	}

	CDialogEx::OnTimer(nIDEvent);
}

void CPropTextDialog::OnEnKillfocusEditNodeText()
{
	EndChangeUIProp();
}

void CPropTextDialog::OnCbnSelchangeComboFontName()
{
	CStringW csFontName = ::GetWindowTextW(&m_fontComboBox);
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_csFontName,(LPARAM)&csFontName);
}
