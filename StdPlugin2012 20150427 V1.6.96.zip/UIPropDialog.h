#pragma once

#include "PropButtonDialog.h"
#include "PropTextDialog.h"
#include "PropCustomDialog.h"
#include "afxcmn.h"
#include "afxwin.h"

#include "XGroupBox.h"
#include "XEdit.h"

#define UI_PROP_DIALOG_LEFT		555

// CUIPropDialog �Ի���

class CUIPropDialog : public CDialogEx
{
public:
	void InitData(const CDrawingBase *pDrawingBase);
	const CDrawingBase* GetDrawingBase() const;
	void SaveChangeUIProp();
private:
	void ChangeDrawingBase(const CDrawingBase *pDrawingBase);
	void ChangeUIProp(EM_UI_PROP_TYPE emUIPropType);
	void EndChangeUIProp();
private:
	CPropButtonDialog m_propButtonDialog;
	CPropTextDialog m_propTextDialog;
	CPropCustomDialog m_propCustomDialog;

	const CDrawingBase *m_pDrawingBase;

	BOOL m_bEditData;					//�Ƿ�����Ϊ�޸�����

	BOOL m_bChangeUIProp;				//�Ƿ��޸�UI����
	EM_UI_PROP_TYPE m_emUIPropType;		//�޸ĵ�UI�������

	DECLARE_DYNAMIC(CUIPropDialog)

public:
	CUIPropDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CUIPropDialog();

// �Ի�������
	enum { IDD = IDD_UI_PROP_DIALOG };
	CSpinButtonCtrl m_nodeXSpinButtonCtrl;
	CSpinButtonCtrl m_nodeYSpinButtonCtrl;
	CSpinButtonCtrl m_nodeWSpinButtonCtrl;
	CSpinButtonCtrl m_nodeHSpinButtonCtrl;
	CXGroupBox m_propSeatStatic;
	CXGroupBox m_propFillStatic;
	CXEdit m_nodeXEdit;
	CXEdit m_nodeYEdit;
	CXEdit m_nodeWEdit;
	CXEdit m_nodeHEdit;
	CXEdit m_topLeftXEdit;
	CXEdit m_topLeftYEdit;
	CXEdit m_bottomRightXEdit;
	CXEdit m_bottomRightYEdit;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnEnChangeEditNodeX();
	afx_msg void OnEnChangeEditNodeY();
	afx_msg void OnEnChangeEditNodeW();
	afx_msg void OnEnChangeEditNodeH();
/*	afx_msg void OnBnClickedButtonXSub();
	afx_msg void OnBnClickedButtonXAdd();
	afx_msg void OnBnClickedButtonYSub();
	afx_msg void OnBnClickedButtonYAdd();
	afx_msg void OnBnClickedButtonWSub();
	afx_msg void OnBnClickedButtonWAdd();
	afx_msg void OnBnClickedButtonHSub();
	afx_msg void OnBnClickedButtonHAdd();*/
	afx_msg void OnCbnSelchangeComboAdaptive();
	afx_msg void OnCbnSelchangeComboAdaptive2();
	afx_msg void OnEnChangeEditTopleftx();
	afx_msg void OnEnChangeEditToplefty();
	afx_msg void OnEnChangeEditBottomrightx();
	afx_msg void OnEnChangeEditBottomrighty();
	afx_msg void OnCbnSelchangeComboNodeAlign();
	afx_msg void OnCbnSelchangeComboVisible();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/);

	LRESULT MessageGetWidthHeight(WPARAM wParam,LPARAM lParam);
	LRESULT MessageEditKillFocus(WPARAM wParam,LPARAM lParam);
};
