#pragma once
#include "afxwin.h"


// CDialogName2 �Ի���

class CDialogName2 : public CDialogEx
{
	DECLARE_DYNAMIC(CDialogName2)

public:
	CDialogName2(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDialogName2();
	void SetCompareName(CStringArray& Names);
	void SetCompareName2(CMapStringToString* pNames2);
	CString GetName();
	CString GetViewName();
// �Ի�������
	enum { IDD = IDD_DIALOG_NAME2 };

	virtual BOOL OnInitDialog();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
	afx_msg void OnNameChange();
	afx_msg void OnBnClickedOk();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	void ShowError(CString strError);

private:
	CString m_strName;
	CString m_strViewName;
	CStringArray m_Names;
	CMapStringToString* m_pNames2;
public:
	CComboBox m_List;
	
};
