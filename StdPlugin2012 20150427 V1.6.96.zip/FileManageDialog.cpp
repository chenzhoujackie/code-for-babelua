// FileManageDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "FileManageDialog.h"
#include "afxdialogex.h"

#include "DialogName.h"

#include "XmlTools.h"
#include "LeftDialog.h"

#include "NeverPromptDialog.h"
#include "PromptDialog.h"

#define ID_POPUP_NEW_DIRECTORY		7001
#define ID_POPUP_NEW_XML_FILE		7002
#define ID_POPUP_DELETE				7003
#define ID_POPUP_GEN_LUA			7004


BOOL IsXmlFile(CString strFilePath)
{
	return ::IsFile(strFilePath) && (strFilePath.Right(4).MakeLower() == _T(".xml"));
}

// CFileManageDialog �Ի���

IMPLEMENT_DYNAMIC(CFileManageDialog, CDialogEx)

CFileManageDialog::CFileManageDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CFileManageDialog::IDD, pParent)
{

}

CFileManageDialog::~CFileManageDialog()
{
}

void CFileManageDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
//	DDX_Control(pDX, IDC_LIST_DIRECTORY, m_directoryListBox);
//	DDX_Control(pDX, IDC_LIST_FILE, m_fileListBox);
	DDX_Control(pDX, IDC_MFCSHELLLIST, m_listCtrl);
}


BEGIN_MESSAGE_MAP(CFileManageDialog, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_NEW_DIRECTORY, &CFileManageDialog::OnBnClickedButtonNewDirectory)
	ON_BN_CLICKED(IDC_BUTTON_DELETE_DIRECTORY, &CFileManageDialog::OnBnClickedButtonDeleteDirectory)
	ON_BN_CLICKED(IDC_BUTTON_EXPORT, &CFileManageDialog::OnBnClickedButtonExport)
	ON_BN_CLICKED(IDC_BUTTON_GEN_LUA, &CFileManageDialog::OnBnClickedButtonGenLua)
	ON_BN_CLICKED(IDC_BUTTON_NEW_FILE, &CFileManageDialog::OnBnClickedButtonNewFile)
	ON_BN_CLICKED(IDC_BUTTON_DELETE_FILE, &CFileManageDialog::OnBnClickedButtonDeleteFile)
	ON_BN_CLICKED(IDOK, &CFileManageDialog::OnBnClickedOk)
	ON_LBN_SELCHANGE(IDC_LIST_DIRECTORY, &CFileManageDialog::OnLbnSelchangeListDirectory)
	ON_LBN_DBLCLK(IDC_LIST_FILE, &CFileManageDialog::OnLbnDblclkListFile)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_DIRECTORY, &CFileManageDialog::OnBnClickedButtonOpenDirectory)
	ON_BN_CLICKED(IDC_BUTTON_GEN_LUA_SINGLE, &CFileManageDialog::OnBnClickedButtonGenLuaSingle)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_MFCSHELLLIST, &CFileManageDialog::OnLvnItemchangedMfcshelllist)
	ON_NOTIFY(LVN_BEGINLABELEDIT, IDC_MFCSHELLLIST, &CFileManageDialog::OnLvnBeginlabeleditMfcshelllist)
	ON_NOTIFY(LVN_ENDLABELEDIT, IDC_MFCSHELLLIST, &CFileManageDialog::OnLvnEndlabeleditMfcshelllist)
	ON_NOTIFY(NM_CLICK, IDC_MFCSHELLLIST, &CFileManageDialog::OnNMClickMfcshelllist)
	ON_NOTIFY(NM_RCLICK, IDC_MFCSHELLLIST, &CFileManageDialog::OnNMRClickMfcshelllist)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, &CFileManageDialog::OnBnClickedButtonDelete)
	ON_BN_CLICKED(IDC_BUTTON_UP, &CFileManageDialog::OnBnClickedButtonUp)
END_MESSAGE_MAP()


// CFileManageDialog ��Ϣ��������

void CFileManageDialog::InitData(CString csSelDirectoryName,CString csSelFileName)
{
	m_csSelDirectoryName = csSelDirectoryName;
	m_csSelFileName = csSelFileName;
}

CString CFileManageDialog::GetSelDirectoryName() const
{
	return m_csSelDirectoryName;
}

CString CFileManageDialog::GetSelFileName() const
{
	return m_csSelFileName;
}

BOOL CFileManageDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetIcon(hIcon, FALSE);

/*
	CString csWindowText;
	GetWindowText(csWindowText);
	SetWindowText(csWindowText+_T(" - ")+EDITOR_DIRECTORY);

	CString csSelDirectoryName = InitDirectoryListBox(m_csSelDirectoryName);
	InitFileListBox(csSelDirectoryName,m_csSelFileName);
*/

	CString strCurrentDirectory = EDITOR_DIRECTORY+_T("\\")+m_csSelDirectoryName;
	m_listCtrl.DisplayFolder(strCurrentDirectory);
	CString csSelFilePath = strCurrentDirectory+_T("\\")+m_csSelFileName;

	m_listCtrl.SetColumnWidth(0,200);
	
	SetSelectPath(csSelFilePath);

	UpdateCurrentDirectory(strCurrentDirectory);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

CString CFileManageDialog::InitDirectoryListBox(CString csSelDirectoryName)
{
	CStringArray csDirectoryArr;
	::FindDirectory(EDITOR_DIRECTORY,csDirectoryArr,FALSE);

	m_directoryListBox.ResetContent();
	int iSel = 0;
	int i;
	for(i=0; i<csDirectoryArr.GetSize(); i++)
	{
		m_directoryListBox.InsertString(i,csDirectoryArr.GetAt(i));
		if(csSelDirectoryName == csDirectoryArr.GetAt(i))
		{
			iSel = i;
		}
	}
	m_directoryListBox.SetCurSel(iSel);

	CString csRetDirectoryName;
	if(iSel < m_directoryListBox.GetCount())
	{
		m_directoryListBox.GetText(iSel,csRetDirectoryName);
	}
	return csRetDirectoryName;
}

void CFileManageDialog::InitFileListBox(CString csDirectoryName,CString csSelFileName)
{
	CStringArray csFilePathArr;
	::FindFile(EDITOR_DIRECTORY+_T("\\")+csDirectoryName,_T("xml"),csFilePathArr);

	m_fileListBox.ResetContent();
	int iSel = 0;
	int i;
	for(i=0; i<csFilePathArr.GetSize(); i++)
	{
		CString csFileName = ::GetFileName(csFilePathArr.GetAt(i),TRUE);
		m_fileListBox.InsertString(i,csFileName);
		if(csSelFileName == csFileName)
		{
			iSel = i;
		}
	}
	m_fileListBox.SetCurSel(iSel);

	UpdateSelect();
}

void CFileManageDialog::UpdateSelect()
{
	int iSelDirectoryIndex = m_directoryListBox.GetCurSel();
	CString csSelDirectoryName;
	if(iSelDirectoryIndex >= 0)
	{
		m_directoryListBox.GetText(iSelDirectoryIndex,csSelDirectoryName);
	}

	int iSelFileIndex = m_fileListBox.GetCurSel();
	CString csSelFileName;
	if(iSelFileIndex >= 0)
	{
		m_fileListBox.GetText(iSelFileIndex,csSelFileName);
	}

	BOOL bSelDirectory = !csSelDirectoryName.IsEmpty();
	BOOL bSelFile = !csSelFileName.IsEmpty();

	GetDlgItem(IDC_BUTTON_DELETE_DIRECTORY)->EnableWindow(bSelDirectory);
	GetDlgItem(IDC_BUTTON_GEN_LUA)->EnableWindow(bSelDirectory);

	GetDlgItem(IDC_BUTTON_DELETE_FILE)->EnableWindow(bSelFile);
	GetDlgItem(IDC_BUTTON_OPEN_DIRECTORY)->EnableWindow(bSelFile);
	GetDlgItem(IDC_BUTTON_GEN_LUA_SINGLE)->EnableWindow(bSelFile);
	GetDlgItem(IDOK)->EnableWindow(bSelFile);
}

void CFileManageDialog::OnBnClickedButtonNewDirectory()
{
/*
	CStringArray csDirectoryArr;
	::FindDirectory(EDITOR_DIRECTORY,csDirectoryArr,FALSE);

	CDialogName dlg;
	dlg.SetCompareName(csDirectoryArr);

	if ( IDOK == dlg.DoModal())
	{
		CString strName = dlg.GetName();
		CString strPath = EDITOR_DIRECTORY + _T("\\") + strName;
		::CreateMultipleDirectory(EDITOR_DIRECTORY);
		if ( ! CreateDirectory(strPath,NULL))
		{
			AfxMessageBox(_T("�����ļ���") + strPath + _T("ʧ��."));
		}

		strPath = VIEW_DIRECTORY + _T("\\") + strName;
		CreateDirectory(strPath,NULL);

		InitDirectoryListBox(strName);
		InitFileListBox(strName,_T(""));
	}
*/
	CString strCurrentDirectory = GetCurrentDirectory();

	CStringArray csDirectoryArr;
	::FindDirectory(strCurrentDirectory,csDirectoryArr,FALSE);

	CDialogName dlg;
	dlg.SetCompareName(csDirectoryArr);

	if ( IDOK == dlg.DoModal())
	{
		CString strName = dlg.GetName();
		CString strPath = strCurrentDirectory + _T("\\") + strName;
		::CreateMultipleDirectory(strCurrentDirectory);
		if ( ! CreateDirectory(strPath,NULL))
		{
			AfxMessageBox(_T("�����ļ���") + strPath + _T("ʧ��."));
		}

		m_listCtrl.Refresh();
		SetSelectPath(strPath);
	}
}


void CFileManageDialog::OnBnClickedButtonDeleteDirectory()
{
	if ( 0 == m_directoryListBox.GetCount() )
		return;
	int id = m_directoryListBox.GetCurSel();

	CString strName;
	m_directoryListBox.GetText(id,strName);
	if ( 0 == strName.Compare(_T("default")))
	{
		AfxMessageBox(_T("����ɾ����default��Ŀ¼."));
		return;
	}
	CString strPath = EDITOR_DIRECTORY + _T("\\") + strName;
	if ( ! RemoveDirectory(strPath))
	{
		AfxMessageBox(_T("ɾ���ļ���ʧ��."));
		return;
	}

	InitDirectoryListBox(_T(""));
	InitFileListBox(_T(""),_T(""));
	OnLbnSelchangeListDirectory();
}


void CFileManageDialog::OnBnClickedButtonExport()
{
}

CString GetRelativePath(CString strRootPath,CString strDirectoryPath)
{
	CString strDirectoryName = strDirectoryPath;
	if(strDirectoryName == strRootPath)
		return _T("");

	if(strRootPath.Right(1) != '\\')
		strRootPath += '\\';
	strDirectoryName.Replace(strRootPath,_T(""));
	return strDirectoryName;
}

void CFileManageDialog::OnBnClickedButtonGenLua()
{
/*
	int iSelDirectoryIndex = m_directoryListBox.GetCurSel();
	if(iSelDirectoryIndex < 0 )
	{
		MessageBox(_T("δѡ��Ŀ¼"));
		return;
	}
	CString csSelDirectoryName;
	m_directoryListBox.GetText(iSelDirectoryIndex,csSelDirectoryName);

	CString csSelDirectoryPath = EDITOR_DIRECTORY + _T("\\") + csSelDirectoryName;
	CStringArray csXmlFilePathArray;
	::FindFile(csSelDirectoryPath,_T("xml"),csXmlFilePathArray);

	if(csXmlFilePathArray.GetSize() <= 0)
	{
		MessageBox(_T("������xml�ļ�"));
		return;
	}

	int iFileNum = 0;
	BOOL bPrompt = TRUE;
	BOOL bXmlToLua = TRUE;
	int i;
	for(i=0; i<csXmlFilePathArray.GetSize(); i++)
	{
		CString csXmlFilePath = csXmlFilePathArray.GetAt(i);
		CString csFileName = ::GetFileName(csXmlFilePath,FALSE);

		CString csLuaDirectory = VIEW_DIRECTORY+_T("\\")+csSelDirectoryName;
		::CreateMultipleDirectory(csLuaDirectory);
		CString csLuaFilePath = csLuaDirectory+_T("\\")+csFileName+_T(".lua");
		if(bPrompt && ::IsFileExist(csLuaFilePath))
		{
			CNeverPromptDialog neverPromptDialog;
			neverPromptDialog.SetStaticText1(_T("�����ļ��Ѿ�����:"));
			neverPromptDialog.SetStaticText2(_T("�Ƿ������µ��ļ�?"));
			CString csEditText;
			csEditText.Format(_T("%s"),csLuaFilePath);
			neverPromptDialog.SetEditText(csEditText);
			int iRet = neverPromptDialog.DoModal();
			if(neverPromptDialog.IsNeverView())
				bPrompt = FALSE;

			if(iRet == IDYES)
			{
				bXmlToLua = TRUE;
			}
			if(iRet == IDNO)
			{
				bXmlToLua = FALSE;
			}
			else if(iRet == IDCANCEL)
				break;
		}

		if(bXmlToLua)
		{
			::XmlToLua(csXmlFilePath,csLuaFilePath);
			iFileNum++;
		}
	}
	if(iFileNum > 0)
	{
		CString csInfo;
		csInfo.Format(_T("�������ļ�%d��"),iFileNum);
		MessageBox(csInfo);
	}
*/

	CString strPath = GetSelectPath();
	if(strPath.IsEmpty())
		return;

	if(::IsXmlFile(strPath))
	{
		CString strDirectoryName = ::GetRelativePath(EDITOR_DIRECTORY,GetCurrentDirectory());

		CString csXmlFilePath = strPath;
		CString csFileName = ::GetFileName(csXmlFilePath,FALSE);
		CString csLuaDirectory = VIEW_DIRECTORY+_T("\\")+strDirectoryName;
		::CreateMultipleDirectory(csLuaDirectory);
		CString csLuaFilePath = csLuaDirectory+_T("\\")+csFileName+_T(".lua");
		::XmlToLua(csXmlFilePath,csLuaFilePath);

		CFileStatus FS;
		CFile::GetStatus(csLuaFilePath,FS);

		CString strMsg;
		strMsg.Format(_T("�ļ���СΪ%d�ֽ�"),FS.m_size);

		CPromptDialog promptDialog;
		promptDialog.SetStaticText1(_T("���ɳɹ�"));
		promptDialog.SetStaticText2(strMsg);
		promptDialog.SetEditText(csLuaFilePath);
		promptDialog.DoModal();
	}
	else
	{
		CString strDirectoryName = ::GetRelativePath(EDITOR_DIRECTORY,strPath);

		CString csSelDirectoryPath = strPath;
		CStringArray csXmlFilePathArray;
		::FindFile(csSelDirectoryPath,_T("xml"),csXmlFilePathArray);

		if(csXmlFilePathArray.GetSize() <= 0)
		{
			MessageBox(_T("������xml�ļ�"));
			return;
		}

		int iFileNum = 0;
		BOOL bPrompt = TRUE;
		BOOL bXmlToLua = TRUE;
		int i;
		for(i=0; i<csXmlFilePathArray.GetSize(); i++)
		{
			CString csXmlFilePath = csXmlFilePathArray.GetAt(i);
			CString csFileName = ::GetFileName(csXmlFilePath,FALSE);

			CString csLuaDirectory = VIEW_DIRECTORY+_T("\\")+strDirectoryName;
			::CreateMultipleDirectory(csLuaDirectory);
			CString csLuaFilePath = csLuaDirectory+_T("\\")+csFileName+_T(".lua");
			if(bPrompt && ::IsFileExist(csLuaFilePath))
			{
				CNeverPromptDialog neverPromptDialog;
				neverPromptDialog.SetStaticText1(_T("�����ļ��Ѿ�����:"));
				neverPromptDialog.SetStaticText2(_T("�Ƿ������µ��ļ�?"));
				CString csEditText;
				csEditText.Format(_T("%s"),csLuaFilePath);
				neverPromptDialog.SetEditText(csEditText);
				int iRet = neverPromptDialog.DoModal();
				if(neverPromptDialog.IsNeverView())
					bPrompt = FALSE;

				if(iRet == IDYES)
				{
					bXmlToLua = TRUE;
				}
				if(iRet == IDNO)
				{
					bXmlToLua = FALSE;
				}
				else if(iRet == IDCANCEL)
					break;
			}

			if(bXmlToLua)
			{
				::XmlToLua(csXmlFilePath,csLuaFilePath);
				iFileNum++;
			}
		}
		if(iFileNum > 0)
		{
			CString csInfo;
			csInfo.Format(_T("�������ļ�%d��"),iFileNum);
			MessageBox(csInfo);
		}
	}
}


void CFileManageDialog::OnBnClickedButtonNewFile()
{
/*
	int iSelDirectoryIndex = m_directoryListBox.GetCurSel();
	if(iSelDirectoryIndex < 0 )
	{
		MessageBox(_T("δѡ��Ŀ¼"));
		return;
	}
	CString csSelDirectoryName;
	CString csSelFileName;
	m_directoryListBox.GetText(iSelDirectoryIndex,csSelDirectoryName);
	
	CDialogName dlg;
	if ( IDOK != dlg.DoModal())
	{
		return;
	}
	CString strName = dlg.GetName();
	if ( strName.GetLength() < 0 )
		return;
	
	strName += _T(".xml");

	CString strXmlDirectory = EDITOR_DIRECTORY + _T("\\") + csSelDirectoryName;
	CString strXmlFile = strXmlDirectory + _T("\\") + strName;
	if(::IsFileExist(strXmlFile))
	{
		CString csInfo;
		csInfo.Format(_T("�ļ���%s���Ѿ����ڣ��Ƿ����´�����"),strXmlFile);
		int iRet = MessageBox(csInfo,NULL,MB_YESNOCANCEL | MB_ICONWARNING);
		if(iRet != IDYES)
			return;
	}
	::CreateMultipleDirectory(strXmlDirectory);
	create_default_xml(CCharArr(strXmlFile));

	InitFileListBox(csSelDirectoryName,strName);
*/
	CString strCurrentDirectory = GetCurrentDirectory();

	CDialogName dlg;
	if ( IDOK != dlg.DoModal())
		return;

	CString strName = dlg.GetName();
	if ( strName.GetLength() < 0 )
		return;
	
	strName += _T(".xml");

	CString strXmlDirectory = strCurrentDirectory;
	CString strXmlFile = strXmlDirectory + _T("\\") + strName;
	if(::IsFileExist(strXmlFile))
	{
		CString csInfo;
		csInfo.Format(_T("�ļ���%s���Ѿ����ڣ��Ƿ����´�����"),strXmlFile);
		int iRet = MessageBox(csInfo,NULL,MB_YESNOCANCEL | MB_ICONWARNING);
		if(iRet != IDYES)
			return;
	}
	::CreateMultipleDirectory(strXmlDirectory);
	create_default_xml(CCharArr(strXmlFile));

	m_listCtrl.Refresh();
	SetSelectPath(strXmlFile);
}


void CFileManageDialog::OnBnClickedButtonDeleteFile()
{
	int iSelDirectoryIndex = m_directoryListBox.GetCurSel();
	if(iSelDirectoryIndex < 0 )
	{
		MessageBox(_T("δѡ��Ŀ¼"));
		return;
	}
	CString csSelDirectoryName;
	m_directoryListBox.GetText(iSelDirectoryIndex,csSelDirectoryName);

	int id = m_fileListBox.GetCurSel();
	if ( id < 0 )
	{
		AfxMessageBox(_T("û��XML�ļ�����ɾ��"));
		return;
	}

	CString strName;
	m_fileListBox.GetText(id,strName);

	if ( 0 == strName.Compare(_T("default.xml")))
	{
		AfxMessageBox(_T("����ɾ����default.xml��"));
		return;
	}

	CString csInfo;
	csInfo.Format(_T("ɾ����%s���ļ����Ƿ�ͬʱɾ���䱸��Ŀ¼"),strName);
	int iRet = MessageBox(csInfo,NULL,MB_YESNOCANCEL | MB_ICONWARNING);

	CString FilePath = EDITOR_DIRECTORY + _T("\\") + csSelDirectoryName + _T("\\") + strName;
	CString csFileName = strName.Left(strName.GetLength()-4);
	CString csXmlDirectory = EDITOR_DIRECTORY+_T("\\")+csSelDirectoryName+_T("\\")+csFileName+_T("_bak");
	if(iRet == IDYES)
	{
		DeleteFile(FilePath,FALSE);
		DeleteFile(csXmlDirectory,FALSE);
	}
	else if(iRet == IDNO)
	{
		DeleteFile(FilePath,FALSE);
	}
	else
		return;


	InitFileListBox(csSelDirectoryName,_T(""));
}

void CFileManageDialog::OnBnClickedOk()
{
/*
	int iSelDirectoryIndex = m_directoryListBox.GetCurSel();
	int iFileListBox = m_fileListBox.GetCurSel();
	if(iSelDirectoryIndex < 0 )
	{
		MessageBox(_T("δѡ��Ŀ¼"));
		return;
	}
	if(iFileListBox < 0)
	{
		MessageBox(_T("δѡ��XML�ļ�"));
		return;
	}
	CString csSelDirectoryName;
	CString csSelFileName;
	m_directoryListBox.GetText(iSelDirectoryIndex,csSelDirectoryName);
	m_fileListBox.GetText(iFileListBox,csSelFileName);

	if(csSelDirectoryName.IsEmpty() || csSelFileName.IsEmpty())
		return;
*/

	CString strFilePath = GetSelectPath();
	if(!::IsXmlFile(strFilePath))
	{
		MessageBox(_T("δѡ��XML�ļ�"));
		return;
	}
	CString strDirectoryName = GetCurrentDirectory();
	if(strDirectoryName == EDITOR_DIRECTORY)
		return;

	strDirectoryName = ::GetRelativePath(EDITOR_DIRECTORY,GetCurrentDirectory());

	m_csSelDirectoryName = strDirectoryName;
	m_csSelFileName = ::GetFileName(strFilePath,TRUE);

	CDialogEx::OnOK();
}


void CFileManageDialog::OnLbnSelchangeListDirectory()
{
	int iCurSel = m_directoryListBox.GetCurSel();
	CString csText;
	if(iCurSel >= 0)
	{
		m_directoryListBox.GetText(iCurSel,csText);
	}
	InitFileListBox(csText,_T(""));
}


void CFileManageDialog::OnLbnDblclkListFile()
{
	OnBnClickedOk();
}


void CFileManageDialog::OnBnClickedButtonOpenDirectory()
{
	int iSelDirectoryIndex = m_directoryListBox.GetCurSel();
	if(iSelDirectoryIndex < 0 )
	{
		MessageBox(_T("δѡ��Ŀ¼"));
		return;
	}
	CString csSelDirectoryName;
	m_directoryListBox.GetText(iSelDirectoryIndex,csSelDirectoryName);

	int id = m_fileListBox.GetCurSel();
	if ( id < 0 )
	{
		AfxMessageBox(_T("û��ѡ��XML�ļ�"));
		return;
	}

	CString strName;
	m_fileListBox.GetText(id,strName);

	CString csFileName = strName.Left(strName.GetLength()-4);
	CString csXmlDirectory = EDITOR_DIRECTORY+_T("\\")+csSelDirectoryName+_T("\\")+csFileName+_T("_bak");

	if(!::IsDirectoryExist(csXmlDirectory))
	{
		CString csInfo;
		csInfo.Format(_T("����Ŀ¼%s������"),csXmlDirectory);
		AfxMessageBox(csInfo);
		return;
	}
	
	ShellExecute(NULL,_T("open"),csXmlDirectory,NULL,NULL,SW_SHOWNORMAL);
}


void CFileManageDialog::OnBnClickedButtonGenLuaSingle()
{
	int iSelDirectoryIndex = m_directoryListBox.GetCurSel();
	if(iSelDirectoryIndex < 0 )
	{
		MessageBox(_T("δѡ��Ŀ¼"));
		return;
	}
	CString csSelDirectoryName;
	m_directoryListBox.GetText(iSelDirectoryIndex,csSelDirectoryName);

	int id = m_fileListBox.GetCurSel();
	if ( id < 0 )
	{
		AfxMessageBox(_T("û��ѡ��XML�ļ�"));
		return;
	}

	CString strName;
	m_fileListBox.GetText(id,strName);

	CString csXmlFilePath = EDITOR_DIRECTORY + _T("\\") + csSelDirectoryName + _T("\\") + strName;
	CString csFileName = ::GetFileName(csXmlFilePath,FALSE);
	CString csLuaDirectory = VIEW_DIRECTORY+_T("\\")+csSelDirectoryName;
	::CreateMultipleDirectory(csLuaDirectory);
	CString csLuaFilePath = csLuaDirectory+_T("\\")+csFileName+_T(".lua");
	::XmlToLua(csXmlFilePath,csLuaFilePath);


	CFileStatus FS;
	CFile::GetStatus(csLuaFilePath,FS);

	CString strMsg;
	strMsg.Format(_T("�ļ���СΪ%d�ֽ�"),FS.m_size);

	CPromptDialog promptDialog;
	promptDialog.SetStaticText1(_T("���ɳɹ�"));
	promptDialog.SetStaticText2(strMsg);
	promptDialog.SetEditText(csLuaFilePath);
	promptDialog.DoModal();
}


void CFileManageDialog::OnLvnItemchangedMfcshelllist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);

	CString strPath = GetSelectPath();
	BOOL bPathEmpty = strPath.IsEmpty();
	GetDlgItem(IDC_BUTTON_DELETE)->EnableWindow(!bPathEmpty);
	GetDlgItem(IDC_BUTTON_GEN_LUA)->EnableWindow(!bPathEmpty);

	*pResult = 0;
}


void CFileManageDialog::OnLvnBeginlabeleditMfcshelllist(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	*pResult = 0;
}


void CFileManageDialog::OnLvnEndlabeleditMfcshelllist(NMHDR *pNMHDR, LRESULT *pResult)
{
	NMLVDISPINFO *pDispInfo = reinterpret_cast<NMLVDISPINFO*>(pNMHDR);

	if(pDispInfo->item.pszText != NULL)
	{
		int iSelItem = pDispInfo->item.iItem;
		CString strName = pDispInfo->item.pszText;

		CString strOldName = m_listCtrl.GetItemText(iSelItem,0);
		if(strName == strOldName)
		{
			*pResult = 0;
			return;
		}

		CString	strCurrentDirectory = GetCurrentDirectory();
		CString strPath = strCurrentDirectory+_T("\\")+strName;
		CString strOldPath = strCurrentDirectory+_T("\\")+strOldName;

		if(MoveFile(strOldPath,strPath))
		{
			m_listCtrl.Refresh();
			SetSelectPath(strPath);
		}
		else
		{
			MessageBox(_T("������ʧ�ܣ�"),NULL,MB_OK | MB_ICONWARNING);
		}
	}

	*pResult = 0;
}


void CFileManageDialog::OnNMClickMfcshelllist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);

	*pResult = 0;
}


void CFileManageDialog::OnNMRClickMfcshelllist(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMITEMACTIVATE pNMItemActivate = reinterpret_cast<LPNMITEMACTIVATE>(pNMHDR);

	CString	strCurrentDirectory = GetCurrentDirectory();
	BOOL bRoot = (strCurrentDirectory == EDITOR_DIRECTORY);
	CString strPath = GetSelectPath();
	BOOL bPathEmpty = strPath.IsEmpty();

	CMenu menu;
	menu.CreatePopupMenu();
	menu.InsertMenu(MF_BYPOSITION,MF_STRING,ID_POPUP_NEW_DIRECTORY,_T("�½��ļ���"));
	menu.InsertMenu(MF_BYPOSITION,MF_STRING,ID_POPUP_NEW_XML_FILE,_T("�½�xml"));
	menu.InsertMenu(MF_BYPOSITION,MF_STRING,ID_POPUP_DELETE,_T("ɾ��"));
	menu.InsertMenu(MF_BYPOSITION,MF_STRING,ID_POPUP_GEN_LUA,_T("����lua"));

	menu.EnableMenuItem(ID_POPUP_NEW_XML_FILE,bRoot);
	menu.EnableMenuItem(ID_POPUP_DELETE,bPathEmpty);
	menu.EnableMenuItem(ID_POPUP_GEN_LUA,bPathEmpty);

	CPoint screenPoint;
	::GetCursorPos(&screenPoint);
	menu.TrackPopupMenu(TPM_LEFTALIGN |TPM_RIGHTBUTTON,screenPoint.x,screenPoint.y,this);

	*pResult = 0;
}

CString CFileManageDialog::GetSelectPath()
{
	CString strPath;
	if(m_listCtrl.m_hWnd == NULL)
		return strPath;

	POSITION position = m_listCtrl.GetFirstSelectedItemPosition();
	while(position != NULL)
	{
		int nItem = m_listCtrl.GetNextSelectedItem(position);
		m_listCtrl.GetItemPath(strPath,nItem);
		break;
	}
	return strPath;
}

CString CFileManageDialog::GetCurrentDirectory()
{
	CString strPath;
	m_listCtrl.GetCurrentFolder(strPath);
	return strPath;
}

void CFileManageDialog::SetSelectPath(CString strSelPath)
{
	int i;
	for(i=0; i<m_listCtrl.GetItemCount(); i++)
	{
		CString strPath;
		m_listCtrl.GetItemPath(strPath,i);
		if(strPath == strSelPath)
		{
			m_listCtrl.SetItemState(i,LVNI_FOCUSED | LVIS_SELECTED, LVNI_FOCUSED | LVIS_SELECTED);
			break;
		}
	}
}

void CFileManageDialog::UpdateCurrentDirectory(CString strCurrentDirectory)
{
	BOOL bRoot = (strCurrentDirectory == EDITOR_DIRECTORY);

	GetDlgItem(IDC_EDIT_DIRECTORY)->SetWindowText(strCurrentDirectory);
	GetDlgItem(IDC_BUTTON_UP)->EnableWindow(!bRoot);
	GetDlgItem(IDC_BUTTON_NEW_FILE)->EnableWindow(!bRoot);
}

BOOL CFileManageDialog::PreTranslateMessage(MSG* pMsg)
{
	switch(pMsg->message)
	{
	case WM_LBUTTONDBLCLK:
		{
			if(pMsg->hwnd == m_listCtrl.m_hWnd)
			{
				CString strPath = GetSelectPath();

				if(strPath.IsEmpty())
					return TRUE;
				else if(::IsXmlFile(strPath))
				{
					OnBnClickedOk();
					return TRUE;
				}

				UpdateCurrentDirectory(strPath);
			}
		}
		break;
	default:
		break;
	}

	return CDialogEx::PreTranslateMessage(pMsg);
}


BOOL CFileManageDialog::OnCommand(WPARAM wParam, LPARAM lParam)
{
	switch (wParam)
	{
	case ID_POPUP_NEW_DIRECTORY:
		{
			OnBnClickedButtonNewDirectory();
		}
		break;
	case ID_POPUP_NEW_XML_FILE:
		{
			OnBnClickedButtonNewFile();
		}
		break;
	case ID_POPUP_DELETE:
		{
			OnBnClickedButtonDelete();
		}
		break;
	case ID_POPUP_GEN_LUA:
		{
			OnBnClickedButtonGenLua();
		}
		break;
	default:
		break;
	}

	return CDialogEx::OnCommand(wParam, lParam);
}


void CFileManageDialog::OnBnClickedButtonDelete()
{
	CString strPath = GetSelectPath();
	if(strPath.IsEmpty())
		return;

	CString csInfo;
	if(::IsDirectory(strPath))
		csInfo.Format(_T("�Ƿ�ɾ����%s��Ŀ¼��"),strPath);
	else
		csInfo.Format(_T("�Ƿ�ɾ����%s���ļ���"),strPath);

	int iRet = MessageBox(csInfo,NULL,MB_YESNO | MB_ICONWARNING);
	if(iRet == IDYES)
	{
		DeleteFile(strPath,FALSE);

		m_listCtrl.Refresh();
	}
}

void CFileManageDialog::OnBnClickedButtonUp()
{
	CString strCurrentDirectory = GetCurrentDirectory();
	if(strCurrentDirectory == EDITOR_DIRECTORY)
		return;

	m_listCtrl.DisplayParentFolder();

	strCurrentDirectory = GetCurrentDirectory();
	UpdateCurrentDirectory(strCurrentDirectory);
}
