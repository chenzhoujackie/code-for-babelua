// PromptDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "PromptDialog.h"
#include "afxdialogex.h"


// CPromptDialog �Ի���

IMPLEMENT_DYNAMIC(CPromptDialog, CDialogEx)

CPromptDialog::CPromptDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CPromptDialog::IDD, pParent)
{

}

CPromptDialog::~CPromptDialog()
{
}

void CPromptDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CPromptDialog, CDialogEx)
	ON_BN_CLICKED(IDOK, &CPromptDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CPromptDialog ��Ϣ��������

void CPromptDialog::SetTitle(LPCTSTR lpszTitle)
{
	m_csTitle = lpszTitle;
}

void CPromptDialog::SetStaticText1(LPCTSTR lpszText)
{
	m_csStaticText1 = lpszText;
}

void CPromptDialog::SetStaticText2(LPCTSTR lpszText)
{
	m_csStaticText2 = lpszText;
}

void CPromptDialog::SetEditText(LPCTSTR lpszText)
{
	m_csEditText = lpszText;
}

BOOL CPromptDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetIcon(hIcon, FALSE);

	GetDlgItem(IDC_STATIC1)->SetWindowText(m_csStaticText1);
	GetDlgItem(IDC_STATIC2)->SetWindowText(m_csStaticText2);
	GetDlgItem(IDC_EDIT1)->SetWindowText(m_csEditText);

	if(!m_csTitle.IsEmpty())
	{
		SetWindowText(m_csTitle);
	}
	else
	{
		CString csAppTitle;
		csAppTitle.LoadString(AFX_IDS_APP_TITLE);
		SetWindowText(csAppTitle);
	}

	return TRUE;
}

void CPromptDialog::OnBnClickedOk()
{
	CDialogEx::OnOK();
}
