#pragma once
#include "afxwin.h"

#include "XGroupBox.h"
#include "ColorButton.h"
#include "XEdit.h"
#include "afxfontcombobox.h"

int CALLBACK NEnumFontNameProc(LOGFONT *plf, TEXTMETRIC* /*ptm*/, INT /*nFontType*/, LPARAM lParam);

// CPropTextDialog �Ի���

class CPropTextDialog : public CDialogEx
{
public:
	void InitData(const CDrawingBase *pDrawingBase);
	void SaveChangeUIProp();
private:
	void ChangeDrawingBase(const CDrawingBase *pDrawingBase);
	void ChangeUIProp(EM_UI_PROP_TYPE emUIPropType);
	void EndChangeUIProp();
private:
	const CDrawingBase *m_pDrawingBase;

	BOOL m_bEditData;

	BOOL m_bChangeUIProp;				//�Ƿ��޸�UI����
	EM_UI_PROP_TYPE m_emUIPropType;		//�޸ĵ�UI�������

	DECLARE_DYNAMIC(CPropTextDialog)

public:
	CPropTextDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPropTextDialog();

// �Ի�������
	enum { IDD = IDD_PROP_TEXT_DIALOG };
	CXGroupBox m_propTextStatic;
	CXEdit m_nodeFontSizeEdit;
	CXEdit m_textColorEdit;
	CColorButton m_getColorButton;
	CComboBox m_fontComboBox;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnEnChangeEditNodeText();
	afx_msg void OnEnChangeEditNodeFontSize();
	afx_msg void OnCbnSelchangeComboNodeAlign();
	afx_msg void OnBnClickedButtonGetColor();
	afx_msg void OnBnClickedMfccolorbuttonText();
	afx_msg void OnEnChangeEditTextColor();
	afx_msg void OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/);

	LRESULT MessageEditKillFocus(WPARAM wParam,LPARAM lParam);
	afx_msg void OnEnKillfocusEditNodeText();
	afx_msg void OnCbnSelchangeComboFontName();
};
