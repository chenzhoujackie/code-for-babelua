// RightDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "RightDialog.h"
#include "afxdialogex.h"

#include "CustomControlDialog.h"

#include <libxml/parser.h>
#include <libxml/tree.h>

BOOL LoadCustomControl(const CString &csFilePath,CArray <CCustomControlData,CCustomControlData> &customControlDataArray)
{
	xmlKeepBlanksDefault(0);
	xmlDocPtr pDoc = xmlReadFile(CCharArr(csFilePath) ,"UTF-8",XML_PARSE_RECOVER);
	if(pDoc == NULL)
		return FALSE;

	xmlNodePtr pRoot = xmlDocGetRootElement(pDoc);
	if(pRoot == NULL)
	{
		xmlFreeDoc(pDoc);
		return FALSE;
	}
	if(xmlStrcmp(pRoot->name, BAD_CAST "CustomControls")) 
	{
		xmlFreeDoc(pDoc);
		return FALSE;
	}

	xmlNodePtr node = pRoot->xmlChildrenNode;
	while(node != NULL)
	{
		xmlChar* szAttr = xmlGetProp(node,BAD_CAST "CustomName");
		
		CArray <CCustomData,CCustomData> customDataArray;
		xmlNodePtr grandson = node->xmlChildrenNode;
		while(grandson != NULL)
		{
			xmlChar* szPropName = xmlGetProp(grandson,BAD_CAST "PropName");
			xmlChar* szDataType = xmlGetProp(grandson,BAD_CAST "DataType");
			customDataArray.Add(CCustomData(CString(szPropName),::GetCustomDataType(CString(szDataType))));

			grandson = grandson->next;
		}

		CCustomControlData customControlData(CString(szAttr),customDataArray);
		customControlDataArray.Add(customControlData);

		node = node->next;
	}

	xmlFreeDoc(pDoc);
	xmlCleanupParser();

	return TRUE;
}

BOOL SaveCustomControl(const CString &csFilePath,const CArray <CCustomControlData,CCustomControlData> &customControlDataArray)
{
	xmlDocPtr doc = xmlNewDoc(BAD_CAST"1.0");

	xmlNodePtr root_node = xmlNewNode(NULL,BAD_CAST"CustomControls");
	//���ø��ڵ�
	xmlDocSetRootElement(doc,root_node);
	//�ڸ��ڵ���ֱ�Ӵ����ڵ�
//	xmlNewTextChild(root_node, NULL, BAD_CAST "name", BAD_CAST "content");

//	xmlNodePtr content = xmlNewText(BAD_CAST"");
//	xmlAddChild(node,content);
	//����һ���ڵ㣬���������ݺ����ԣ�Ȼ���������
	int i,j;
	for(i=0; i<customControlDataArray.GetSize(); i++)
	{
		xmlNodePtr node = xmlNewNode(NULL,BAD_CAST"CustomControl");
		xmlAddChild(root_node,node);
		xmlNewProp(node,BAD_CAST"CustomName",BAD_CAST (char*)CCharArr(customControlDataArray.GetAt(i).GetCustomName()));

		CArray <CCustomData,CCustomData> customDataArray;
		customControlDataArray.GetAt(i).GetCustomData(customDataArray);
		for(j=0; j<customDataArray.GetSize(); j++)
		{
			xmlNodePtr grandson = xmlNewNode(NULL, BAD_CAST "CustomData");
			xmlAddChild(node,grandson);
			xmlNewProp(grandson,BAD_CAST"PropName",BAD_CAST (char*)CCharArr(customDataArray.GetAt(j).GetCustomPropName()));
			xmlNewProp(grandson,BAD_CAST"DataType",BAD_CAST (char*)CCharArr(::GetCustomDataType(customDataArray.GetAt(j).GetCustomDataType())));
		}
	}
/*
	//����һ�����Ӻ����ӽڵ�
	node = xmlNewNode(NULL, BAD_CAST "son");
	xmlAddChild(root_node,node);
	xmlNodePtr grandson = xmlNewNode(NULL, BAD_CAST "grandson");
	xmlAddChild(node,grandson);
	xmlAddChild(grandson, xmlNewText(BAD_CAST "This is a grandson node"));
*/
	//�洢xml�ĵ�
	int nRel = xmlSaveFile(CCharArr(csFilePath),doc);
	if (nRel != -1)
	{
		//cout<<"һ��xml�ĵ�������,д��"<<nRel<<"���ֽ�"<<endl;
	}

	//�ͷ��ĵ��ڽڵ㶯̬������ڴ�
	xmlFreeDoc(doc);
	return 1;
}


CCustomControlData::CCustomControlData()
{
}

CCustomControlData::CCustomControlData(const CString &csCustomName,const CArray <CCustomData,CCustomData> &customDataArray)
{
	m_csCustomName = csCustomName;
	m_customDataArray.RemoveAll();
	int i;
	for(i=0; i<customDataArray.GetSize(); i++)
	{
		m_customDataArray.Add(customDataArray.GetAt(i));
	}
}

CCustomControlData::CCustomControlData(const CCustomControlData &customControlData)
{
	*this = customControlData;
}

CCustomControlData& CCustomControlData::operator=(const CCustomControlData &customControlData)
{
	m_csCustomName = customControlData.m_csCustomName;
	m_customDataArray.RemoveAll();
	int i;
	for(i=0; i<customControlData.m_customDataArray.GetSize(); i++)
	{
		m_customDataArray.Add(customControlData.m_customDataArray.GetAt(i));
	}

	return *this;
}

CCustomControlData::~CCustomControlData()
{
}

CString CCustomControlData::GetCustomName() const
{
	return m_csCustomName;
}

void CCustomControlData::GetCustomData(CArray <CCustomData,CCustomData> &customDataArray) const
{
	customDataArray.RemoveAll();
	int i;
	for(i=0; i<m_customDataArray.GetSize(); i++)
	{
		customDataArray.Add(m_customDataArray.GetAt(i));
	}
}


// CRightDialog �Ի���

IMPLEMENT_DYNAMIC(CRightDialog, CDialogEx)

CRightDialog::CRightDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CRightDialog::IDD, pParent)
{
}

CRightDialog::~CRightDialog()
{
}

void CRightDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CRightDialog, CDialogEx)
	ON_BN_CLICKED(IDOK, &CRightDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CRightDialog::OnBnClickedCancel)
	ON_WM_SIZE()

	ON_MESSAGE(WM_RCLICK_NODE,MessageRClickNode)
END_MESSAGE_MAP()


// CRightDialog ��Ϣ��������


void CRightDialog::OnBnClickedOk()
{
}


void CRightDialog::OnBnClickedCancel()
{
}


const CString g_csAddDrawingTypeNameArray[] =
{
	_T("Image"),			//DRAWING_TYPE_Image
	_T("Button"),			//DRAWING_TYPE_Button
	_T("CheckBoxGroup"),	//DRAWING_TYPE_CheckBoxGroup
	_T("CheckBox"),			//DRAWING_TYPE_CheckBox
	_T("RadioButtonGroup"),	//DRAWING_TYPE_RadioButtonGroup
	_T("RadioButton"),		//DRAWING_TYPE_RadioButton
	_T("TextView"),			//DRAWING_TYPE_TextView
	_T("Text"),				//DRAWING_TYPE_Text
	_T("EditTextView"),		//DRAWING_TYPE_EditTextView
	_T("EditText"),			//DRAWING_TYPE_EditText
	_T("View"),				//DRAWING_TYPE_Node
	_T("ViewPaper"),		//DRAWING_TYPE_ViewPager
	_T("ListView"),			//DRAWING_TYPE_ListView
	_T("ScrollView"),		//DRAWING_TYPE_ScrollView
	_T("Slider"),			//DRAWING_TYPE_Slider
	_T(""),	//DRAWING_TYPE_Base
	_T(""),	//DRAWING_TYPE_ImageBase
	_T(""),	//DRAWING_TYPE_Empty
	_T(""),	//DRAWING_TYPE_Images
	_T(""),	//DRAWING_TYPE_GroupNode
	_T(""),	//DRAWING_TYPE_GroupItem
	_T(""),	//DRAWING_TYPE_ScrollableNode
	_T(""),	//DRAWING_TYPE_ScrollBar
	_T(""),	//DRAWING_TYPE_TabView
	_T(""),	//DRAWING_TYPE_TableView
	_T(""),	//DRAWING_TYPE_GridView
	_T(""),	//DRAWING_TYPE_Switch
	_T(""),	//DRAWING_TYPE_DrawingCustom
	_T("")	//DRAWING_TYPE_CustomNode
};

int g_nAddDrawingTypeViewImageIDArr[] =
{
	IDB_PNG_IMAGE_VIEW,		//DRAWING_TYPE_Image
	IDB_PNG_BUTTON_VIEW,	//DRAWING_TYPE_Button
	IDB_PNG_CHECK_BOX_GROUP_VIEW,//DRAWING_TYPE_CheckBoxGroup
	IDB_PNG_CHECK_BOX_VIEW,	//DRAWING_TYPE_CheckBox
	IDB_PNG_RADIO_BUTTON_GROUP_VIEW,//DRAWING_TYPE_RadioButtonGroup
	IDB_PNG_RADIO_BUTTON_VIEW,//DRAWING_TYPE_RadioButton
	IDB_PNG_TEXT_VIEW_VIEW,	//DRAWING_TYPE_TextView
	IDB_PNG_TEXT_VIEW,		//DRAWING_TYPE_Text
	IDB_PNG_EDIT_TEXT_VIEW_VIEW,//DRAWING_TYPE_EditTextView
	IDB_PNG_EDIT_TEXT_VIEW,	//DRAWING_TYPE_EditText
	IDB_PNG_VIEW_VIEW,		//DRAWING_TYPE_Node
	IDB_PNG_VIEW_VIEW,		//DRAWING_TYPE_ViewPager
	IDB_PNG_VIEW_VIEW,		//DRAWING_TYPE_ListView
	IDB_PNG_VIEW_VIEW,		//DRAWING_TYPE_ScrollView
	IDB_PNG_SLIDER_VIEW,	//DRAWING_TYPE_Slider
	0,	//DRAWING_TYPE_Base
	0,	//DRAWING_TYPE_ImageBase
	0,	//DRAWING_TYPE_Empty
	0,	//DRAWING_TYPE_Images
	0,	//DRAWING_TYPE_GroupNode
	0,	//DRAWING_TYPE_GroupItem
	0,	//DRAWING_TYPE_ScrollableNode
	0,	//DRAWING_TYPE_ScrollBar
	0,	//DRAWING_TYPE_TabView
	0,	//DRAWING_TYPE_TableView
	0,	//DRAWING_TYPE_GridView
	0,	//DRAWING_TYPE_Switch
	0,	//DRAWING_TYPE_DrawingCustom
	0	//DRAWING_TYPE_CustomNode
};

int g_nAddDrawingTypeImageIDArr[] =
{
	IDB_PNG_IMAGE_VIEW,		//DRAWING_TYPE_Image
	IDB_PNG_BUTTON_VIEW,	//DRAWING_TYPE_Button
	IDB_PNG_VIEW,			//DRAWING_TYPE_CheckBoxGroup
	IDB_PNG_CHECK_BOX,		//DRAWING_TYPE_CheckBox
	IDB_PNG_VIEW,			//DRAWING_TYPE_RadioButtonGroup
	IDB_PNG_RADIO_BUTTON,	//DRAWING_TYPE_RadioButton
	IDB_PNG_VIEW,			//DRAWING_TYPE_TextView
	IDB_PNG_TEXT,			//DRAWING_TYPE_Text
	IDB_PNG_VIEW,			//DRAWING_TYPE_EditTextView
	IDB_PNG_EDITTEXT,		//DRAWING_TYPE_EditText
	IDB_PNG_VIEW,			//DRAWING_TYPE_Node
	IDB_PNG_VIEW,			//DRAWING_TYPE_ViewPager
	IDB_PNG_VIEW,			//DRAWING_TYPE_ListView
	IDB_PNG_VIEW,			//DRAWING_TYPE_ScrollView
	IDB_PNG_SLIDER,			//DRAWING_TYPE_Slider
	0,	//DRAWING_TYPE_Base
	0,	//DRAWING_TYPE_ImageBase
	0,	//DRAWING_TYPE_Empty
	0,	//DRAWING_TYPE_Images
	0,	//DRAWING_TYPE_GroupNode
	0,	//DRAWING_TYPE_GroupItem
	0,	//DRAWING_TYPE_ScrollableNode
	0,	//DRAWING_TYPE_ScrollBar
	0,	//DRAWING_TYPE_TabView
	0,	//DRAWING_TYPE_TableView
	0,	//DRAWING_TYPE_GridView
	0,	//DRAWING_TYPE_Switch
	0,	//DRAWING_TYPE_DrawingCustom
	0	//DRAWING_TYPE_CustomNode
};

EM_DRAWING_TYPE g_emAddDrawingTypeArray[] =
{
	DRAWING_TYPE_Image,
	DRAWING_TYPE_Button,
	DRAWING_TYPE_CheckBoxGroup,
	DRAWING_TYPE_CheckBox,
	DRAWING_TYPE_RadioButtonGroup,
	DRAWING_TYPE_RadioButton,
	DRAWING_TYPE_TextView,
	DRAWING_TYPE_Text,
	DRAWING_TYPE_EditTextView,
	DRAWING_TYPE_EditText,
	DRAWING_TYPE_Node,
	DRAWING_TYPE_ViewPager,
	DRAWING_TYPE_ListView,
	DRAWING_TYPE_ScrollView,
	DRAWING_TYPE_Slider,
	DRAWING_TYPE_Base,
	DRAWING_TYPE_ImageBase,
	DRAWING_TYPE_Empty,
	DRAWING_TYPE_Images,
	DRAWING_TYPE_GroupNode,
	DRAWING_TYPE_GroupItem,
	DRAWING_TYPE_ScrollableNode,
	DRAWING_TYPE_ScrollBar,
	DRAWING_TYPE_TabView,
	DRAWING_TYPE_TableView,
	DRAWING_TYPE_GridView,
	DRAWING_TYPE_Switch,
	DRAWING_TYPE_DrawingCustom,
	DRAWING_TYPE_CustomNode
};

BOOL GetAddNodeDrawingTypeArray(CStringArray &csDrawingNameArray,CArray <int,int> &nAddViewImageIDArray,CArray <int,int> &nAddMouseImageIDArray,CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &typeArray)
{
	csDrawingNameArray.RemoveAll();
	typeArray.RemoveAll();

	int iSize = sizeof(g_csAddDrawingTypeNameArray)/sizeof(CString);
	int i;
	for(i=0; i<iSize; i++)
	{
		if(!g_csAddDrawingTypeNameArray[i].IsEmpty())
		{
			csDrawingNameArray.Add(g_csAddDrawingTypeNameArray[i]);
			nAddViewImageIDArray.Add(g_nAddDrawingTypeViewImageIDArr[i]);
			nAddMouseImageIDArray.Add(g_nAddDrawingTypeImageIDArr[i]);
			typeArray.Add(g_emAddDrawingTypeArray[i]);
		}
	}

	return TRUE;
}

BOOL GetAddNodeDrawingTypeArray(CStringArray &csDrawingNameArray,CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &typeArray)
{
	CArray <int,int> nAddViewImageIDArray;
	CArray <int,int> nAddMouseImageIDArray;
	return ::GetAddNodeDrawingTypeArray(csDrawingNameArray,nAddViewImageIDArray,nAddMouseImageIDArray,typeArray);
}

void CRightDialog::ChangeDrawingBase(const CDrawingBase *pDrawingBase)
{
	if(m_addNodeWnd.m_hWnd != NULL)
	{
		m_addNodeWnd.ChangeDrawingBase(pDrawingBase);
	}
}

void CRightDialog::GetCustomData(CString csCustomName,CArray <CCustomData,CCustomData> &customDataArray) const
{
	int i;
	for(i=0; i<m_customControlDataArray.GetSize(); i++)
	{
		if(csCustomName == m_customControlDataArray.GetAt(i).GetCustomName())
		{
			m_customControlDataArray.GetAt(i).GetCustomData(customDataArray);
			break;
		}
	}
}

BOOL CRightDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	CString csWndClass = AfxRegisterWndClass(CS_VREDRAW | CS_HREDRAW,
		::LoadCursor(NULL, IDC_ARROW),
		(HBRUSH) ::GetStockObject(WHITE_BRUSH),
		::LoadIcon(NULL, IDI_APPLICATION));
	m_addNodeWnd.Create(csWndClass,_T(""),WS_CHILD | WS_VISIBLE,CRect(0,0,0,0),this,0x1001);
	m_addNodeWnd.ShowWindow(SW_SHOW);

	CStringArray csDrawingNameArray;
	CArray <int,int> nAddViewImageIDArray;
	CArray <int,int> nAddMouseImageIDArray;
	CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> typeArray;
	::GetAddNodeDrawingTypeArray(csDrawingNameArray,nAddViewImageIDArray,nAddMouseImageIDArray,typeArray);
	int i;
	for(i=0; i<csDrawingNameArray.GetSize() && i<typeArray.GetSize(); i++)
	{
		m_addNodeWnd.AddNodeItem(csDrawingNameArray.GetAt(i),typeArray.GetAt(i),nAddViewImageIDArray.GetAt(i),nAddMouseImageIDArray.GetAt(i));
	}
/*
	CString csCustomControlsPath = MODULE_FILE_DIRECTORY+_T("\\CustomControls.xml");
	::LoadCustomControl(csCustomControlsPath,m_customControlDataArray);
	for(i=0; i<m_customControlDataArray.GetSize(); i++)
	{
		m_addNodeWnd.AddNodeItem(m_customControlDataArray.GetAt(i).GetCustomName(),DRAWING_TYPE_CustomControl,IDB_PNG_VIEW_VIEW,IDB_PNG_VIEW);
	}
*/
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CRightDialog::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	if(m_addNodeWnd.m_hWnd != NULL)
	{
		CRect clientRect;
		GetClientRect(clientRect);
		m_addNodeWnd.MoveWindow(clientRect);
	}
}


BOOL CRightDialog::PreTranslateMessage(MSG* pMsg)
{
	switch(pMsg->message)
	{
	case WM_KEYDOWN:
		{
			switch(pMsg->wParam)
			{
			case 'x':
			case 'X':
				AfxGetMainWnd()->PostMessage(pMsg->message,pMsg->wParam,pMsg->lParam);
				break;
			case 'c':
			case 'C':
				AfxGetMainWnd()->PostMessage(pMsg->message,pMsg->wParam,pMsg->lParam);
				break;
			case 'v':
			case 'V':
				AfxGetMainWnd()->PostMessage(pMsg->message,pMsg->wParam,pMsg->lParam);
				break;
			case 'z':
			case 'Z':
				AfxGetMainWnd()->PostMessage(pMsg->message,pMsg->wParam,pMsg->lParam);
				break;
			case 'y':
			case 'Y':
				AfxGetMainWnd()->PostMessage(pMsg->message,pMsg->wParam,pMsg->lParam);
				break;
			case VK_DELETE:
				AfxGetMainWnd()->PostMessage(pMsg->message,pMsg->wParam,pMsg->lParam);
				break;
			default:
				break;
			}
		}
		break;
	default:
		break;
	}

	return CDialogEx::PreTranslateMessage(pMsg);
}


BOOL CRightDialog::OnCommand(WPARAM wParam, LPARAM lParam)
{
	switch(wParam)
	{
	case ID_ADD_CUSTOM_CONTROL:
		{
			CCustomControlDialog customControlDialog;
			CStringArray csCustomControlArray;
			int i;
			for(i=0; i<m_customControlDataArray.GetSize(); i++)
			{
				csCustomControlArray.Add(m_customControlDataArray.GetAt(i).GetCustomName());
			}
			customControlDialog.InitData(csCustomControlArray);
			if(customControlDialog.DoModal() == IDOK)
			{
				CString csCustomName = customControlDialog.GetCustomName();
				CArray <CCustomData,CCustomData> customDataArray;
				customControlDialog.GetCustomData(customDataArray);

				m_addNodeWnd.AddNodeItem(csCustomName,DRAWING_TYPE_CustomControl,IDB_PNG_VIEW_VIEW,IDB_PNG_VIEW);

				m_customControlDataArray.Add(CCustomControlData(csCustomName,customDataArray));
				CString csCustomControlsPath = MODULE_FILE_DIRECTORY+_T("\\CustomControls.xml");
				::SaveCustomControl(csCustomControlsPath,m_customControlDataArray);
			}
		}
		break;
	case ID_DELETE_CUSTOM_CONTROL:
		{
			CString csItemName = m_addNodeWnd.GetSelectItemName();

			CString csInfo;
			csInfo.Format(_T("�Ƿ�ɾ���Զ���ؼ� %s ��"),csItemName);
			int iRet = MessageBox(csInfo,NULL,MB_ICONWARNING | MB_YESNO);
			if(iRet == IDYES)
			{
				if(m_addNodeWnd.DeleteSelectItem())
				{
					int i;
					for(i=0; i<m_customControlDataArray.GetSize(); i++)
					{
						if(csItemName == m_customControlDataArray.GetAt(i).GetCustomName())
						{
							m_customControlDataArray.RemoveAt(i);
							break;
						}
					}
					CString csCustomControlsPath = MODULE_FILE_DIRECTORY+_T("\\CustomControls.xml");
					::SaveCustomControl(csCustomControlsPath,m_customControlDataArray);
				}
			}
		}
		break;
	default:
		break;
	}

	return CWnd::OnCommand(wParam, lParam);
}

LRESULT CRightDialog::MessageRClickNode(WPARAM wParam,LPARAM lParam)
{
	int iSelectItem = wParam;
	BOOL bDelete = lParam;
/*
	CMenu menu;
	menu.CreatePopupMenu();
	menu.InsertMenu(MF_BYPOSITION,MF_STRING,ID_ADD_CUSTOM_CONTROL,_T("�����Զ���ؼ�"));
	menu.InsertMenu(MF_BYPOSITION,MF_STRING,ID_DELETE_CUSTOM_CONTROL,_T("ɾ���Զ���ؼ�"));
	menu.EnableMenuItem(ID_DELETE_CUSTOM_CONTROL,!bDelete);

	CPoint screenPoint;
	::GetCursorPos(&screenPoint);
	menu.TrackPopupMenu(TPM_LEFTALIGN |TPM_RIGHTBUTTON,screenPoint.x,screenPoint.y,this);
*/
	return 0;
}
