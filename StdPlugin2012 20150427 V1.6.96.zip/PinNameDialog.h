#pragma once
#include "afxwin.h"

#include "ImageWnd.h"

#include <list>
using namespace std;

class CPinImage
{
public:
	CPinImage();
	~CPinImage();
public:
	CString m_imageName;
	CString m_file;
	int m_x;
	int m_y;
	int m_width;
	int m_height;
};

void EnumPinMapTableItem(lua_State *L, const char* lpszTableName,vector <CPinImage> &pinImageArray);


// CPinNameDialog �Ի���

class CPinNameDialog : public CDialogEx
{
public:
	void InitData(CString csPinName,CString csPinPath,CString csPngName);
	CString GetPngName();
protected:
	CString m_csPinName;
	CString m_csPinPath;

	CString m_csPngName;

	vector <CPinImage> m_pinImageArray;
	bool m_bFind;
	CPinImage m_curPinImage;

	Bitmap *m_pBitmap;
	CImageWnd m_imageWnd;

	DECLARE_DYNAMIC(CPinNameDialog)

public:
	CPinNameDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPinNameDialog();

// �Ի�������
	enum { IDD = IDD_PIN_NAME_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonOpenPin();
	afx_msg void OnBnClickedOk();
	CListBox m_listBox;
	afx_msg void OnLbnSelchangeList();
	afx_msg void OnEnChangeEditImageName();
	afx_msg void OnLbnDblclkList();
};
