#pragma once

#define HISTORY_ITEM_HEIGHT			22

#define HISTORY_TYPE_NUM			4

// CHistoryDialog �Ի���

class CHistoryDialog : public CDialogEx
{
public:
	void UpdateHistory(int iCommandHistoryUndoPos,int iCommandHistoryUndoCount,int iCommandHistoryRedoCount,const CArray<int,int> &iTypeArr,const CStringArray &csHistoryNameArr);
private:
	BOOL UpdateScroll();
	int GetSelectItem(CPoint point);
	void SetHandCursor();
private:
	int m_iCommandHistoryUndoPos;
	int m_iCommandHistoryUndoCount;
	int m_iCommandHistoryRedoCount;
	CArray <int,int> m_iTypeArr;
	CStringArray m_csHistoryNameArr;

	int m_iMoveSelectItem;

	Image *m_pArrowImage;
	Image *m_pTypeImageArr[HISTORY_TYPE_NUM];

	BOOL m_bTracking;

	DECLARE_DYNAMIC(CHistoryDialog)

public:
	CHistoryDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CHistoryDialog();

// �Ի�������
	enum { IDD = IDD_HISTORY_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/);
	afx_msg void OnMouseHover(UINT nFlags, CPoint point);
	afx_msg void OnMouseLeave();
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
