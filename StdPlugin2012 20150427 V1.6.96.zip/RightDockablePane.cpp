// RightDockablePane.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "RightDockablePane.h"


// CRightDockablePane

IMPLEMENT_DYNAMIC(CRightDockablePane, CDockablePane)

CRightDockablePane::CRightDockablePane()
{

}

CRightDockablePane::~CRightDockablePane()
{
}


BEGIN_MESSAGE_MAP(CRightDockablePane, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
END_MESSAGE_MAP()



// CRightDockablePane ��Ϣ��������

void CRightDockablePane::ChangeDrawingBase(const CDrawingBase *pDrawingBase)
{
	if(m_hWnd == NULL)
		return;

	CString csName;
	if(pDrawingBase != NULL)
	{
		pDrawingBase->GetName(csName);
	}
	CString csPaneTitle = _T(" UI���");
	if(!csName.IsEmpty())
	{
//		csPaneTitle += _T(" [")+csName+_T("]");
	}
	CString csWindowText;
	GetWindowText(csWindowText);
	if(csWindowText != csPaneTitle)
		SetWindowText(csPaneTitle);

	m_rightDialog.ChangeDrawingBase(pDrawingBase);
}

void CRightDockablePane::GetCustomData(CString csCustomName,CArray <CCustomData,CCustomData> &customDataArray) const
{
	m_rightDialog.GetCustomData(csCustomName,customDataArray);
}

int CRightDockablePane::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_rightDialog.Create(IDD_RIGHT_DIALOG,this);
	m_rightDialog.ShowWindow(SW_SHOW);

	return 0;
}


void CRightDockablePane::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);

	if(m_rightDialog.m_hWnd != NULL)
	{
		CRect clientRect;
		GetClientRect(clientRect);
		m_rightDialog.MoveWindow(clientRect);
	}
}

