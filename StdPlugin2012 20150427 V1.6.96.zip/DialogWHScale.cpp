// DialogWHScale.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "DialogWHScale.h"
#include "afxdialogex.h"


// CDialogWHScale �Ի���

IMPLEMENT_DYNAMIC(CDialogWHScale, CDialogEx)

CDialogWHScale::CDialogWHScale(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDialogWHScale::IDD, pParent)
	, m_scale(1.0)
{

}

CDialogWHScale::~CDialogWHScale()
{
}

void CDialogWHScale::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_COMBO1, m_List1);
	DDX_Control(pDX, IDC_COMBO2, m_List2);
	DDX_Text(pDX, IDC_EDIT1, m_scale);
	DDV_MinMaxDouble(pDX, m_scale, 0.1, 10.0);
}


BEGIN_MESSAGE_MAP(CDialogWHScale, CDialogEx)
	ON_BN_CLICKED(IDOK, &CDialogWHScale::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON_SET_DEFAULT, &CDialogWHScale::OnBnClickedButtonSetDefault)
	ON_CBN_SELCHANGE(IDC_COMBO2, &CDialogWHScale::OnCbnSelchangeCombo2)
	ON_CBN_SELCHANGE(IDC_COMBO1, &CDialogWHScale::OnCbnSelchangeCombo1)
END_MESSAGE_MAP()


// CDialogWHScale ��Ϣ��������


void CDialogWHScale::OnBnClickedOk()
{
	if ( !UpdateData())
	{
		return;
	}
	CDialogEx::OnOK();
}


BOOL CDialogWHScale::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetIcon(hIcon, FALSE);

	int sel1 = theApp.m_Config.m_sel1;
	int sel2 = theApp.m_Config.m_sel2;
	int check = theApp.m_Config.m_check1;

	CString strFile = MODULE_FILE_DIRECTORY + _T("\\Scale.cfg");

	m_num = 0;
	int w,h;

	FILE* fp = fopen(CCharArr(strFile),"r");
	if ( NULL != fp )
	{
		char buf[80];
		while ( 3 == fscanf(fp,"%d %d %s",&w,&h,buf))
		{
			m_w[m_num] = w;
			m_h[m_num] = h;
			strcpy(m_wdh[m_num],buf);
			m_num ++;
		}
		fflush(fp);
		fclose(fp);
	}
	else
	{
		AfxMessageBox(_T("�޷���ȡ��Scale.cfg���ļ�."));
	}

	if ( m_num > 0 )
	{
		if ( sel1 >= m_num ) sel1 = m_num-1;
		if ( sel2 >= m_num ) sel2 = m_num-1;

		for ( int i = 0; i < m_num; i ++ )
		{
			CString str;
			str.Format(_T("%dx%d  %s"),m_w[i],m_h[i],CString(m_wdh[i]));
			m_List1.InsertString(-1,str);
			m_List2.InsertString(-1,str);
		}

		m_List1.SetCurSel(sel1);
		m_List2.SetCurSel(sel2);
		((CButton*)GetDlgItem(IDC_CHECK1))->SetCheck(check);

		double f1,f2;
		if ( check > 0 )
		{
			f1 = m_w[sel1];
			f2 = m_w[sel2];
			m_scale = f2/f1;
		}
		else
		{
			f1 = m_h[sel1];
			f2 = m_h[sel2];
			m_scale = f2/f1;
		}
	}
	else
	{
		m_scale = 1.0;
	}

	UpdateData(FALSE);
	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CDialogWHScale::OnBnClickedButtonSetDefault()
{
	int sel1 = m_List1.GetCurSel();
	int sel2 = m_List2.GetCurSel();	
	int check = ((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck();
	
	if ( sel1 < 0 ) sel1 = 0;
	if ( sel2 < 0 ) sel2 = 0;

	theApp.m_Config.setWHScale(sel1,sel2,check);
}


void CDialogWHScale::OnCbnSelchangeCombo2()
{
	int sel1 = m_List1.GetCurSel();
	int sel2 = m_List2.GetCurSel();	

	int check = ((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck();

	double f1,f2;
	if ( check > 0 )
	{
		f1 = m_w[sel1];
		f2 = m_w[sel2];
		m_scale = f2/f1;
	}
	else
	{
		f1 = m_h[sel1];
		f2 = m_h[sel2];
		m_scale = f2/f1;
	}

	UpdateData(FALSE);
}


void CDialogWHScale::OnCbnSelchangeCombo1()
{
	int sel1 = m_List1.GetCurSel();
	int sel2 = m_List2.GetCurSel();	

	int check = ((CButton*)GetDlgItem(IDC_CHECK1))->GetCheck();

	double f1,f2;
	if ( check > 0 )
	{
		f1 = m_w[sel1];
		f2 = m_w[sel2];
		m_scale = f2/f1;
	}
	else
	{
		f1 = m_h[sel1];
		f2 = m_h[sel2];
		m_scale = f2/f1;
	}

	UpdateData(FALSE);

}
