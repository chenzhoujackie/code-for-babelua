#pragma once


// CDialogName �Ի���

class CDialogName : public CDialogEx
{
	DECLARE_DYNAMIC(CDialogName)

public:
	CDialogName(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDialogName();
	void SetInitName(CString csName);
	void SetCompareName(CStringArray& Names);
	void SetCompareName2(CMapStringToString* pNames2);
	CString GetName();

// �Ի�������
	enum { IDD = IDD_DIALOG_NAME };

	virtual BOOL OnInitDialog();

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
	afx_msg void OnBnClickedOk();
	afx_msg void OnNameChange();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);

	void ShowError(CString strError);
private:
	CString m_strName;
	CStringArray m_Names;
	CMapStringToString* m_pNames2;
public:
};
