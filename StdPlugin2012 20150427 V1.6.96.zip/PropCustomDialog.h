#pragma once

#include "XGroupBox.h"
#include "XEdit.h"

#include "CustomControlDialog.h"

#define ID_CUSTOM_STATIC_START			1000
#define ID_CUSTOM_EDIT_DATA_START		2000
#define ID_CUSTOM_COLOR_DATA_START		3000

// CPropCustomDialog �Ի���

class CPropCustomDialog : public CDialogEx
{
public:
	void InitData(const CDrawingBase *pDrawingBase);
	void SaveChangeUIProp();
private:
	void ChangeDrawingBase(const CDrawingBase *pDrawingBase);
	void ChangeUIProp(EM_UI_PROP_TYPE emUIPropType);
	void EndChangeUIProp();

	void ChangeUIPropCustom();
	void ReleasePropWndArray();
private:
	const CDrawingBase *m_pDrawingBase;

	BOOL m_bEditData;

	BOOL m_bChangeUIProp;				//�Ƿ��޸�UI����
	EM_UI_PROP_TYPE m_emUIPropType;		//�޸ĵ�UI�������

	CFont m_font;
	CStatic *m_pPropStaticArray[CUSTOM_PAR_NUM];
	CXEdit *m_pPropEditDataArray[CUSTOM_PAR_NUM];
	CMFCColorButton *m_pPropColorDataArray[CUSTOM_PAR_NUM];

	DECLARE_DYNAMIC(CPropCustomDialog)

public:
	CPropCustomDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPropCustomDialog();

// �Ի�������
	enum { IDD = IDD_PROP_CUSTOM_DIALOG };
	CXGroupBox m_propCustomStatic;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnEnChangeEditText(UINT nID);
	afx_msg void OnBnClickedMfccolorbuttonText(UINT nID);
	afx_msg void OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/);

	LRESULT MessageEditKillFocus(WPARAM wParam,LPARAM lParam);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};
