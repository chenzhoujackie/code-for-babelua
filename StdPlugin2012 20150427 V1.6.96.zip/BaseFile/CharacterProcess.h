#ifndef _CHARACTER_PROCESS_H
#define _CHARACTER_PROCESS_H


class CCharArr
{
public:
	CCharArr();
	CCharArr(const CCharArr &szArr);
	CCharArr(const CString& stringSrc);
	CCharArr(LPCSTR lpsz);
	CCharArr(LPCWSTR lpsz);
	~CCharArr();
	const CCharArr& operator=(const CCharArr &szArr);
	const CCharArr& operator=(LPCSTR lpsz);
	const CCharArr& operator=(LPCWSTR lpsz);
	const CCharArr& operator=(const CString& stringSrc);;
	operator char*() const;
private:
	char *m_pchData;
};

class CWCharArr
{
public:
	CWCharArr();
	CWCharArr(const CWCharArr &szArr);
	CWCharArr(const CString& stringSrc);
	CWCharArr(LPCSTR lpsz);
	CWCharArr(LPCWSTR lpsz);
	~CWCharArr();
	const CWCharArr& operator=(const CWCharArr &szArr);
	const CWCharArr& operator=(LPCSTR lpsz);
	const CWCharArr& operator=(LPCWSTR lpsz);
	const CWCharArr& operator=(const CString& stringSrc);;
	operator WCHAR*() const;
private:
	WCHAR *m_pchData;
};

#endif