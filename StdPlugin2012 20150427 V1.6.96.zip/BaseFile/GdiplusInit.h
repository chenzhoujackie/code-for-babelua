#ifndef _GDIPLUS_INIT_H
#define _GDIPLUS_INIT_H

#ifndef ULONG_PTR
typedef unsigned long ULONG_PTR;
#endif
#include "GdiPlus.h"
#pragma comment(lib,"gdiplus.lib")
using namespace Gdiplus;

class CGdiplusInit
{
public:
	CGdiplusInit()
	{
		Gdiplus::GdiplusStartupInput gdiplusStartupInput;
		Gdiplus::GdiplusStartup(&m_gdiplusToken, &gdiplusStartupInput, NULL);
	}
	~CGdiplusInit()
	{
		Gdiplus::GdiplusShutdown(m_gdiplusToken);
	}
private:
	ULONG_PTR m_gdiplusToken;
};

const CGdiplusInit g_gdiplusInit;

#endif
