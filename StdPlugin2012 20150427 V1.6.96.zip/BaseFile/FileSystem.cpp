#include "stdafx.h"
#include "FileSystem.h"

BOOL FindFile(const CString &csDirectory,CString csSuffix,CStringArray &csFilePathArr)
{
	CString csTemp = csSuffix;
	if(!csTemp.IsEmpty())
		csSuffix.Format(_T("*.%s"),csTemp);
	else
		csSuffix = _T("*.*");

	CString csFileFind;
	if(csDirectory.Right(1) != '\\')
		csFileFind = csDirectory + '\\' + csSuffix;
	else
		csFileFind = csDirectory + csSuffix;

	CFileFind fileFind;
	BOOL bFileFind = fileFind.FindFile(csFileFind);
	while(bFileFind)
	{
		bFileFind = fileFind.FindNextFile();
		if(fileFind.IsDirectory() && !fileFind.IsDots())
		{
			//FindFile(fileFind.GetFilePath(),lpszSuffix,csFilePathArr);
		}
		else if(!fileFind.IsDirectory() && !fileFind.IsDots())
		{
			csFilePathArr.Add(fileFind.GetFilePath());
		}
	}
	fileFind.Close();

	return TRUE;
}

BOOL FindDirectory(const CString &csDirectory,CStringArray &csDirectoryArr,BOOL bPathOrName)
{
	CString csFileFind;
	if(csDirectory.Right(1) != '\\')
		csFileFind = csDirectory + _T("\\*.*");
	else
		csFileFind = csDirectory + _T("*.*");

	CFileFind fileFind;
	BOOL bFileFind = fileFind.FindFile(csFileFind);
	while(bFileFind)
	{
		bFileFind = fileFind.FindNextFile();
		if(fileFind.IsDirectory() && !fileFind.IsDots())
		{
			if(bPathOrName)
			{
				csDirectoryArr.Add(fileFind.GetFilePath());
			}
			else
			{
				csDirectoryArr.Add(fileFind.GetFileName());
			}
		}
		else if(!fileFind.IsDirectory() && !fileFind.IsDots())
		{
		}
	}
	fileFind.Close();

	return TRUE;
}

BOOL FindFileDirectory(const CString &csDirectory,CStringArray &csFilePathArr,CStringArray &csDirectoryArr)
{
	CString csFileFind;
	if(csDirectory.Right(1) != '\\')
		csFileFind = csDirectory + _T("\\*.*");
	else
		csFileFind = csDirectory + _T("*.*");

	CFileFind fileFind;
	BOOL bFileFind = fileFind.FindFile(csFileFind);
	while(bFileFind)
	{
		bFileFind = fileFind.FindNextFile();
		if(fileFind.IsDirectory() && !fileFind.IsDots())
		{
			csDirectoryArr.Add(fileFind.GetFilePath());
		}
		else if(!fileFind.IsDirectory() && !fileFind.IsDots())
		{
			csFilePathArr.Add(fileFind.GetFilePath());
		}
	}
	fileFind.Close();

	return TRUE;
}

void CopyFiles(CString csSrcDirectory,CString csDesDirectory)
{
	CString csSuffix = csSrcDirectory;
	if(csSuffix.Right(1) != '\\')
		csSuffix += '\\';
	csSuffix += _T("*.*");

	CFileFind fileFind;
	BOOL bFileFind = fileFind.FindFile(csSuffix);
	while(bFileFind)
	{
		bFileFind = fileFind.FindNextFile();
		CString csTempSrcPath = fileFind.GetFilePath();
		CString csTempDesPath = csTempSrcPath;
		csTempDesPath.Replace(csSrcDirectory,csDesDirectory);
		if(fileFind.IsDirectory() && !fileFind.IsDots())
		{
			CreateDirectory(csTempDesPath,NULL);
			CopyFiles(csTempSrcPath,csTempDesPath);
		}
		else if(!fileFind.IsDirectory() && !fileFind.IsDots())
		{
			CopyFile(csTempSrcPath,csTempDesPath,FALSE);
		}
	}
}


BOOL CreateDirectory(CString csDirectory)
{
	return CreateDirectory(csDirectory,NULL);
}

void CreateMultipleDirectory(CString csDirectory)
{
	if(csDirectory.GetLength() <= 0)
		return;
	if(csDirectory.Right(1) == '\\')
	{
		csDirectory = csDirectory.Left(csDirectory.GetLength()-1);
	}
	if(GetFileAttributes(csDirectory) != -1)
		return;

	int iIndex = csDirectory.ReverseFind('\\');

	CreateMultipleDirectory(csDirectory.Left(iIndex));
	CreateDirectory(csDirectory,NULL);
}

CString GetLastFileFolderName(CString csDirectory)
{
	CString csLastFileFolderName;
	if(csDirectory.GetLength() <= 0)
		return csLastFileFolderName;

	//����ļ���·�������\��������ɾ��\����
	if(csDirectory.GetAt(csDirectory.GetLength()-1) == '\\')
	{
		csDirectory = csDirectory.Left(csDirectory.GetLength()-1);
	}

	int iIndex = csDirectory.ReverseFind('\\');
	if(iIndex >= 0)
	{
		csLastFileFolderName = csDirectory.Mid(iIndex+1,csDirectory.GetLength()-iIndex-1);
	}
	return csLastFileFolderName;
}

CString GetFileDirectory(CString csFilePath)
{
	int iIndex = csFilePath.ReverseFind('\\');
	CString csDirectory;
	if(iIndex >= 0)
		csDirectory = csFilePath.Left(iIndex);
	return csDirectory;
}

BOOL IsDirectory(CString csPath)
{
	DWORD dwAttributes = GetFileAttributes(csPath);
	if(dwAttributes == -1)
		return FALSE;
	if((dwAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY)
		return TRUE;
	else
		return FALSE;
}

BOOL IsDirectoryExist(CString csDirectory)
{
	return IsDirectory(csDirectory);
}

BOOL IsFile(CString csPath)
{
	DWORD dwAttributes = GetFileAttributes(csPath);
	if(dwAttributes == -1)
		return FALSE;
	if(!((dwAttributes & FILE_ATTRIBUTE_DIRECTORY) == FILE_ATTRIBUTE_DIRECTORY))
		return TRUE;
	else
		return FALSE;
}

BOOL IsFileExist(CString csFilePath)
{
#ifdef _UNICODE
	if(_waccess(csFilePath,0) == 0)
		return TRUE;
#else
	if(_access(csFilePath,0) == 0)
		return TRUE;
#endif
	return FALSE;
}


CString GetFileName(CString csFilePath,BOOL bIncludeKind)
{
	CString csFileName;
	int nPos = csFilePath.ReverseFind('\\');
	if(nPos >= 0)
	{
		csFileName = csFilePath.Mid(nPos+1);
		if(!bIncludeKind)
		{
			int iSeat = csFileName.ReverseFind('.');
			if(iSeat >= 0)
				csFileName = csFileName.Left(iSeat);
		}
	}
	return csFileName;
}

BOOL DeleteFile(CString csFileName,BOOL bDelete)
{
	TCHAR szPathArr[MAX_PATH]  = {0};
	_tcscpy(szPathArr,csFileName);
	SHFILEOPSTRUCT  shDelFile;
	memset(&shDelFile,0,sizeof(SHFILEOPSTRUCT));
	shDelFile.fFlags |= FOF_SILENT;
	shDelFile.fFlags |= FOF_NOERRORUI;
	shDelFile.fFlags |= FOF_NOCONFIRMATION;
	shDelFile.wFunc = FO_DELETE;
	shDelFile.pFrom = szPathArr;
	shDelFile.pTo = NULL;
	if(bDelete)
	{
		shDelFile.fFlags &= ~FOF_ALLOWUNDO;	//don't use Recycle Bin
	}
	else
	{
		shDelFile.fFlags |= FOF_ALLOWUNDO;	//send to Recycle Bin
	}
	return (SHFileOperation(&shDelFile) == 0);
}


CString GetModuleFileDirectory()
{
	TCHAR szFileNameArr[MAX_PATH];
	GetModuleFileName(NULL,szFileNameArr,MAX_PATH);
	CString csFileName = szFileNameArr;
	int iIndex = csFileName.ReverseFind('\\');
	CString csFilePath;
	if(iIndex >= 0)
		csFilePath = csFileName.Left(iIndex);
	return csFilePath;
}

CString GetProgramFilesDirectory()
{
	CString csProgramFilesDirectory = GetWindowsDirectory();
	csProgramFilesDirectory.Replace(_T("WINDOWS"),_T("Program Files"));
	return csProgramFilesDirectory;
}

CString GetWindowsDirectory()
{
	TCHAR szPath[MAX_PATH];
	GetWindowsDirectory(szPath,MAX_PATH);
	CString csWindowDirectory = szPath;
	return csWindowDirectory;
}

CString GetSystemDirectory()
{
	TCHAR szSystemDirectory[MAX_PATH];
	GetSystemDirectory(szSystemDirectory,MAX_PATH);
	CString csSystemDirectory = szSystemDirectory;
	return csSystemDirectory;
}

CString GetDeskDirectory()
{
	LPITEMIDLIST pItemidList;
	SHGetSpecialFolderLocation(NULL,CSIDL_DESKTOP,&pItemidList); 
	TCHAR szPath[MAX_PATH];
	SHGetPathFromIDList(pItemidList,szPath);
	CString csDeskDirectory = szPath;
	return csDeskDirectory;
}


#ifdef _CHARACTER_PROCESS_H
BOOL SetRegKey(HKEY hOpenKey,CString csSubKey,CString csValueName,CString csValue)
{
	HKEY hKEY;
	DWORD dwDisp;
	long lRet = RegCreateKeyEx(hOpenKey,csSubKey,0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKEY,&dwDisp);
	//::RegOpenKeyEx(hOpenKey,csSubKey,0,KEY_WRITE,&hKEY);
	if(lRet != ERROR_SUCCESS)
		return FALSE;

	CCharArr charArr = csValue;
	lRet = ::RegSetValueEx(hKEY,csValueName,NULL,REG_SZ,(BYTE*)(CHAR*)charArr,(DWORD)strlen((CHAR*)charArr));
	if(lRet != ERROR_SUCCESS)
	{
		RegCloseKey(hKEY);
		return FALSE;
	}

	RegCloseKey(hKEY);
	return TRUE;
}

HRESULT CreateLink(CString csAppPath,CString csLink,CString csIconLocation,CString csWorkingDirectory,CString csDescription)
{
	CoInitialize(NULL);

	IShellLink *pShellLink;
	HRESULT lResult = CoCreateInstance(CLSID_ShellLink,NULL,CLSCTX_INPROC_SERVER,IID_IShellLink,(void **)&pShellLink);
	if(!SUCCEEDED(lResult))
		return lResult;
	pShellLink->SetPath(csAppPath);
	pShellLink->SetIconLocation(csIconLocation,0);
	pShellLink->SetWorkingDirectory(csWorkingDirectory);
	pShellLink->SetDescription(csDescription);
	pShellLink->SetShowCmd(SW_SHOW);

	IPersistFile *pPersistFile;
	lResult = pShellLink->QueryInterface(IID_IPersistFile,(void **)&pPersistFile);
	if(!SUCCEEDED(lResult))
		return lResult;
	CWCharArr wCharArr = csLink;
	pPersistFile->Save(wCharArr,TRUE);
	pPersistFile->Release();
	pShellLink->Release();

	CoUninitialize();
	return lResult;
}
#endif


BOOL ReadFileToByte(CString csFilePath,BYTE **pFileByte,long &lFileLen)
{
	if(*pFileByte = NULL)
		return FALSE;
	CFile file;
	if(!file.Open(csFilePath,CFile::modeRead|CFile::typeBinary))
		return FALSE;
	lFileLen = (long)file.GetLength();
	*pFileByte = new BYTE[lFileLen];
	file.Read(*pFileByte,lFileLen);
	file.Close();
	return TRUE;
}

BOOL SaveByteToFile(CString csFilePath,BYTE *pFileByte,long lFileLen)
{
	if(pFileByte == NULL)
		return FALSE;
	CFile file;
	if(!file.Open(csFilePath,CFile::modeCreate|CFile::modeReadWrite))
		return FALSE;
	file.Write(pFileByte,lFileLen);
	file.Close();
	return TRUE;
}

