#include "stdafx.h"
#include "DataTypeConversion.h"

double _wtof(const wchar_t *);

#ifdef _UNICODE
#define _tstof		_wtof
#else
#define _tstof		atof
#endif

double _wtof(const wchar_t *str)
{
    wchar_t *stopscan;
    return wcstod(str,&stopscan);
}

BOOL CStringToBool(const CString &csStr)
{
	return _ttoi(csStr);
}

BYTE CStringToBYTE(const CString &csStr)
{
	return _ttoi(csStr);
}

int CStringToInt(const CString &csStr)
{
	return _ttoi(csStr);
}

long CStringToLong(const CString &csStr)
{
	return _ttol(csStr);
}

float CStringToFloat(const CString &csStr)
{
	return (float)_tstof(csStr);
}

double CStringToDouble(const CString &csStr)
{
	return _tstof(csStr);
}

LONGLONG CStringToLONGLONG(const CString &csStr)
{
	return _ttoi64(csStr);
}

CString BoolToCString(BOOL bData)
{
	CString csStr;
	csStr.Format(_T("%d"),bData);
	return csStr;
}

CString BYTEToCString(BYTE byData)
{
	CString csStr;
	csStr.Format(_T("%d"),byData);
	return csStr;
}

CString IntToCString(int iData)
{
	CString csStr;
	csStr.Format(_T("%d"),iData);
	return csStr;
}

CString LongToCString(long lData)
{
	CString csStr;
	csStr.Format(_T("%d"),lData);
	return csStr;
}

CString FloatToCString(float fData,int iDecimalPoint)
{
	CString csDecimalPoint;
	csDecimalPoint.Format(_T("%%0.%df"),iDecimalPoint);
	CString csStr;
	csStr.Format(csDecimalPoint,fData);
	return csStr;
}

CString DoubleToCString(double dData,int iDecimalPoint)
{
	CString csDecimalPoint;
	csDecimalPoint.Format(_T("%%0.%df"),iDecimalPoint);
	CString csStr;
	csStr.Format(csDecimalPoint,dData);
	return csStr;
}

CString LONGLONGToCString(LONGLONG llData)
{
	CString csStr;
	csStr.Format(_T("%I64d"),llData);
	return csStr;
}
