#ifndef _DATA_TYPE_CONVERSION_H
#define _DATA_TYPE_CONVERSION_H

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define DECIMAL_POINT_DEFAULT		2

BOOL CStringToBool(const CString &csStr);
BYTE CStringToBYTE(const CString &csStr);
int CStringToInt(const CString &csStr);
long CStringToLong(const CString &csStr);
float CStringToFloat(const CString &csStr);
double CStringToDouble(const CString &csStr);
LONGLONG CStringToLONGLONG(const CString &csStr);

CString BoolToCString(BOOL bData);
CString BYTEToCString(BYTE byData);
CString IntToCString(int iData);
CString LongToCString(long lData);
CString FloatToCString(float fData,int iDecimalPoint = DECIMAL_POINT_DEFAULT);
CString DoubleToCString(double dData,int iDecimalPoint = DECIMAL_POINT_DEFAULT);
CString LONGLONGToCString(LONGLONG llData);

#endif
