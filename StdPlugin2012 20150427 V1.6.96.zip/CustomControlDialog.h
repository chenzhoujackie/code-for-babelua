#pragma once

#define CUSTOM_PAR_NUM			5

// CCustomControlDialog �Ի���

class CCustomControlDialog : public CDialogEx
{
public:
	void InitData(const CStringArray &csCustomNameArray);
	CString GetCustomName() const;
	void GetCustomData(CArray <CCustomData,CCustomData> &customDataArray) const;
private:
	void CustomPropChange();
private:
	CStringArray m_csCustomNameArray;
	CString m_csCustomName;
	CArray <CCustomData,CCustomData> m_customDataArray;

	DECLARE_DYNAMIC(CCustomControlDialog)

public:
	CCustomControlDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CCustomControlDialog();

// �Ի�������
	enum { IDD = IDD_CUSTOM_CONTROL_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnEnChangeEditCustomName();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	afx_msg void OnEnChangeEditCustomPar1();
	afx_msg void OnEnChangeEditCustomPar2();
	afx_msg void OnEnChangeEditCustomPar3();
	afx_msg void OnEnChangeEditCustomPar4();
	afx_msg void OnEnChangeEditCustomPar5();
	afx_msg void OnCbnSelchangeComboDataType1();
	afx_msg void OnCbnSelchangeComboDataType2();
	afx_msg void OnCbnSelchangeComboDataType3();
	afx_msg void OnCbnSelchangeComboDataType4();
	afx_msg void OnCbnSelchangeComboDataType5();
};
