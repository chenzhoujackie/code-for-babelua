// PropButtonDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "PropButtonDialog.h"
#include "afxdialogex.h"

#include "FileDialogEx.h"
#include "MainFrm.h"

#include "PinNameDialog.h"

// CPropButtonDialog �Ի���

IMPLEMENT_DYNAMIC(CPropButtonDialog, CDialogEx)

CPropButtonDialog::CPropButtonDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CPropButtonDialog::IDD, pParent)
{
	m_pDrawingBase = NULL;

	m_bEditData = TRUE;

	m_bChangeUIProp = FALSE;
	m_emUIPropType = (EM_UI_PROP_TYPE)-1;
}

CPropButtonDialog::~CPropButtonDialog()
{
}

void CPropButtonDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_PROP_IMAGE, m_propImageStatic);
	DDX_Control(pDX, IDC_EDIT_NODE_G9LEFT, m_nodeG9LeftEdit);
	DDX_Control(pDX, IDC_EDIT_NODE_G9RIGHT, m_nodeG9RightEdit);
	DDX_Control(pDX, IDC_EDIT_NODE_G9TOP, m_nodeG9TopEdit);
	DDX_Control(pDX, IDC_EDIT_NODE_G9BOTTOM, m_nodeG9BottomEdit);
}


BEGIN_MESSAGE_MAP(CPropButtonDialog, CDialogEx)
	ON_BN_CLICKED(IDOK, &CPropButtonDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CPropButtonDialog::OnBnClickedCancel)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON_NODE_IMAGE1, &CPropButtonDialog::OnBnClickedButtonNodeImage1)
	ON_BN_CLICKED(IDC_BUTTON_NODE_IMAGE2, &CPropButtonDialog::OnBnClickedButtonNodeImage2)
	ON_BN_CLICKED(IDC_BUTTON_GET_WH, &CPropButtonDialog::OnBnClickedButtonGetWh)
	ON_EN_CHANGE(IDC_EDIT_NODE_G9LEFT, &CPropButtonDialog::OnEnChangeEditNodeG9left)
	ON_EN_CHANGE(IDC_EDIT_NODE_G9RIGHT, &CPropButtonDialog::OnEnChangeEditNodeG9right)
	ON_EN_CHANGE(IDC_EDIT_NODE_G9TOP, &CPropButtonDialog::OnEnChangeEditNodeG9top)
	ON_EN_CHANGE(IDC_EDIT_NODE_G9BOTTOM, &CPropButtonDialog::OnEnChangeEditNodeG9bottom)
	ON_BN_CLICKED(IDC_BUTTON_GET_LUA_PIN, &CPropButtonDialog::OnBnClickedButtonGetLuaPin)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR_LUA_PIN, &CPropButtonDialog::OnBnClickedButtonClearLuaPin)
	ON_WM_CONTEXTMENU()
	ON_MESSAGE(WM_EDIT_KILLFOCUS,MessageEditKillFocus)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR_NODE_IMAGE2, &CPropButtonDialog::OnBnClickedButtonClearNodeImage2)
END_MESSAGE_MAP()


// CPropButtonDialog ��Ϣ��������

void CPropButtonDialog::InitData(const CDrawingBase *pDrawingBase)
{
	m_pDrawingBase = pDrawingBase;

	ChangeDrawingBase(m_pDrawingBase);
}

void CPropButtonDialog::SaveChangeUIProp()
{
	EndChangeUIProp();
}

void CPropButtonDialog::ChangeDrawingBase(const CDrawingBase *pDrawingBase)
{
	m_bEditData = FALSE;

	EM_DRAWING_TYPE type = (EM_DRAWING_TYPE)-1;
	if(pDrawingBase != NULL)
		type = pDrawingBase->GetDrawingType();

	CString csFileName;
	CString csFile2Name;
	CString csPickFile;
	int leftWidth = 0;
	int rightWidth = 0;
	int topWidth = 0;
	int bottomWidth = 0;

	GetDlgItem(IDC_BUTTON_NODE_IMAGE2)->EnableWindow(TRUE);
	switch(type)
	{
	case DRAWING_TYPE_Image:
		{
			GetDlgItem(IDC_BUTTON_NODE_IMAGE2)->EnableWindow(FALSE);

			CDrawingImage *pDrawingImage = CDrawingImage::CDrawingBaseToCDrawingImage(const_cast<CDrawingBase*>(pDrawingBase));
			if(pDrawingImage != NULL)
			{
				pDrawingImage->GetFile(csFileName);
				pDrawingImage->GetPackFile(csPickFile);
				pDrawingImage->GetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);
			}
		}
		break;
	case DRAWING_TYPE_Button:
	case DRAWING_TYPE_CheckBox:
	case DRAWING_TYPE_RadioButton:
		{
			CDrawingButton *pDrawingButton = CDrawingButton::CDrawingBaseToCDrawingButton(const_cast<CDrawingBase*>(pDrawingBase));
			if(pDrawingButton != NULL)
			{
				pDrawingButton->GetFile(csFileName);
				pDrawingButton->GetFile2(csFile2Name);
				pDrawingButton->GetPackFile(csPickFile);
				pDrawingButton->GetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);
			}
		}
		break;
	default:
		break;
	}

	GetDlgItem(IDC_BUTTON_NODE_IMAGE1)->SetWindowText(csFileName);
	GetDlgItem(IDC_BUTTON_NODE_IMAGE2)->SetWindowText(csFile2Name);
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_NODE_G9LEFT),::IntToCString(leftWidth));
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_NODE_G9RIGHT),::IntToCString(rightWidth));
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_NODE_G9TOP),::IntToCString(topWidth));
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_NODE_G9BOTTOM),::IntToCString(bottomWidth));
	if(csPickFile.IsEmpty())
		GetDlgItem(IDC_BUTTON_GET_LUA_PIN)->SetWindowText(STRING_CLICK_SELECT_LUA);
	else
		GetDlgItem(IDC_BUTTON_GET_LUA_PIN)->SetWindowText(csPickFile);

	m_bEditData = TRUE;

	m_bChangeUIProp = FALSE;
	m_emUIPropType = (EM_UI_PROP_TYPE)-1;
}

BOOL CPropButtonDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	m_propImageStatic.SetTextColor(RGB(0,0,255));
	m_propImageStatic.SetBorderColor(RGB(0,0,255));//107,143,246));

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPropButtonDialog::OnBnClickedOk()
{
}


void CPropButtonDialog::OnBnClickedCancel()
{
}



void CPropButtonDialog::OnBnClickedButtonNodeImage1()
{
	CString strLuaPin;
	GetDlgItem(IDC_BUTTON_GET_LUA_PIN)->GetWindowText(strLuaPin);
	if(strLuaPin.IsEmpty() || strLuaPin == STRING_CLICK_SELECT_LUA)
	{
		const TCHAR szFilter[] = _T("Image Files (*.png)|*.png|All Files (*.*)|*.*||");
		const TCHAR szExt[] = _T("png");

		CString csImagesDirectory = IMAGES_DIRECTORY + _T("\\");
		CString csImageText;
		GetDlgItem(IDC_BUTTON_NODE_IMAGE1)->GetWindowText(csImageText);
		csImageText.Replace(_T("/"),_T("\\"));
		CString csFileName = csImagesDirectory+csImageText;

		CFileDialogEx dlg(TRUE, szExt, csFileName,//NULL, 
			OFN_READONLY |OFN_NONETWORKBUTTON, szFilter, this);
		dlg.m_ofn.lpstrTitle = _T("��Resource/imagesĿ¼��ѡ��pngͼƬ");
		dlg.m_ofn.lpstrInitialDir = csImagesDirectory;

		EnableKeyHook(false);
		if(dlg.DoModal() == IDOK)
		{
			CString str = dlg.GetPathName();
			CString strImages = IMAGES_DIRECTORY + _T("\\");
			if ( -1 == str.Find(strImages))
			{
				AfxMessageBox(_T("�˴�����ѡ��Resource/imagesĿ¼�µ�ͼƬ."));
				EnableKeyHook(true);
				return;
			}
			str.Replace(strImages,_T(""));
			str.Replace(_T("\\"),_T("/"));
			GetDlgItem(IDC_BUTTON_NODE_IMAGE1)->SetWindowText(str);

			::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_csFile,(LPARAM)&str);
		}
		EnableKeyHook(true);
	}
	else
	{
		CString strLuaPinPath = SCRIPTS_DIRECTORY + _T("\\") + strLuaPin;
		strLuaPinPath.Replace(_T("/"),_T("\\"));
		CString csImageText;
		GetDlgItem(IDC_BUTTON_NODE_IMAGE1)->GetWindowText(csImageText);

		CPinNameDialog pinNameDialog;
		pinNameDialog.InitData(strLuaPin,strLuaPinPath,csImageText);
		if(pinNameDialog.DoModal() == IDOK)
		{
			CString str = pinNameDialog.GetPngName();
			GetDlgItem(IDC_BUTTON_NODE_IMAGE1)->SetWindowText(str);

			::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_csFile,(LPARAM)&str);

			//��ȡƴͼ�ļ�����
			OnBnClickedButtonGetWh();
		}
	}
}


void CPropButtonDialog::OnBnClickedButtonNodeImage2()
{
	CString strLuaPin;
	GetDlgItem(IDC_BUTTON_GET_LUA_PIN)->GetWindowText(strLuaPin);
	if(strLuaPin.IsEmpty() || strLuaPin == STRING_CLICK_SELECT_LUA)
	{
		const TCHAR szFilter[] = _T("Image Files (*.png)|*.png|All Files (*.*)|*.*||");
		const TCHAR szExt[] = _T("png");

		CString csImagesDirectory = IMAGES_DIRECTORY + _T("\\");
		CString csImageText;
		GetDlgItem(IDC_BUTTON_NODE_IMAGE2)->GetWindowText(csImageText);
		csImageText.Replace(_T("/"),_T("\\"));
		CString csFileName = csImagesDirectory+csImageText;

		CFileDialogEx dlg(TRUE, szExt, csFileName,//NULL, 
			OFN_READONLY |OFN_NONETWORKBUTTON, szFilter, this);
		dlg.m_ofn.lpstrTitle = _T("��Resource/imagesĿ¼��ѡ��pngͼƬ");
		dlg.m_ofn.lpstrInitialDir = csImagesDirectory;

		EnableKeyHook(false);
		if(dlg.DoModal() == IDOK)
		{
			CString str = dlg.GetPathName();
			CString strImages = IMAGES_DIRECTORY + _T("\\");
			if ( -1 == str.Find(strImages))
			{
				AfxMessageBox(_T("�˴�����ѡ��Resource/imagesĿ¼�µ�ͼƬ."));
				EnableKeyHook(true);
				return;
			}
			str.Replace(strImages,_T(""));
			str.Replace(_T("\\"),_T("/"));
			GetDlgItem(IDC_BUTTON_NODE_IMAGE2)->SetWindowText(str);

			::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_csFile2,(LPARAM)&str);
		}
		EnableKeyHook(true);
	}
	else
	{
		CString strLuaPinPath = SCRIPTS_DIRECTORY + _T("\\") + strLuaPin;
		strLuaPinPath.Replace(_T("/"),_T("\\"));
		CString csImageText;
		GetDlgItem(IDC_BUTTON_NODE_IMAGE2)->GetWindowText(csImageText);

		CPinNameDialog pinNameDialog;
		pinNameDialog.InitData(strLuaPin,strLuaPinPath,csImageText);
		if(pinNameDialog.DoModal() == IDOK)
		{
			CString str = pinNameDialog.GetPngName();
			GetDlgItem(IDC_BUTTON_NODE_IMAGE2)->SetWindowText(str);

			::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_csFile2,(LPARAM)&str);
		}
	}
}

void CPropButtonDialog::OnBnClickedButtonClearNodeImage2()
{
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_csFile2,(LPARAM)&CString(_T("")));
}

int GetStringNum(const CString &csString,int iStartIndex,CString &csNum)
{
	csNum.Empty();

	int iEndIndex = iStartIndex;
	for(; iEndIndex < csString.GetLength(); iEndIndex++)
	{
		TCHAR tChar = csString.GetAt(iEndIndex);
		if(!(tChar >= '0' && tChar <= '9'))
			break;

		csNum += tChar;
	}
	return iEndIndex;
}

void CPropButtonDialog::OnBnClickedButtonGetWh()
{
	CString strImage;
	GetDlgItem(IDC_BUTTON_NODE_IMAGE1)->GetWindowText(strImage);
	CString strLuaPin;
	GetDlgItem(IDC_BUTTON_GET_LUA_PIN)->GetWindowText(strLuaPin);
	if(strLuaPin.IsEmpty() || strLuaPin == STRING_CLICK_SELECT_LUA)
	{
		CString strFileName  = IMAGES_DIRECTORY + _T("\\") + strImage;

		int width = 0;
		int height = 0;
		if(::GetImageWidthHeight(strFileName,width,height))
		{
			::SendMessage(GetParent()->GetSafeHwnd(),WM_GET_WIDTH_HEIGHT,width,height);
		}
	}
	else
	{
		CString strLuaPinPath = SCRIPTS_DIRECTORY + _T("\\") + strLuaPin;
		CString csLuaPinString;
		CStdioFile stdioFile;
		if(stdioFile.Open(strLuaPinPath,CFile::modeRead))
		{
			CString csString;
			while(stdioFile.ReadString(csString))
			{
				csLuaPinString += csString;
			}
			stdioFile.Close();
		}

		//��luaƴͼ�ļ��в�������ΪstrImage��width,height
		int width = 0;
		int height = 0;
		int iImageIndex = csLuaPinString.Find(strImage);
		if(iImageIndex >= 0)
		{
			int iLeftIndex = csLuaPinString.Find('{',iImageIndex);
			int iWidthIndex = csLuaPinString.Find(_T("width"),iLeftIndex);
			if(iWidthIndex >= 0)
			{
				int iWidthEqualIndex = csLuaPinString.Find(_T("="),iWidthIndex);
				CString csWidthNum;
				int iWidthEndIndex = ::GetStringNum(csLuaPinString,iWidthEqualIndex+1,csWidthNum);
				int iHeightIndex = csLuaPinString.Find(_T("height"),iWidthEndIndex);
				CString csHeightNum;
				if(iHeightIndex >= 0)
				{
					int iHeightEqualIndex = csLuaPinString.Find(_T("="),iHeightIndex);
					::GetStringNum(csLuaPinString,iHeightEqualIndex+1,csHeightNum);
				}
				width = ::CStringToInt(csWidthNum);
				height = ::CStringToInt(csHeightNum);
			}
		}

		::SendMessage(GetParent()->GetSafeHwnd(),WM_GET_WIDTH_HEIGHT,width,height);
	}
}


void CPropButtonDialog::OnEnChangeEditNodeG9left()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_G9LEFT)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_gLeft,::CStringToInt(csValue));
		ChangeUIProp(UI_PROP_gLeft);
	}
}


void CPropButtonDialog::OnEnChangeEditNodeG9right()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_G9RIGHT)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_gRight,::CStringToInt(csValue));
		ChangeUIProp(UI_PROP_gRight);
	}
}


void CPropButtonDialog::OnEnChangeEditNodeG9top()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_G9TOP)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_gTop,::CStringToInt(csValue));
		ChangeUIProp(UI_PROP_gTop);
	}
}


void CPropButtonDialog::OnEnChangeEditNodeG9bottom()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_G9BOTTOM)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_gBottom,::CStringToInt(csValue));
		ChangeUIProp(UI_PROP_gBottom);
	}
}


void CPropButtonDialog::OnBnClickedButtonGetLuaPin()
{
	const TCHAR szFilter[] = _T("Lua Files (*.lua)|*.lua|All Files (*.*)|*.*||");
	const TCHAR szExt[] = _T("lua");

	CString strLuaPin;
	GetDlgItem(IDC_BUTTON_GET_LUA_PIN)->GetWindowText(strLuaPin);
	if(strLuaPin.IsEmpty() || strLuaPin == STRING_CLICK_SELECT_LUA)
		strLuaPin.Empty();
	strLuaPin.Replace(_T("/"),_T("\\"));
	CString csFileName = SCRIPTS_DIRECTORY + _T("\\") + strLuaPin;

	CFileDialog dlg(TRUE, szExt, csFileName,//NULL, 
		OFN_READONLY |OFN_NONETWORKBUTTON, szFilter, this);
	dlg.m_ofn.lpstrTitle = _T("��Resource/scriptsĿ¼��ѡ��ƴͼ�������ɵ�lua�ļ�");
	CString csScriptsDirectory = SCRIPTS_DIRECTORY + _T("\\");
	dlg.m_ofn.lpstrInitialDir = csScriptsDirectory;

	EnableKeyHook(false);
	if(dlg.DoModal() == IDOK)
	{
		CString str = dlg.GetPathName();
		CString strLua = SCRIPTS_DIRECTORY + _T("\\");
		if ( -1 == str.Find(strLua))
		{
			AfxMessageBox(_T("�˴�����ѡ��Resource/scriptsĿ¼�µ�lua�ļ�."));
			EnableKeyHook(true);
			return;
		}
		str.Replace(strLua,_T(""));
		str.Replace(_T("\\"),_T("/"));
		GetDlgItem(IDC_BUTTON_GET_LUA_PIN)->SetWindowText(str);

		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_strLuaName,(LPARAM)&str);
	}
}

void CPropButtonDialog::OnBnClickedButtonClearLuaPin()
{
	GetDlgItem(IDC_BUTTON_GET_LUA_PIN)->SetWindowText(STRING_CLICK_SELECT_LUA);
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_strLuaName,(LPARAM)&CString(_T("")));
}


void CPropButtonDialog::OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/)
{
}

LRESULT CPropButtonDialog::MessageEditKillFocus(WPARAM wParam,LPARAM lParam)
{
	CEdit *pEdit = (CEdit*)wParam;
	CWnd *pNewWnd = (CWnd*)lParam;

	EndChangeUIProp();

	return 0;
}

void CPropButtonDialog::ChangeUIProp(EM_UI_PROP_TYPE emUIPropType)
{
	m_bChangeUIProp = TRUE;
	m_emUIPropType = emUIPropType;

	SetTimer(TIMER_CHANGE_UI_PROP,CHANGE_UI_PROP_DELAY,NULL);
}

void CPropButtonDialog::EndChangeUIProp()
{
	KillTimer(TIMER_CHANGE_UI_PROP);
	if(!m_bChangeUIProp)
		return;

	switch(m_emUIPropType)
	{
	case UI_PROP_gLeft:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_NODE_G9LEFT)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_gLeft,::CStringToInt(csValue));
			}
		}
		break;
	case UI_PROP_gRight:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_NODE_G9RIGHT)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_gRight,::CStringToInt(csValue));
			}
		}
		break;
	case UI_PROP_gTop:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_NODE_G9TOP)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_gTop,::CStringToInt(csValue));
			}
		}
		break;
	case UI_PROP_gBottom:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_NODE_G9BOTTOM)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_gBottom,::CStringToInt(csValue));
			}
		}
		break;
	default:
		break;
	}

	m_bChangeUIProp = FALSE;
	m_emUIPropType = (EM_UI_PROP_TYPE)-1;
}

void CPropButtonDialog::OnTimer(UINT_PTR nIDEvent)
{
	switch(nIDEvent)
	{
	case TIMER_CHANGE_UI_PROP:
		{
			EndChangeUIProp();
		}
		break;
	default:
		break;
	}

	CDialogEx::OnTimer(nIDEvent);
}

