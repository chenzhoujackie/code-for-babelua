// StdPlugin.h : StdPlugin DLL ����ͷ�ļ�
//

#pragma once

#ifndef __AFXWIN_H__
	#error "�ڰ������ļ�֮ǰ������stdafx.h�������� PCH �ļ�"
#endif

#include "resource.h"		// ������


#pragma warning(disable:4786)
#include <string>
#include <vector>
#include <map>
using namespace std;

class ConfigSys
{
public:
	ConfigSys();
	~ConfigSys();

	void Init();

	void setGroup(const char* str);
	void setXml(const char* str);
	void setWHScale(int sel1,int sel2,int check1);

	string m_group;
	string m_xml;

	int m_sel1;
	int m_sel2;
	int m_check1;

	string m_encode;

private:
	void Save();
};
// CStdPluginApp
// �йش���ʵ�ֵ���Ϣ������� StdPlugin.cpp
//

class CStdPluginApp : public CWinAppEx
{
private:
	void InitCfg();
	void InitViewCfg();
	void InitSetting();
public:
	CStringArray m_ViewCfgs;
	CMapStringToString m_ViewCfgChilds;

	ConfigSys m_Config;

public:
	CStdPluginApp();


// ��д
public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();

	virtual BOOL LoadWindowPlacement(CRect& rectNormalPosition, int& nFflags, int& nShowCmd);
	virtual BOOL StoreWindowPlacement(const CRect& rectNormalPosition, int nFflags, int nShowCmd);

// ʵ��
	UINT  m_nAppLook;
	virtual void PreLoadState();
	virtual void LoadCustomState();
	virtual void SaveCustomState();

	afx_msg void OnUpdateFileNew(CCmdUI *pCmdUI);
	afx_msg void OnUpdateFileOpen(CCmdUI *pCmdUI);
	afx_msg void OnUpdateFileSave(CCmdUI *pCmdUI);
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CStdPluginApp theApp;
