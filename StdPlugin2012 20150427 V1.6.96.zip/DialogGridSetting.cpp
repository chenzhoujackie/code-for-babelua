// DialogGridSetting.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "DialogGridSetting.h"
#include "afxdialogex.h"


// CDialogGridSetting �Ի���

IMPLEMENT_DYNAMIC(CDialogGridSetting, CDialogEx)

CDialogGridSetting::CDialogGridSetting(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDialogGridSetting::IDD, pParent)
	, m_H(0)
	, m_V(0)
{

}

CDialogGridSetting::~CDialogGridSetting()
{
}

void CDialogGridSetting::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_H, m_H);
	DDV_MinMaxInt(pDX, m_H, 64, 2048);
	DDX_Text(pDX, IDC_EDIT_V, m_V);
	DDV_MinMaxInt(pDX, m_V, 64, 2048);
//	DDX_Control(pDX, IDC_COMBO1, m_List);
}


BEGIN_MESSAGE_MAP(CDialogGridSetting, CDialogEx)
	ON_BN_CLICKED(IDOK, &CDialogGridSetting::OnBnClickedOk)
END_MESSAGE_MAP()


// CDialogGridSetting ��Ϣ��������

BOOL CDialogGridSetting::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetIcon(hIcon, FALSE);

	m_H = ::GetGridHSkip();
	m_V = ::GetGridVSkip();
	UpdateData(FALSE);

/*	int i;
	for(i=0; i<COMBO_COLOR_NUM; i++)
	{
		m_List.InsertString(-1,::GetComboColorString(i));
	}
*/
	COLORREF color = RGB(::GetGridRed(),::GetGridGreen(),::GetGridBlue());
/*	int index = ::GetComboColorIndex(color);
	m_List.SetCurSel(index);*/
	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_GRID))->SetColor(color);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CDialogGridSetting::OnBnClickedOk()
{
	UpdateData(TRUE);

	::SetGridHSkip(m_H);
	::SetGridVSkip(m_V);

/*	int iGridColor = m_List.GetCurSel();

	COLORREF color = ::GetComboColorCOLORREF(iGridColor);*/
	COLORREF color = ((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_GRID))->GetColor();
	::SetGridRed(GetRValue(color));
	::SetGridGreen(GetGValue(color));
	::SetGridBlue(GetBValue(color));

	::WritePrivateProfileString(_T("setting"),_T("GridH"),::IntToCString(m_H),SETTING_FILE_PATH);
	::WritePrivateProfileString(_T("setting"),_T("GridV"),::IntToCString(m_V),SETTING_FILE_PATH);
	::WritePrivateProfileString(_T("setting"),_T("GridColor"),::COLORREFToRGBCString(color),SETTING_FILE_PATH);
/*
	int iGridRed = ::GetGridRed();
	int iGridGreen = ::GetGridGreen();
	int iGridBlue = ::GetGridBlue();
	switch(iGridColor)
	{
	case 0:
		iGridRed = 255;
		iGridGreen = 255;
		iGridBlue = 255;
		break;
	case 1:
		iGridRed = 0;
		iGridGreen = 0;
		iGridBlue = 0;
		break;
	case 2:
		iGridRed = 255;
		iGridGreen = 0;
		iGridBlue = 0;
		break;
	case 3:
		iGridRed = 0;
		iGridGreen = 255;
		iGridBlue = 0;
		break;
	case 4:
		iGridRed = 0;
		iGridGreen = 0;
		iGridBlue = 255;
		break;
	case 5:
		iGridRed = 255;
		iGridGreen = 255;
		iGridBlue = 0;
		break;
	case 6:
		iGridRed = 255;
		iGridGreen = 0;
		iGridBlue = 255;
		break;
	default:
		break;
	}
	::SetGridRed(iGridRed);
	::SetGridGreen(iGridGreen);
	::SetGridBlue(iGridBlue);
*/
	CDialogEx::OnOK();
}
