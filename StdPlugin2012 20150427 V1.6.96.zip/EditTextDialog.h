#pragma once
#include "afxwin.h"


// CEditTextDialog �Ի���

class CEditTextDialog : public CDialogEx
{
public:
	void SetTitle(LPCTSTR lpszTitle);
	void SetEditText(CStringW csText);
	CStringW GetEditText() const;
protected:
	CString m_csTitle;
	CStringW m_csEditText;

	DECLARE_DYNAMIC(CEditTextDialog)

public:
	CEditTextDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CEditTextDialog();

// �Ի�������
	enum { IDD = IDD_EDIT_TEXT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
};
