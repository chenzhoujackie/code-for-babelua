// PropCustomDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "PropCustomDialog.h"
#include "afxdialogex.h"

#include "MainFrm.h"

// CPropCustomDialog �Ի���

IMPLEMENT_DYNAMIC(CPropCustomDialog, CDialogEx)

CPropCustomDialog::CPropCustomDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CPropCustomDialog::IDD, pParent)
{
	m_pDrawingBase = NULL;

	m_bEditData = TRUE;

	m_bChangeUIProp = FALSE;
	m_emUIPropType = (EM_UI_PROP_TYPE)-1;

	int i;
	for(i=0; i<CUSTOM_PAR_NUM; i++)
	{
		m_pPropStaticArray[i] = NULL;
		m_pPropEditDataArray[i] = NULL;
		m_pPropColorDataArray[i] = NULL;
	}
}

CPropCustomDialog::~CPropCustomDialog()
{
	ReleasePropWndArray();
}

void CPropCustomDialog::ReleasePropWndArray()
{
	int i;
	for(i=0; i<CUSTOM_PAR_NUM; i++)
	{
		if(m_pPropStaticArray[i] != NULL)
		{
			delete m_pPropStaticArray[i];
			m_pPropStaticArray[i] = NULL;
		}
		if(m_pPropEditDataArray[i] != NULL)
		{
			delete m_pPropEditDataArray[i];
			m_pPropEditDataArray[i] = NULL;
		}
		if(m_pPropColorDataArray[i] != NULL)
		{
			delete m_pPropColorDataArray[i];
			m_pPropColorDataArray[i] = NULL;
		}
	}
}

void CPropCustomDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_PROP_CUSTOM, m_propCustomStatic);
}


BEGIN_MESSAGE_MAP(CPropCustomDialog, CDialogEx)
	ON_BN_CLICKED(IDOK, &CPropCustomDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CPropCustomDialog::OnBnClickedCancel)
	ON_WM_TIMER()
	ON_CONTROL_RANGE(EN_CHANGE,ID_CUSTOM_EDIT_DATA_START,ID_CUSTOM_EDIT_DATA_START+CUSTOM_PAR_NUM,&CPropCustomDialog::OnEnChangeEditText)
	ON_COMMAND_RANGE(ID_CUSTOM_COLOR_DATA_START,ID_CUSTOM_COLOR_DATA_START+CUSTOM_PAR_NUM,&CPropCustomDialog::OnBnClickedMfccolorbuttonText)
	ON_WM_CONTEXTMENU()
	ON_MESSAGE(WM_EDIT_KILLFOCUS,MessageEditKillFocus)
END_MESSAGE_MAP()


// CPropCustomDialog ��Ϣ��������

void CPropCustomDialog::InitData(const CDrawingBase *pDrawingBase)
{
	m_pDrawingBase = pDrawingBase;

	ChangeDrawingBase(m_pDrawingBase);
}

void CPropCustomDialog::SaveChangeUIProp()
{
	EndChangeUIProp();
}

void CPropCustomDialog::ChangeDrawingBase(const CDrawingBase *pDrawingBase)
{
	m_bEditData = FALSE;

	EM_DRAWING_TYPE type = (EM_DRAWING_TYPE)-1;
	if(pDrawingBase != NULL)
		type = pDrawingBase->GetDrawingType();

	CArray <CCustomData,CCustomData> customDataArray;
	if(type == DRAWING_TYPE_CustomControl)
	{
		const CDrawingCustomControl *pDrawingCustomControl = CDrawingCustomControl::CDrawingBaseToCDrawingCustomControl(const_cast<CDrawingBase*>(pDrawingBase));
		if(pDrawingCustomControl != NULL)
		{
			pDrawingCustomControl->GetCustomData(customDataArray);
		}
	}

	int i;
	for(i=0; i<CUSTOM_PAR_NUM; i++)
	{
		if(m_pPropStaticArray[i] != NULL)
		{
			m_pPropStaticArray[i]->ShowWindow(SW_HIDE);
		}
		if(m_pPropEditDataArray[i] != NULL)
		{
			m_pPropEditDataArray[i]->ShowWindow(SW_HIDE);
		}
		if(m_pPropColorDataArray[i] != NULL)
		{
			m_pPropColorDataArray[i]->ShowWindow(SW_HIDE);
		}
	}
	for(i=0; i<customDataArray.GetSize() && i<CUSTOM_PAR_NUM; i++)
	{
		if(m_pPropStaticArray[i] != NULL)
		{
			m_pPropStaticArray[i]->SetWindowText(customDataArray.GetAt(i).GetCustomPropName());
			m_pPropStaticArray[i]->ShowWindow(SW_SHOW);
		}
		switch(customDataArray.GetAt(i).GetCustomDataType())
		{
		case CUSTOM_DATA_INT:
			{
				if(m_pPropEditDataArray[i] != NULL)
				{
					m_pPropEditDataArray[i]->SetWindowText(::IntToCString(customDataArray.GetAt(i).GetDataInt()));
					m_pPropEditDataArray[i]->ShowWindow(SW_SHOW);
				}
			}
			break;
		case CUSTOM_DATA_STRING:
			{
				if(m_pPropEditDataArray[i] != NULL)
				{
					m_pPropEditDataArray[i]->SetWindowText(customDataArray.GetAt(i).GetDataCString());
					m_pPropEditDataArray[i]->ShowWindow(SW_SHOW);
				}
			}
			break;
		case CUSTOM_DATA_COLOR:
			{
				if(m_pPropColorDataArray[i] != NULL)
				{
					m_pPropColorDataArray[i]->SetColor(customDataArray.GetAt(i).GetDataCOLORREF());
					m_pPropColorDataArray[i]->ShowWindow(SW_SHOW);
				}
			}
			break;
		default:
			break;
		}
	}

	m_bEditData = TRUE;

	m_bChangeUIProp = FALSE;
	m_emUIPropType = (EM_UI_PROP_TYPE)-1;
}

BOOL CPropCustomDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	m_propCustomStatic.SetTextColor(RGB(0,0,255));
	m_propCustomStatic.SetBorderColor(RGB(0,0,255));//107,143,246));

	m_font.CreateFont(12,0,0,0,FW_NORMAL,FALSE,FALSE,0,GB2312_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH | FF_SWISS,_T("����"));

	int iRowNum = 3;
	int i;
	for(i=0; i<CUSTOM_PAR_NUM; i++)
	{
		int iRow = i%iRowNum;
		int iCol = i/iRowNum;
		int iStaticWidth = 60;
		int iLeft = 20;
		int iTop = 26;
		int iHeight = 22;
		int iHDis = 30;
		int iWDis = 180;

		int iStaticLeft = iLeft+iCol*iWDis;
		int iStaticTop = iTop+iRow*iHDis+4;
		int iStaticRight = iStaticLeft+iStaticWidth;
		int iStaticBottom = iStaticTop+iHeight;

		m_pPropStaticArray[i] = new CStatic;
		m_pPropStaticArray[i]->Create(_T(""),WS_CHILD | WS_VISIBLE | SS_RIGHT,CRect(iStaticLeft,iStaticTop,iStaticRight,iStaticBottom),this,ID_CUSTOM_STATIC_START+i);
		m_pPropStaticArray[i]->SetFont(&m_font);

		int iDataLeft = iStaticRight+4;
		int iDataTop = iTop+iRow*iHDis;
		int iDataRight = iDataLeft+100;
		int iDataBottom = iDataTop+iHeight;

		m_pPropEditDataArray[i] = new CXEdit;
		m_pPropEditDataArray[i]->Create(WS_CHILD | WS_VISIBLE | WS_TABSTOP | WS_BORDER,CRect(iDataLeft,iDataTop,iDataRight,iDataBottom),this,ID_CUSTOM_EDIT_DATA_START+i);
		m_pPropEditDataArray[i]->SetFont(&m_font);

		m_pPropColorDataArray[i] = new CMFCColorButton;
		m_pPropColorDataArray[i]->Create(_T(""),WS_CHILD | WS_VISIBLE,CRect(iDataLeft,iDataTop,iDataRight,iDataBottom),this,ID_CUSTOM_COLOR_DATA_START+i);
		m_pPropColorDataArray[i]->EnableOtherButton(_T("Other"));
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CPropCustomDialog::OnBnClickedOk()
{
}


void CPropCustomDialog::OnBnClickedCancel()
{
}


void CPropCustomDialog::OnEnChangeEditText(UINT nID)
{
	int index = nID-ID_CUSTOM_EDIT_DATA_START;
	ChangeUIProp(UI_PROP_Custom);
}

void CPropCustomDialog::OnBnClickedMfccolorbuttonText(UINT nID)
{
	int index = nID-ID_CUSTOM_COLOR_DATA_START;
	ChangeUIPropCustom();
}


void CPropCustomDialog::OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/)
{
}

LRESULT CPropCustomDialog::MessageEditKillFocus(WPARAM wParam,LPARAM lParam)
{
	CEdit *pEdit = (CEdit*)wParam;
	CWnd *pNewWnd = (CWnd*)lParam;

	EndChangeUIProp();

	return 0;
}

void CPropCustomDialog::ChangeUIProp(EM_UI_PROP_TYPE emUIPropType)
{
	m_bChangeUIProp = TRUE;
	m_emUIPropType = emUIPropType;

	SetTimer(TIMER_CHANGE_UI_PROP,CHANGE_UI_PROP_DELAY,NULL);
}

void CPropCustomDialog::ChangeUIPropCustom()
{
	EM_DRAWING_TYPE type = (EM_DRAWING_TYPE)-1;
	if(m_pDrawingBase != NULL)
		type = m_pDrawingBase->GetDrawingType();

	CArray <CCustomData,CCustomData> customDataArray;
	if(type == DRAWING_TYPE_CustomControl)
	{
		const CDrawingCustomControl *pDrawingCustomControl = CDrawingCustomControl::CDrawingBaseToCDrawingCustomControl(const_cast<CDrawingBase*>(m_pDrawingBase));
		if(pDrawingCustomControl != NULL)
		{
			pDrawingCustomControl->GetCustomData(customDataArray);
		}
	}
	int i;
	for(i=0; i<customDataArray.GetSize() && i<CUSTOM_PAR_NUM; i++)
	{
		switch(customDataArray.GetAt(i).GetCustomDataType())
		{
		case CUSTOM_DATA_INT:
			{
				if(m_pPropEditDataArray[i] != NULL)
				{
					CString csPropData;
					m_pPropEditDataArray[i]->GetWindowText(csPropData);
					customDataArray[i].SetDataInt(::CStringToInt(csPropData));
				}
			}
			break;
		case CUSTOM_DATA_STRING:
			{
				if(m_pPropEditDataArray[i] != NULL)
				{
					CString csPropData;
					m_pPropEditDataArray[i]->GetWindowText(csPropData);
					customDataArray[i].SetDataCString(csPropData);
				}
			}
			break;
		case CUSTOM_DATA_COLOR:
			{
				if(m_pPropColorDataArray[i] != NULL)
				{
					COLORREF color = m_pPropColorDataArray[i]->GetColor();
					customDataArray[i].SetDataCOLORREF(color);
				}
			}
			break;
		default:
			break;
		}
	}
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_Custom,(LPARAM)&customDataArray);
	}
}

void CPropCustomDialog::EndChangeUIProp()
{
	KillTimer(TIMER_CHANGE_UI_PROP);
	if(!m_bChangeUIProp)
		return;

	ChangeUIPropCustom();

	m_bChangeUIProp = FALSE;
	m_emUIPropType = (EM_UI_PROP_TYPE)-1;
}

void CPropCustomDialog::OnTimer(UINT_PTR nIDEvent)
{
	switch(nIDEvent)
	{
	case TIMER_CHANGE_UI_PROP:
		{
			EndChangeUIProp();
		}
		break;
	default:
		break;
	}

	CDialogEx::OnTimer(nIDEvent);
}

BOOL CPropCustomDialog::PreTranslateMessage(MSG* pMsg)
{
	int nWndID = ::GetWindowLong(pMsg->hwnd,GWL_ID);
	switch(pMsg->message)
	{
	case WM_KEYDOWN:
		{
		}
		break;
	case WM_LBUTTONDOWN:
		{
		}
		break;
	case WM_LBUTTONUP:
		{
		}
		break;
	default:
		break;
	}

	return CDialogEx::PreTranslateMessage(pMsg);
}
