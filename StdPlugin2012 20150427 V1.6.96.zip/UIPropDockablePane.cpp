// UIPropDockablePane.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "UIPropDockablePane.h"


// CUIPropDockablePane

IMPLEMENT_DYNAMIC(CUIPropDockablePane, CDockablePane)

CUIPropDockablePane::CUIPropDockablePane()
{

}

CUIPropDockablePane::~CUIPropDockablePane()
{
}


BEGIN_MESSAGE_MAP(CUIPropDockablePane, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
END_MESSAGE_MAP()



// CUIPropDockablePane ��Ϣ��������


void CUIPropDockablePane::ChangeDrawingBase(const CDrawingBase *pDrawingBase)
{
	CString csPaneTitle = _T("UI���� ����[");
	if(pDrawingBase != NULL)
	{
		CString csName;
		pDrawingBase->GetName(csName);
		csPaneTitle += csName;
	}
	csPaneTitle += _T("]");

	if(pDrawingBase != NULL)
	{
		csPaneTitle += _T(" ����(");
		CString csTypeName = pDrawingBase->GetDrawingTypeName();
		csPaneTitle += csTypeName;
		csPaneTitle += _T(")");
	}

	CString csWindowText;
	GetWindowText(csWindowText);
	if(csWindowText != csPaneTitle)
		SetWindowText(csPaneTitle);

	m_uiPropDialog.InitData(pDrawingBase);
}

const CDrawingBase* CUIPropDockablePane::GetDrawingBase() const
{
	return m_uiPropDialog.GetDrawingBase();
}

void CUIPropDockablePane::SaveChangeUIProp()
{
	m_uiPropDialog.SaveChangeUIProp();
}

int CUIPropDockablePane::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_uiPropDialog.Create(IDD_UI_PROP_DIALOG,this);
	m_uiPropDialog.ShowWindow(SW_SHOW);

	return 0;
}


void CUIPropDockablePane::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);

	if(m_uiPropDialog.m_hWnd != NULL)
	{
		CRect clientRect;
		GetClientRect(clientRect);
		m_uiPropDialog.MoveWindow(clientRect);
	}
}
