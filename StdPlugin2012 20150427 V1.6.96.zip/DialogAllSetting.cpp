// DialogAllSetting.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "DialogAllSetting.h"
#include "afxdialogex.h"

#include "PropTextDialog.h"


// CDialogAllSetting �Ի���

IMPLEMENT_DYNAMIC(CDialogAllSetting, CDialogEx)

CDialogAllSetting::CDialogAllSetting(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDialogAllSetting::IDD, pParent)
	, m_H(0)
	, m_V(0)
{

}

CDialogAllSetting::~CDialogAllSetting()
{
}

void CDialogAllSetting::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_H, m_H);
	DDV_MinMaxInt(pDX, m_H, 64, 2048);
	DDX_Text(pDX, IDC_EDIT_V, m_V);
	DDV_MinMaxInt(pDX, m_V, 64, 2048);
	DDX_Control(pDX, IDC_COMBO_FONT_NAME, m_fontComboBox);
}


BEGIN_MESSAGE_MAP(CDialogAllSetting, CDialogEx)
	ON_BN_CLICKED(IDOK, &CDialogAllSetting::OnBnClickedOk)
END_MESSAGE_MAP()


// CDialogAllSetting ��Ϣ��������

BOOL CDialogAllSetting::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetIcon(hIcon, FALSE);

	m_H = ::GetGridHSkip();
	m_V = ::GetGridVSkip();
	UpdateData(FALSE);
	COLORREF gridColor = RGB(::GetGridRed(),::GetGridGreen(),::GetGridBlue());
	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_GRID))->SetColor(gridColor);


	COLORREF wellColor = RGB(::GetWellRed(),::GetWellGreen(),::GetWellBlue());
	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_WELL))->SetColor(wellColor);


	COLORREF bkColor = RGB(::GetBkRed(),::GetBkGreen(),::GetBkBlue());
	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLOR_BOTTOM_BK))->SetColor(bkColor);
	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLOR_BOTTOM))->SetColor(::GetBottomColor());


	m_fontComboBox.AddString(_T(""));
	::EnumFontFamilies(GetDC()->m_hDC, (LPTSTR) NULL, (FONTENUMPROC)NEnumFontNameProc, (LPARAM)&(m_fontComboBox));
	m_fontComboBox.SelectString(-1,::GetDefaultFontName());

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CDialogAllSetting::OnBnClickedOk()
{
	UpdateData(TRUE);

	::SetGridHSkip(m_H);
	::SetGridVSkip(m_V);
	COLORREF gridColor = ((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_GRID))->GetColor();
	::SetGridRed(GetRValue(gridColor));
	::SetGridGreen(GetGValue(gridColor));
	::SetGridBlue(GetBValue(gridColor));
	::WritePrivateProfileString(_T("setting"),_T("GridH"),::IntToCString(m_H),SETTING_FILE_PATH);
	::WritePrivateProfileString(_T("setting"),_T("GridV"),::IntToCString(m_V),SETTING_FILE_PATH);
	::WritePrivateProfileString(_T("setting"),_T("GridColor"),::COLORREFToRGBCString(gridColor),SETTING_FILE_PATH);


	COLORREF wellColor = ((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_WELL))->GetColor();
	::SetWellRed(GetRValue(wellColor));
	::SetWellGreen(GetGValue(wellColor));
	::SetWellBlue(GetBValue(wellColor));
	::WritePrivateProfileString(_T("setting"),_T("WellColor"),::COLORREFToRGBCString(wellColor),SETTING_FILE_PATH);


	COLORREF bkColor = ((CMFCColorButton*)GetDlgItem(IDC_MFCCOLOR_BOTTOM_BK))->GetColor();
	::SetBkRed(GetRValue(bkColor));
	::SetBkGreen(GetGValue(bkColor));
	::SetBkBlue(GetBValue(bkColor));
	::SetBottomColor(((CMFCColorButton*)GetDlgItem(IDC_MFCCOLOR_BOTTOM))->GetColor());
	::WritePrivateProfileString(_T("setting"),_T("BkColor"),::COLORREFToRGBCString(bkColor),SETTING_FILE_PATH);
	::WritePrivateProfileString(_T("setting"),_T("BottomColor"),::COLORREFToRGBCString(::GetBottomColor()),SETTING_FILE_PATH);


	CString csDefaultFontName;
	m_fontComboBox.GetWindowText(csDefaultFontName);
	::SetDefaultFontName(csDefaultFontName);
	::WritePrivateProfileString(_T("setting"),_T("DefaultFontName"),csDefaultFontName,SETTING_FILE_PATH);

	CDialogEx::OnOK();
}
