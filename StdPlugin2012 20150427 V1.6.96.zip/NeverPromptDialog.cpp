// NeverPromptDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "NeverPromptDialog.h"
#include "afxdialogex.h"


// CNeverPromptDialog �Ի���

IMPLEMENT_DYNAMIC(CNeverPromptDialog, CDialogEx)

CNeverPromptDialog::CNeverPromptDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CNeverPromptDialog::IDD, pParent)
{
	m_bNeverView = FALSE;
}

CNeverPromptDialog::~CNeverPromptDialog()
{
}

void CNeverPromptDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CNeverPromptDialog, CDialogEx)
	ON_BN_CLICKED(IDYES, &CNeverPromptDialog::OnBnClickedYes)
	ON_BN_CLICKED(IDNO, &CNeverPromptDialog::OnBnClickedNo)
	ON_BN_CLICKED(IDCANCEL, &CNeverPromptDialog::OnBnClickedCancel)
END_MESSAGE_MAP()


// CNeverPromptDialog ��Ϣ��������

void CNeverPromptDialog::SetTitle(LPCTSTR lpszTitle)
{
	m_csTitle = lpszTitle;
}

void CNeverPromptDialog::SetStaticText1(LPCTSTR lpszText)
{
	m_csStaticText1 = lpszText;
}

void CNeverPromptDialog::SetStaticText2(LPCTSTR lpszText)
{
	m_csStaticText2 = lpszText;
}

void CNeverPromptDialog::SetEditText(LPCTSTR lpszText)
{
	m_csEditText = lpszText;
}

BOOL CNeverPromptDialog::IsNeverView() const
{
	return m_bNeverView;
}

BOOL CNeverPromptDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetIcon(hIcon, FALSE);

	GetDlgItem(IDC_STATIC1)->SetWindowText(m_csStaticText1);
	GetDlgItem(IDC_STATIC2)->SetWindowText(m_csStaticText2);
	GetDlgItem(IDC_EDIT1)->SetWindowText(m_csEditText);

	if(!m_csTitle.IsEmpty())
	{
		SetWindowText(m_csTitle);
	}
	else
	{
		CString csAppTitle;
		csAppTitle.LoadString(AFX_IDS_APP_TITLE);
		SetWindowText(csAppTitle);
	}

	return TRUE;
}

void CNeverPromptDialog::OnBnClickedYes()
{
	m_bNeverView = ((CButton*)GetDlgItem(IDC_CHECK_NEVER_VIEW))->GetCheck();

	CDialogEx::EndDialog(IDYES);
}


void CNeverPromptDialog::OnBnClickedNo()
{
	m_bNeverView = ((CButton*)GetDlgItem(IDC_CHECK_NEVER_VIEW))->GetCheck();

	CDialogEx::EndDialog(IDNO);
}


void CNeverPromptDialog::OnBnClickedCancel()
{
	CDialogEx::OnCancel();
}
