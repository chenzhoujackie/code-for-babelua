// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// MainFrm.h : CMainFrame ��Ľӿ�
//

#pragma once

#include "LeftDockablePane.h"
#include "RightDockablePane.h"
#include "UIPropDockablePane.h"
#include "HistoryDockablePane.h"

#define TIMER_UPDATE_DOCKPANE_STATE			1
#define TIMER_INIT_GRID_TEXT				2
#define TIMER_CONSOLE_DISABLE_TOPMOST		3

class CMainFrame : public CFrameWndEx
{
public:
	void ChangeEditorDrawingId();
	int GetTreeSelectItemDrawingId() const;
	void ChangeEditorDrawingSeat(double dX,double dY,double dWidth,double dHeight,BOOL bLButtonUp);

	void UpdateStatusBarPane1(LPCTSTR lpszText);
	void UpdateStatusBarPane2(LPCTSTR lpszText);

	void UpdateHistory(int iCommandHistoryUndoPos,int iCommandHistoryUndoCount,int iCommandHistoryRedoCount,const CArray<int,int> &iTypeArr,const CStringArray &csHistoryNameArr);
	void SetHistory(int iCommandHistoryPos);

	void UpdateXml();
	void UpdateDockablePane();

	void GetCustomData(CString csCustomName,CArray <CCustomData,CCustomData> &customDataArray);

	const CDrawingBase* GetSelDrawingBase();

	void ShowConsole();
	void SetConsoleTopMost();

	BOOL LoadMainFrmState();
private:
	void UpdateRibbonCheckBox(UINT nID,BOOL bCheck);
	void UpdateRibbonDisabled(UINT nID,BOOL bDisabled);
	virtual BOOL OnCloseMiniFrame(CPaneFrameWnd* pWnd);
	virtual BOOL OnCloseDockingPane(CDockablePane* pWnd);
private:

protected: // �������л�����
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// ����
public:
	CLeftDockablePane m_leftDockablePane;
	CRightDockablePane m_rightDockablePane;
	CUIPropDockablePane m_uiPropDockablePane;
	CHistoryDockablePane m_historyDockablePane;

	CMFCToolBarImages m_fileLargeImages;
	CMFCToolBarImages m_writeSmallImages;
// ����
public:

// ��д
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// ʵ��
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // �ؼ���Ƕ���Ա
	CMFCRibbonBar     m_wndRibbonBar;
	CMFCRibbonApplicationButton m_MainButton;
	CMFCToolBarImages m_PanelImages;
	CMFCRibbonStatusBar  m_wndStatusBar;

// ���ɵ���Ϣӳ�亯��
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnApplicationLook(UINT id);
	afx_msg void OnUpdateApplicationLook(CCmdUI* pCmdUI);

	afx_msg void OnXmlmagFolder();
	afx_msg void OnGenLuaFinal();
	afx_msg void OnSaveXml();
	afx_msg void OnGenConfigLua();
	afx_msg void OnEditCut();
	afx_msg void OnEditCopy();
	afx_msg void OnEditPaste();
	afx_msg void OnEditDelete();
	afx_msg void OnEditUndo();
	afx_msg void OnEditRedo();
	afx_msg void OnXmlmagXml();
	afx_msg void OnExit();
	afx_msg void OnEditMode();
	afx_msg void OnViewMode();
	afx_msg void OnGridShow();
	afx_msg void OnGridSetting();
	afx_msg void OnCrossShow();
	afx_msg void OnCrossSetting();
	afx_msg void OnBorderShow();
	afx_msg void OnAllBorderShow();
	afx_msg void OnBorderSetting();
	afx_msg void OnBkSetting();
	afx_msg void OnAllSetting();
	afx_msg void OnConsoleShow();
	afx_msg void OnConsoleClear();
	afx_msg void OnViewLeftPane();
	afx_msg void OnViewRightPane();
	afx_msg void OnViewUiPropPane();
	afx_msg void OnViewHistoryPane();
	afx_msg void OnHelp();
	afx_msg void OnAbout();
	afx_msg void OnUpdateXmlmagFolder(CCmdUI* pCmdUI);
	afx_msg void OnUpdateGenLuaFinal(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSaveXml(CCmdUI* pCmdUI);
	afx_msg void OnUpdateGenConfigLua(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditCut(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditCopy(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditPaste(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditDelete(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditUndo(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditRedo(CCmdUI* pCmdUI);
	afx_msg void OnUpdateXmlmagXml(CCmdUI* pCmdUI);
	afx_msg void OnUpdateExit(CCmdUI* pCmdUI);
	afx_msg void OnUpdateEditMode(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewMode(CCmdUI* pCmdUI);
	afx_msg void OnUpdateGridShow(CCmdUI* pCmdUI);
	afx_msg void OnUpdateGridSetting(CCmdUI* pCmdUI);
	afx_msg void OnUpdateCrossShow(CCmdUI* pCmdUI);
	afx_msg void OnUpdateCrossSetting(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBorderShow(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBorderSetting(CCmdUI* pCmdUI);
	afx_msg void OnUpdateBkSetting(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAllSetting(CCmdUI* pCmdUI);
	afx_msg void OnUpdateConsoleShow(CCmdUI* pCmdUI);
	afx_msg void OnUpdateConsoleClear(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewLeftPane(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewRightPane(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewUiPropPane(CCmdUI* pCmdUI);
	afx_msg void OnUpdateViewHistoryPane(CCmdUI* pCmdUI);
	afx_msg void OnUpdateHelp(CCmdUI* pCmdUI);
	afx_msg void OnUpdateAbout(CCmdUI* pCmdUI);

	DECLARE_MESSAGE_MAP()
	
	LRESULT MessageAddNode(WPARAM wParam,LPARAM lParam);
	LRESULT MessageChangeDrawingBase(WPARAM wParam,LPARAM lParam);
	LRESULT MessageTreeSelchanging(WPARAM wParam,LPARAM lParam);
	LRESULT MessageGetTreeDrawingTimes(WPARAM wParam,LPARAM lParam);
	LRESULT MessageChangeUIProp(WPARAM wParam,LPARAM lParam);
	LRESULT MessageUpdateUIProp(WPARAM wParam,LPARAM lParam);
public:
	afx_msg void OnClose();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};


