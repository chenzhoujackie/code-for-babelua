// HistoryDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "HistoryDialog.h"
#include "afxdialogex.h"

#include "MainFrm.h"

#include "AddNodeWnd.h"

// CHistoryDialog �Ի���

IMPLEMENT_DYNAMIC(CHistoryDialog, CDialogEx)

CHistoryDialog::CHistoryDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CHistoryDialog::IDD, pParent)
{
	m_iCommandHistoryUndoPos = 0;
	m_iCommandHistoryUndoCount = 0;
	m_iCommandHistoryRedoCount = 0;

	m_iMoveSelectItem = -1;

	m_pArrowImage = ::BitmapFromIDResource(IDB_PNG_ARROW,RESOURCE_TYPE_PNG);
	int nTypeImageIDArr[HISTORY_TYPE_NUM] = {IDB_PNG_HISTORY_ADD,IDB_PNG_HISTORY_DELETE,IDB_PNG_HISTORY_MODIFY,IDB_PNG_HISTORY_MOVE};
	int i;
	for(i=0; i<HISTORY_TYPE_NUM; i++)
	{
		m_pTypeImageArr[i] = ::BitmapFromIDResource(nTypeImageIDArr[i],RESOURCE_TYPE_PNG);
	}

	m_bTracking = FALSE;
}

CHistoryDialog::~CHistoryDialog()
{
	if(m_pArrowImage != NULL)
	{
		delete m_pArrowImage;
		m_pArrowImage = NULL;
	}
	int i;
	for(i=0; i<HISTORY_TYPE_NUM; i++)
	{
		if(m_pTypeImageArr[i] != NULL)
		{
			delete m_pTypeImageArr[i];
			m_pTypeImageArr[i] = NULL;
		}
	}
}

void CHistoryDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CHistoryDialog, CDialogEx)
	ON_BN_CLICKED(IDOK, &CHistoryDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CHistoryDialog::OnBnClickedCancel)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_VSCROLL()
	ON_WM_MOUSEWHEEL()
	ON_WM_SIZE()
	ON_WM_CONTEXTMENU()
	ON_WM_MOUSEHOVER()
	ON_WM_MOUSELEAVE()
END_MESSAGE_MAP()


// CHistoryDialog ��Ϣ��������

void CHistoryDialog::UpdateHistory(int iCommandHistoryUndoPos,int iCommandHistoryUndoCount,int iCommandHistoryRedoCount,const CArray<int,int> &iTypeArr,const CStringArray &csHistoryNameArr)
{
	m_iCommandHistoryUndoPos = iCommandHistoryUndoPos;
	m_iCommandHistoryUndoCount = iCommandHistoryUndoCount;
	m_iCommandHistoryRedoCount = iCommandHistoryRedoCount;

	int i;
	m_iTypeArr.RemoveAll();
	for(i=0; i<iTypeArr.GetSize(); i++)
	{
		m_iTypeArr.Add(iTypeArr.GetAt(i));
	}

	m_csHistoryNameArr.RemoveAll();
	m_csHistoryNameArr.Add(_T("Start"));
	for(i=0; i<csHistoryNameArr.GetSize(); i++)
	{
		m_csHistoryNameArr.Add(csHistoryNameArr.GetAt(i));
	}

	if(m_hWnd != NULL)
	{
		UpdateScroll();

		SCROLLINFO scrollInfo;
		memset(&scrollInfo,0,sizeof(SCROLLINFO));
		GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);
		//��������ǰָʾλ��
		int nPos = m_iCommandHistoryUndoCount*HISTORY_ITEM_HEIGHT;
		if(!(nPos >= scrollInfo.nPos && nPos < scrollInfo.nPos+scrollInfo.nPage))
		{
			scrollInfo.nPos = nPos;
		}
		if(scrollInfo.nPos > scrollInfo.nMax-(int)scrollInfo.nPage)
			scrollInfo.nPos = scrollInfo.nMax-(int)scrollInfo.nPage;
		SetScrollPos(SB_VERT,scrollInfo.nPos,TRUE);

		Invalidate(FALSE);
	}
}

void CHistoryDialog::OnBnClickedOk()
{
}


void CHistoryDialog::OnBnClickedCancel()
{
}

BOOL CHistoryDialog::UpdateScroll()
{
	CRect windowRect;
	GetWindowRect(windowRect);

	int iPageWidth = windowRect.Width();
	int iPageHeight = windowRect.Height();

	int iTotalHeight = HISTORY_ITEM_HEIGHT*m_csHistoryNameArr.GetSize()+HISTORY_ITEM_HEIGHT;

	if(iPageHeight < iTotalHeight)
	{
		SCROLLINFO scrollInfo;
		memset(&scrollInfo,0,sizeof(SCROLLINFO));
		GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);

		scrollInfo.nMax = iTotalHeight;
		scrollInfo.nPage = iPageHeight;
		if(scrollInfo.nPos > scrollInfo.nMax-(int)scrollInfo.nPage)
			scrollInfo.nPos = scrollInfo.nMax-(int)scrollInfo.nPage;
		SetScrollInfo(SB_VERT,&scrollInfo,TRUE);
		ShowScrollBar(SB_VERT,TRUE);
	}
	else
	{
		ShowScrollBar(SB_VERT,FALSE);
	}
	return TRUE;
}

int CHistoryDialog::GetSelectItem(CPoint point)
{
	CRect rect;
	GetClientRect(rect);

	SCROLLINFO scrollInfo;
	GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);
	DWORD windowStyle = GetWindowLong(m_hWnd,GWL_STYLE);
	BOOL bVertScroll = windowStyle & WS_VSCROLL;
	int nScrollPos = bVertScroll ? scrollInfo.nPos : 0;

	int iPageWidth = rect.Width();
	int iPageHeight = rect.Height();

	int i;
	for(i=0; i<m_csHistoryNameArr.GetSize(); i++)
	{
		int iItemTop = i*HISTORY_ITEM_HEIGHT-nScrollPos;
		CRect itemRect(rect.left,iItemTop,rect.right,iItemTop+HISTORY_ITEM_HEIGHT);

		if(itemRect.PtInRect(point))
			return i;
	}
	return -1;
}

void CHistoryDialog::OnLButtonDown(UINT nFlags, CPoint point) 
{
	SetFocus();

	int iSelectItem = GetSelectItem(point);
	if(iSelectItem >= 0)
	{
		SetHandCursor();
	}
	Invalidate(FALSE);

	if(iSelectItem >= 0 && iSelectItem < m_csHistoryNameArr.GetSize())
	{
		((CMainFrame*)AfxGetMainWnd())->SetHistory(iSelectItem);
	}
}

void CHistoryDialog::OnLButtonUp(UINT nFlags, CPoint point) 
{
	int iSelectItem = GetSelectItem(point);
	if(iSelectItem >= 0)
	{
		SetHandCursor();
	}

	CWnd::OnLButtonUp(nFlags, point);
}

void CHistoryDialog::SetHandCursor()
{
	HINSTANCE hInstance = AfxGetInstanceHandle();
	HCURSOR hCursor = LoadCursor(hInstance,MAKEINTRESOURCE(IDC_CURSOR_HAND));
	::SetCursor(hCursor);
	if(hCursor != NULL)
	{
		::DestroyIcon(hCursor);
		hCursor = NULL;
	}
}

void CHistoryDialog::OnMouseMove(UINT nFlags, CPoint point) 
{
	int iSelectItem = GetSelectItem(point);
	if(iSelectItem >= 0)
	{
		SetHandCursor();
	}
	m_iMoveSelectItem = iSelectItem;
	Invalidate(FALSE);

	if(!m_bTracking)
	{ 
		TRACKMOUSEEVENT tme; 
		tme.cbSize = sizeof(tme); 
		tme.hwndTrack = m_hWnd; 
		tme.dwFlags = TME_LEAVE | TME_HOVER;
		tme.dwHoverTime = 1; 
		m_bTracking = _TrackMouseEvent(&tme); 
	}

	CWnd::OnMouseMove(nFlags, point);
}

void CHistoryDialog::OnPaint()
{
	CPaintDC dc(this); // device context for painting


	CRect rect;
	GetClientRect(rect);

	SCROLLINFO scrollInfo;
	GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);
	DWORD windowStyle = GetWindowLong(m_hWnd,GWL_STYLE);
	BOOL bVertScroll = windowStyle & WS_VSCROLL;
	int nScrollPos = bVertScroll ? scrollInfo.nPos : 0;

	CDC MemDC;
	MemDC.CreateCompatibleDC(&dc);
	CBitmap MemBitmap;
	MemBitmap.CreateCompatibleBitmap(&dc,rect.Width(),rect.Height());
	if(MemBitmap.m_hObject == NULL)
		return;
	CBitmap *pOldBit=MemDC.SelectObject(&MemBitmap);
	MemDC.FillSolidRect(0,0,rect.Width(),rect.Height(),RGB(255,255,255));
	MemDC.SetBkMode(TRANSPARENT);

	Graphics g(MemDC.GetSafeHdc());
	g.FillRectangle(&SolidBrush(Color(16,0,0,0)),0,0,rect.Width(),rect.Height());

	CFont font;
	font.CreateFont(12,0,0,0,FW_NORMAL,FALSE,FALSE,0,GB2312_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH | FF_SWISS,_T("����"));
	CFont italicFont;
	italicFont.CreateFont(12,0,0,0,FW_NORMAL,TRUE,FALSE,0,GB2312_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH | FF_SWISS,_T("����"));
	CFont *pOldFont = MemDC.SelectObject(&font);

	int iPageWidth = rect.Width();
	int iPageHeight = rect.Height();

	int i;
	for(i=0; i<m_csHistoryNameArr.GetSize(); i++)
	{
		int iItemTop = i*HISTORY_ITEM_HEIGHT-nScrollPos;
		CRect itemRect(0,iItemTop,rect.right,iItemTop+HISTORY_ITEM_HEIGHT);

		COLORREF textColor = RGB(0,0,0);
		CFont *pOldFont = NULL;
		
		int iCommandHistoryPos = m_iCommandHistoryUndoCount;
		if(i < iCommandHistoryPos)
		{
		}
		else if(i == iCommandHistoryPos)
		{
			g.FillRectangle(&SolidBrush(Color(107,173,246)),itemRect.left,itemRect.top,itemRect.Width(),itemRect.Height());

			if(m_pArrowImage != NULL)
			{
				g.DrawImage(m_pArrowImage,Rect(itemRect.left+2,itemRect.top,20,itemRect.Height()));
			}
//			MemDC.DrawText(_T("->"),CRect(itemRect.left+10,itemRect.top,itemRect.left+30,itemRect.bottom),DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		}
		else
		{
			g.FillRectangle(&SolidBrush(Color(128,83,83,83)),itemRect.left,itemRect.top,itemRect.Width(),itemRect.Height());
			textColor = RGB(119,119,119);
			pOldFont = MemDC.SelectObject(&italicFont);
		}

		BOOL bMouseOnItem = (m_iMoveSelectItem == i);
		if(bMouseOnItem)
		{
			g.FillRectangle(&SolidBrush(Color(128,107,173,246)),itemRect.left,itemRect.top,itemRect.Width(),itemRect.Height());
		}

		g.DrawLine(&Pen(Color(128,0,0,0)),itemRect.left,itemRect.bottom-1,itemRect.right,itemRect.bottom-1);

		COLORREF oldTextColor = MemDC.SetTextColor(textColor);
		if(i > 0)
		{
			CString csIndex;
			csIndex.Format(_T("%03d"),i);
			MemDC.DrawText(csIndex+_T(":"),CRect(itemRect.left+20,itemRect.top,itemRect.left+50,itemRect.bottom),DT_RIGHT | DT_VCENTER | DT_SINGLELINE);
		}
		BOOL bDrawTypeImage = FALSE;
		if((i-1) >= 0)
		{
			int iType = m_iTypeArr[i-1];
			if((iType >= 0 && iType < HISTORY_TYPE_NUM))
			{
				if(m_pTypeImageArr[iType] != NULL)
				{
					g.DrawImage(m_pTypeImageArr[iType],itemRect.left+50,itemRect.top+2);
					bDrawTypeImage = TRUE;
				}
			}
		}
		int iHistoryNameLeft = bDrawTypeImage ? (itemRect.left+70) : (itemRect.left+50);
		MemDC.DrawText(m_csHistoryNameArr.GetAt(i),CRect(iHistoryNameLeft,itemRect.top,itemRect.right,itemRect.bottom),DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		MemDC.SetTextColor(oldTextColor);

		if(pOldFont != NULL)
		{
			MemDC.SelectObject(pOldFont);
		}
	}
	MemDC.SelectObject(pOldFont);

	dc.BitBlt(0,0,rect.Width(),rect.Height(),&MemDC,0,0,SRCCOPY);
	MemDC.SelectObject(pOldBit);
	MemBitmap.DeleteObject();
}


BOOL CHistoryDialog::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CDialogEx::OnEraseBkgnd(pDC);
}

void CHistoryDialog::OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/)
{
}

void CHistoryDialog::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	SCROLLINFO scrollInfo;
	GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);
	int nDis = HISTORY_ITEM_HEIGHT;
	int nPageDis = scrollInfo.nPage;
	int nOldPos = scrollInfo.nPos;
	switch(nSBCode)
	{
	case SB_LINEUP:
		scrollInfo.nPos = max(nOldPos-nDis,scrollInfo.nMin);
		break;
	case SB_LINEDOWN:
		scrollInfo.nPos = min(nOldPos+nDis,scrollInfo.nMax-(int)scrollInfo.nPage+1);
		break;
	case SB_PAGEUP:
		scrollInfo.nPos = max(nOldPos-nPageDis,scrollInfo.nMin);
		break;
	case SB_PAGEDOWN:
		scrollInfo.nPos = min(nOldPos+nPageDis,scrollInfo.nMax-(int)scrollInfo.nPage+1);
		break;
	case SB_THUMBTRACK:
		scrollInfo.nPos = scrollInfo.nTrackPos;
		break;
	case SB_THUMBPOSITION:
		break;
	}
	scrollInfo.fMask = SIF_POS;
	SetScrollInfo(SB_VERT,&scrollInfo,TRUE);

	Invalidate(FALSE);
	CWnd::OnVScroll(nSBCode, nPos, pScrollBar);
}

BOOL CHistoryDialog::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	if(zDelta == WHEEL_DELTA)
	{
		::SendMessage(m_hWnd,WM_VSCROLL,SB_LINEUP,NULL);
	}
	else if(zDelta == -WHEEL_DELTA)
	{
		::SendMessage(m_hWnd,WM_VSCROLL,SB_LINEDOWN,NULL);
	}

	return CWnd::OnMouseWheel(nFlags, zDelta, pt);
}

void CHistoryDialog::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	UpdateScroll();
	Invalidate(FALSE);
}


void CHistoryDialog::OnMouseHover(UINT nFlags, CPoint point)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ

	CDialogEx::OnMouseHover(nFlags, point);
}


void CHistoryDialog::OnMouseLeave()
{
	m_bTracking = FALSE;

	m_iMoveSelectItem = -1;
	Invalidate(FALSE);

	CDialogEx::OnMouseLeave();
}


BOOL CHistoryDialog::PreTranslateMessage(MSG* pMsg)
{
	switch(pMsg->message)
	{
	case WM_KEYDOWN:
		{
			switch(pMsg->wParam)
			{
			case 'x':
			case 'X':
				AfxGetMainWnd()->PostMessage(pMsg->message,pMsg->wParam,pMsg->lParam);
				break;
			case 'c':
			case 'C':
				AfxGetMainWnd()->PostMessage(pMsg->message,pMsg->wParam,pMsg->lParam);
				break;
			case 'v':
			case 'V':
				AfxGetMainWnd()->PostMessage(pMsg->message,pMsg->wParam,pMsg->lParam);
				break;
			case 'z':
			case 'Z':
				AfxGetMainWnd()->PostMessage(pMsg->message,pMsg->wParam,pMsg->lParam);
				break;
			case 'y':
			case 'Y':
				AfxGetMainWnd()->PostMessage(pMsg->message,pMsg->wParam,pMsg->lParam);
				break;
			case VK_DELETE:
				AfxGetMainWnd()->PostMessage(pMsg->message,pMsg->wParam,pMsg->lParam);
				break;
			default:
				break;
			}
		}
		break;
	default:
		break;
	}

	return CDialogEx::PreTranslateMessage(pMsg);
}
