// StdPlugin.cpp : ���� DLL �ĳ�ʼ�����̡�
//

#include "stdafx.h"
#include "afxwinappex.h"
#include "afxdialogex.h"
#include "StdPlugin.h"
#include "MainFrm.h"

#include "XmlTools.h"

#include "StdPluginDoc.h"
#include "StdPluginView.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

class CConfigString
{
public:
	CString GetLeft() const
	{
		return m_csLeft;
	}
	CString GetRight() const
	{
		return m_csRight;
	}
public:
	CConfigString()
	{
	}
	CConfigString(CString csLeft,CString csRight)
	{
		m_csLeft = csLeft;
		m_csRight = csRight;
	}
	CConfigString(const CConfigString &configString)
	{
		*this = configString;
	}
	CConfigString& operator=(const CConfigString &configString)
	{
		m_csLeft = configString.m_csLeft;
		m_csRight = configString.m_csRight;

		return *this;
	}
	~CConfigString()
	{
	}
protected:
	CString m_csLeft;
	CString m_csRight;
};

BOOL CStringToConfigString(const CString &csConfigString,CString &csLeft,CString &csRight)
{
	int index = csConfigString.Find('=');
	if(index >= 0)
	{
		csLeft = csConfigString.Left(index);
		csRight = csConfigString.Right(csConfigString.GetLength()-index-1);
		return TRUE;
	}
	return FALSE;
}

CString GetConfigStringRight(const CArray <CConfigString,CConfigString> &configStringArray,CString csLeft)
{
	int i;
	for(i=0; i<configStringArray.GetSize(); i++)
	{
		if(configStringArray.GetAt(i).GetLeft() == csLeft)
			return configStringArray.GetAt(i).GetRight();
	}
	return _T("");
}

ConfigSys::ConfigSys()
{
	m_sel1 = 0;
	m_sel2 = 0;
	m_check1 = 0;
}
ConfigSys::~ConfigSys()
{
}

void ConfigSys::Init()
{
	CString strFile = MODULE_FILE_DIRECTORY + _T("\\StdPlugin.cfg");

	//��������Ϊ����,������Unicode�����¶��������ַ�Ϊ���� ����CStdioFile�ɶ�����������
	TCHAR* old_locale = _tcsdup(_tsetlocale(LC_CTYPE,NULL));
	_tsetlocale(LC_CTYPE,_T("chs"));

	CArray <CConfigString,CConfigString> configStringArray;
	CStdioFile stdioFile;
	if(stdioFile.Open(strFile,CFile::modeRead))
	{
		CString csString;
		while(stdioFile.ReadString(csString))
		{
			CString csLeft;
			CString csRight;
			if(::CStringToConfigString(csString,csLeft,csRight))
			{
				configStringArray.Add(CConfigString(csLeft,csRight));
			}
		}
		stdioFile.Close();
	}

	_tsetlocale(LC_CTYPE,old_locale);
	free(old_locale);

	CString csGroup = ::GetConfigStringRight(configStringArray,_T("group"));
	m_group = csGroup.IsEmpty() ? _T("default") : CCharArr(csGroup);
	
	CString csXml = ::GetConfigStringRight(configStringArray,_T("xml"));
	m_xml = csXml.IsEmpty() ? _T("default.xml") : CCharArr(csXml);

	CString csWhscale_sel1 = ::GetConfigStringRight(configStringArray,_T("whscale_sel1"));
	m_sel1 = ::CStringToInt(csWhscale_sel1);
	if ( m_sel1 < 0 )
		m_sel1 = 0;

	CString csWhscale_sel2 = ::GetConfigStringRight(configStringArray,_T("whscale_sel2"));
	m_sel2 = ::CStringToInt(csWhscale_sel2);
	if ( m_sel2 < 0 )
		m_sel2 = 0;

	CString csWhscale_check1 = ::GetConfigStringRight(configStringArray,_T("whscale_check1"));
	m_check1 = ::CStringToInt(csWhscale_check1);
	if ( m_check1 < 0 )
		m_check1 = 0;

	CString csEncode = ::GetConfigStringRight(configStringArray,_T("encode"));
	m_encode = csEncode.IsEmpty() ? _T("GB2312") : CCharArr(csEncode);

/*	FILE* fp = fopen(CCharArr(strFile),"r");
	if ( NULL != fp )
	{
		char buf[256];
		while(!feof(fp))
		{
			buf[0] = '\0';
			if ( 1 == fscanf(fp,"%s",buf) )
			{
				if ( strlen(buf))
				{
					_putenv(buf);
				}
			}
		}
		fclose(fp);
	}

	char* str = getenv("group");
	m_group = 0==str?"group":str;

	str = getenv("xml");
	m_xml = 0==str?"default.xml":str;

	str = getenv("whscale_sel1");
	if ( 0 != str )
	{
		m_sel1 = atoi(str);
		if ( m_sel1 < 0 ) m_sel1 = 0;
	}
	str = getenv("whscale_sel2");
	if ( 0 != str )
	{
		m_sel2 = atoi(str);
		if ( m_sel2 < 0 ) m_sel2 = 0;
	}
	str = getenv("whscale_check1");
	if ( 0 != str )
	{
		m_check1 = atoi(str);
		if ( m_check1 < 0 ) m_check1 = 0;
	}
	str = getenv("encode");
	m_encode = 0==str?"GB2312":str;*/
}
void ConfigSys::setGroup(const char* str)
{
	m_group = str;
	Save();
}
void ConfigSys::setXml(const char* str)
{
	m_xml = str;
	Save();
}
void ConfigSys::setWHScale(int sel1,int sel2,int check1)
{
	m_sel1 = sel1;
	m_sel2 = sel2;
	m_check1 = check1;
	Save();
}
void ConfigSys::Save()
{
	CString strFile = MODULE_FILE_DIRECTORY + _T("\\StdPlugin.cfg");
	FILE* fp = fopen(CCharArr(strFile),"w");
	if ( NULL != fp )
	{
		fprintf(fp,"encode=%s\n",m_encode.c_str());
		fprintf(fp,"group=%s\n",m_group.c_str());
		fprintf(fp,"xml=%s\n",m_xml.c_str());
		fprintf(fp,"whscale_sel1=%d\n",m_sel1);
		fprintf(fp,"whscale_sel2=%d\n",m_sel2);
		fprintf(fp,"whscale_check1=%d\n",m_check1);
		fflush(fp);
		fclose(fp);
	}

}

//
//TODO: ����� DLL ����� MFC DLL �Ƕ�̬���ӵģ�
//		��Ӵ� DLL �������κε���
//		MFC �ĺ������뽫 AFX_MANAGE_STATE �����ӵ�
//		�ú�������ǰ�档
//
//		����:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// �˴�Ϊ��ͨ������
//		}
//
//		�˺������κ� MFC ����
//		������ÿ��������ʮ����Ҫ������ζ��
//		��������Ϊ�����еĵ�һ�����
//		���֣������������ж������������
//		������Ϊ���ǵĹ��캯���������� MFC
//		DLL ���á�
//
//		�й�������ϸ��Ϣ��
//		����� MFC ����˵�� 33 �� 58��
//

// CStdPluginApp

BEGIN_MESSAGE_MAP(CStdPluginApp, CWinAppEx)
	ON_COMMAND(ID_APP_ABOUT, &CStdPluginApp::OnAppAbout)
	// �����ļ��ı�׼�ĵ�����
	ON_COMMAND(ID_FILE_NEW, &CStdPluginApp::OnFileNew)//CWinAppEx
	ON_COMMAND(ID_FILE_OPEN, &CStdPluginApp::OnFileOpen)//CWinAppEx

	ON_UPDATE_COMMAND_UI(ID_FILE_NEW, OnUpdateFileNew)
	ON_UPDATE_COMMAND_UI(ID_FILE_OPEN, OnUpdateFileOpen)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
END_MESSAGE_MAP()

// CStdPluginApp ����

CStdPluginApp::CStdPluginApp()
{
	// ֧����������������
	m_dwRestartManagerSupportFlags = AFX_RESTART_MANAGER_SUPPORT_ALL_ASPECTS;
#ifdef _MANAGED
	// ���Ӧ�ó��������ù�����������ʱ֧��(/clr)�����ģ���:
	//     1) �����д˸������ã�������������������֧�ֲ�������������
	//     2) ��������Ŀ�У������밴������˳���� System.Windows.Forms �������á�
	System::Windows::Forms::Application::SetUnhandledExceptionMode(System::Windows::Forms::UnhandledExceptionMode::ThrowException);
#endif

	// TODO: ������Ӧ�ó��� ID �ַ����滻ΪΨһ�� ID �ַ�����������ַ�����ʽ
	//Ϊ CompanyName.ProductName.SubProduct.VersionInformation
	SetAppID(_T("StdPlugin.AppID.NoVersion"));
	// TODO: �ڴ˴����ӹ�����룬
	// ��������Ҫ�ĳ�ʼ�������� InitInstance ��
}


// Ψһ��һ�� CStdPluginApp ����

CStdPluginApp theApp;


// CStdPluginApp ��ʼ��

BOOL CStdPluginApp::InitInstance()
{
	// ���һ�������� Windows XP �ϵ�Ӧ�ó����嵥ָ��Ҫ
	// ʹ�� ComCtl32.dll �汾 6 ����߰汾�����ÿ��ӻ���ʽ��
	//����Ҫ InitCommonControlsEx()�����򣬽��޷��������ڡ�
	INITCOMMONCONTROLSEX InitCtrls;
	InitCtrls.dwSize = sizeof(InitCtrls);
	// ��������Ϊ��������Ҫ��Ӧ�ó�����ʹ�õ�
	// �����ؼ��ࡣ
	InitCtrls.dwICC = ICC_WIN95_CLASSES;
	InitCommonControlsEx(&InitCtrls);

	CWinAppEx::InitInstance();


	// ��ʼ�� OLE ��
	if (!AfxOleInit())
	{
		AfxMessageBox(IDP_OLE_INIT_FAILED);
		return FALSE;
	}

	//
	InitCfg();
	InitViewCfg();
	InitSetting();

	AfxEnableControlContainer();

	EnableTaskbarInteraction(FALSE);

	// ʹ�� RichEdit �ؼ���Ҫ  AfxInitRichEdit2()	
	// AfxInitRichEdit2();

	// ��׼��ʼ��
	// ���δʹ����Щ���ܲ�ϣ����С
	// ���տ�ִ���ļ��Ĵ�С����Ӧ�Ƴ�����
	// ����Ҫ���ض���ʼ������
	// �������ڴ洢���õ�ע�����
	// TODO: Ӧ�ʵ��޸ĸ��ַ�����
	// �����޸�Ϊ��˾����֯��
	SetRegistryKey(_T("Ӧ�ó��������ɵı���Ӧ�ó���"));
	LoadStdProfileSettings(4);  // ���ر�׼ INI �ļ�ѡ��(���� MRU)


	InitContextMenuManager();

	InitKeyboardManager();

	InitTooltipManager();
	CMFCToolTipInfo ttParams;
	ttParams.m_bVislManagerTheme = TRUE;
	theApp.GetTooltipManager()->SetTooltipParams(AFX_TOOLTIP_TYPE_ALL,
		RUNTIME_CLASS(CMFCToolTipCtrl), &ttParams);

	// ע��Ӧ�ó�����ĵ�ģ�塣�ĵ�ģ��
	// �������ĵ�����ܴ��ں���ͼ֮�������
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CStdPluginDoc),
		RUNTIME_CLASS(CMainFrame),       // �� SDI ��ܴ���
		RUNTIME_CLASS(CStdPluginView));
	if (!pDocTemplate)
		return FALSE;
	AddDocTemplate(pDocTemplate);


	// ������׼ shell ���DDE�����ļ�������������
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);



	// ��������������ָ����������
	// �� /RegServer��/Register��/Unregserver �� /Unregister ����Ӧ�ó����򷵻� FALSE��
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// Ψһ��һ�������ѳ�ʼ���������ʾ����������и���
	m_pMainWnd->ShowWindow(SW_MAXIMIZE);
	m_pMainWnd->UpdateWindow();
	// �������к�׺ʱ�ŵ��� DragAcceptFiles
	//  �� SDI Ӧ�ó����У���Ӧ�� ProcessShellCommand ֮����
	return TRUE;
}

int CStdPluginApp::ExitInstance()
{
	//TODO: �������������ӵĸ�����Դ
	AfxOleTerm(FALSE);

	return CWinAppEx::ExitInstance();
}

BOOL CStdPluginApp::LoadWindowPlacement(CRect& rectNormalPosition, int& nFflags, int& nShowCmd)
{
	return CWinAppEx::LoadWindowPlacement(rectNormalPosition,nFflags,nShowCmd);
}

BOOL CStdPluginApp::StoreWindowPlacement(const CRect& rectNormalPosition, int nFflags, int nShowCmd)
{
	return CWinAppEx::StoreWindowPlacement(rectNormalPosition, nFflags, nShowCmd);
}

// CStdPluginApp ��Ϣ��������


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��
	BOOL OnInitDialog();

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BOOL CAboutDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	CString csAppTitle;
	csAppTitle.LoadString(AFX_IDS_APP_TITLE);
	SetWindowText(_T("���� ")+csAppTitle);
	GetDlgItem(IDC_STATIC_ABOUT)->SetWindowText(csAppTitle+_T(" ")+APP_VERSION+_T(" ��"));

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()

void CStdPluginApp::OnUpdateFileNew(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);
}

void CStdPluginApp::OnUpdateFileOpen(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);
}

void CStdPluginApp::OnUpdateFileSave(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(FALSE);
}

// �������жԻ����Ӧ�ó�������
void CStdPluginApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

// CStdPluginApp �Զ������/���淽��

void CStdPluginApp::PreLoadState()
{
	BOOL bNameValid;
	CString strName;
	bNameValid = strName.LoadString(IDS_EDIT_MENU);
	ASSERT(bNameValid);
	GetContextMenuManager()->AddMenu(strName, IDR_POPUP_EDIT);
}

void CStdPluginApp::LoadCustomState()
{
	((CMainFrame*)AfxGetMainWnd())->LoadMainFrmState();
}

void CStdPluginApp::SaveCustomState()
{
}

// CStdPluginApp ��Ϣ��������

void CStdPluginApp::InitCfg()
{
	m_Config.Init();
}
void CStdPluginApp::InitViewCfg()
{
	CString strFile = MODULE_FILE_DIRECTORY + _T("\\UserView.cfg");
	FILE* fp = fopen(CCharArr(strFile),"r");
	if ( NULL != fp )
	{
		TCHAR buf[256];
		while ( 1 )
		{
			buf[0] = '\0';
			if ( _ftscanf(fp,_T("%s\n"),buf) > 0 )
			{
				CString strCheck = CString(buf);
				if ( strCheck.GetLength() < 1)
				{
					continue;
				}
				if ( strCheck.GetLength() > 32)
				{
					AfxMessageBox(_T("���ԡ�UserView.cfg�������Ƴ��ȳ�����32�ַ�������."));
					continue;
				}
				CString strName;
				CString strChild;
				if ( -1 != strCheck.Find(_T(",")))
				{
					strName = strCheck.Left(strCheck.Find(_T(",")));
					strChild = strCheck.Right(strCheck.GetLength() - strCheck.Find(_T(","))-1);
				}
				else
				{
					strName = strCheck;
				}

				if ( !check_name(strName))
				{
					continue;
				}
				if ( !check_name(strChild))
				{
					continue;
				}
				m_ViewCfgs.Add(strName);
				if ( strChild.GetLength() > 0 )
				{
					//m_ViewCfgs.Add(strChild);
					m_ViewCfgChilds.SetAt(strName,strChild);
				}
				continue;
			}
			break;
		}
		fclose(fp);
	}

}

void CStdPluginApp::InitSetting()
{
	TCHAR szReturnedString[1024];
	int nSize = 1024;

	int iGridHSkip = ::GetPrivateProfileInt(_T("setting"),_T("GridH"),64,SETTING_FILE_PATH);
	int iGridVSkip = ::GetPrivateProfileInt(_T("setting"),_T("GridV"),64,SETTING_FILE_PATH);
	::GetPrivateProfileString(_T("setting"),_T("GridColor"),_T("255,255,255"),szReturnedString,nSize,SETTING_FILE_PATH);
	COLORREF gridColor = ::RGBCStringToCOLORREF(szReturnedString);

	::GetPrivateProfileString(_T("setting"),_T("BorderColor"),_T("255,0,0"),szReturnedString,nSize,SETTING_FILE_PATH);
	COLORREF borderColor = ::RGBCStringToCOLORREF(szReturnedString);
	::GetPrivateProfileString(_T("setting"),_T("BkColor"),_T("0,0,0"),szReturnedString,nSize,SETTING_FILE_PATH);
	COLORREF bkColor = ::RGBCStringToCOLORREF(szReturnedString);
	::GetPrivateProfileString(_T("setting"),_T("WellColor"),_T("255,255,0"),szReturnedString,nSize,SETTING_FILE_PATH);
	COLORREF wellColor = ::RGBCStringToCOLORREF(szReturnedString);
	::GetPrivateProfileString(_T("setting"),_T("BottomColor"),_T("255,255,255"),szReturnedString,nSize,SETTING_FILE_PATH);
	COLORREF bottomColor = ::RGBCStringToCOLORREF(szReturnedString);

	BOOL bEditMode = ::GetPrivateProfileInt(_T("setting"),_T("EditMode"),TRUE,SETTING_FILE_PATH);
	BOOL bShowGrid = ::GetPrivateProfileInt(_T("setting"),_T("ShowGrid"),FALSE,SETTING_FILE_PATH);
	BOOL bShowBorder = ::GetPrivateProfileInt(_T("setting"),_T("ShowBorder"),FALSE,SETTING_FILE_PATH);
	BOOL bShowWell = ::GetPrivateProfileInt(_T("setting"),_T("ShowWell"),FALSE,SETTING_FILE_PATH);

	::GetPrivateProfileString(_T("setting"),_T("DefaultFontName"),_T(""),szReturnedString,nSize,SETTING_FILE_PATH);
	::SetDefaultFontName(szReturnedString);

	::SetGridHSkip(iGridHSkip);
	::SetGridVSkip(iGridVSkip);
	::SetGridRed(GetRValue(gridColor));
	::SetGridGreen(GetGValue(gridColor));
	::SetGridBlue(GetBValue(gridColor));

	::SetBorderRed(GetRValue(borderColor));
	::SetBorderGreen(GetGValue(borderColor));
	::SetBorderBlue(GetBValue(borderColor));

	::SetBkRed(GetRValue(bkColor));
	::SetBkGreen(GetGValue(bkColor));
	::SetBkBlue(GetBValue(bkColor));

	::SetBottomColor(bottomColor);

	::SetWellRed(GetRValue(wellColor));
	::SetWellGreen(GetGValue(wellColor));
	::SetWellBlue(GetBValue(wellColor));

	::SetEditMode(bEditMode);
	::SetShowGrid(bShowGrid);
	::SetShowBorder(bShowBorder);
	::SetShowWell(bShowWell);
}
/*
void OnPrepareWindow ( WindowInterface* wi )
{
	HWND hConsole = GetConsoleWindow();
	RECT rc;
	::GetWindowRect(hConsole,&rc);
	::MoveWindow(hConsole,rc.left,48,rc.right-rc.left,rc.bottom-rc.top-48,TRUE);

	ShowWindow(hConsole,SW_HIDE);

	CWinApp *pWinApp = AfxGetApp();
	wi->hWndParent = ((CMainFrame*)AfxGetMainWnd())->GetActiveView()->GetSafeHwnd();
	wi->dwStyle = WS_CHILD;
	wi->dwExStyle = 0;
	wi->wc.lpszMenuName = 0;
}
*/
static HHOOK g_hKBH = NULL;
LRESULT CALLBACK KeyboardProc(int code,WPARAM wParam,LPARAM lParam)
{
/*	MSG* pMsg=(MSG*) lParam;
	if (code>=0)
	{
		switch(pMsg->message)
		{
		case WM_KEYDOWN:
			{
				switch(pMsg->wParam)
				{
				case VK_LEFT:
					break;
				default:
					break;
				}
			}
			break;
		case WM_LBUTTONDBLCLK:
			{
			}
			break;
		case WM_RBUTTONDOWN:
			{
			}
			break;
		default:
			break;
		}
	}*/
	if (HC_ACTION == code)
	{
		if (0 == (static_cast<DWORD>(lParam) & (1 << 31)) && 0 == (static_cast<DWORD>(lParam) & (1 << 30)))
		{
			// WM_KEYDOWN
/*			switch(wParam)
			{
			default:
				break;
			}*/
		}
	}
	return CallNextHookEx(g_hKBH, code, wParam, lParam);
}

void OnCreate(HWND hWnd)
{
//	HMODULE hModule = GetModuleHandle(NULL);
	g_hKBH = ::SetWindowsHookEx(WH_KEYBOARD,KeyboardProc,::GetUIInstance(),GetCurrentThreadId());
//	g_hKBH = ::SetWindowsHookEx(WH_GETMESSAGE,KeyboardProc,::GetUIInstance(),GetCurrentThreadId());

	HWND hViewWnd = ((CMainFrame*)AfxGetMainWnd())->GetActiveView()->GetSafeHwnd();
	::SetUIWnd(hWnd);

	RECT rc;
	::GetWindowRect(hWnd,&rc);
	int w = rc.right - rc.left;
	int h = rc.bottom - rc.top;
	int x = 0;
	int y = 0;
	::MoveWindow(hWnd,x,y,w,h,TRUE);
}

int g_iDrawingIdTouchEditor = -1;

float g_fDrawingTouchBeginX = 0.0f;
float g_fDrawingTouchBeginY = 0.0f;
float g_fDrawingTouchEndX = 0.0f;
float g_fDrawingTouchEndY = 0.0f;
float g_fDrawingTouchLastX = 0.0f;
float g_fDrawingTouchLastY = 0.0f;
float g_fDrawingX = 0.0f;
float g_fDrawingY = 0.0f;
float g_fDrawingOffsetX = 0.0f;
float g_fDrawingOffsetY = 0.0f;

int OnLButtonDown ( int x,int y )
{
//	::SetFocus(::GetUIWnd());


	g_fDrawingTouchBeginX = 0.0f;
	g_fDrawingTouchBeginY = 0.0f;

	g_fDrawingTouchLastX = 0.0f;
	g_fDrawingTouchLastY = 0.0f;

	g_fDrawingTouchEndX = 0.0f;
	g_fDrawingTouchEndY = 0.0f;

	g_fDrawingX = 0.0f;
	g_fDrawingY = 0.0f;

	g_fDrawingOffsetX = 0.0f;
	g_fDrawingOffsetY = 0.0f;

	g_iDrawingIdTouchEditor = -1;

	AnimInterface *pAnimInterface = ::GetAnimInterface();
	if ( ::GetEditMode() )
	{
		g_iDrawingIdTouchEditor = pAnimInterface->drawing_pick(0,x,y);
		if ( g_iDrawingIdTouchEditor < 3000 )
		{
			g_iDrawingIdTouchEditor = -1;
			DeleteWellText();
			return 1;
		}
		
		int id = g_iDrawingIdTouchEditor;
		while ( true )
		{
			if ( 0 != pAnimInterface->drawing_get_name(id) )
			{
				break;
			}
			id = pAnimInterface->drawing_get_parent(id);
			if ( -1 == id )
			{
				break;
			}
		}
		g_iDrawingIdTouchEditor = id;

		if ( -1 != g_iDrawingIdTouchEditor )
		{
			::SetEditorDrawingId(g_iDrawingIdTouchEditor);
			g_fDrawingTouchBeginX = (float)x;
			g_fDrawingTouchBeginY = (float)y;
			g_fDrawingTouchLastX = (float)x;
			g_fDrawingTouchLastY = (float)y;

			double fx,fy,fw,fh;
			if ( pAnimInterface->drawing_get_rect(g_iDrawingIdTouchEditor,fx,fy,fw,fh) < 0 )
			{
				g_iDrawingIdTouchEditor = -1;
				::SetEditorDrawingId(-1);
			}
			else
			{
				g_fDrawingX = (float)fx;
				g_fDrawingY = (float)fy;

				double ox,oy;
				pAnimInterface->drawing_get_offset(g_iDrawingIdTouchEditor,ox,oy);

				g_fDrawingOffsetX = (float)ox;
				g_fDrawingOffsetY = (float)oy;

				fx += ox;
				fy += oy;
				if ( ::GetShowWell() )
				{
					ReCreateWellText((int)fx,(int)fy,(int)(fx+fw),(int)(fy+fh),::GetWellRed(),::GetWellGreen(),::GetWellBlue());
				}

				CString strName;
				CString strParent;
				::GetUIPathName(::GetEditorDrawingId(),strParent,strName);
				if(!strName.IsEmpty())
				{
//					char strLog[256];
//					sprintf(strLog,"click %d %s",g_iDrawingIdTouchEditor,CCharArr(strName));
					print_string("","click %d %s",g_iDrawingIdTouchEditor,CCharArr(strName));
//					pAnimInterface->print_string(strLog);
				}
			}
			((CMainFrame*)AfxGetMainWnd())->ChangeEditorDrawingId();
		}
		return 1;
	}
	else
	{
		return 0;
	}
/*
	float fDrawingTouchBeginX = (float)x;
	float fDrawingTouchBeginY = (float)y;
	int iDrawingIdTouchEditor = -1;
	if(::GetEditMode())
	{
		iDrawingIdTouchEditor = pAnimInterface->drawing_pick(0,x,y);
		if(iDrawingIdTouchEditor < 3000)
		{
			iDrawingIdTouchEditor = -1;
			DeleteWellText();
			return 1;
		}
		int id = iDrawingIdTouchEditor;
		while(true)
		{
			if(0 != pAnimInterface->drawing_get_name(id))
				break;

			id = pAnimInterface->drawing_get_parent(id);
			if(-1 == id)
				break;
		}
		iDrawingIdTouchEditor = id;

		g_fDrawingTouchBeginX = x;
		g_fDrawingTouchBeginY = y;

		if(-1 != iDrawingIdTouchEditor)
		{
			double fx,fy,fw,fh;
			if(pAnimInterface->drawing_get_rect(iDrawingIdTouchEditor,fx,fy,fw,fh) < 0)
			{
				iDrawingIdTouchEditor = -1;
			}
			else
			{
				g_fDrawingX = fx;
				g_fDrawingY = fy;
			}
		}
	}

	SetDrawingIdTouchEditor(iDrawingIdTouchEditor);
	((CMainFrame*)AfxGetMainWnd())->ChangeDrawingIdTouchEditor();

	CString strName;
	CString strParent;
	::GetUIPathName(iDrawingIdTouchEditor,strParent,strName);
	if(!strName.IsEmpty())
	{
		char strLog[256];
		sprintf(strLog,"click %d %s",iDrawingIdTouchEditor,CCharArr(strName));
		pAnimInterface->print_string(strLog);
	}

	return 1;*/
}

int OnLButtonUp ( int x,int y )
{
//	if(::GetFocus() != ::GetUIWnd())
//		return 0;

	if ( ::GetEditMode() )
	{
		AnimInterface *pAnimInterface = ::GetAnimInterface();
		if ( -1 != g_iDrawingIdTouchEditor )
		{
			g_fDrawingTouchEndX = (float)x;
			g_fDrawingTouchEndY = (float)y;

			float fx = g_fDrawingX+(g_fDrawingTouchEndX-g_fDrawingTouchBeginX);
			float fy = g_fDrawingY+(g_fDrawingTouchEndY-g_fDrawingTouchBeginY);
			pAnimInterface->drawing_set_position(g_iDrawingIdTouchEditor,fx,fy);

			BOOL bMoveSeat = !(fabs(fx-g_fDrawingX) < 0.5 && fabs(fy-g_fDrawingY) < 0.5);
			double dX,dY,dWidth,dHeight;
			if (bMoveSeat && !(pAnimInterface->drawing_get_rect(g_iDrawingIdTouchEditor,dX,dY,dWidth,dHeight) < 0) )
			{
				((CMainFrame*)AfxGetMainWnd())->ChangeEditorDrawingSeat(dX,dY,dWidth,dHeight,TRUE);
			}
//			g_pMainDialog->SetDiffXY(g_fDrawingTouchEndX-g_fDrawingTouchLastX,g_fDrawingTouchEndY-g_fDrawingTouchLastY,false);
			g_fDrawingTouchLastX = (float)x;
			g_fDrawingTouchLastY = (float)y;

/*			if ( (fx-g_fDrawingX) < 0.5 && (fy-g_fDrawingY) < 0.5 )
			{
				g_pMainDialog->EnableRevoke(TRUE);
			}*/
		}
		g_iDrawingIdTouchEditor = -1;

		return 1;
	}
	else
	{
		return 0;
	}
}

int OnMouseMove ( int x,int y )
{
//	if(::GetFocus() != ::GetUIWnd())
//		return 0;

	AnimInterface *pAnimInterface = ::GetAnimInterface();
	if ( ::GetEditMode() )
	{
		if ( -1 != g_iDrawingIdTouchEditor )
		{
			g_fDrawingTouchEndX = (float)x;
			g_fDrawingTouchEndY = (float)y;

			float fx = g_fDrawingX+(g_fDrawingTouchEndX-g_fDrawingTouchBeginX);
			float fy = g_fDrawingY+(g_fDrawingTouchEndY-g_fDrawingTouchBeginY);
			pAnimInterface->drawing_set_position(g_iDrawingIdTouchEditor,fx,fy);
			double dX,dY,dWidth,dHeight;
			if ( !(pAnimInterface->drawing_get_rect(g_iDrawingIdTouchEditor,dX,dY,dWidth,dHeight) < 0) )
			{
				((CMainFrame*)AfxGetMainWnd())->ChangeEditorDrawingSeat(dX,dY,dWidth,dHeight,FALSE);
			}
//			g_pMainDialog->SetDiffXY(g_fDrawingTouchEndX-g_fDrawingTouchLastX,g_fDrawingTouchEndY-g_fDrawingTouchLastY,true);
			g_fDrawingTouchLastX = (float)x;
			g_fDrawingTouchLastY = (float)y;
			if ( ::GetShowWell() )
			{
				double ox,oy;
				pAnimInterface->drawing_get_offset(g_iDrawingIdTouchEditor,ox,oy);
				double x1,y1,w1,h1;
				pAnimInterface->drawing_get_rect(g_iDrawingIdTouchEditor,x1,y1,w1,h1);
				fx += (float)ox;
				fy += (float)oy;
				ReCreateWellText((int)fx,(int)fy,(int)(fx+w1),(int)(fy+h1),::GetWellRed(),::GetWellGreen(),::GetWellBlue());
			}
			
		}
		return 1;
	}
	else
	{
		return 0;
	}

}

void LuaInit(void* param1,void* param2)
{
	LuaInterface* pLuaInterface = (LuaInterface*)param1;
	::SetLuaInterface(pLuaInterface);
	if(pLuaInterface != NULL)
	{
		SetLuaState((lua_State*)pLuaInterface->GetLuaState());
	}
}

void RenderBegin()
{
	CRenderBase *pRenderBase = GetRenderBase();
	if(pRenderBase == NULL)
		return;

	pRenderBase->SetClearColor(((float)::GetBkRed())/255.0f,((float)::GetBkGreen())/255.0f,((float)::GetBkBlue())/255.0f);
}

void RenderEnd()
{
	CRenderBase *pRenderBase = GetRenderBase();
	if(pRenderBase == NULL)
		return;

	if (::GetShowGrid() )
	{
		int iMainWidth = ::GetUIWndWidth();
		int iMainHeight = ::GetUIWndHeight();

		pRenderBase->Reset();
		int i;
		pRenderBase->PushColor();
		pRenderBase->ForceColor(((float)::GetGridRed())/255.0f,((float)::GetGridGreen())/255.0f,((float)::GetGridBlue())/255.0f,1.0f);
		for ( i = 0; i < iMainWidth; )
		{
			::DrawVLine((float)i);
			i += ::GetGridHSkip();
		}
		for ( i = iMainHeight; i > 0; )
		{
			::DrawHLine((float)(iMainHeight - i));
			i -= ::GetGridVSkip();
		}
		pRenderBase->PopColor();
	}
}
void DrawNodeBegin(DrawingInterface* pDrawing)
{
	CRenderBase *pRenderBase = GetRenderBase();
	if(pRenderBase == NULL)
		return;

	if ( ::GetEditMode() )
	{
		pRenderBase->PushClip();
		pRenderBase->ForceClip(0,0,5000,5000);
	}
}

void DrawNodeEnd ( DrawingInterface* pDrawing )
{
	CRenderBase *pRenderBase = GetRenderBase();
	if(pRenderBase == NULL)
		return;
	AnimInterface *pAnimInterface = ::GetAnimInterface();
	if(pAnimInterface == NULL)
		return;

	int iDrawingId = pDrawing->GetId();
	float x,y,w,h;
	pDrawing->GetRect(x,y,w,h);
	x = y = 0.0f;
	if ( ::GetShowBorder() && iDrawingId > 3000)
	{
		const char* strName = pAnimInterface->drawing_get_name(iDrawingId);
		if ( 0 != strName && 0 != strcmp(strName,"root"))
		{
			if ( EDrawingNode == pAnimInterface->drawing_get_type(iDrawingId))
			{
				if ( w < 1 ) w = 8;
				if ( h < 1 ) h = 8;
			}
			float fRect[8];
			fRect[0] = x;
			fRect[1] = y;
			fRect[2] = x+w;
			fRect[3] = y;
			fRect[4] = x+w;
			fRect[5] = y+h;
			fRect[6] = x;
			fRect[7] = y+h;

			pRenderBase->PushColor();
			pRenderBase->ForceColor(((float)::GetBorderRed())/255.0f,((float)::GetBorderGreen())/255.0f,((float)::GetBorderBlue())/255.0f,1.0f);
			pRenderBase->DrawPolygon(fRect,0,4,false);
			pRenderBase->PopColor();
		}
	}
	if ( ::GetEditMode())
	{
		int iEditorDrawingId = GetEditorDrawingId();
		if ( iEditorDrawingId == iDrawingId )
		{
			if ( w < 1 ) w = 8;
			if ( h < 1 ) h = 8;

			float fRect[8];
			fRect[0] = x;
			fRect[1] = y;
			fRect[2] = x+w;
			fRect[3] = y;
			fRect[4] = x+w;
			fRect[5] = y+h;
			fRect[6] = x;
			fRect[7] = y+h;

			pRenderBase->PushColor();
			pRenderBase->ForceColor(((float)::GetBorderRed())/255.0f,((float)::GetBorderGreen())/255.0f,((float)::GetBorderBlue())/255.0f,0.3f);
			pRenderBase->DrawPolygon(fRect,0,4,true);
			pRenderBase->PopColor();

			if(::GetShowWell())
			{
				pRenderBase->PushColor();
				pRenderBase->ForceColor(((float)::GetWellRed())/255.0f,((float)::GetWellGreen())/255.0f,((float)::GetWellBlue())/255.0f,1.0f);
				::DrawWell(x,y,w,h);
				pRenderBase->PopColor();
			}
		}
		pRenderBase->PopClip();
	}

}

int _plugin_proc(EPluginMsgType eMsgType,void* param1,void* param2)
{
	switch(eMsgType)
	{
	case EWin32Instance:
		::SetUIInstance((HINSTANCE)param1);
		break;
	case EWin32EngineStart:
		{
			::SetEngineInterface((EngineInterface*)param1);
			EngineInterface *pEngineInterface = ::GetEngineInterface();
			if(pEngineInterface != NULL)
			{
				int w;
				int h;
				pEngineInterface->GetViewSize(w,h);
				pEngineInterface->SetStartLua("editor.lua");
				
				SetUIWndSize(w,h);
				((CStdPluginView*)((CMainFrame*)AfxGetMainWnd())->GetActiveView())->SetUIWndSize(w,h);
			}

			HWND hConsole = GetConsoleWindow();
			RECT rc;
			::GetWindowRect(hConsole,&rc);
			::MoveWindow(hConsole,rc.left,48,rc.right-rc.left,rc.bottom-rc.top-48,TRUE);

			ShowWindow(hConsole,SW_HIDE);

			theApp.Run();
		}
		break;
/*
	case EWndPrepare:
		OnPrepareWindow((WindowInterface*)param1);
		break;

	case EWndCreate:
		OnCreate((HWND)param1);
		break;
*/
	case EViewOnReady:
		::SetAnimInterface((AnimInterface*)param1);
		//��ֹ��˸
		GetAnimInterface()->sys_set_int("force_redraw",1);
		::SetRenderBase((CRenderBase*)param2);
		break;
	case ELuaOnReady:
		LuaInit(param1,param2);
		break;
/*
	case ELuaPrepare:
		strcpy((char*)param1,"editor.lua");
		break;
*/	
	case ERenderBegin:
		RenderBegin();
		break;
	
	case ERenderEnd:
		RenderEnd();
		break;
	
	case ENodeRenderBegin:
		DrawNodeBegin((DrawingInterface*)param1);
		break;
	
	case ENodeRenderEnd:
		DrawNodeEnd((DrawingInterface*)param1);
		break;
	
	case ETouchDown:
		OnLButtonDown((int)*((float*)param1),(int)*((float*)param2));
		break;

	case ETouchMove:
		OnMouseMove((int)*((float*)param1),(int)*((float*)param2));
		break;

	case ETouchUp:
		OnLButtonUp((int)*((float*)param1),(int)*((float*)param2));
		break;

	case ETouchCancel:
		break;

	case EWin32ConsoleError:
		{
		}
		break;

	case EWin32LuaError:
		{
			CMainFrame *pMainFrame = (CMainFrame*)AfxGetMainWnd();
			if(pMainFrame != NULL)
			{
				pMainFrame->ShowConsole();
				pMainFrame->SetConsoleTopMost();
			}
		}
		break;

	default:
		break;
	}
	return 0;
}
extern "C"
{
	int plugin_proc(EPluginMsgType eMsgType,void* param1,void* param2)
	{
		AFX_MANAGE_STATE(AfxGetStaticModuleState());
		return _plugin_proc(eMsgType,param1,param2);
	}
}
