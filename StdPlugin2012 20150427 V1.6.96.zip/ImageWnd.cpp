// AddNodeWnd.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "ImageWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CImageWnd

IMPLEMENT_DYNAMIC(CImageWnd, CWnd)

CImageWnd::CImageWnd()
{
}

CImageWnd::~CImageWnd()
{
	m_pBitmap = NULL;
}


BEGIN_MESSAGE_MAP(CImageWnd, CWnd)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	ON_WM_SIZE()
END_MESSAGE_MAP()



// CImageWnd ��Ϣ��������

void CImageWnd::SetImage(Bitmap *pBitmap,int x,int y,int width,int height)
{
	m_pBitmap = pBitmap;
	m_x = x;
	m_y = y;
	m_width = width;
	m_height = height;

	Invalidate(FALSE);
}

int CImageWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	return 0;
}

BOOL CImageWnd::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
	return CWnd::OnEraseBkgnd(pDC);
}

CSize ShowPicSize(int iBmpWidth,int iBmpHigh,int iShowWidth,int iShowHigh)
{
	CSize size(0,0);
	if(iBmpHigh == 0 || iShowHigh == 0)
		return size;

	float fBmp,fShow;
	fBmp = (float)iBmpWidth/(float)iBmpHigh;
	fShow = (float)iShowWidth/(float)iShowHigh;
	if(fBmp > fShow)
	{
		size.cx = iShowWidth;
		size.cy = (int)(iShowWidth/fBmp);
	}
	else
	{
		size.cy = iShowHigh;
		size.cx = (int)(iShowHigh*fBmp);
	}
	return size;
}

void CImageWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	CRect rect;
	GetClientRect(rect);

	CDC MemDC;
	MemDC.CreateCompatibleDC(&dc);
	CBitmap MemBitmap;
	MemBitmap.CreateCompatibleBitmap(&dc,rect.Width(),rect.Height());
	if(MemBitmap.m_hObject == NULL)
		return;
	CBitmap *pOldBit=MemDC.SelectObject(&MemBitmap);
	MemDC.FillSolidRect(0,0,rect.Width(),rect.Height(),RGB(255,255,255));
	MemDC.SetBkMode(TRANSPARENT);

	int iPageWidth = rect.Width();
	int iPageHeight = rect.Height();

	Graphics g(MemDC.GetSafeHdc());

	int iDistance = 8;
	int iXNum = iPageWidth/iDistance+1;
	int iYNum = iPageHeight/iDistance+1;
	SolidBrush brush1(Color(255,255,255));
	SolidBrush brush2(Color(204,204,204));
	int i,j;
	for(i=0; i<iXNum; i++)
	{
		for(j=0; j<iYNum; j++)
		{
			BOOL bFlag = (i%2) ? (j%2) : !(j%2);
			if(bFlag)
				g.FillRectangle(&brush1,i*iDistance,j*iDistance,iDistance,iDistance);
			else
				g.FillRectangle(&brush2,i*iDistance,j*iDistance,iDistance,iDistance);
		}
	}

	g.DrawRectangle(&Pen(Color(128,0,0,255)),0,0,iPageWidth-1,iPageHeight-1);

	if(m_pBitmap != NULL)
	{
		CSize size = ::ShowPicSize(m_width,m_height,iPageWidth,iPageHeight);
		int iShowWidth = min(size.cx,m_width);
		int iShowHeight = min(size.cy,m_height);
		int iShowLeft = (iPageWidth-iShowWidth)/2;
		int iShowTop = (iPageHeight-iShowHeight)/2;
		g.DrawImage(m_pBitmap,Rect(iShowLeft,iShowTop,iShowWidth,iShowHeight),m_x,m_y,m_width,m_height,UnitPixel);
	}

	dc.BitBlt(0,0,rect.Width(),rect.Height(),&MemDC,0,0,SRCCOPY);
	MemDC.SelectObject(pOldBit);
	MemBitmap.DeleteObject();
}

void CImageWnd::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	Invalidate(FALSE);
}
