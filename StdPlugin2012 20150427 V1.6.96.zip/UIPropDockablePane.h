#pragma once

#include "UIPropDialog.h"

// CUIPropDockablePane

class CUIPropDockablePane : public CDockablePane
{
public:
	void ChangeDrawingBase(const CDrawingBase *pDrawingBase);
	const CDrawingBase* GetDrawingBase() const;
	void SaveChangeUIProp();
private:
	CUIPropDialog m_uiPropDialog;

	DECLARE_DYNAMIC(CUIPropDockablePane)

public:
	CUIPropDockablePane();
	virtual ~CUIPropDockablePane();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


