#pragma once


// CImageWnd

class CImageWnd : public CWnd
{
public:
	void SetImage(Bitmap *pBitmap,int x,int y,int width,int height);
private:
	Bitmap *m_pBitmap;
	int m_x;
	int m_y;
	int m_width;
	int m_height;

	DECLARE_DYNAMIC(CImageWnd)

public:
	CImageWnd();
	virtual ~CImageWnd();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


