#pragma once


// CTreeCtrl2
class CView1;
class CTreeCtrl2 : public CTreeCtrl
{
	DECLARE_DYNAMIC(CTreeCtrl2)

public:
	CTreeCtrl2();
	virtual ~CTreeCtrl2();

	CMapStringToString* GetChildsNames ( HTREEITEM hItem );

public:
	void DeleteAllItems2();
	void SetItemData2(HTREEITEM hItem,CView1* pView);
	void DeleteItem2(HTREEITEM hItem);
private:
	CImageList* CreateDragImageEx(HTREEITEM hItem);
	BOOL FirstIsParent ( HTREEITEM hFirst,HTREEITEM hItem);
protected: 
	//{{AFX_MSG(CTreeCtrl2) 
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point); 
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point); 
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point); 
	afx_msg void OnMouseMove(UINT nFlags, CPoint point); 
	afx_msg void OnBegindrag(NMHDR* pNMHDR, LRESULT* pResult); 
	//}}AFX_MSG 

	DECLARE_MESSAGE_MAP() 

protected: 
	HTREEITEM CopyBranch(HTREEITEM hItem , HTREEITEM hParent , HTREEITEM hAfter); 

private: 

	CMapStringToString m_ChildsNames;
	CMap<HTREEITEM,HTREEITEM,CView1*,CView1*> m_TreeData;
	CPoint m_DragPos; 

	BOOL        m_bIsDrag  ;       //�Ƿ����϶�  
	HTREEITEM	m_hItemDrag;       //���϶��Ľڵ� 
	HTREEITEM   m_hItemDrop;       //��ǰѡ�нڵ�   
	CImageList*	m_pDragImage;      //�϶�ͼ���б� 
public:
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
};


