// FileDialogEx.cpp : implementation file
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "FileDialogEx.h"
#include <dlgs.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileDialogEx

IMPLEMENT_DYNAMIC(CFileDialogEx, CFileDialog)

CFileDialogEx::CFileDialogEx(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
}


BEGIN_MESSAGE_MAP(CFileDialogEx, CFileDialog)
	//{{AFX_MSG_MAP(CFileDialogEx)
	ON_WM_DESTROY()
	ON_MESSAGE(WM_POSTINIT, OnPostInit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void MoveDown ( CWnd* pDlg,CWnd* pWnd, UINT iHeightExt )
{
	RECT Rect;
	pWnd->GetWindowRect(&Rect);
	pDlg->ScreenToClient(&Rect);
	pWnd->MoveWindow(
		Rect.left,
		Rect.top + iHeightExt,
		Rect.right - Rect.left, 
		Rect.bottom - Rect.top,FALSE); 

}
BOOL CFileDialogEx::OnInitDialog() 
{
	CFileDialog::OnInitDialog();
	
	RECT Rect;
	CWnd* pWnd;
	CWnd *pDlg = GetParent();
	
	pDlg->GetWindowRect(&Rect);
	int nFullWidth=GetSystemMetrics(SM_CXSCREEN);   
	int nFullHeight=GetSystemMetrics(SM_CYSCREEN);

	UINT iWidthExt = (nFullWidth - ( Rect.right - Rect.left ))-8;
	UINT iHeightExt = (nFullHeight - ( Rect.bottom - Rect.top ))-64;

	//��������
	// Change the size of FileOpen dialog
	pDlg->SetWindowPos(NULL, 0, 0, 
                        (Rect.right - Rect.left) + iWidthExt, 
                        (Rect.bottom - Rect.top) + iHeightExt, 
                        SWP_NOMOVE);


	//��������
	pWnd = pDlg->GetDlgItem(lst1);
	pWnd->GetWindowRect(&Rect);
	pWnd->ScreenToClient(&Rect);
	pWnd->SetWindowPos(NULL, 0, 0, 
		(Rect.right - Rect.left) + iWidthExt, 
		(Rect.bottom - Rect.top) + iHeightExt, 
		SWP_NOMOVE);

	//���·Ŵ�
	pWnd = pDlg->GetDlgItem(ctl1);
	pWnd->GetWindowRect(&Rect);
	pWnd->ScreenToClient(&Rect);
	pWnd->SetWindowPos(NULL, 0,0,
		(Rect.right - Rect.left), 
		(Rect.bottom - Rect.top) + iHeightExt, 
		SWP_NOMOVE);

	//����
	pWnd = pDlg->GetDlgItem(stc2);
	pWnd->GetWindowRect(&Rect);
	pDlg->ScreenToClient(&Rect);
	pWnd->MoveWindow(
		Rect.left,
		Rect.top + iHeightExt,
		Rect.right - Rect.left, 
		Rect.bottom - Rect.top,FALSE); 

	//����
	pWnd = pDlg->GetDlgItem(stc3);
	pWnd->GetWindowRect(&Rect);
	pDlg->ScreenToClient(&Rect);
	pWnd->MoveWindow(
		Rect.left,
		Rect.top + iHeightExt,
		Rect.right - Rect.left, 
		Rect.bottom - Rect.top,FALSE); 

	//���Ʋ����ҷŴ�
	pWnd = pDlg->GetDlgItem(cmb13);
	pWnd->GetWindowRect(&Rect);
	pDlg->ScreenToClient(&Rect);
	pWnd->MoveWindow(
		Rect.left,
		Rect.top + iHeightExt,
		Rect.right - Rect.left + iWidthExt, 
		Rect.bottom - Rect.top,FALSE); 

	//���Ʋ����ҷŴ�
	pWnd = pDlg->GetDlgItem(cmb1);
	pWnd->GetWindowRect(&Rect);
	pDlg->ScreenToClient(&Rect);
	pWnd->MoveWindow(
		Rect.left,
		Rect.top + iHeightExt,
		Rect.right - Rect.left + iWidthExt, 
		Rect.bottom - Rect.top,FALSE); 
	
	pWnd = pDlg->GetDlgItem(chx1);
	pWnd->GetWindowRect(&Rect);
	pDlg->ScreenToClient(&Rect);
	pWnd->MoveWindow(
		Rect.left,
		Rect.top + iHeightExt,
		Rect.right - Rect.left + iWidthExt, 
		Rect.bottom - Rect.top,FALSE); 

	//��������
	pWnd = pDlg->GetDlgItem(IDOK);
	pWnd->GetWindowRect(&Rect);
	pDlg->ScreenToClient(&Rect);
	pWnd->MoveWindow(
		Rect.left + iWidthExt,
		Rect.top + iHeightExt,
		Rect.right - Rect.left, 
		Rect.bottom - Rect.top,FALSE); 

	//��������
	pWnd = pDlg->GetDlgItem(IDCANCEL);
	pWnd->GetWindowRect(&Rect);
	pDlg->ScreenToClient(&Rect);
	pWnd->MoveWindow(
		Rect.left + iWidthExt,
		Rect.top + iHeightExt,
		Rect.right - Rect.left, 
		Rect.bottom - Rect.top,FALSE); 

	PostMessage(WM_POSTINIT,0,0);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
LRESULT CFileDialogEx::OnPostInit(WPARAM wp, LPARAM lp)
{
	UINT ODM_VIEW_THUMBS= 0x702d;
	CWnd* pshell = GetParent()->GetDlgItem(lst2);
	if (pshell) {
		pshell->SendMessage(WM_COMMAND, ODM_VIEW_THUMBS);
		return TRUE;
	}
	return 0;
}

void CFileDialogEx::OnDestroy() 
{
	CFileDialog::OnDestroy();	
}
