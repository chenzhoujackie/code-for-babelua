#pragma once

#include "AddNodeWnd.h"

class CCustomControlData
{
public:
	CString GetCustomName() const;
	void GetCustomData(CArray <CCustomData,CCustomData> &customDataArray) const;
public:
	CCustomControlData();
	CCustomControlData(const CString &csCustomName,const CArray <CCustomData,CCustomData> &customDataArray);
	CCustomControlData(const CCustomControlData &customControlData);
	CCustomControlData& operator=(const CCustomControlData &customControlData);
	~CCustomControlData();
private:
	CString m_csCustomName;
	CArray <CCustomData,CCustomData> m_customDataArray;
};

BOOL GetAddNodeDrawingTypeArray(CStringArray &csDrawingNameArray,CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &typeArray);

// CRightDialog �Ի���

class CRightDialog : public CDialogEx
{
public:
	void ChangeDrawingBase(const CDrawingBase *pDrawingBase);
	void GetCustomData(CString csCustomName,CArray <CCustomData,CCustomData> &customDataArray) const;
private:
	CAddNodeWnd m_addNodeWnd;

	CArray <CCustomControlData,CCustomControlData> m_customControlDataArray;

	DECLARE_DYNAMIC(CRightDialog)

public:
	CRightDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CRightDialog();

// �Ի�������
	enum { IDD = IDD_RIGHT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

	afx_msg LRESULT MessageRClickNode(WPARAM wParam,LPARAM lParam);
};
