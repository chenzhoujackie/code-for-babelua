// DialogWellSetting.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "DialogWellSetting.h"
#include "afxdialogex.h"


// CDialogWellSetting �Ի���

IMPLEMENT_DYNAMIC(CDialogWellSetting, CDialogEx)

CDialogWellSetting::CDialogWellSetting(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDialogWellSetting::IDD, pParent)
{

}

CDialogWellSetting::~CDialogWellSetting()
{
}

void CDialogWellSetting::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
//	DDX_Control(pDX, IDC_COMBO1, m_List);
}


BEGIN_MESSAGE_MAP(CDialogWellSetting, CDialogEx)
	ON_BN_CLICKED(IDOK, &CDialogWellSetting::OnBnClickedOk)
END_MESSAGE_MAP()


// CDialogWellSetting ��Ϣ��������


BOOL CDialogWellSetting::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetIcon(hIcon, FALSE);

/*	int i;
	for(i=0; i<COMBO_COLOR_NUM; i++)
	{
		m_List.InsertString(-1,::GetComboColorString(i));
	}
*/
	COLORREF color = RGB(::GetWellRed(),::GetWellGreen(),::GetWellBlue());
/*	int index = ::GetComboColorIndex(color);
	m_List.SetCurSel(index);*/
	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_WELL))->SetColor(color);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CDialogWellSetting::OnBnClickedOk()
{
/*	int iWellColor = m_List.GetCurSel();

	COLORREF color = ::GetComboColorCOLORREF(iWellColor);*/
	COLORREF color = ((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_WELL))->GetColor();
	::SetWellRed(GetRValue(color));
	::SetWellGreen(GetGValue(color));
	::SetWellBlue(GetBValue(color));

	::WritePrivateProfileString(_T("setting"),_T("WellColor"),::COLORREFToRGBCString(color),SETTING_FILE_PATH);
/*
	int iWellRed = ::GetWellRed();
	int iWellGreen = ::GetWellGreen();
	int iWellBlue = ::GetWellBlue();
	switch(iWellColor)
	{
	case 0:
		iWellRed = 255;
		iWellGreen = 255;
		iWellBlue = 255;
		break;
	case 1:
		iWellRed = 0;
		iWellGreen = 0;
		iWellBlue = 0;
		break;
	case 2:
		iWellRed = 255;
		iWellGreen = 0;
		iWellBlue = 0;
		break;
	case 3:
		iWellRed = 0;
		iWellGreen = 255;
		iWellBlue = 0;
		break;
	case 4:
		iWellRed = 0;
		iWellGreen = 0;
		iWellBlue = 255;
		break;
	case 5:
		iWellRed = 255;
		iWellGreen = 255;
		iWellBlue = 0;
		break;
	case 6:
		iWellRed = 255;
		iWellGreen = 0;
		iWellBlue = 255;
		break;
	default:
		break;
	}
	::SetWellRed(iWellRed);
	::SetWellGreen(iWellGreen);
	::SetWellBlue(iWellBlue);
*/
	CDialogEx::OnOK();
}
