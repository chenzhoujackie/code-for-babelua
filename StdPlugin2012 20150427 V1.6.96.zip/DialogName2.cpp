// DialogName2.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "DialogName2.h"
#include "afxdialogex.h"

#include "XmlTools.h"

// CDialogName2 �Ի���

IMPLEMENT_DYNAMIC(CDialogName2, CDialogEx)

CDialogName2::CDialogName2(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDialogName2::IDD, pParent)
	, m_strName(_T(""))
{
	m_pNames2 = NULL;
}
void CDialogName2::SetCompareName(CStringArray& Names)
{
	m_Names.Copy(Names);
}
void CDialogName2::SetCompareName2(CMapStringToString* pNames2)
{
	m_pNames2 = pNames2;
}

CString CDialogName2::GetName()
{
	return m_strName;
}
CDialogName2::~CDialogName2()
{
	m_Names.RemoveAll();
}

void CDialogName2::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_strName);
	DDV_MaxChars(pDX, m_strName, 60);
	DDX_Control(pDX, IDC_COMBO_VISIBLE, m_List);
}


BEGIN_MESSAGE_MAP(CDialogName2, CDialogEx)
	ON_EN_CHANGE(IDC_EDIT1, OnNameChange)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDOK, &CDialogName2::OnBnClickedOk)
END_MESSAGE_MAP()

void CDialogName2::OnNameChange()
{
	UpdateData(TRUE);
	if ( 0 == m_strName.GetLength())
	{
		ShowError(_T("���Ʋ���Ϊ��."));
		return;
	}
	if ( !check_name(m_strName,FALSE))
	{
		ShowError(_T("������Ӣ����ĸ��ͷ,�����ֺ��»���."));
		return;
	}
	CString strCompare;
	for ( int i = 0; i < m_Names.GetCount(); i ++ )
	{
		strCompare = m_Names.GetAt(i);
		if ( 0 == m_strName.CompareNoCase(strCompare))
		{
			ShowError(_T("�������ѱ�ʹ��."));
			return;
		}
	}
	if ( NULL != m_pNames2 )
	{
		CString strValue;
		if ( m_pNames2->Lookup(m_strName,strValue))
		{
			ShowError(_T("�������ѱ�ʹ��."));
			return;
		}
	}
	ShowError(_T(""));
}

void CDialogName2::ShowError(CString strError)
{
	CWnd* pText = GetDlgItem(IDC_STATIC_ERROR);
	CWnd* pBtn = GetDlgItem(IDOK);
	if ( 0 == strError.GetLength())
	{
		pBtn->EnableWindow(TRUE);
		pText->SetWindowText(_T(""));
	}
	else
	{
		pBtn->EnableWindow(FALSE);
		pText->SetWindowText(strError);
	}
}

// CDialogName2 ��Ϣ��������
void CDialogName2::OnBnClickedOk()
{
	m_List.GetLBText(m_List.GetCurSel(),m_strViewName);
	CDialogEx::OnOK();
}
CString CDialogName2::GetViewName()
{
	return m_strViewName;
}
HBRUSH CDialogName2::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hBrush = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	if ( pWnd->GetDlgCtrlID() == IDC_STATIC_ERROR )
	{
		pDC->SetTextColor(RGB(255,0,0));
	}
	return hBrush;
}

BOOL CDialogName2::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetIcon(hIcon, FALSE);

	m_List.AddString(_T("View"));
	m_strViewName = _T("View");
	m_List.SetCurSel(m_List.GetCount()-1);

	for ( int i = 0; i < theApp.m_ViewCfgs.GetCount(); i ++ )
	{
		m_List.AddString(theApp.m_ViewCfgs.GetAt(i));
	}

	CWnd* pBtn = GetDlgItem(IDOK);
	pBtn->EnableWindow(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}
