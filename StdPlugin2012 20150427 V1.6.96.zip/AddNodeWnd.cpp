// AddNodeWnd.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "AddNodeWnd.h"
#include "resource.h"
#include "MainFrm.h"
#include "StdPluginDoc.h"
#include "StdPluginView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

Bitmap* BitmapFromIDResourceType(UINT nID,LPCTSTR lpType)
{
	HINSTANCE hResource = AfxGetResourceHandle();
	HRSRC hRsrc = FindResource(hResource,MAKEINTRESOURCE(nID),lpType);
	if(hRsrc == NULL)
		return NULL;

	DWORD dwResourceSize = SizeofResource(hResource,hRsrc);
	HGLOBAL hRsrcGlobal = LoadResource(hResource,hRsrc);
	if(hRsrcGlobal == NULL)
		return NULL;

	HGLOBAL hStreamGlobal = GlobalAlloc(GMEM_FIXED,dwResourceSize);
	memcpy(hStreamGlobal,hRsrcGlobal,dwResourceSize);

	IStream *pStream = NULL;
	CreateStreamOnHGlobal(hStreamGlobal,FALSE,&pStream);
	Bitmap *pBitmap = Bitmap::FromStream(pStream);

	if(pStream != NULL)
	{
		pStream->Release();
		pStream = NULL;
	}
	GlobalUnlock(hStreamGlobal);
	FreeResource(hRsrcGlobal);

	return pBitmap;
}

Bitmap* BitmapFromIDResource(UINT nID,EM_RESOURCE_TYPE emResourceType)
{
	switch(emResourceType)
	{
	case RESOURCE_TYPE_PNG:
		return BitmapFromIDResourceType(nID,_T("png"));
	default:
		return NULL;
	}
	return NULL;
}

CAddNodeItem::CAddNodeItem()
{
	m_dwData = 0;
	m_pViewBitmap = NULL;
	m_pMouseBitmap = NULL;
}

CAddNodeItem::~CAddNodeItem()
{
	if(m_pViewBitmap != NULL)
	{
		delete m_pViewBitmap;
		m_pViewBitmap = NULL;
	}
	if(m_pMouseBitmap != NULL)
	{
		delete m_pMouseBitmap;
		m_pMouseBitmap = NULL;
	}
}

void CAddNodeItem::SetItemName(const CString &csItemName)
{
	m_csItemName = csItemName;
}

void CAddNodeItem::SetItemData(DWORD_PTR dwData)
{
	m_dwData = dwData;
}

CString CAddNodeItem::GetItemName() const
{
	return m_csItemName;
}

DWORD_PTR CAddNodeItem::GetItemData() const
{
	return m_dwData;
}

void CAddNodeItem::LoadImage(int nViewID,int nMouseID)
{
	if(m_pViewBitmap != NULL)
	{
		delete m_pViewBitmap;
		m_pViewBitmap = NULL;
	}
	if(m_pMouseBitmap != NULL)
	{
		delete m_pMouseBitmap;
		m_pMouseBitmap = NULL;
	}

	m_pViewBitmap = ::BitmapFromIDResource(nViewID,RESOURCE_TYPE_PNG);
	m_pMouseBitmap = ::BitmapFromIDResource(nMouseID,RESOURCE_TYPE_PNG);
}

Bitmap* CAddNodeItem::GetViewBitmap() const
{
	return m_pViewBitmap;
}

Bitmap* CAddNodeItem::GetMouseBitmap() const
{
	return m_pMouseBitmap;
}


// CAddNodeWnd

IMPLEMENT_DYNAMIC(CAddNodeWnd, CWnd)

CAddNodeWnd::CAddNodeWnd()
{
	m_iSelectItem = -1;
	m_iMoveSelectItem = -1;

	m_pDrawingBase = NULL;

	m_bLButtonDown = FALSE;
	m_bDragAddNode = FALSE;

	m_bDraging = FALSE;
	m_bRegeister = FALSE;

	m_hCursor = NULL;

	m_bTracking = FALSE;
}

CAddNodeWnd::~CAddNodeWnd()
{
	int i;
	for(i=0; i<m_addNodeItemArray.GetSize(); i++)
	{
		if(m_addNodeItemArray.GetAt(i) != NULL)
		{
			delete m_addNodeItemArray.GetAt(i);
			m_addNodeItemArray[i] = NULL;
		}
	}
	m_addNodeItemArray.RemoveAll();
}


BEGIN_MESSAGE_MAP(CAddNodeWnd, CWnd)
	ON_WM_CREATE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONDOWN()
	ON_WM_PAINT()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
	ON_WM_MOUSEWHEEL()
	ON_WM_SIZE()

	ON_MESSAGE(DROPM_DRAGOVER,OnDragOver)
	ON_MESSAGE(DROPM_DROPEX,OnDropEx)
	ON_MESSAGE(DROPM_DROP,OnDrop)
	ON_WM_SETCURSOR()
	ON_WM_CONTEXTMENU()
	ON_WM_MOUSEHOVER()
	ON_WM_MOUSELEAVE()
END_MESSAGE_MAP()



// CAddNodeWnd ��Ϣ��������

void CAddNodeWnd::AddNodeItem(CString csItemName,DWORD_PTR dwData,int nViewID,int nMouseID)
{
	CAddNodeItem *pAddNodeItem = new CAddNodeItem;
	if(pAddNodeItem != NULL)
	{
		pAddNodeItem->SetItemName(csItemName);
		pAddNodeItem->SetItemData(dwData);
		pAddNodeItem->LoadImage(nViewID,nMouseID);

		m_addNodeItemArray.Add(pAddNodeItem);
	}

	UpdateScroll();
	Invalidate(FALSE);

	if(m_toolTipCtrl.m_hWnd != NULL)
	{
		m_toolTipCtrl.AddTool(this,_T("Ĭ�����ӵ���ǰѡ�нڵ���ӽڵ㣬��סCtrl�����ӵ���ǰѡ�нڵ��ͬ���ڵ�"),CRect(0,0,0,0),dwData);
	}
	UpdateToolTipRect();
}

void CAddNodeWnd::UpdateToolTipRect()
{
	if(m_toolTipCtrl.m_hWnd == NULL)
		return;

	CRect rect;
	GetClientRect(rect);

	SCROLLINFO scrollInfo;
	GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);
	DWORD windowStyle = GetWindowLong(m_hWnd,GWL_STYLE);
	BOOL bVertScroll = windowStyle & WS_VSCROLL;
	int nScrollPos = bVertScroll ? scrollInfo.nPos : 0;

	int iPageWidth = rect.Width();
	int iPageHeight = rect.Height();

	//��������������
	int iColNum = max(1,((iPageWidth-(ADD_NODE_LEFT_DIS+ADD_NODE_RIGHT_DIS))/(ADD_NODE_WIDTH+ADD_NODE_X_DIS)));

	int i;
	for(i=0; i<m_addNodeItemArray.GetSize(); i++)
	{
		int iItemLeft = ADD_NODE_LEFT_DIS+(i%iColNum)*(ADD_NODE_WIDTH+ADD_NODE_X_DIS);
		int iItemTop = ADD_NODE_TOP_DIS+(i/iColNum)*(ADD_NODE_HEIGHT+ADD_NODE_Y_DIS)-nScrollPos;
		CRect itemRect(iItemLeft,iItemTop,iItemLeft+ADD_NODE_WIDTH,iItemTop+ADD_NODE_HEIGHT);

		if(m_addNodeItemArray.GetAt(i) == NULL)
			continue;

		DWORD_PTR dwData = m_addNodeItemArray.GetAt(i)->GetItemData();
		m_toolTipCtrl.SetToolRect(this,dwData,itemRect);
	}
}

void CAddNodeWnd::ChangeDrawingBase(const CDrawingBase *pDrawingBase)
{
	m_pDrawingBase = pDrawingBase;
	Invalidate(FALSE);
}

DWORD_PTR CAddNodeWnd::GetSelectItemData() const
{
	if(m_iSelectItem >= 0 && m_iSelectItem < m_addNodeItemArray.GetSize())
	{
		if(m_addNodeItemArray.GetAt(m_iSelectItem) != NULL)
		{
			return m_addNodeItemArray.GetAt(m_iSelectItem)->GetItemData();
		}
	}
	return 0;
}

CString CAddNodeWnd::GetSelectItemName() const
{
	if(m_iSelectItem >= 0 && m_iSelectItem < m_addNodeItemArray.GetSize())
	{
		if(m_addNodeItemArray.GetAt(m_iSelectItem) != NULL)
		{
			return m_addNodeItemArray.GetAt(m_iSelectItem)->GetItemName();
		}
	}
	return _T("");
}

BOOL CAddNodeWnd::DeleteSelectItem()
{
	if(m_iSelectItem >= 0 && m_iSelectItem < m_addNodeItemArray.GetSize())
	{
		if(m_addNodeItemArray.GetAt(m_iSelectItem) != NULL)
		{
			if(m_addNodeItemArray.GetAt(m_iSelectItem)->GetItemData() != DRAWING_TYPE_CustomControl)
				return FALSE;

			delete m_addNodeItemArray.GetAt(m_iSelectItem);
		}
		m_addNodeItemArray.RemoveAt(m_iSelectItem);

		UpdateScroll();
		Invalidate(FALSE);
		return TRUE;
	}

	return FALSE;
}

BOOL CAddNodeWnd::UpdateScroll()
{
	CRect clientRect;
	GetClientRect(clientRect);

	int iPageWidth = clientRect.Width();
	int iPageHeight = clientRect.Height();

	//��������������
	int iColNum = max(1,((iPageWidth-(ADD_NODE_LEFT_DIS+ADD_NODE_RIGHT_DIS))/(ADD_NODE_WIDTH+ADD_NODE_X_DIS)));
	int iRowNum = (m_addNodeItemArray.GetSize()+(iColNum-1))/iColNum;

	int iTotalHeight = ADD_NODE_TOP_DIS+ADD_NODE_BOTTOM_DIS+((ADD_NODE_HEIGHT+ADD_NODE_Y_DIS)*iRowNum);

	if(iPageHeight < iTotalHeight)
	{
		SCROLLINFO scrollInfo;
		memset(&scrollInfo,0,sizeof(SCROLLINFO));
		GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);

		scrollInfo.nMax = iTotalHeight;
		scrollInfo.nPage = iPageHeight;
		if(scrollInfo.nPos > scrollInfo.nMax-(int)scrollInfo.nPage)
			scrollInfo.nPos = scrollInfo.nMax-(int)scrollInfo.nPage;
		SetScrollInfo(SB_VERT,&scrollInfo,TRUE);
		ShowScrollBar(SB_VERT,TRUE);
	}
	else
	{
		ShowScrollBar(SB_VERT,FALSE);
	}
	return TRUE;
}

int CAddNodeWnd::GetSelectItem(CPoint point)
{
	CRect rect;
	GetClientRect(rect);

	SCROLLINFO scrollInfo;
	GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);
	DWORD windowStyle = GetWindowLong(m_hWnd,GWL_STYLE);
	BOOL bVertScroll = windowStyle & WS_VSCROLL;
	int nScrollPos = bVertScroll ? scrollInfo.nPos : 0;

	int iPageWidth = rect.Width();
	int iPageHeight = rect.Height();

	//��������������
	int iColNum = max(1,((iPageWidth-(ADD_NODE_LEFT_DIS+ADD_NODE_RIGHT_DIS))/(ADD_NODE_WIDTH+ADD_NODE_X_DIS)));

	int i;
	for(i=0; i<m_addNodeItemArray.GetSize(); i++)
	{
		int iItemLeft = ADD_NODE_LEFT_DIS+(i%iColNum)*(ADD_NODE_WIDTH+ADD_NODE_X_DIS);
		int iItemTop = ADD_NODE_TOP_DIS+(i/iColNum)*(ADD_NODE_HEIGHT+ADD_NODE_Y_DIS)-nScrollPos;
		CRect itemRect(iItemLeft,iItemTop,iItemLeft+ADD_NODE_WIDTH,iItemTop+ADD_NODE_HEIGHT);

		if(itemRect.PtInRect(point))
			return i;
	}

	return -1;
}

HCURSOR CreateIconIndirect(Bitmap *pBitmap)
{
	if(pBitmap == NULL)
		return NULL;

	HBITMAP hBitmap = NULL;
	pBitmap->GetHBITMAP(Color(255,255,255),&hBitmap);

	ICONINFO iconInfo;
	iconInfo.fIcon = FALSE;
	iconInfo.xHotspot = 0;
	iconInfo.yHotspot = 0;
	iconInfo.hbmColor = hBitmap;//LoadBitmap(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(IDB_BITMAP_TREE));
	iconInfo.hbmMask = hBitmap;//LoadBitmap(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(IDB_BITMAP_TREE));
	return ::CreateIconIndirect(&iconInfo);
}

int CAddNodeWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	Regeister();

	m_toolTipCtrl.Create(this);
	m_toolTipCtrl.SetMaxTipWidth(200);

	return 0;
}

BOOL CAddNodeWnd::OnEraseBkgnd(CDC* pDC) 
{
	return TRUE;
	return CWnd::OnEraseBkgnd(pDC);
}

void CAddNodeWnd::OnLButtonDown(UINT nFlags, CPoint point) 
{
	SetFocus();

	m_iSelectItem = GetSelectItem(point);
	m_iMoveSelectItem = m_iSelectItem;
	Invalidate(FALSE);

	if(m_iSelectItem >= 0)
	{
		SetCapture();
		m_bLButtonDown = TRUE;

		Bitmap *pBitmap = NULL;
		if(m_iSelectItem >= 0 && m_iSelectItem < m_addNodeItemArray.GetSize())
		{
			if(m_addNodeItemArray.GetAt(m_iSelectItem) != NULL)
			{
				pBitmap = m_addNodeItemArray.GetAt(m_iSelectItem)->GetMouseBitmap();
			}
		}
		if(m_hCursor != NULL)
		{
			::DestroyIcon(m_hCursor);
			m_hCursor = NULL;
		}
		if(pBitmap != NULL)
		{
			m_hCursor = ::CreateIconIndirect(pBitmap);
		}
		else
		{
			HINSTANCE hInstance = AfxGetInstanceHandle();
			m_hCursor = LoadCursor(hInstance,MAKEINTRESOURCE(IDC_CURSOR_ADD_NODE));
		}
	}
	CWnd::OnLButtonDown(nFlags,point);
	return;

	if(!m_bRegeister)
		return;

	Sleep(100);

	MSG msg;
	::PeekMessage(&msg,GetSafeHwnd(),WM_LBUTTONUP,WM_LBUTTONUP,PM_NOREMOVE);
	if( msg.message==WM_LBUTTONUP )
		return;

	UINT format = RegisterClipboardFormat(DROP_ADD_NODE_FORMAT);
	CString csBitmapPath = _T("");
	HGLOBAL hData = GlobalAlloc(GHND|GMEM_SHARE, (csBitmapPath.GetLength()+1)*sizeof(TCHAR));
	LPBYTE lpx = (LPBYTE)::GlobalLock(hData);
	memcpy( lpx, (LPCTSTR)csBitmapPath, (csBitmapPath.GetLength()+1)*sizeof(TCHAR) );
	GlobalUnlock( hData );

	m_bDraging = TRUE;	//��ʼ�϶�
	COleDataSource source;
	source.CacheGlobalData( CF_TEXT, hData );
	source.DoDragDrop( DROPEFFECT_COPY );
	GlobalFree( hData );
	m_bDraging = FALSE;	//����϶�
}

void CAddNodeWnd::OnLButtonUp(UINT nFlags, CPoint point) 
{
	m_bLButtonDown = FALSE;
	ReleaseCapture();


	HWND hUIWnd = ((CStdPluginView*)((CMainFrame*)AfxGetMainWnd())->GetActiveView())->GetUIWnd();

	CPoint wndPoint;
	::GetCursorPos(&wndPoint);
	HWND hCursorWnd = ::WindowFromPoint(wndPoint);
	if(hCursorWnd == hUIWnd)
	{
		DWORD_PTR dwData = 0;
		CString csItemName;
		if(m_iSelectItem >= 0 && m_iSelectItem < m_addNodeItemArray.GetSize())
		{
			if(m_addNodeItemArray.GetAt(m_iSelectItem) != NULL)
			{
				dwData = m_addNodeItemArray.GetAt(m_iSelectItem)->GetItemData();
				csItemName = m_addNodeItemArray.GetAt(m_iSelectItem)->GetItemName();
			}
		}

		if(!IsDisable(dwData))
		{
			::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_ADD_NODE,dwData,(LPARAM)&csItemName);
		}
	}

	CWnd::OnLButtonUp(nFlags, point);
}

void CAddNodeWnd::OnMouseMove(UINT nFlags, CPoint point) 
{
	if(m_bLButtonDown)
	{
		HWND hUIWnd = ((CStdPluginView*)((CMainFrame*)AfxGetMainWnd())->GetActiveView())->GetUIWnd();

		CPoint wndPoint;
		::GetCursorPos(&wndPoint);
		HWND hCursorWnd = ::WindowFromPoint(wndPoint);
		m_bDragAddNode = ((hCursorWnd == hUIWnd) || (hCursorWnd == m_hWnd));

		DWORD_PTR dwData = 0;
		if(m_iSelectItem >= 0 && m_iSelectItem < m_addNodeItemArray.GetSize())
		{
			if(m_addNodeItemArray.GetAt(m_iSelectItem) != NULL)
			{
				dwData = m_addNodeItemArray.GetAt(m_iSelectItem)->GetItemData();
			}
		}

		if(m_bDragAddNode && !IsDisable(dwData))
		{
//			HINSTANCE hInstance = AfxGetInstanceHandle();
//			HCURSOR hAddNodeCursor = LoadCursor(hInstance,MAKEINTRESOURCE(IDC_CURSOR_ADD_NODE));
			::SetCursor(m_hCursor);
		}
		else
		{
			::SetCursor(::LoadCursor(NULL, IDC_NO));
		}
	}
	else
	{
		m_iMoveSelectItem = GetSelectItem(point);
		Invalidate(FALSE);
	}

	if(!m_bTracking)
	{ 
		TRACKMOUSEEVENT tme; 
		tme.cbSize = sizeof(tme); 
		tme.hwndTrack = m_hWnd; 
		tme.dwFlags = TME_LEAVE | TME_HOVER;
		tme.dwHoverTime = 1; 
		m_bTracking = _TrackMouseEvent(&tme); 
	}

	CWnd::OnMouseMove(nFlags, point);
}

void CAddNodeWnd::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	CWnd::OnLButtonDblClk(nFlags, point);
}

void CAddNodeWnd::OnRButtonDown(UINT nFlags, CPoint point) 
{
	m_iSelectItem = GetSelectItem(point);
	m_iMoveSelectItem = m_iSelectItem;
	Invalidate(FALSE);

	BOOL bDelete = FALSE;
	if(m_iSelectItem >= 0 && m_iSelectItem < m_addNodeItemArray.GetSize())
	{
		if(m_addNodeItemArray.GetAt(m_iSelectItem) != NULL)
		{
			if(m_addNodeItemArray.GetAt(m_iSelectItem)->GetItemData() == DRAWING_TYPE_CustomControl)
				bDelete = TRUE;
		}
	}

	::SendMessage(GetParent()->GetSafeHwnd(),WM_RCLICK_NODE,m_iSelectItem,bDelete);

	CWnd::OnRButtonDown(nFlags, point);
}

BOOL CAddNodeWnd::IsDisable(DWORD_PTR data)
{
	BOOL bControl = (GetAsyncKeyState(VK_CONTROL) < 0);

	EM_DRAWING_TYPE emDrawingType = (EM_DRAWING_TYPE)-1;
	if(m_pDrawingBase != NULL)
	{
		emDrawingType = m_pDrawingBase->GetDrawingType();
	}
	switch(emDrawingType)
	{
	case DRAWING_TYPE_CheckBoxGroup:
		{
			if(!bControl)
			{
				if(data != DRAWING_TYPE_CheckBox)
					return TRUE;
			}
			else
			{
				if((data == DRAWING_TYPE_CheckBox) || (data == DRAWING_TYPE_RadioButton))
					return TRUE;
			}
		}
		break;
	case DRAWING_TYPE_RadioButtonGroup:
		{
			if(!bControl)
			{
				if(data != DRAWING_TYPE_RadioButton)
					return TRUE;
			}
			else
			{
				if((data == DRAWING_TYPE_CheckBox) || (data == DRAWING_TYPE_RadioButton))
					return TRUE;
			}
		}
		break;
	case DRAWING_TYPE_CheckBox:
		{
			if(!bControl)
			{
				if((data == DRAWING_TYPE_CheckBox) || (data == DRAWING_TYPE_RadioButton))
					return TRUE;
			}
			else
			{
				if(data != DRAWING_TYPE_CheckBox)
					return TRUE;
			}
		}
		break;
	case DRAWING_TYPE_RadioButton:
		{
			if(!bControl)
			{
				if((data == DRAWING_TYPE_CheckBox) || (data == DRAWING_TYPE_RadioButton))
					return TRUE;
			}
			else
			{
				if(data != DRAWING_TYPE_RadioButton)
					return TRUE;
			}
		}
		break;
	default:
		{
			if((data == DRAWING_TYPE_CheckBox) || (data == DRAWING_TYPE_RadioButton))
				return TRUE;
		}
		break;
	}
	return FALSE;
}

void CAddNodeWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	CRect rect;
	GetClientRect(rect);

	SCROLLINFO scrollInfo;
	GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);
	DWORD windowStyle = GetWindowLong(m_hWnd,GWL_STYLE);
	BOOL bVertScroll = windowStyle & WS_VSCROLL;
	int nScrollPos = bVertScroll ? scrollInfo.nPos : 0;

	CDC MemDC;
	MemDC.CreateCompatibleDC(&dc);
	CBitmap MemBitmap;
	MemBitmap.CreateCompatibleBitmap(&dc,rect.Width(),rect.Height());
	if(MemBitmap.m_hObject == NULL)
		return;
	CBitmap *pOldBit=MemDC.SelectObject(&MemBitmap);
	MemDC.FillSolidRect(0,0,rect.Width(),rect.Height(),RGB(255,255,255));
	MemDC.SetBkMode(TRANSPARENT);

	CFont font;
	font.CreateFont(12,0,0,0,FW_NORMAL,FALSE,FALSE,0,GB2312_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH | FF_SWISS,_T("����"));
	CFont *pOldFont = MemDC.SelectObject(&font);

	int iPageWidth = rect.Width();
	int iPageHeight = rect.Height();

	//��������������
	int iColNum = max(1,((iPageWidth-(ADD_NODE_LEFT_DIS+ADD_NODE_RIGHT_DIS))/(ADD_NODE_WIDTH+ADD_NODE_X_DIS)));

	int i;
	for(i=0; i<m_addNodeItemArray.GetSize(); i++)
	{
		int iItemLeft = ADD_NODE_LEFT_DIS+(i%iColNum)*(ADD_NODE_WIDTH+ADD_NODE_X_DIS);
		int iItemTop = ADD_NODE_TOP_DIS+(i/iColNum)*(ADD_NODE_HEIGHT+ADD_NODE_Y_DIS)-nScrollPos;
		CRect itemRect(iItemLeft,iItemTop,iItemLeft+ADD_NODE_WIDTH,iItemTop+ADD_NODE_HEIGHT);

		if(m_addNodeItemArray.GetAt(i) == NULL)
			continue;

		DWORD_PTR data = m_addNodeItemArray.GetAt(i)->GetItemData();
		BOOL bIsDisable = IsDisable(data);
		BOOL bSelectItem = (m_iSelectItem == i);
		BOOL bMouseOnItem = (m_iMoveSelectItem == i);

		COLORREF textColor;
		if(bIsDisable)
			textColor = RGB(128,128,128);
		else
			textColor = (data == DRAWING_TYPE_CustomControl) ? RGB(128,0,0) : RGB(0,0,0);
		COLORREF oldTextColor = MemDC.SetTextColor(textColor);
		Color penColor = bIsDisable ? Color(239,239,239) : Color(128,0,0,255);

		Graphics g(MemDC.GetSafeHdc());
		if(bSelectItem)
		{
			g.FillRectangle(&SolidBrush(Color(penColor)),itemRect.left,itemRect.top,itemRect.Width()+1,itemRect.Height()+1);
		}
		else if(bMouseOnItem)
		{
			Color mouseOnColor(penColor.GetA()/2,penColor.GetR(),penColor.GetG(),penColor.GetB());
			g.FillRectangle(&SolidBrush(Color(mouseOnColor)),itemRect.left,itemRect.top,itemRect.Width()+1,itemRect.Height()+1);
		}
		g.DrawRectangle(&Pen(penColor),itemRect.left,itemRect.top,itemRect.Width(),itemRect.Height());
/*		CPen selectPen(PS_SOLID,1,penColor);
		CPen *pOldPen = MemDC.SelectObject(&selectPen);
		CBrush *pOldBrush = (CBrush*)MemDC.SelectStockObject(NULL_BRUSH);
		MemDC.Rectangle(itemRect);
		MemDC.SelectObject(pOldBrush);
		MemDC.SelectObject(pOldPen);*/

		ImageAttributes imageAttrs;
		ColorMatrix grayColorMatrix =
		{
			0.299f,0.299f,0.299f,0,0,
			0.518f,0.518f,0.518f,0,0,
			0.114f,0.114f,0.114f,0,0,
			0,0,0,1,0,
			0,0,0,0,1
		};
		if(bIsDisable)
		{
			imageAttrs.SetColorMatrix(&grayColorMatrix);
		}
		Bitmap *pBitmap = m_addNodeItemArray.GetAt(i)->GetViewBitmap();
		if(pBitmap != NULL)
		{
			float fWHRate = (float)ADD_NODE_WIDTH/ADD_NODE_HEIGHT;
			float fImageWHRate = (pBitmap->GetHeight() != 0) ? ((float)pBitmap->GetWidth()/pBitmap->GetHeight()) : 1.0f;
			int iMaxWidth = ADD_NODE_WIDTH*3/4;
			int iMaxHeight = ADD_NODE_HEIGHT*3/5;
			int iShowWidth = 0;
			int iShowHeight = 0;
			if(fWHRate > fImageWHRate)
			{
				iShowWidth = (int)(fImageWHRate*iMaxHeight);
				iShowHeight = iMaxHeight;
			}
			else
			{
				iShowWidth = iMaxWidth;
				iShowHeight = (fImageWHRate != 0) ? (int)(iMaxWidth/fImageWHRate) : iMaxHeight;
			}
			g.DrawImage(pBitmap,Rect(itemRect.left+(ADD_NODE_WIDTH-iShowWidth)/2,itemRect.top+(ADD_NODE_HEIGHT*4/5-iShowHeight)/2,iShowWidth,iShowHeight),
				0,0,pBitmap->GetWidth(),pBitmap->GetHeight(),UnitPixel,&imageAttrs);
			MemDC.DrawText(m_addNodeItemArray.GetAt(i)->GetItemName(),itemRect,DT_CENTER | DT_BOTTOM | DT_SINGLELINE);
		}
		else
		{
			MemDC.DrawText(m_addNodeItemArray.GetAt(i)->GetItemName(),itemRect,DT_CENTER | DT_VCENTER | DT_SINGLELINE);
		}

		MemDC.SetTextColor(oldTextColor);
	}

	MemDC.SelectObject(pOldFont);

	dc.BitBlt(0,0,rect.Width(),rect.Height(),&MemDC,0,0,SRCCOPY);
	MemDC.SelectObject(pOldBit);
	MemBitmap.DeleteObject();
}

void CAddNodeWnd::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	CWnd::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CAddNodeWnd::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	SCROLLINFO scrollInfo;
	GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);
	int nDis = (ADD_NODE_HEIGHT+ADD_NODE_Y_DIS);
	int nPageDis = scrollInfo.nPage;
	int nOldPos = scrollInfo.nPos;
	switch(nSBCode)
	{
	case SB_LINEUP:
		scrollInfo.nPos = max(nOldPos-nDis,scrollInfo.nMin);
		break;
	case SB_LINEDOWN:
		scrollInfo.nPos = min(nOldPos+nDis,scrollInfo.nMax-(int)scrollInfo.nPage+1);
		break;
	case SB_PAGEUP:
		scrollInfo.nPos = max(nOldPos-nPageDis,scrollInfo.nMin);
		break;
	case SB_PAGEDOWN:
		scrollInfo.nPos = min(nOldPos+nPageDis,scrollInfo.nMax-(int)scrollInfo.nPage+1);
		break;
	case SB_THUMBTRACK:
		scrollInfo.nPos = scrollInfo.nTrackPos;
		break;
	case SB_THUMBPOSITION:
		break;
	}
	scrollInfo.fMask = SIF_POS;
	SetScrollInfo(SB_VERT,&scrollInfo,TRUE);

	Invalidate(FALSE);
	UpdateToolTipRect();

	CWnd::OnVScroll(nSBCode, nPos, pScrollBar);
}

BOOL CAddNodeWnd::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt) 
{
	if(zDelta == WHEEL_DELTA)
	{
		::SendMessage(m_hWnd,WM_VSCROLL,SB_LINEUP,NULL);
	}
	else if(zDelta == -WHEEL_DELTA)
	{
		::SendMessage(m_hWnd,WM_VSCROLL,SB_LINEDOWN,NULL);
	}

	return CWnd::OnMouseWheel(nFlags, zDelta, pt);
}

void CAddNodeWnd::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);

	UpdateScroll();
	Invalidate(FALSE);

	UpdateToolTipRect();
}

BOOL CAddNodeWnd::Regeister()
{
	m_bRegeister = TRUE;
	return m_oleTarget.Register(this);
}

LRESULT CAddNodeWnd::OnDragOver(WPARAM pDropInfoClass, LPARAM lParm)
{
	COleDropInfo* pInfo = (COleDropInfo* )pDropInfoClass;
	ASSERT(pInfo->IsKindOf(RUNTIME_CLASS(COleDropInfo)));

	UINT format = RegisterClipboardFormat(DROP_ADD_NODE_FORMAT);
	if( pInfo->m_pDataObject->IsDataAvailable( CF_TEXT ) )
		return DROPEFFECT_COPY;
	else
		return DROPEFFECT_NONE;
}

LRESULT CAddNodeWnd::OnDropEx(WPARAM pDropInfoClass, LPARAM lParm)
{
	return (DROPEFFECT)-1;
}

LRESULT CAddNodeWnd::OnDrop(WPARAM pDropInfoClass, LPARAM lParm)
{
	COleDropInfo* pInfo = (COleDropInfo* )pDropInfoClass;
	ASSERT(pInfo->IsKindOf(RUNTIME_CLASS(COleDropInfo)));

	UINT format = RegisterClipboardFormat(DROP_ADD_NODE_FORMAT);
	if( pInfo->m_pDataObject->IsDataAvailable( CF_TEXT ) )
	{
		HGLOBAL hMem = pInfo->m_pDataObject->GetGlobalData( CF_TEXT );
		TCHAR* pGlobal = (TCHAR*)GlobalLock(hMem);
		CString csBitmapPath = pGlobal;

		GlobalUnlock( hMem );//unlock source
		return TRUE;
	}
	else
		return FALSE;
}


BOOL CAddNodeWnd::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	return CWnd::OnSetCursor(pWnd, nHitTest, message);
}


void CAddNodeWnd::OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/)
{
}


void CAddNodeWnd::OnMouseHover(UINT nFlags, CPoint point)
{
	// TODO: �ڴ�������Ϣ������������/�����Ĭ��ֵ

	CWnd::OnMouseHover(nFlags, point);
}


void CAddNodeWnd::OnMouseLeave()
{
	m_bTracking = FALSE;

	m_iMoveSelectItem = -1;
	Invalidate(FALSE);

	CWnd::OnMouseLeave();
}


BOOL CAddNodeWnd::PreTranslateMessage(MSG* pMsg)
{
	BOOL bKey = FALSE;
	switch(pMsg->message)
	{
	case WM_KEYDOWN:
	case WM_KEYUP:
		{
			Invalidate(FALSE);
			bKey = TRUE;
		}
		break;
	default:
		break;
	}

	if(!bKey)
	{
		m_toolTipCtrl.RelayEvent(pMsg);
	}

	return CWnd::PreTranslateMessage(pMsg);
}
