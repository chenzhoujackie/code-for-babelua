#pragma once
#include "afxwin.h"


// CDialogBorderSetting �Ի���

class CDialogBorderSetting : public CDialogEx
{
	DECLARE_DYNAMIC(CDialogBorderSetting)

public:
	CDialogBorderSetting(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDialogBorderSetting();

// �Ի�������
	enum { IDD = IDD_DIALOG_BORDER_SETTING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
//	CComboBox m_List;
};
