#ifndef _BOYAA_PLUGIN_H_
#define _BOYAA_PLUGIN_H_

typedef enum EPluginMsgType
{
	EViewOnReady=10,
	ELuaOnReady=11,
	EFrameUpdate=12,
	EOnPause=15,
	EOnResume=16,
	EOnExit=30,

	ERenderBegin=101,
	ERenderEnd=102,
	ENodeRenderBegin=103,
	ENodeRenderEnd=104,

	ETouchDown=201,
	ETouchMove=202,
	ETouchUp=203,
	ETouchCancel=204,

	EKeyDown=220,
	EKeyUp=221,

	EWin32Instance=1001,
	EWin32EngineStart=1002,
	EWin32Wnd=1003,
	EWin32LuaCallNative=1004,
	EWin32CmdId=1005,
	EWin32ConsoleError=1010,
	EWin32LuaError=1011,

} EPluginMsgType;

#ifdef _BABE_PROJECT_
extern "C"
{
	typedef int (*plugin_proc)(EPluginMsgType,void*,void*);
}

#endif

class CAnimEventCB;
class CDrawingTouchCB;
class CDrawingDragCB;
class AnimInterface;
class DrawingInterface;
class LuaInterface;

#ifdef _BABE_PROJECT_
class CDrawingBase;
class CPlugin
{
public:
	CPlugin();
	~CPlugin();

	void Load();
	void Unload();
	void AddPluginCB ( plugin_proc proc );
	void CallPlugin ( EPluginMsgType eMsg,void* pParam1,void* pParam2 );

	void OnViewReady();
	void OnLuaReady();
	void OnNodeRenderBegin(CDrawingBase* pDrawing );
	void OnNodeRenderEnd(CDrawingBase* pDrawing );

private:
	AnimInterface* m_pAnimInterface;
	DrawingInterface* m_pDrawingInterface;
	LuaInterface* m_pLuaInterface;
};
#endif

typedef enum EDrawingType
{
	EDrawingNull=-1,
	EDrawingNode=0,
	EDrawingBitmap=1,
	EDrawingBitmap9=2,
	EDrawingTile=3,
} EDrawingType;

class AnimInterface
{
public:

	virtual int res_create_double_array ( int iGroup, int iResId, float* pData,int iLen ) = 0;
	virtual int res_create_int_array(int iGroup, int iResId, int* pData,int iLen) = 0;
	virtual int res_create_ushort_array(int iGroup, int iResId, unsigned short* pData,int iLen) = 0;
	virtual int res_create_image (int iGroup,  int iResId, const char* strFile, int iFormat, int iFilter) = 0;
	virtual int res_create_text_image (int iGroup, int iResId, const char* strText, int iWidth, int iHeight,int iRed255,int iGreen255,int iBlue255,int iAlign,const char* strFont,int iFontSize,int iMultiLine) = 0;
	virtual int res_set_double_array ( int iResId,float* pData,int iLen) = 0;
	virtual int res_set_int_array( int iResId, int* pData,int iLen) = 0;
	virtual int res_set_ushort_array( int iResId, unsigned short* pData,int iLen) = 0;
	virtual int res_print(int iResId) = 0;
	virtual int res_alloc_id() = 0;
	virtual int res_free_id(int iResId ) = 0;
	virtual int res_get_array_size(int iResId) = 0;
	virtual int res_get_image_size ( int iResId, int& iWidth, int& iHeight ) = 0;
	virtual int res_delete ( int iResId ) = 0;
	virtual int res_delete_group ( int iGroup ) = 0;

	virtual int anim_create_double ( int iGroup, int iAnimId,int iType, double fStartValue, double fEndValue, int iDuration, int iDelay) = 0;
	virtual int anim_create_int ( int iGroup, int iAnimId, int iType, int iStartValue, int iEndValue, int iDuration,int iDelay) = 0;
	virtual int anim_create_index ( int iGroup, int iAnimId, int iType, int iStartValue,int iEndValue, int iDuration, int iResId,int iDelay) = 0;
	virtual int anim_set_event (int iAnimId,CAnimEventCB* pEventCB) = 0;
	virtual double anim_get_value (int iAnimId, double fDefaultValue ) = 0;
	virtual int anim_delete ( int iAnimId ) = 0;
	virtual int anim_delete_group ( int iGroupId ) = 0;
	virtual int anim_print(int iAnimId) = 0;
	virtual int anim_alloc_id() = 0;
	virtual int anim_free_id(int iAnimId ) = 0;

	virtual int prop_create_color ( int iGroup, int iPropId, int iAnimIdR,int iAnimIdG, int iAnimIdB ) = 0;
	virtual int prop_create_point_size ( int iGroup, int iPropId,int iAnimId) = 0;
	virtual int prop_create_line_width ( int iGroup, int iPropId,int iAnimId) = 0;
	virtual int prop_create_transparency ( int iGroup, int iPropId,int iAnimId) = 0;
	virtual int prop_create_translate ( int iGroup, int iPropId,int iAnimIdX,int iAnimIdY ) = 0;
	virtual int prop_create_rotate(int iGroup, int iPropId, int iAnimId, int iCenter,double fCenterX,double fCenterY) = 0;
	virtual int prop_create_scale ( int iGroup, int iPropId, int iAnimIdX,int iAnimIdY,int iCenter,double fCenterX,double fCenterY ) = 0;
	virtual int prop_create_image_index ( int iGroup, int iPropId,int iAnimId) = 0;
	virtual int prop_create_clip ( int iGroup, int iPropId, int iAnimIdX,int iAnimIdY, int iAnimIdWidth, int iAnimIdHeight ) = 0;
	virtual int prop_create_translate_solid ( int iGroup, int iPropId, double x,double y ) = 0;
	virtual int prop_create_rotate_solid ( int iGroup, int iPropId, double fAngle360, int iCenter,double fCenterX,double fCenterY) = 0;
	virtual int prop_create_scale_solid ( int iGroup, int iPropId, double x, double y, int iCenter,double fCenterX,double fCenterY) = 0;
	virtual int prop_set_translate_solid ( int iPropId, double x,double y ) = 0;
	virtual int prop_set_rotate_solid ( int iPropId, double fAngle360) = 0;
	virtual int prop_set_scale_solid ( int iPropId, double x, double y) = 0;
	virtual int prop_delete ( int iPropId ) = 0;
	virtual int prop_delete_group ( int iGroupId ) = 0;
	virtual int prop_print(int iPropId) = 0;
	virtual int prop_alloc_id() = 0;
	virtual int prop_free_id(int iPropId ) = 0;
	
	virtual int drawing_create_node ( int iGroup, int iDrawingId,int iLevel ) = 0; 
	virtual int drawing_set_node_renderable(int iDrawingId,int iRenderType, int iUseData) = 0;
	virtual int drawing_set_node_texture(int iDrawingId,int iResIdBitmap, int iResDoubleArrayIdTextureCoord ) = 0;
	virtual int drawing_set_node_vertex(int iDrawingId,int iResDoubleArrayIdVertex,int iResUShortIdIndices ) = 0;
	virtual int drawing_set_node_colors(int iDrawingId,int iResDoubleArrayIdColors ) = 0;

	virtual int drawing_set_touchable ( int iDrawingId,CDrawingTouchCB* pTouchCB ) = 0;
	virtual int drawing_set_dragable ( int iDrawingId,CDrawingDragCB* pDragCB ) = 0;

	virtual int drawing_set_level ( int iDrawingId,int iLevel ) = 0;
	virtual int drawing_set_parent ( int iDrawingId, int iDrawingIdParent ) = 0;
	virtual int drawing_set_pickable(int iDrawingId,int iPickable ) = 0;
	virtual int drawing_set_visible ( int iDrawingId,int iVisible ) = 0;

	virtual int drawing_set_point_size ( int iDrawingId, double fSize) = 0;
	virtual int drawing_set_line_width ( int iDrawingId, double fWidth) = 0;
	virtual int drawing_set_color ( int iDrawingId,int iRed255,int iGreen255,int iBlue255) = 0;
	virtual int drawing_set_transparency ( int iDrawingId,int iEnableTransparency,double fTransparency ) = 0;
	virtual int drawing_set_clip_rect ( int iDrawingId,double x,double y ,double fWidth,double fHeight) = 0;
	virtual int drawing_pick ( int iDrawingId, int x,int y ) = 0;
	virtual int drawing_hittest ( int iDrawingId,double x,double y ) = 0;
	virtual int drawing_set_bounding_circle_visible_test ( int iDrawingId,int iEnable ) = 0;

	virtual int drawing_set_position ( int iDrawingId, double x,double y) = 0;
	virtual int drawing_set_size ( int iDrawingId, double fWidth, double fHeight ) = 0;
	virtual int drawing_convert_x_to_surface ( int iDrawingId, double x) = 0;
	virtual int drawing_convert_y_to_surface ( int iDrawingId, double y) = 0;

	virtual EDrawingType drawing_get_type( int iDrawingId ) = 0;
	virtual int drawing_get_parent( int iDrawingId ) = 0;
	virtual int drawing_get_size ( int iDrawingId,double& fWidth,double& fHeight) = 0;
	virtual int drawing_get_position( int iDrawingId,double& x,double& y ) = 0;
	virtual int drawing_get_rect( int iDrawingId,double& x,double& y,double& fWidth,double& fHeight ) = 0;
	virtual int drawing_get_offset( int iDrawingId,double& x,double& y ) = 0;
	virtual const char* drawing_get_name( int iDrawingId ) = 0;
	virtual int drawing_tracking_by_name ( const char* strName,const char* strParent) = 0;

	virtual int drawing_get_transformed_vertex(int iDrawingId,float*& pX,float*& pY,int& iVertexNum ) = 0;
	virtual int drawing_get_transformed_bbox(int iDrawingId,float& fLeft,float& fTop,float& fRight,float& fBottom ) = 0;
	virtual int drawing_get_transformed_bcircle(int iDrawingId,float& fCenterX,float& fCenterY,float& fRadius ) = 0;

	virtual int drawing_create_image ( int iGroup, int iDrawingId, int iResId, double x,double y,double fWidth,double fHeight, int iGrid9,int iLeftWidth, int iRightWidth, int iBottomWidth, int iTopWidth,int iLevel) = 0;
	virtual int drawing_set_image_index ( int iDrawingId,int iIndex) = 0;
	virtual int drawing_set_image_add_image ( int iDrawingId,int iResId, int iIndex ) = 0;
	virtual int drawing_set_image_remove_image ( int iDrawingId, int iIndex ) = 0;
	virtual int drawing_set_image_remove_all_images ( int iDrawingId) = 0;
	virtual int drawing_set_image_res_rect ( int iDrawingId, int iIndex, int iResX,int iResY,int iResWidth,int iResHeight ) = 0;
	
	virtual int drawing_prop_add ( int iDrawingId, int iPropId, int iSequence) = 0;
	virtual int drawing_prop_remove ( int iDrawingId, int iSequence) = 0;
	virtual int drawing_prop_remove_id ( int iDrawingId, int iPropId) = 0;
	virtual int drawing_delete ( int iDrawingId ) = 0;
	virtual int drawing_delete_all ( ) = 0;
	virtual int drawing_print(int iDrawingId) = 0;
	virtual int drawing_alloc_id() = 0;
	virtual int drawing_free_id(int iDrawingId ) = 0;

	virtual void camera_set_position ( int x,int y ) = 0;

	virtual int res_set_name ( int iResId,const char* strName) = 0;
	virtual int anim_set_name ( int iAnimId,const char* strName) = 0;
	virtual int prop_set_name ( int iPropId,const char* strName) = 0;
	virtual int drawing_set_name ( int iDrawingId,const char* strName) = 0;
	virtual int res_set_debug_name ( int iResId,const char* strName) = 0;
	virtual int anim_set_debug_name ( int iAnimId,const char* strName) = 0;
	virtual int prop_set_debug_name ( int iPropId,const char* strName) = 0;
	virtual int drawing_set_debug_name ( int iDrawingId,const char* strName) = 0;

	virtual void log_vprintf(const char* tag,const char* fmt,va_list args) = 0;
	virtual void msgbox_show ( const char* strMessage, const char* strTitle ) = 0;

	virtual const char* sys_get_string(const char* strKey) = 0;
	virtual int sys_set_string(const char* strKey, const char* strValue) = 0;
	virtual int sys_get_int ( const char* strKey, int iDefaultValue) = 0;
	virtual int sys_set_int ( const char* strKey, int iValue) = 0;
	virtual double sys_get_double ( const char* strKey, double fDefaultValue) = 0;
	virtual int sys_set_double ( const char* strKey, double fValue ) = 0;
	virtual void sys_exit() = 0;

	virtual int dict_set_int ( const char* strGroup, const char* strKey, int iValue ) = 0;
	virtual int dict_set_double ( const char* strGroup, const char* strKey, double fValue ) = 0;
	virtual int dict_set_string ( const char* strGroup, const char* strKey, const char* strValue ) = 0;
	virtual int dict_get_int ( const char* strGroup, const char* strKey, int iDefaultValue ) = 0;
	virtual double dict_get_double ( const char* strGroup, const char* strKey, double fDefaultValue ) = 0;
	virtual const char* dict_get_string ( const char* strGroup, const char* strKey ) = 0;
	virtual int dict_save(const char* strGroup ) = 0;
	virtual int dict_load ( const char* strGroup ) = 0;
	virtual int dict_delete ( const char* strGroup ) = 0;
};

class DrawingInterface
{
public:

#ifdef _BABE_PROJECT_
	virtual void SetDrawing(CDrawingBase* pDrawing ) = 0;
#else
	virtual void SetDrawing(void* ) = 0;
#endif

	virtual int GetId() = 0;
	virtual EDrawingType GetType() = 0;
	virtual const char* GetName() = 0;

	virtual void SetRect ( float x,float y,float fWidth,float fHeight ) = 0;
	virtual void GetRect ( float& x,float& y,float& fWidth,float& fHeight ) = 0;

	virtual int GetVertexNum () = 0;
	virtual float* GetVertexX() = 0;
	virtual float* GetVertexY() = 0;

	virtual void GetBBox ( float& fLeft,float& fTop,float& fRight,float& fBottom) = 0;
	virtual void GetCenter(float& fCenterX,float& fCenterY,float& fRadius) = 0;

	virtual bool GetVisible() = 0;
	virtual void SetVisible(bool bVisible) = 0;

	virtual bool GetPickable() = 0;
	virtual void SetPickable(bool bPickable) = 0;

	virtual void SetColor(float fRed,float fGreen,float fBlue) = 0;
	virtual bool GetColor(float& fRed,float& fGreen,float& fBlue) = 0;

	virtual void SetAlpha ( bool bEnable,float fAlpha ) = 0;
	virtual bool GetAlpha ( float& fAlpha ) = 0;

};

class LuaInterface
{
public:
	virtual void* GetLuaState() = 0;
	virtual int	ToLua ( const char* strLuaFileName ) = 0;
	virtual int ExecBuffer ( const char* strLuaScripts ) = 0;
	virtual int CallFunc ( const char* strFunctionName ) = 0;
	virtual void LuaError ( ) = 0;
	virtual bool GetEvent( int& iTable, int& iFunction ) = 0;
	virtual void PushEvent ( int iTable,int iFunction ) = 0; 

};

class EngineInterface
{
public:
	virtual void GetViewSize ( int& w,int& h ) = 0;
	virtual bool SetStartLua ( const char* strFile ) = 0;
	virtual void RenderFrame( void* wnd ) = 0;
	virtual void TouchBegin ( int x,int y ) = 0;
	virtual void TouchMove ( int x,int y ) = 0;
	virtual void TouchEnd ( int x,int y ) = 0;
};

#endif // _BOYAA_PLUGIN_H_