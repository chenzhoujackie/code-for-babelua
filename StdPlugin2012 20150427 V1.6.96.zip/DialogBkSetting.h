#pragma once
#include "afxwin.h"


// CDialogBkSetting �Ի���

class CDialogBkSetting : public CDialogEx
{
	DECLARE_DYNAMIC(CDialogBkSetting)

public:
	CDialogBkSetting(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDialogBkSetting();

// �Ի�������
	enum { IDD = IDD_DIALOG_BK_SETTING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();
//	CComboBox m_List;
};
