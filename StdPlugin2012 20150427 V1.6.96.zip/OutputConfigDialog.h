#pragma once
#include "afxwin.h"

BOOL IsDrawingTypeInArr(EM_DRAWING_TYPE emDrawingType,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr);

// COutputConfigDialog �Ի���

class COutputConfigDialog : public CDialogEx
{
public:
	void InitData(CString csOutputPath);
	CString GetOutputPath() const;
	BOOL GetLeafNode() const;
	void GetDrawingTypeArr(CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr) const;
private:
	CString m_csOutputPath;
	BOOL m_bLeafNode;
	CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> m_emDrawingTypeArr;

	DECLARE_DYNAMIC(COutputConfigDialog)

public:
	COutputConfigDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~COutputConfigDialog();

// �Ի�������
	enum { IDD = IDD_OUTPUT_CONFIG_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CCheckListBox m_listBox;
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedButtonFilePath();
};
