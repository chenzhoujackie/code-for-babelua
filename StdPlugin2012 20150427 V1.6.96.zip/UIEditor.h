#pragma once

extern "C"
{
 #include "lua\lua.h"
 #include "lua\lualib.h"
 #include "lua\lauxlib.h"
};
#pragma comment(lib,"lua51.lib")

#include <string>
#include <vector>
#include <map>
using namespace std;

#include "Plugin.h"
#include "RenderBase.h"

//��ȡ��һ��Ŀ¼·��
CString GetUpFileDirectory(CString csFileDirectory);

//Resource Editor Images Scripts View�ļ���·��
#define MODULE_FILE_DIRECTORY	::GetModuleFileDirectory()
#define RECOURCE_DIRECTORY		::GetUpFileDirectory(MODULE_FILE_DIRECTORY)+_T("\\Resource")
#define EDITOR_DIRECTORY		RECOURCE_DIRECTORY+_T("\\editor")
#define IMAGES_DIRECTORY		RECOURCE_DIRECTORY+_T("\\images")
#define SCRIPTS_DIRECTORY		RECOURCE_DIRECTORY+_T("\\scripts")
#define VIEW_DIRECTORY			SCRIPTS_DIRECTORY+_T("\\view")
#define TMP_DIRECTORY			RECOURCE_DIRECTORY+_T("\\tmp")

//setting.ini�ļ�·��
#define SETTING_FILE_PATH		MODULE_FILE_DIRECTORY+_T("\\setting.ini")


//���úͻ�ȡLuaInterface
void SetLuaInterface(LuaInterface *pLuaInterface);
LuaInterface* GetLuaInterface();
void SetLuaState(lua_State* L);
lua_State* GetLuaState();

//���úͻ�ȡUI����
void SetUIWnd(HWND hWnd);
//HWND GetUIWnd();

//���úͻ�ȡUI Instance
void SetUIInstance(HINSTANCE hInstance);
HINSTANCE GetUIInstance();

void print_string (const char* tag,const char *fmt, ...);

//���úͻ�ȡAnimInterface
void SetAnimInterface(AnimInterface* pAnimInterface);
AnimInterface* GetAnimInterface();

//���úͻ�ȡCRenderBase
void SetRenderBase(CRenderBase *pRenderBase);
CRenderBase* GetRenderBase();

//���úͻ�ȡEngineInterface
void SetEngineInterface(EngineInterface *pEngineInterface);
EngineInterface* GetEngineInterface();

void SetUIWndSize(int iWidth,int iHeight);
int GetUIWndWidth();
int GetUIWndHeight();

//���úͻ�ȡ��ǰѡ��UIԪ��ID
void SetEditorDrawingId(int iEditorDrawingId);
int GetEditorDrawingId();

//EditMode ShowGrid ShowBorder ShowWell
BOOL GetEditMode();
BOOL GetShowGrid();
BOOL GetShowBorder();
BOOL GetShowWell();
void SetEditMode(BOOL bEditMode);
void SetShowGrid(BOOL bShowGrid);
void SetShowBorder(BOOL bShowBorder);
void SetShowWell(BOOL bShowWell);
//GridSkip
void SetGridHSkip(int iGridHSkip);
int GetGridHSkip();
void SetGridVSkip(int iGridVSkip);
int GetGridVSkip();
//GridColor
void SetGridRed(int iGridRed);
int GetGridRed();
void SetGridGreen(int iGridGreen);
int GetGridGreen();
void SetGridBlue(int iGridBlue);
int GetGridBlue();
//BorderColor
void SetBorderRed(int iBorderRed);
int GetBorderRed();
void SetBorderGreen(int iBorderGreen);
int GetBorderGreen();
void SetBorderBlue(int iBorderBlue);
int GetBorderBlue();
//WellColor
void SetWellRed(int iWellRed);
int GetWellRed();
void SetWellGreen(int iWellGreen);
int GetWellGreen();
void SetWellBlue(int iWellBlue);
int GetWellBlue();
//BkColor
void SetBkRed(int iBkRed);
int GetBkRed();
void SetBkGreen(int iBkGreen);
int GetBkGreen();
void SetBkBlue(int iBkBlue);
int GetBkBlue();
//BottomColor
void SetBottomColor(COLORREF color);
COLORREF GetBottomColor();
//DefaultFontName
void SetDefaultFontName(CString csDefaultFontName);
CString GetDefaultFontName();

//��ɫ�ַ�����ʽ�磺255,255,255
CString COLORREFToRGBCString(COLORREF color);
COLORREF RGBCStringToCOLORREF(CString csColor);
//��ɫ�ַ�����ʽ�磺0xFF00FF
CString COLORREFToCString(COLORREF color);
BOOL CStringToCOLORREF(CString csColor,COLORREF &color);

void ReCreateGridText ( int wskip,int hskip,int r,int g,int b,bool bOnlyDelete );
void DeleteWellText();
void ReCreateWellText( int x1,int y1,int x2,int y2,int r,int g,int b );
void ReCreateWellText();
void DrawWell(float x, float y, float iWidth, float iHeight);
void DrawHLine ( float y );
void DrawVLine ( float x );

void EnableKeyHook (bool bEnable );

//ͨ��UIԪ��ID��ȡUIԪ��·��������
BOOL GetUIPathName(int iDrawingId,CString &strParent,CString &strName);
//ͨ��UIԪ��ID��ȡUIԪ������·��
BOOL GetUITreePathArray(int iDrawingId,CStringArray &uiTreePathArray);


//drawing����
enum EM_DRAWING_TYPE
{
	DRAWING_TYPE_Base = 0,
	DRAWING_TYPE_ImageBase,
	DRAWING_TYPE_Empty,
	DRAWING_TYPE_Node,
	DRAWING_TYPE_Image,
	DRAWING_TYPE_Images,
	DRAWING_TYPE_Button,
	DRAWING_TYPE_GroupNode,
	DRAWING_TYPE_GroupItem,
	DRAWING_TYPE_CheckBoxGroup,
	DRAWING_TYPE_CheckBox,
	DRAWING_TYPE_RadioButtonGroup,
	DRAWING_TYPE_RadioButton,
	DRAWING_TYPE_Text,
	DRAWING_TYPE_ScrollableNode,
	DRAWING_TYPE_TextView,
	DRAWING_TYPE_EditTextView,
	DRAWING_TYPE_EditText,
	DRAWING_TYPE_ScrollBar,
	DRAWING_TYPE_TabView,
	DRAWING_TYPE_TableView,
	DRAWING_TYPE_GridView,
	DRAWING_TYPE_ViewPager,
	DRAWING_TYPE_ListView,
	DRAWING_TYPE_ScrollView,
	DRAWING_TYPE_Slider,
	DRAWING_TYPE_Switch,
	DRAWING_TYPE_DrawingCustom,
	DRAWING_TYPE_CustomNode,
	DRAWING_TYPE_CustomControl
};

//���ֶ�������
enum EM_TEXT_ALIGN_TYPE
{
	TextkAlignCenter=0,
	TextkAlignTop=1,
	TextkAlignTopRight=2,
	TextkAlignRight=3,
	TextkAlignBottomRight=4,
	TextkAlignBottom=5,
	TextkAlignBottomLeft=6,
	TextkAlignLeft=7,
	TextkAlignTopLeft=8
};

//��ȡDrawingType����
CString GetDrawingTypeName(EM_DRAWING_TYPE type);
//��ȡDrawingType�½�luaԪ������
CString GetDrawingTypeNewLuaName(EM_DRAWING_TYPE type);
//��ȡDrawingType����
EM_DRAWING_TYPE GetDrawingType(const CString &csType);
//��ȡOld type
CString GetOldType(EM_DRAWING_TYPE type);
//��ȡ������������
CString GetAlignTypeName(int align);

CCharArr UnicodeToUTF8(CWCharArr wcharArr);
CWCharArr UTF8ToUnicode(CCharArr charArr);

void SetWindowTextW(CWnd *pWnd,CStringW csText);
CStringW GetWindowTextW(CWnd *pWnd);


#define TAG_Name			"name"
#define TAG_Type			"type"
#define TAG_TypeName		"typeName"
#define TAG_CreateTime		"time"
#define TAG_XName			"x"
#define TAG_YName			"y"
#define TAG_WidthName		"width"
#define TAG_HeightName		"height"
#define TAG_NodeAlign		"nodeAlign"
#define TAG_VisibleName		"visible"
#define TAG_LuaName			"packFile"
#define TAG_TopLeftX		"fillTopLeftX"
#define TAG_TopLeftY		"fillTopLeftY"
#define TAG_BottomRightX	"fillBottomRightX"
#define TAG_BottomRightY	"fillBottomRightY"
#define TAG_9GridLeft		"gridLeft"
#define TAG_9GridRight		"gridRight"
#define TAG_9GridTop		"gridTop"
#define TAG_9GridBottom		"gridBottom"
#define TAG_AdaptiveWidthName	"fillParentWidth"
#define TAG_AdaptiveHeightName	"fillParentHeight"
#define TAG_FileName		"file"
#define TAG_StringDataName	"string"
#define TAG_FontName		"fontName"
#define TAG_FontSize		"fontSize"
#define TAG_TextAlign		"textAlign"
#define TAG_Align			"align"
#define TAG_Color			"color"
#define TAG_File2Name		"file2"
#define TAG_CustomName		"customName"
#define TAG_CustomNum		"customNum"
#define TAG_CustomProp		"customProp"
#define TAG_CustomType		"customType"
#define TAG_CustomData		"customData"


long GetDrawingTime();

//
class CDrawingBase
{
public:
	EM_DRAWING_TYPE GetDrawingType() const;			//��ȡDrawing����
	void SetTime(long time);						//����ʱ��
	long GetTime() const;							//��ȡʱ��
	void SetPos(int x,int y);						//����X,Y����
	BOOL GetPos(int &x,int &y) const;				//��ȡX,Y����
	void SetSize(int width,int height);				//���ÿ��ȸ߶�
	BOOL GetSize(int &width,int &height) const;		//��ȡ���ȸ߶�
	void SetFillRegion(int topLeftX,int topLeftY,int bottomRightX,int bottomRightY);			//�����������
	BOOL GetFillRegion(int &topLeftX,int &topLeftY,int &bottomRightX,int &bottomRightY) const;	//��ȡ�������
	void SetAlign(int align);						//���ö��뷽ʽ
	BOOL GetAlign(int &align) const;				//��ȡ���뷽ʽ
	void SetFillParent(bool doFillParentWidth,bool doFillParentHeight);			//�����Ƿ���丸�ڵ�
	BOOL GetFillParent(bool &doFillParentWidth,bool &doFillParentHeight) const;	//��ȡ�Ƿ���丸�ڵ�
	void SetColor(COLORREF color);					//������ɫ
	BOOL GetColor(COLORREF &color) const;			//��ȡ��ɫ
	void SetTransparency(BYTE alpha);				//����͸����
	BOOL GetTransparency(BYTE &alpha) const;		//��ȡ͸����
	void SetVisible(bool visible);					//�����Ƿ�ɼ�
	BOOL GetVisible(bool &visible) const;			//��ȡ�Ƿ�ɼ�
	void SetName(CString name);						//��������
	BOOL GetName(CString &name) const;				//��ȡ����
	void SetPackFile(CString pickFile);				//����ƴͼ
	BOOL GetPackFile(CString &pickFile) const;		//��ȡƴͼ
public:
	virtual CString GetDrawingTypeName() const;		//��ȡDrawingType����
	virtual CString GetOldType() const;				//��ȡOld type
protected:
	CStringW GetTAGName() const;
	CStringW GetTAGType() const;
	CStringW GetTAGTypeName() const;
	CStringW GetTAGCreateTime() const;
	CStringW GetTAGXName() const;
	CStringW GetTAGYName() const;
	CStringW GetTAGWidthName() const;
	CStringW GetTAGHeightName() const;
	CStringW GetTAGFillRegion() const;
	CStringW GetTAGVisibleName() const;
	CStringW GetTAGAdaptiveWidthName() const;
	CStringW GetTAGAdaptiveHeightName() const;
	CStringW GetTAGNodeAlign() const;
	CStringW GetTAGDrawingBase() const;
public:
	virtual CStringW GetTAGTotal() const;
	CStringW GetLuaScriptsName() const;				//��ȡLua������ Ϊeditor+m_time
	CStringW GetLuaScriptsSetPos() const;			//
	CStringW GetLuaScriptsSetSize() const;			//
	CStringW GetLuaScriptsSetFillRegion() const;		//
	CStringW GetLuaScriptsSetAlign() const;			//
	CStringW GetLuaScriptsSetFillParent() const;		//
	CStringW GetLuaScriptsSetColor() const;			//
	CStringW GetLuaScriptsSetTransparency() const;	//
	CStringW GetLuaScriptsSetVisible() const;		//
	CStringW GetLuaScriptsSetName() const;			//
	CStringW GetLuaScriptsSetPackFile() const;		//
	CStringW GetLuaScriptsSetLevel(int iLevel) const;//
	virtual CStringW GetDrawingTypeNewLuaName() const;//��ȡDrawingType�½�luaԪ������
	virtual CStringW GetLuaScriptsNew() const;		//�½�
	virtual CStringW GetLuaScriptsSetAll() const;	//
	virtual CStringW GetLuaScriptsRecreate() const;	//���´���
public:
	virtual CDrawingBase* Clone() const;			//
protected:
	void SetDrawingType(EM_DRAWING_TYPE type);		//����Drawing����
public:
	CDrawingBase();
	virtual CDrawingBase& operator=(const CDrawingBase &drawingBase);
	virtual ~CDrawingBase();
private:
	EM_DRAWING_TYPE m_type;		//drawing����
protected:
	long m_t;					//ʱ��
	int m_x;					//X����
	int m_y;					//Y����
	int m_width;				//����
	int m_height;				//�߶�
	int m_topLeftX;				//������� ����X����
	int m_topLeftY;				//������� ����Y����
	int m_bottomRightX;			//������� ����X����
	int m_bottomRightY;			//������� ����Y����
	int m_iAlign;				//���뷽ʽ
	bool m_bAdaptiveWidth;		//�Ƿ���丸�ڵ� ������
	bool m_bAdaptiveHeight;		//�Ƿ���丸�ڵ� ���߶�
	COLORREF m_color;			//��ɫ
	BYTE m_alpha;				//͸����
	bool m_bVisible;			//�Ƿ�ɼ�
	CString m_strName;			//����
	CString m_strLuaName;		//Lua����
};
CStringW GetLuaScriptsAddChild(CDrawingBase *pParentDrawingBase,CDrawingBase *pChildDrawingBase);
CStringW GetLuaScriptsRemoveChild(CDrawingBase *pParentDrawingBase,CDrawingBase *pChildDrawingBase);

//
class CDrawingImageBase : public CDrawingBase
{
public:
	void SetGrid9(int leftWidth,int rightWidth,int topWidth,int bottomWidth);			//����9GridͼƬ����
	BOOL GetGrid9(int &leftWidth,int &rightWidth,int &topWidth,int &bottomWidth) const;	//��ȡ9GridͼƬ����
public:
	CStringW GetLuaScriptsSetGrid9() const;			//
	virtual CStringW GetLuaScriptsSetAll() const;	//
public:
	virtual CDrawingBase* Clone() const;			//
public:
	static CDrawingImageBase* CDrawingBaseToCDrawingImageBase(CDrawingBase *pDrawingBase);
public:
	CDrawingImageBase();
	CDrawingImageBase& operator=(const CDrawingBase &drawingBase);
	CDrawingImageBase& operator=(const CDrawingImageBase &drawingImageBase);
	~CDrawingImageBase();
protected:
	int m_gLeft;				//9GridͼƬ���� ��
	int m_gRight;				//9GridͼƬ���� ��
	int m_gTop;					//9GridͼƬ���� ��
	int m_gBottom;				//9GridͼƬ���� ��
};

//
class CDrawingEmpty : public CDrawingBase
{
public:
	CDrawingEmpty();
	CDrawingEmpty& operator=(const CDrawingBase &drawingBase);
	CDrawingEmpty& operator=(const CDrawingEmpty &drawingEmpty);
	~CDrawingEmpty();
};

class CDrawingNode : public CDrawingEmpty
{
public:
	CDrawingNode();
	CDrawingNode& operator=(const CDrawingBase &drawingBase);
	CDrawingNode& operator=(const CDrawingNode &drawingNode);
	~CDrawingNode();
};

BOOL GetImageWidthHeight(CString csFile,int &width,int &height);
class CDrawingImage: public CDrawingImageBase
{
public:
	void SetFile(CString file);			//����ͼƬ·��
	BOOL GetFile(CString &file) const;	//��ȡͼƬ·��
	BOOL FixFileSize();					//��ȡͼƬ�ߴ�����Size
protected:
	CStringW GetTAGFileName() const;
	CStringW GetTAGLuaName() const;
	CStringW GetTAG9Grid() const;
	CStringW GetTAGDrawingImage() const;
public:
	virtual CStringW GetTAGTotal() const;
	CStringW GetLuaScriptsSetFile() const;			//
//	virtual CStringW GetLuaScriptsNew() const;		//
	virtual CStringW GetLuaScriptsSetAll() const;	//
public:
	virtual CDrawingBase* Clone() const;			//
public:
	static CDrawingImage* CDrawingBaseToCDrawingImage(CDrawingBase *pDrawingBase);
public:
	CDrawingImage();
	CDrawingImage& operator=(const CDrawingBase &drawingBase);
	CDrawingImage& operator=(const CDrawingImage &drawingImage);
	~CDrawingImage();
protected:
	CString m_csFile;		//ͼƬ·��
};

class CDrawingImages : public CDrawingImage
{
public:
	CDrawingImages();
	CDrawingImages& operator=(const CDrawingBase &drawingBase);
	CDrawingImages& operator=(const CDrawingImages &drawingImages);
	~CDrawingImages();
};

class CDrawingButton : public CDrawingImages
{
public:
	void SetFile2(CString file);			//����ͼƬ2·��
	BOOL GetFile2(CString &file) const;		//��ȡͼƬ2·��
	BOOL FixFileSize();						//��ȡͼƬ�ߴ�����Size
protected:
	CStringW GetTAGFile2Name() const;
	CStringW GetTAGDrawingButton() const;
public:
	virtual CStringW GetTAGTotal() const;
	CStringW GetLuaScriptsSetFile2() const;			//
//	virtual CStringW GetLuaScriptsNew() const;		//
	virtual CStringW GetLuaScriptsSetAll() const;	//
public:
	virtual CDrawingBase* Clone() const;			//
public:
	static CDrawingButton* CDrawingBaseToCDrawingButton(CDrawingBase *pDrawingBase);
public:
	CDrawingButton();
	CDrawingButton& operator=(const CDrawingBase &drawingBase);
	CDrawingButton& operator=(const CDrawingButton &drawingButton);
	~CDrawingButton();
protected:
	CString m_csFile2;		//ͼƬ2·��
};

class CDrawingGroupNode : public CDrawingNode
{
public:
	CDrawingGroupNode();
	~CDrawingGroupNode();
};

class CDrawingGroupItem : public CDrawingImages
{
public:
	CDrawingGroupItem();
	CDrawingGroupItem& operator=(const CDrawingBase &drawingBase);
	CDrawingGroupItem& operator=(const CDrawingGroupItem &drawingGroupItem);
	~CDrawingGroupItem();
};

class CDrawingCheckBoxGroup : public CDrawingGroupNode
{
public:
	CDrawingCheckBoxGroup();
	~CDrawingCheckBoxGroup();
};

class CDrawingCheckBox : public CDrawingButton
{
public:
	virtual CStringW GetLuaScriptsSetAll() const;	//
public:
	virtual CDrawingBase* Clone() const;			//
public:
	static CDrawingCheckBox* CDrawingBaseToCDrawingCheckBox(CDrawingBase *pDrawingBase);
public:
	CDrawingCheckBox();
	CDrawingCheckBox& operator=(const CDrawingBase &drawingBase);
	CDrawingCheckBox& operator=(const CDrawingCheckBox &drawingCheckBox);
	~CDrawingCheckBox();
};

class CDrawingRadioButtonGroup : public CDrawingGroupNode
{
public:
	CDrawingRadioButtonGroup();
	~CDrawingRadioButtonGroup();
};

class CDrawingRadioButton : public CDrawingButton
{
public:
	virtual CStringW GetLuaScriptsSetAll() const;	//
public:
	virtual CDrawingBase* Clone() const;			//
public:
	static CDrawingRadioButton* CDrawingBaseToCDrawingRadioButton(CDrawingBase *pDrawingBase);
public:
	CDrawingRadioButton();
	CDrawingRadioButton& operator=(const CDrawingBase &drawingBase);
	CDrawingRadioButton& operator=(const CDrawingRadioButton &drawingRadioButton);
	~CDrawingRadioButton();
};

class CDrawingText : public CDrawingImage
{
public:
	void SetStr(CStringW str);					//������������
	BOOL GetStr(CStringW &str) const;			//��ȡ��������
	void SetFontName(CStringW fontName);			//������������
	BOOL GetFontName(CStringW &fontName) const;	//��ȡ��������
	void SetFontSize(int fontSize);				//���������С
	BOOL GetFontSize(int &fontSize) const;		//��ȡ�����С
	void SetTextAlign(int align);				//���ö��뷽ʽ
	BOOL GetTextAlign(int &align) const;		//��ȡ���뷽ʽ
protected:
	CStringW GetTAGStr() const;
	CStringW GetTAGFontName() const;
	CStringW GetTAGFontSize() const;
	CStringW GetTAGTextAlign() const;
	CStringW GetTAGColor() const;
	CStringW GetTAGDrawingText() const;
public:
	virtual CStringW GetTAGTotal() const;
	CStringW GetLuaScriptsSetText() const;			//
//	virtual CStringW GetLuaScriptsNew() const;		//
	virtual CStringW GetLuaScriptsSetAll() const;	//
public:
	virtual CDrawingBase* Clone() const;			//
public:
	static CDrawingText* CDrawingBaseToCDrawingText(CDrawingBase *pDrawingBase);
public:
	CDrawingText();
	CDrawingText& operator=(const CDrawingBase &drawingBase);
	CDrawingText& operator=(const CDrawingText &drawingText);
	~CDrawingText();
protected:
	CStringW m_csStr;			//��������
	CStringW m_csFontName;		//��������
	int m_iFontSize;			//�����С
	int m_iTextAlign;			//���뷽ʽ
};

class CDrawingScrollableNode : public CDrawingNode
{
public:
	CDrawingScrollableNode();
	CDrawingScrollableNode& operator=(const CDrawingBase &drawingBase);
	CDrawingScrollableNode& operator=(const CDrawingScrollableNode &drawingScrollableNode);
	~CDrawingScrollableNode();
};

class CDrawingTextView : public CDrawingScrollableNode
{
public:
	void SetStr(CStringW str);					//������������
	BOOL GetStr(CStringW &str) const;			//��ȡ��������
	void SetFontName(CStringW fontName);			//������������
	BOOL GetFontName(CStringW &fontName) const;	//��ȡ��������
	void SetFontSize(int fontSize);				//���������С
	BOOL GetFontSize(int &fontSize) const;		//��ȡ�����С
	void SetTextAlign(int align);				//���ö��뷽ʽ
	BOOL GetTextAlign(int &align) const;		//��ȡ���뷽ʽ
protected:
	CStringW GetTAGStr() const;
	CStringW GetTAGFontName() const;
	CStringW GetTAGFontSize() const;
	CStringW GetTAGTextAlign() const;
	CStringW GetTAGColor() const;
	CStringW GetTAGDrawingTextView() const;
public:
	virtual CStringW GetTAGTotal() const;
	CStringW GetLuaScriptsSetText() const;			//
//	virtual CStringW GetLuaScriptsNew() const;		//
	virtual CStringW GetLuaScriptsSetAll() const;	//
public:
	virtual CDrawingBase* Clone() const;			//
public:
	static CDrawingTextView* CDrawingBaseToCDrawingTextView(CDrawingBase *pDrawingBase);
public:
	CDrawingTextView();
	CDrawingTextView& operator=(const CDrawingBase &drawingBase);
	CDrawingTextView& operator=(const CDrawingTextView &drawingTextView);
	~CDrawingTextView();
protected:
	CStringW m_csStr;			//��������
	CStringW m_csFontName;		//��������
	int m_iFontSize;			//�����С
	int m_iTextAlign;			//���뷽ʽ
};

class CDrawingEditTextView : public CDrawingTextView
{
public:
	CDrawingEditTextView();
	~CDrawingEditTextView();
};

class CDrawingEditText : public CDrawingText
{
public:
	CDrawingEditText();
	~CDrawingEditText();
};

class CDrawingScrollBar : public CDrawingImage
{
public:
	CDrawingScrollBar();
	~CDrawingScrollBar();
};

class CDrawingTabView : public CDrawingScrollableNode
{
public:
	CDrawingTabView();
	~CDrawingTabView();
};

class CDrawingTableView : public CDrawingScrollableNode
{
public:
	CDrawingTableView();
	CDrawingTableView& operator=(const CDrawingBase &drawingBase);
	CDrawingTableView& operator=(const CDrawingTableView &drawingTableView);
	~CDrawingTableView();
};

class CDrawingGridView : public CDrawingTableView
{
public:
	CDrawingGridView();
	~CDrawingGridView();
};

class CDrawingViewPager : public CDrawingTableView
{
public:
//	virtual CStringW GetLuaScriptsNew() const;		//
	virtual CStringW GetLuaScriptsSetAll() const;	//
public:
	virtual CDrawingBase* Clone() const;			//
public:
	static CDrawingViewPager* CDrawingBaseToCDrawingViewPager(CDrawingBase *pDrawingBase);
public:
	CDrawingViewPager();
	CDrawingViewPager& operator=(const CDrawingBase &drawingBase);
	CDrawingViewPager& operator=(const CDrawingViewPager &drawingViewPager);
	~CDrawingViewPager();
};

class CDrawingListView : public CDrawingTableView
{
public:
	CDrawingListView();
	~CDrawingListView();
};

class CDrawingScrollView : public CDrawingScrollableNode
{
public:
	CDrawingScrollView();
	~CDrawingScrollView();
};

class CDrawingSlider : public CDrawingNode
{
public:
	CDrawingSlider();
	~CDrawingSlider();
};

class CDrawingSwitch : public CDrawingNode
{
public:
	CDrawingSwitch();
	~CDrawingSwitch();
};

class CDrawingDrawingCustom : public CDrawingEmpty
{
public:
	CDrawingDrawingCustom();
	~CDrawingDrawingCustom();
};

class CDrawingCustomNode : public CDrawingDrawingCustom
{
public:
	CDrawingCustomNode();
	~CDrawingCustomNode();
};


enum EM_CUSTOM_DATA_TYPE
{
	CUSTOM_DATA_INT,
	CUSTOM_DATA_STRING,
	CUSTOM_DATA_COLOR
};

CString GetCustomDataType(EM_CUSTOM_DATA_TYPE emCustomDataType);
EM_CUSTOM_DATA_TYPE GetCustomDataType(const CString &csCustomDataType);

#define CUSTOM_DATA_TYPE_NUM	3
CString GetComboCustomDataTypeString(int index);

class CCustomData
{
public:
	void SetCustomPropName(const CString &csCustomPropName);
	void SetCustomDataType(EM_CUSTOM_DATA_TYPE emCustomDataType);
	void SetDataInt(int iData);
	void SetDataCString(const CString &csData);
	void SetDataCOLORREF(COLORREF color);
	CString GetCustomPropName() const;
	EM_CUSTOM_DATA_TYPE GetCustomDataType() const;
	int GetDataInt() const;
	CString GetDataCString() const;
	COLORREF GetDataCOLORREF() const;
	CString GetCustomData() const;		//��ȡdata�ַ���
public:
	CString GetTAGCustomData() const;
	CString GetLuaCustomData() const;
public:
	CCustomData();
	CCustomData(const CString &csCustomPropName,EM_CUSTOM_DATA_TYPE emCustomDataType);
	CCustomData(const CString &csCustomPropName,EM_CUSTOM_DATA_TYPE emCustomDataType,const CString &csCustomData);
	CCustomData(const CCustomData &customData);
	CCustomData& operator=(const CCustomData &customData);
	~CCustomData();
protected:
	CString m_csCustomPropName;
	EM_CUSTOM_DATA_TYPE m_emCustomDataType;
	_variant_t m_data;
};

class CDrawingCustomControl : public CDrawingBase
{
public:
	void SetCustomName(const CString &csCustomName);
	CString GetCustomName() const;
	void SetCustomData(const CArray <CCustomData,CCustomData> &customDataArray);
	void SetCustomData(int index,const CCustomData &customData);
	BOOL GetCustomData(CArray <CCustomData,CCustomData> &customDataArray) const;
	CString GetLuaCustomName() const;
protected:
	CStringW GetTAGDrawingCustomControl() const;
public:
	virtual CStringW GetTAGTotal() const;
	virtual CStringW GetLuaScriptsNew() const;		//
public:
	virtual CDrawingBase* Clone() const;			//
public:
	static CDrawingCustomControl* CDrawingBaseToCDrawingCustomControl(CDrawingBase *pDrawingBase);
public:
	CDrawingCustomControl();
	CDrawingCustomControl& operator=(const CDrawingBase &drawingBase);
	CDrawingCustomControl& operator=(const CDrawingCustomControl &drawingCustomControl);
	~CDrawingCustomControl();
protected:
	CString m_csCustomName;
	CArray <CCustomData,CCustomData> m_customDataArray;
};

CDrawingBase* NewCDrawingBase(EM_DRAWING_TYPE type);
void InitDrawingBase(CDrawingBase *pDrawingBase);

//����UI��ʾ�������޸�UI����ֵ��������ʷ��¼
#define WM_UPDATE_UI_PROP			WM_USER+6471
//UI���Ըı���Ϣ
#define WM_CHANGE_UI_PROP			WM_USER+6472
//UI��������	WPARAM:UI�������ͣ�LPARAM:UI����ֵ
enum EM_UI_PROP_TYPE
{
	UI_PROP_x,
	UI_PROP_y,
	UI_PROP_xy,
	UI_PROP_width,
	UI_PROP_height,
	UI_PROP_topLeftX,
	UI_PROP_topLeftY,
	UI_PROP_bottomRightX,
	UI_PROP_bottomRightY,
	UI_PROP_iAlign,
	UI_PROP_bAdaptiveWidth,
	UI_PROP_bAdaptiveHeight,
	UI_PROP_color,
	UI_PROP_alpha,
	UI_PROP_bVisible,
	UI_PROP_strName,
	UI_PROP_strLuaName,
	UI_PROP_gLeft,
	UI_PROP_gRight,
	UI_PROP_gTop,
	UI_PROP_gBottom,
	UI_PROP_csFile,
	UI_PROP_csFile2,
	UI_PROP_csStr,
	UI_PROP_csFontName,
	UI_PROP_iFontSize,
	UI_PROP_iTextAlign,
	UI_PROP_Custom
};

CString GetUIPropTypeName(EM_UI_PROP_TYPE emUIPropType);

//UI Prop�޸�SetTimer����CHANGE_UI_PROP_DELAYʱ���ڵ��޸ļ�¼��һ����ʷ��¼
#define TIMER_CHANGE_UI_PROP		1
#define CHANGE_UI_PROP_DELAY		1000


#define COMBO_COLOR_NUM				7
CString GetComboColorString(int index);
COLORREF GetComboColorCOLORREF(int index);
int GetComboColorIndex(COLORREF color);


enum EM_PROPTYPE
{
	PROPTYPE_BASE,
	PROPTYPE_INT,
	PROPTYPE_DOUBLE,
	PROPTYPE_DATA,
	PROPTYPE_STRING,
	PROPTYPE_ENUM,
	PROPTYPE_BOOL,
	PROPTYPE_IMAGE,
	PROPTYPE_PACKFILE,
	PROPTYPE_TEXT,
	PROPTYPE_FONT,
	PROPTYPE_COLOR
};

class CPropType
{
protected:
	EM_PROPTYPE m_proptype;
public:
	CStringW typeViewName;
public:
	CPropType();
	EM_PROPTYPE GetProptype();
};

class CPropTypeInt : public CPropType
{
public:
	CPropTypeInt();
};

class CPropTypeDouble : public CPropType
{
public:
	CPropTypeDouble();
};

class CPropTypeData : public CPropType
{
public:
	CPropTypeData();
};

class CPropTypeString : public CPropType
{
public:
	CPropTypeString();
};

class CPropTypeEnum : public CPropType
{
public:
	int defaultValue;
	vector<CStringW> valueViewName;
	vector<CStringW> valueLuaName;
public:
	CPropTypeEnum();
	int GetEnumCount();
	CStringW GetViewName(int value);
	CStringW GetLuaName(int value);
};

class CPropTypeBool : public CPropType
{
public:
	bool defaultValue;
	vector<CStringW> typeValueName;
	vector<CStringW> valueLuaName;
public:
	CPropTypeBool();
	static bool GetValue(string value);
	CStringW GetLuaName(bool value);
};

class CPropTypeImage : public CPropType
{
public:
	CStringW defaultValue;
	CStringW res;
public:
	CPropTypeImage();
};

class CPropTypePackfile : public CPropType
{
public:
	CPropTypePackfile();
};

class CPropTypeText : public CPropType
{
public:
	CPropTypeText();
	static CStringW GetLuaText(CStringW text);
};

class CPropTypeFont : public CPropType
{
public:
	CPropTypeFont();
};

class CPropTypeColor : public CPropType
{
public:
	bool colorType;  //true:��ɫΪBGR false:��ɫΪRGB  ����ʷԭ�򣺼�����ʷ�汾��
	int defaultValue;
	vector<CStringW> typeLuaName;
public:
	CPropTypeColor();
	int GetColor(CString color);
	CStringW GetLuaName(int index);
	CStringW GetColor(int color);
	CStringW GetLuaColor(int color);
};

class UIProperties
{
public:
	CStringW cursor;
	map<CStringW, CPropType> Properties;
};

class UIControl
{
public:
	UIProperties Base;
	map<CStringW, UIProperties> UIProperties;
};

bool LoadEditorXML(string xmlPath,UIControl &uiControl);

