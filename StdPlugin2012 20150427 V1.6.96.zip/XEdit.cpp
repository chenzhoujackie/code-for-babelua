// XEdit.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "XEdit.h"

void SetEditTextNotChangeCursorSeat(CEdit *pEdit,const CString &csText)
{
	if(pEdit == NULL)
		return;

	int nStartChar = 0;
	int nEndChar = 0;
	pEdit->GetSel(nStartChar,nEndChar);
	pEdit->SetWindowText(csText);
	pEdit->SetSel(nStartChar,nEndChar);
}

void SetEditTextNotChangeCursorSeat(CEdit *pEdit,const CStringW &csText)
{
	if(pEdit == NULL)
		return;

	int nStartChar = 0;
	int nEndChar = 0;
	pEdit->GetSel(nStartChar,nEndChar);
	::SetWindowTextW(pEdit,csText);
	pEdit->SetSel(nStartChar,nEndChar);
}

// CXEdit

IMPLEMENT_DYNAMIC(CXEdit, CEdit)

CXEdit::CXEdit()
{

}

CXEdit::~CXEdit()
{
}


BEGIN_MESSAGE_MAP(CXEdit, CEdit)
	ON_WM_KILLFOCUS()
END_MESSAGE_MAP()



// CXEdit ��Ϣ��������




void CXEdit::OnKillFocus(CWnd* pNewWnd)
{
	CEdit::OnKillFocus(pNewWnd);

	CWnd *pParentWnd = GetParent();
	if(pParentWnd != NULL)
	{
		::SendMessage(pParentWnd->GetSafeHwnd(),WM_EDIT_KILLFOCUS,(WPARAM)this,(LPARAM)pNewWnd);
	}
}
