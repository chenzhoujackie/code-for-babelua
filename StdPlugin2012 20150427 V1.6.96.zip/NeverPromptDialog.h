#pragma once


// CNeverPromptDialog �Ի���

class CNeverPromptDialog : public CDialogEx
{
public:
	void SetTitle(LPCTSTR lpszTitle);
	void SetStaticText1(LPCTSTR lpszText);
	void SetStaticText2(LPCTSTR lpszText);
	void SetEditText(LPCTSTR lpszText);

	BOOL IsNeverView() const;
protected:
	CString m_csTitle;
	CString m_csStaticText1;
	CString m_csStaticText2;
	CString m_csEditText;

	BOOL m_bNeverView;

	DECLARE_DYNAMIC(CNeverPromptDialog)

public:
	CNeverPromptDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CNeverPromptDialog();

// �Ի�������
	enum { IDD = IDD_NEVER_PROMPT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedYes();
	afx_msg void OnBnClickedNo();
	afx_msg void OnBnClickedCancel();
};
