// DialogName.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "DialogName.h"
#include "afxdialogex.h"

#include "XmlTools.h"

// CDialogName �Ի���

IMPLEMENT_DYNAMIC(CDialogName, CDialogEx)

CDialogName::CDialogName(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDialogName::IDD, pParent)
	, m_strName(_T(""))
{
	m_pNames2 = NULL;
}
void CDialogName::SetInitName(CString csName)
{
	m_strName = csName;
}
void CDialogName::SetCompareName(CStringArray& Names)
{
	m_Names.Copy(Names);
}
void CDialogName::SetCompareName2(CMapStringToString* pNames2)
{
	m_pNames2 = pNames2;
}
CString CDialogName::GetName()
{
	return m_strName;
}
CDialogName::~CDialogName()
{
	m_Names.RemoveAll();
}

void CDialogName::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT1, m_strName);
	DDV_MaxChars(pDX, m_strName, 60);
}


BEGIN_MESSAGE_MAP(CDialogName, CDialogEx)
	ON_EN_CHANGE(IDC_EDIT1, OnNameChange)
	ON_WM_CTLCOLOR()
	ON_BN_CLICKED(IDOK, &CDialogName::OnBnClickedOk)
END_MESSAGE_MAP()

void CDialogName::OnNameChange()
{
	UpdateData(TRUE);
	if ( 0 == m_strName.GetLength())
	{
		ShowError(_T("���Ʋ���Ϊ��."));
		return;
	}
	if ( !check_name(m_strName,FALSE))
	{
		ShowError(_T("������Ӣ����ĸ��ͷ,�����ֺ��»���."));
		return;
	}
	CString strCompare;
	for ( int i = 0; i < m_Names.GetCount(); i ++ )
	{
		strCompare = m_Names.GetAt(i);
		if ( 0 == m_strName.CompareNoCase(strCompare))
		{
			ShowError(_T("�������ѱ�ʹ��."));
			return;
		}
	}
	if ( NULL != m_pNames2 )
	{
		CString strValue;
		if ( m_pNames2->Lookup(m_strName,strValue))
		{
			ShowError(_T("�������ѱ�ʹ��."));
			return;
		}
	}
	ShowError(_T(""));
}
void CDialogName::ShowError(CString strError)
{
	CWnd* pText = GetDlgItem(IDC_STATIC_ERROR);
	CWnd* pBtn = GetDlgItem(IDOK);
	if ( 0 == strError.GetLength())
	{
		pBtn->EnableWindow(TRUE);
		pText->SetWindowText(_T(""));
	}
	else
	{
		pBtn->EnableWindow(FALSE);
		pText->SetWindowText(strError);
	}
}
// CDialogName ��Ϣ��������
void CDialogName::OnBnClickedOk()
{
	CDialogEx::OnOK();
}

HBRUSH CDialogName::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hBrush = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	if ( pWnd->GetDlgCtrlID() == IDC_STATIC_ERROR )
	{
		pDC->SetTextColor(RGB(255,0,0));
	}
	return hBrush;
}
BOOL CDialogName::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetIcon(hIcon, FALSE);

	CWnd* pBtn = GetDlgItem(IDOK);
	pBtn->EnableWindow(FALSE);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}
