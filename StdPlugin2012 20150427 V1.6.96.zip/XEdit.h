#pragma once

#define WM_EDIT_KILLFOCUS		WM_USER+5321

//����Edit Text���ı���λ��
void SetEditTextNotChangeCursorSeat(CEdit *pEdit,const CString &csText);
void SetEditTextNotChangeCursorSeat(CEdit *pEdit,const CStringW &csText);

// CXEdit

class CXEdit : public CEdit
{
	DECLARE_DYNAMIC(CXEdit)

public:
	CXEdit();
	virtual ~CXEdit();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnKillFocus(CWnd* pNewWnd);
};


