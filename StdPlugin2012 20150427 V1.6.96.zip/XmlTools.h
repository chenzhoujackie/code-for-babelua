#pragma once

#pragma warning(disable:4786)
#include <string>
#include <vector>
#include <map>
using namespace std;

//file,string,fontSize,align,color,file2


#define VIEW_TYPE_VIEW			0
#define VIEW_TYPE_IMAGE			1
#define VIEW_TYPE_BUTTON		2
#define VIEW_TYPE_BUTTON2		3
#define VIEW_TYPE_TEXT			4
#define VIEW_TYPE_TEXTVIEW		5
#define VIEW_TYPE_EDITTEXT		6
#define VIEW_TYPE_EDITTEXTVIEW	7

class CView1
{
public:
	CView1();
	virtual ~CView1();

public:
	//  ����
	static string tagType;
	static string tagTypeName;
	static string tagCreateTime;
	// x,y,w,h
	static string tagXName;
	static string tagYName;
	static string tagWidthName;
	static string tagHeightName;
	static string tagNodeAlign;

	static string tag9GridLeft;
	static string tag9GridRight;
	static string tag9GridTop;
	static string tag9GridBottom;

	static string tagTopLeftX;
	static string tagTopLeftY;
	static string tagBottomRightX;
	static string tagBottomRightY;

	static string tagVisibleName;
	static string tagLuaName;

	static string tagView1Name;
	static string tagAdaptiveWidthName;
	static string tagAdaptiveHeightName;

	long t;
	int x,y,width,height;
	int topleftx,toplefty,bottomrightx,bottomrighty;
	int iNodeAlign;
	int gleft,gright,gtop,gbottom;
	bool bVisible;
	int iType;
	string strVariableName;//������
	string strViewNameEx;
	string strLuaName;
	
	bool bAdaptiveWidth;
	bool bAdaptiveHeight;

public:
	string _strFile;
	COLORREF _color;
	string _strStringData;
	string _strAlignDesc;
	int _iFontSize;
	int _iAlign;
	string _strFile2;
};

class CImage1 : public CView1
{
public:
	CImage1();
	virtual ~CImage1();
public:
	static string tagImage1Name;
	static string tagFileName;

	string strFile;

};
class CText1 : public CView1
{
public:
	CText1();
	virtual ~CText1();
public:
	static string tagTextName;
	static string tagTextViewName;
	static string tagEditTextName;
	static string tagEditTextViewName;

	static string tagStringDataName;
	static string tagFontSize;
	static string tagTextAlign;
	static string tagAlign;
	static string tagColor;

	COLORREF color;
	string strStringData;
	string strAlignDesc;
	int iFontSize;
	int iTextAlign;
};

class CButton1 : public CImage1
{
public:
	CButton1();
	virtual ~CButton1();

public:
	static string tagButton1Name;//button
	static string tagFile2Name;	

	string strFile2;

};

class CButton2 : public CImage1
{
public:
	CButton2();
	virtual ~CButton2();
public:
	static string tagButton2Name;//button2
	static string tagFile2Name;	

	string strFile2;
};
class CTreeCtrl2;

char* getViewTypeName ( CView1* pView );
CString GetViewTypeNameCn ( CView1* pView );
char* getAlignType ( int iType );
int load_xml ( const char* strXmlFile,CTreeCtrl2& TreeCtrl,HTREEITEM hRoot );
int save_xml ( const char* strXmlFile,CTreeCtrl2& TreeCtrl ,bool bPrompt = true);

int gen_lua ( const char* strFile,const char* strName,CTreeCtrl2& TreeCtrl );

void create_default_xml(const char* strXmlFile);
void create_default_lua(const char* strLuaFile);

BOOL check_name ( CString str, BOOL bAlert = TRUE);

int load_xml_name ( const char* strXmlFile,CMapStringToString& Names);

int export_xml ( const char* strXmlFile,const char* strXmlFile2,double scale );

bool gen_debug_lua( const char* strFile, const char* strName );

int convertFromHex(string hex);