// ��� MFC ʾ��Դ������ʾ���ʹ�� MFC Microsoft Office Fluent �û����� 
// (��Fluent UI��)����ʾ�������ο���
// ���Բ��䡶Microsoft ������ο����� 
// MFC C++ �������渽����ص����ĵ���
// ���ơ�ʹ�û�ַ� Fluent UI �����������ǵ����ṩ�ġ�
// ��Ҫ�˽��й� Fluent UI ���ɼƻ�����ϸ��Ϣ�������  
// http://msdn.microsoft.com/officeui��
//
// ��Ȩ����(C) Microsoft Corporation
// ��������Ȩ����

// StdPluginView.cpp : CStdPluginView ���ʵ��
//

#include "stdafx.h"
// SHARED_HANDLERS ������ʵ��Ԥ��������ͼ������ɸѡ�������
// ATL ��Ŀ�н��ж��壬�����������Ŀ�����ĵ����롣
#ifndef SHARED_HANDLERS
#include "StdPlugin.h"
#endif

#include "StdPluginDoc.h"
#include "StdPluginView.h"
#include "MainFrm.h"

#include "EditTextDialog.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CStdPluginView

IMPLEMENT_DYNCREATE(CStdPluginView, CView)

BEGIN_MESSAGE_MAP(CStdPluginView, CView)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_WM_ERASEBKGND()
	ON_WM_HSCROLL()
	ON_WM_VSCROLL()
END_MESSAGE_MAP()

// CStdPluginView ����/����

CStdPluginView::CStdPluginView()
{
	m_iUIWndWidth = 400;
	m_iUIWndHeight = 300;

//	m_pImage = NULL;
}

CStdPluginView::~CStdPluginView()
{
/*	if(m_pImage != NULL)
	{
		delete m_pImage;
		m_pImage = NULL;
	}*/
}

BOOL CStdPluginView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: �ڴ˴�ͨ���޸�
	//  CREATESTRUCT cs ���޸Ĵ��������ʽ

	return CView::PreCreateWindow(cs);
}

// CStdPluginView ����

void CStdPluginView::OnDraw(CDC* pDC)
{
	CStdPluginDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	CRect rect;
	GetClientRect(rect);

	pDC->FillSolidRect(0,0,rect.Width(),rect.Height(),::GetBottomColor());
/*	{
		Graphics g(pDC->GetSafeHdc());
		g.DrawImage(m_pImage,Rect(0,0,rect.Width(),rect.Height()));
	}*/
}

void CStdPluginView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
/*
	ClientToScreen(&point);
	OnContextMenu(this, point);
*/
}

void CStdPluginView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
/*
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
*/
}


// CStdPluginView ���

#ifdef _DEBUG
void CStdPluginView::AssertValid() const
{
	CView::AssertValid();
}

void CStdPluginView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CStdPluginDoc* CStdPluginView::GetDocument() const // �ǵ��԰汾��������
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CStdPluginDoc)));
	return (CStdPluginDoc*)m_pDocument;
}
#endif //_DEBUG


// CStdPluginView ��Ϣ��������


void CStdPluginView::SetUIWndSize(int iWidth,int iHeight)
{
	m_iUIWndWidth = iWidth;
	m_iUIWndHeight = iHeight;

	if(m_uiWnd.m_hWnd != NULL)
	{
		m_uiWnd.MoveWindow(0,0,m_iUIWndWidth,m_iUIWndHeight,TRUE);
		UpdateScroll();
		MoveUIWnd();
	}
}

HWND CStdPluginView::GetUIWnd()
{
	return m_uiWnd.GetSafeHwnd();
}

void CStdPluginView::OnInitialUpdate()
{
	CView::OnInitialUpdate();

	long lWindowStyle = ::GetWindowLong(GetSafeHwnd(),GWL_STYLE);
//	lWindowStyle &= ~WS_CLIPCHILDREN;
//	lWindowStyle &= ~WS_CLIPSIBLINGS;
//	::SetWindowLong(GetSafeHwnd(),GWL_STYLE,lWindowStyle);

	CString csWndClass = AfxRegisterWndClass(CS_VREDRAW | CS_HREDRAW | CS_DBLCLKS,
		::LoadCursor(NULL, IDC_ARROW),
		(HBRUSH) ::GetStockObject(WHITE_BRUSH),
		::LoadIcon(NULL, IDI_APPLICATION));
	m_uiWnd.Create(csWndClass,_T(""),WS_CHILD | WS_VISIBLE,CRect(0,0,0,0),this,0x1001);
	m_uiWnd.ShowWindow(SW_SHOW);

	SetTimer(TIMER_RENDER_FRAME,RENDER_FRAME_DELAY,NULL);

/*
	CString csBackgroundImagePath = MODULE_FILE_DIRECTORY+_T("\\boyaa.jpg");
	if(::IsFileExist(csBackgroundImagePath))
	{
		m_pImage = Image::FromFile(csBackgroundImagePath);
	}*/
}


void CStdPluginView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);
	CRect clientRect;
	GetClientRect(clientRect);
/*
	if(m_uiWnd.m_hWnd != NULL)
	{
		m_uiWnd.MoveWindow(0,0,m_iUIWndWidth,m_iUIWndHeight);
	}
*/
	if(AfxGetMainWnd() != NULL)
	{
		((CMainFrame*)AfxGetMainWnd())->UpdateDockablePane();
	}
	UpdateScroll();
	MoveUIWnd();
}

void CStdPluginView::UpdateScroll()
{
	if(m_uiWnd.m_hWnd == NULL)
		return;

	CRect clientRect;
	this->GetClientRect(clientRect);

	CRect uiWndRect;
	m_uiWnd.GetWindowRect(uiWndRect);

	int iPageWidth = clientRect.Width();
	int iTotalWidth = uiWndRect.Width();
	if(iPageWidth < iTotalWidth)
	{
		SCROLLINFO scrollInfo;
		memset(&scrollInfo,0,sizeof(SCROLLINFO));
		GetScrollInfo(SB_HORZ,&scrollInfo,SIF_ALL);

		scrollInfo.nMax = iTotalWidth;
		scrollInfo.nPage = iPageWidth;
		if(scrollInfo.nPos > scrollInfo.nMax-(int)scrollInfo.nPage)
			scrollInfo.nPos = scrollInfo.nMax-(int)scrollInfo.nPage;
		SetScrollInfo(SB_HORZ,&scrollInfo,TRUE);
		ShowScrollBar(SB_HORZ,TRUE);
	}
	else
	{
		ShowScrollBar(SB_HORZ,FALSE);
	}

	int iPageHeight = clientRect.Height();
	int iTotalHeight = uiWndRect.Height();
	if(iPageHeight < iTotalHeight)
	{
		SCROLLINFO scrollInfo;
		memset(&scrollInfo,0,sizeof(SCROLLINFO));
		GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);

		scrollInfo.nMax = iTotalHeight;
		scrollInfo.nPage = iPageHeight;
		if(scrollInfo.nPos > scrollInfo.nMax-(int)scrollInfo.nPage)
			scrollInfo.nPos = scrollInfo.nMax-(int)scrollInfo.nPage;
		SetScrollInfo(SB_VERT,&scrollInfo,TRUE);
		ShowScrollBar(SB_VERT,TRUE);
	}
	else
	{
		ShowScrollBar(SB_VERT,FALSE);
	}
}

void CStdPluginView::MoveUIWnd()
{
	if(m_uiWnd.m_hWnd == NULL)
		return;

	CRect clienRect;
	GetClientRect(clienRect);
	CRect uiWndRect;
	m_uiWnd.GetWindowRect(uiWndRect);

	SCROLLINFO scrollInfo;
	DWORD windowStyle = GetWindowLong(m_hWnd,GWL_STYLE);
	GetScrollInfo(SB_HORZ,&scrollInfo,SIF_ALL);
	BOOL bHorzScroll = windowStyle & WS_HSCROLL;
	int nHorzPos = bHorzScroll ? -scrollInfo.nPos : (clienRect.Width()-uiWndRect.Width())/2;
	GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);
	BOOL bVertScroll = windowStyle & WS_VSCROLL;
	int nVertPos = bVertScroll ? -scrollInfo.nPos : (clienRect.Height()-uiWndRect.Height())/2;

	m_uiWnd.MoveWindow(nHorzPos,nVertPos,uiWndRect.Width(),uiWndRect.Height());
}

void CStdPluginView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	SCROLLINFO scrollInfo;
	GetScrollInfo(SB_HORZ,&scrollInfo,SIF_ALL);
	int nDis = 10;
	int nOldPos = scrollInfo.nPos;
	switch(nSBCode)
	{
	case SB_LINELEFT:
		scrollInfo.nPos = max(nOldPos-nDis,scrollInfo.nMin);
		break;
	case SB_LINERIGHT:
		scrollInfo.nPos = min(nOldPos+nDis,scrollInfo.nMax-(int)scrollInfo.nPage+1);
		break;
	case SB_PAGELEFT:
		scrollInfo.nPos = max(nOldPos-nDis*10,scrollInfo.nMin);
		break;
	case SB_PAGERIGHT:
		scrollInfo.nPos = min(nOldPos+nDis*10,scrollInfo.nMax-(int)scrollInfo.nPage+1);
		break;
	case SB_THUMBTRACK:
		scrollInfo.nPos = scrollInfo.nTrackPos;
		break;
	case SB_THUMBPOSITION:
		scrollInfo.nPos = scrollInfo.nTrackPos;
		break;
	}
	scrollInfo.fMask = SIF_POS;
	SetScrollInfo(SB_HORZ,&scrollInfo,TRUE);

	MoveUIWnd();

	CWnd::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CStdPluginView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	SCROLLINFO scrollInfo;
	GetScrollInfo(SB_VERT,&scrollInfo,SIF_ALL);
	int nDis = 10;
	int nOldPos = scrollInfo.nPos;
	switch(nSBCode)
	{
	case SB_LINEUP:
		scrollInfo.nPos = max(nOldPos-nDis,scrollInfo.nMin);
		break;
	case SB_LINEDOWN:
		scrollInfo.nPos = min(nOldPos+nDis,scrollInfo.nMax-(int)scrollInfo.nPage+1);
		break;
	case SB_PAGEUP:
		scrollInfo.nPos = max(nOldPos-(int)scrollInfo.nPage,scrollInfo.nMin);
		break;
	case SB_PAGEDOWN:
		scrollInfo.nPos = min(nOldPos+(int)scrollInfo.nPage,scrollInfo.nMax-(int)scrollInfo.nPage+1);
		break;
	case SB_THUMBTRACK:
		scrollInfo.nPos = scrollInfo.nTrackPos;
		break;
	case SB_THUMBPOSITION:
		scrollInfo.nPos = scrollInfo.nTrackPos;
		break;
	}
	scrollInfo.fMask = SIF_POS;
	SetScrollInfo(SB_VERT,&scrollInfo,TRUE);

	MoveUIWnd();

	CWnd::OnVScroll(nSBCode, nPos, pScrollBar);
}

void CStdPluginView::OnTimer(UINT_PTR nIDEvent)
{
	switch(nIDEvent)
	{
	case TIMER_RENDER_FRAME:
		{
			EngineInterface *pEngineInterface = ::GetEngineInterface();
			if(pEngineInterface != NULL)
			{
				pEngineInterface->RenderFrame(m_uiWnd.GetSafeHwnd());
			}
		}
		break;
	default:
		break;
	}

	CView::OnTimer(nIDEvent);
}


BOOL CStdPluginView::PreTranslateMessage(MSG* pMsg)
{
	EngineInterface *pEngineInterface = ::GetEngineInterface();
	switch(pMsg->message)
	{
	case WM_LBUTTONDOWN:
		{
			int xPos = LOWORD(pMsg->lParam);
			int yPos = HIWORD(pMsg->lParam);
			if(pMsg->hwnd == m_uiWnd.m_hWnd)
			{
				if(pEngineInterface != NULL)
				{
					pEngineInterface->TouchBegin(xPos,yPos);
				}
			}
		}
		break;
	case WM_MOUSEMOVE:
		{
			int xPos = LOWORD(pMsg->lParam);
			int yPos = HIWORD(pMsg->lParam);
			if(pMsg->hwnd == m_uiWnd.m_hWnd)
			{
				if(pEngineInterface != NULL)
				{
					pEngineInterface->TouchMove(xPos,yPos);
					pEngineInterface->RenderFrame(m_uiWnd.GetSafeHwnd());
				}
			}
		}
		break;
	case WM_LBUTTONUP:
		{
			int xPos = LOWORD(pMsg->lParam);
			int yPos = HIWORD(pMsg->lParam);
			if(pMsg->hwnd == m_uiWnd.m_hWnd)
			{
				if(pEngineInterface != NULL)
				{
					pEngineInterface->TouchEnd(xPos,yPos);
				}
			}
		}
		break;
	case WM_LBUTTONDBLCLK:
		{
			const CDrawingBase *pDrawingBase = ((CMainFrame*)AfxGetMainWnd())->GetSelDrawingBase();

			BOOL bEditText = FALSE;
			CString csName;
			CStringW csStr;
			if(pDrawingBase != NULL)
			{
				pDrawingBase->GetName(csName);
				switch(pDrawingBase->GetDrawingType())
				{
				case DRAWING_TYPE_Text:
				case DRAWING_TYPE_EditText:
					{
						const CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(const_cast<CDrawingBase*>(pDrawingBase));
						if(pDrawingText != NULL)
						{
							pDrawingText->GetStr(csStr);
							bEditText = TRUE;
						}
					}
					break;
				case DRAWING_TYPE_TextView:
				case DRAWING_TYPE_EditTextView:
					{
						const CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(const_cast<CDrawingBase*>(pDrawingBase));
						if(pDrawingTextView != NULL)
						{
							pDrawingTextView->GetStr(csStr);
							bEditText = TRUE;
						}
					}
					break;
				default:
					break;
				}
			}
			
			if(bEditText && (pDrawingBase != NULL))
			{
				CEditTextDialog editTextDialog(this);
				editTextDialog.SetTitle(csName);
				//\n�滻Ϊ\r\n�Ա���Text������ʾ
				csStr.Replace(L"\\n",L"\r\n");
				editTextDialog.SetEditText(csStr);
				if(editTextDialog.DoModal() == IDOK)
				{
					csStr = editTextDialog.GetEditText();
					//��Text�е�\r\n��\nת��Ϊ\n�ַ����������ɵ�lua���뻻�г����﷨����
					csStr.Replace(L"\r\n",L"\\n");
					csStr.Replace(L"\n",L"\\n");
					::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_csStr,(LPARAM)&csStr);
				}
			}
			return TRUE;
		}
		break;
	case WM_RBUTTONDOWN:
		{
			int xPos = LOWORD(pMsg->lParam);
			int yPos = HIWORD(pMsg->lParam);
			if(pMsg->hwnd == m_uiWnd.m_hWnd)
			{
				if(pEngineInterface != NULL)
				{
					pEngineInterface->TouchBegin(xPos,yPos);
				}
			}
		}
		break;
	case WM_RBUTTONUP:
		{
			int xPos = LOWORD(pMsg->lParam);
			int yPos = HIWORD(pMsg->lParam);
			if(pMsg->hwnd == m_uiWnd.m_hWnd)
			{
				if(pEngineInterface != NULL)
				{
					pEngineInterface->TouchEnd(xPos,yPos);
				}
			}
/*			CMenu xmlMenu;
			xmlMenu.LoadMenu(IDR_MENU_XML);
			CMenu *pSubXmlMenu = xmlMenu.GetSubMenu(0);
			CMenu menu;
			menu.Attach(pSubXmlMenu->m_hMenu);

			CPoint screenPoint;
			::GetCursorPos(&screenPoint);
			menu.TrackPopupMenu(TPM_LEFTALIGN |TPM_RIGHTBUTTON,screenPoint.x,screenPoint.y,this);*/
		}
		break;
	case WM_KEYDOWN:
		break;
	default:
		break;
	}

	return CView::PreTranslateMessage(pMsg);
}


BOOL CStdPluginView::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;

	return CView::OnEraseBkgnd(pDC);
}
