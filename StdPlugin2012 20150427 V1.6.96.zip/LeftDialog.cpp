// LeftDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "LeftDialog.h"
#include "afxdialogex.h"

#include "XmlTools.h"

#include "MainFrm.h"

#include "DialogWHScale.h"
#include "DialogName.h"
#include "DialogName2.h"

#include "OutputConfigDialog.h"

#include <libxml/parser.h>
#include <libxml/tree.h>


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define ExecBuffer_UTF8


int GetImageId(CDrawingBase *pDrawingBase)
{
	EM_DRAWING_TYPE type = (EM_DRAWING_TYPE)-1;
	if(pDrawingBase != NULL)
		type = pDrawingBase->GetDrawingType();

	switch(type)
	{
	case DRAWING_TYPE_Base:
		break;
	case DRAWING_TYPE_ImageBase:
		break;
	case DRAWING_TYPE_Empty:
		break;
	case DRAWING_TYPE_Node:
		break;
	case DRAWING_TYPE_Image:
		return 0;
		break;
	case DRAWING_TYPE_Images:
		break;
	case DRAWING_TYPE_Button:
		return 1;
		break;
	case DRAWING_TYPE_GroupNode:
		break;
	case DRAWING_TYPE_GroupItem:
		break;
	case DRAWING_TYPE_CheckBoxGroup:
		return 2;
		break;
	case DRAWING_TYPE_CheckBox:
		return 3;
		break;
	case DRAWING_TYPE_RadioButtonGroup:
		return 4;
		break;
	case DRAWING_TYPE_RadioButton:
		return 5;
		break;
	case DRAWING_TYPE_Text:
		return 7;
		break;
	case DRAWING_TYPE_ScrollableNode:
		break;
	case DRAWING_TYPE_TextView:
		return 6;
		break;
	case DRAWING_TYPE_EditTextView:
		return 8;
		break;
	case DRAWING_TYPE_EditText:
		return 9;
		break;
	case DRAWING_TYPE_ScrollBar:
		break;
	case DRAWING_TYPE_TabView:
		break;
	case DRAWING_TYPE_TableView:
		break;
	case DRAWING_TYPE_GridView:
		break;
	case DRAWING_TYPE_ViewPager:
		break;
	case DRAWING_TYPE_ListView:
		break;
	case DRAWING_TYPE_ScrollView:
		break;
	case DRAWING_TYPE_Slider:
		return 11;
		break;
	case DRAWING_TYPE_Switch:
		break;
	case DRAWING_TYPE_DrawingCustom:
		break;
	case DRAWING_TYPE_CustomNode:
		break;
	case DRAWING_TYPE_CustomControl:
		break;
	default:
		break;
	};
	return 10;
}

void DeleteItemData(CXTreeCtrl &treeCtrl,HTREEITEM hTreeItem)
{
	if(hTreeItem == NULL)
		return;

	DWORD_PTR dwData = treeCtrl.GetItemData(hTreeItem);
	if(dwData != 0)
	{
		CDrawingBase *pDrawingBase = (CDrawingBase *)dwData;
		if(pDrawingBase != NULL)
		{
			delete pDrawingBase;
			pDrawingBase = NULL;
		}
		treeCtrl.SetItemData(hTreeItem,NULL);
	}

	HTREEITEM hChildItem = treeCtrl.GetChildItem(hTreeItem);
	if(treeCtrl.ItemHasChildren(hTreeItem))
	{
		while (hChildItem != NULL)
		{
			DeleteItemData(treeCtrl,hChildItem);
			hChildItem = treeCtrl.GetNextSiblingItem(hChildItem);
		}
	}
}

void GetTreeItemName(CXTreeCtrl &treeCtrl,HTREEITEM hItem,CStringArray &csAllTreeItemName)
{
	if(hItem == NULL)
		return;

	HTREEITEM hNextItem = hItem;
	while(hNextItem != NULL)
	{
		CString csItemName = treeCtrl.GetItemText(hNextItem);
		csAllTreeItemName.Add(csItemName);
		if(treeCtrl.ItemHasChildren(hNextItem))
		{
			GetTreeItemName(treeCtrl,treeCtrl.GetChildItem(hNextItem),csAllTreeItemName);
		}

		hNextItem = treeCtrl.GetNextItem(hNextItem, TVGN_NEXT);
	}
}

CString TrackingTreeName(const CXTreeCtrl &treeCtrl,HTREEITEM hItem)
{
	CString strTTN;
	HTREEITEM hParent = treeCtrl.GetParentItem(hItem);
	while ( 0 != hParent )
	{
		strTTN += treeCtrl.GetItemText(hParent);
		hParent = treeCtrl.GetParentItem(hParent);
	}
	return strTTN;
}

void GetTrackingTreeName(CXTreeCtrl &treeCtrl,HTREEITEM hItem,CStringArray &csTrackingTreeName)
{
	if(hItem == NULL)
		return;

	while ( 0 != hItem )
	{
		CString csItemName = treeCtrl.GetItemText(hItem);
		csTrackingTreeName.InsertAt(0,csItemName);
		hItem = treeCtrl.GetParentItem(hItem);
	}
}

HTREEITEM GetLastChildTreeItem(CXTreeCtrl &treeCtrl,HTREEITEM hItem)
{
	HTREEITEM hLastItem = NULL;
	if(treeCtrl.ItemHasChildren(hItem))
	{
		HTREEITEM hChildItem = treeCtrl.GetChildItem(hItem);
		while( 0 != hChildItem )
		{
			hLastItem = hChildItem;

			hChildItem =treeCtrl.GetNextItem(hChildItem, TVGN_NEXT);  
		}
	}
	return hLastItem;
}

void GetParentPrevTrackingTreeName(CXTreeCtrl &treeCtrl,HTREEITEM hParentItem,HTREEITEM hPrevItem,CStringArray &csParentTrackingTreeName,CString &csPrevItemName)
{
	if(hParentItem == NULL)
		return;

	GetTrackingTreeName(treeCtrl,hParentItem,csParentTrackingTreeName);
	if(hPrevItem != NULL)
	{
		csPrevItemName = treeCtrl.GetItemText(hPrevItem);
	}
}

void GetParentsPos(CXTreeCtrl &treeCtrl,HTREEITEM hItem,int &iParentsX,int &iParentsY)
{
	if(hItem == NULL)
		return;

	CDrawingBase *pDrawingBase = (CDrawingBase*)treeCtrl.GetItemData(hItem);
	if(pDrawingBase != NULL)
	{
		int x = 0;
		int y = 0;
		pDrawingBase->GetPos(x,y);
		iParentsX += x;
		iParentsY += y;
	}
	HTREEITEM hParentItem = treeCtrl.GetParentItem(hItem);
	if(hParentItem != NULL)
	{
		GetParentsPos(treeCtrl,hParentItem,iParentsX,iParentsY);
	}
}

BOOL GetCDrawingBaseNode(CXTreeCtrl &treeCtrl,HTREEITEM hItem,CCDrawingBaseNode *pDrawingBaseNode)
{
	if(hItem == NULL)
		return FALSE;

	if(pDrawingBaseNode == NULL)
		return FALSE;

	if(treeCtrl.ItemHasChildren(hItem))
	{
		HTREEITEM hChildItem = treeCtrl.GetChildItem(hItem);
		while(hChildItem != NULL)
		{
			CDrawingBase *pDrawingBase = (CDrawingBase*)treeCtrl.GetItemData(hChildItem);
			CCDrawingBaseNode *pChildCDrawingBaseNode = pDrawingBaseNode->AddCDrawingBaseNode(pDrawingBase);
			if(treeCtrl.ItemHasChildren(hChildItem))
			{
				GetCDrawingBaseNode(treeCtrl,hChildItem,pChildCDrawingBaseNode);
			}
			hChildItem = treeCtrl.GetNextSiblingItem(hChildItem);
		}
	}
	return TRUE;
}

BOOL IsNameInArray(const CString &csName,const CStringArray &csNameArray)
{
	int i;
	for(i=0; i<csNameArray.GetSize(); i++)
	{
		if(csName == csNameArray.GetAt(i))
			return TRUE;
	}
	return FALSE;
}

CString GetDifferentName(const CStringArray &csAllTreeItemName,CString csName)
{
	int index = 1;
	while(TRUE)
	{
		if(!::IsNameInArray(csName+::IntToCString(index),csAllTreeItemName))
			break;
		index++;
	}
	CString csDifferentName = csName+::IntToCString(index);
	return csDifferentName;
}

//����lua���� ���ڵ����ӵ�UIEditor��ʾ
BOOL AddNodeToUIEditor(CDrawingBase *pParentDrawingBase,CDrawingBase *pNewDrawingBase)
{
	if(pParentDrawingBase == NULL || pNewDrawingBase == NULL)
		return FALSE;

	//��UI�ؼ��������ڵ�
	AnimInterface *pAnimInterface = GetAnimInterface();
	CStringW csLuaScripts = pNewDrawingBase->GetLuaScriptsNew()+pNewDrawingBase->GetLuaScriptsSetAll();
	LuaInterface* pLuaInterface = GetLuaInterface();
#ifdef ExecBuffer_UTF8
	pLuaInterface->ExecBuffer(::UnicodeToUTF8(CWCharArr(csLuaScripts)));
#else
	pLuaInterface->ExecBuffer(CCharArr(csLuaScripts));
#endif

	csLuaScripts = ::GetLuaScriptsAddChild(pParentDrawingBase,pNewDrawingBase);
#ifdef ExecBuffer_UTF8
	pLuaInterface->ExecBuffer(::UnicodeToUTF8(CWCharArr(csLuaScripts)));
#else
	pLuaInterface->ExecBuffer(CCharArr(csLuaScripts));
#endif

	return TRUE;
}

void AddCopyDrawingBaseNodeToChild(CXTreeCtrl &treeCtrl,HTREEITEM hItem,CCDrawingBaseNode *pCDrawingBaseNode)
{
	if(hItem == NULL)
		return;
	if(pCDrawingBaseNode == NULL)
		return;

	CDrawingBase *pCurrentDrawingBase = (CDrawingBase*)treeCtrl.GetItemData(hItem);
	if(pCurrentDrawingBase == NULL)
		return;

	CDrawingBase *pDrawingBase = pCDrawingBaseNode->GetCDrawingBase();
	if(pDrawingBase == NULL)
		return;

	CDrawingBase *pNewDrawingBase = pDrawingBase->Clone();
	if(pNewDrawingBase == NULL)
		return;
	CString csName;
	pNewDrawingBase->GetName(csName);

	AddNodeToUIEditor(pCurrentDrawingBase,pNewDrawingBase);

	int iImageId = ::GetImageId(pNewDrawingBase);
	HTREEITEM hChildItem = treeCtrl.InsertItem(csName, iImageId,iImageId,hItem);
	treeCtrl.SetItemData(hChildItem,(DWORD_PTR)pNewDrawingBase);

	int i;
	for(i=0; i<pCDrawingBaseNode->GetCDrawingBaseNodeChildNum(); i++)
	{
		CCDrawingBaseNode *pCDrawingBaseNodeChild = pCDrawingBaseNode->GetCDrawingBaseNode(i);
		if(pCDrawingBaseNodeChild != NULL)
		{
			AddCopyDrawingBaseNodeToChild(treeCtrl,hChildItem,pCDrawingBaseNodeChild);
		}
	}
}

long GetDifferentTime(const map<long,bool> &lTimeMap,long lTime)
{
	long lDifferentTime = lTime;
	while(lTimeMap.find(lDifferentTime) != lTimeMap.end())
	{
		lDifferentTime++;
	}
	return lDifferentTime;
}

void GetDifferentTime(const map<long,bool> &lTimeMap,long lTime,int iSize,CArray <long,long> &lTimeArray)
{
	lTimeArray.SetSize(iSize);
	long lDifferentTime = lTime;
	int i;
	for(i=0; i<iSize; i++)
	{
		bool bAddTime = false;
		while(lTimeMap.find(lDifferentTime) != lTimeMap.end())
		{
			lDifferentTime++;
			bAddTime = true;
		}
		if(!bAddTime)
		{
			lDifferentTime++;
		}
		lTimeArray[i] = lDifferentTime;
	}
}

long GetDifferentDrawingTime(long lTime)
{
	map<long,bool> lTimeMap;
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),WM_GET_TREE_DRAWING_TIMES,(WPARAM)&lTimeMap,NULL);

	return ::GetDifferentTime(lTimeMap,lTime);
}

void GetDifferentDrawingTime(int iSize,CArray <long,long> &lTimeArray)
{
	map<long,bool> lTimeMap;
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),WM_GET_TREE_DRAWING_TIMES,(WPARAM)&lTimeMap,NULL);

	long lTime = ::GetDrawingTime();
	::GetDifferentTime(lTimeMap,lTime,iSize,lTimeArray);
}


CConfigNode::CConfigNode(EM_DRAWING_TYPE emDrawingType,const CString &csNodeName)
{
	m_emDrawingType = emDrawingType;
	m_csNodeName = csNodeName;
}

CConfigNode::~CConfigNode()
{
	POSITION pos = m_configNodeList.GetHeadPosition();
	int i;
	for(i=0; i<m_configNodeList.GetCount(); i++)
	{
		CConfigNode *pConfigNode = m_configNodeList.GetNext(pos);
		if(pConfigNode != NULL)
		{
			delete pConfigNode;
			pConfigNode = NULL;
		}
	}
	m_configNodeList.RemoveAll();
}

CConfigNode* CConfigNode::AddConfigNode(EM_DRAWING_TYPE emDrawingType,const CString &csNodeName)
{
	CConfigNode* pConfigNode = new CConfigNode(emDrawingType,csNodeName);
	if(pConfigNode != NULL)
	{
		m_configNodeList.AddTail(pConfigNode);
	}
	return pConfigNode;
}

EM_DRAWING_TYPE CConfigNode::GetDrawingType() const
{
	return m_emDrawingType;
}

CString CConfigNode::GetNodeName() const
{
	return m_csNodeName;
}

BOOL CConfigNode::IsHaveChildNode() const
{
	return (m_configNodeList.GetCount() > 0);
}

BOOL CConfigNode::GetConfigNodeName(CStringArray &csConfigNodeNameArr) const
{
	csConfigNodeNameArr.RemoveAll();

	POSITION pos = m_configNodeList.GetHeadPosition();
	int i;
	for(i=0; i<m_configNodeList.GetCount(); i++)
	{
		CConfigNode *pConfigNode = m_configNodeList.GetNext(pos);
		if(pConfigNode != NULL)
		{
			csConfigNodeNameArr.Add(pConfigNode->GetNodeName());
		}
	}
	return TRUE;
}

BOOL CConfigNode::GetAllConfigNodeName(CList <CString,CString> &csAllConfigNodeNameList,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode)
{
	POSITION pos = m_configNodeList.GetHeadPosition();
	int i;
	for(i=0; i<m_configNodeList.GetCount(); i++)
	{
		CConfigNode *pConfigNode = m_configNodeList.GetNext(pos);
		if((pConfigNode != NULL))
		{
			if(::IsDrawingTypeInArr(pConfigNode->GetDrawingType(),emDrawingTypeArr))
			{
				if(!bLeafNode || (bLeafNode && !pConfigNode->IsHaveChildNode()))
				{
					csAllConfigNodeNameList.AddTail(pConfigNode->GetNodeName());
				}
			}
			pConfigNode->GetAllConfigNodeName(csAllConfigNodeNameList,emDrawingTypeArr,bLeafNode);
		}
	}
	return TRUE;
}

BOOL IsDrawingTypeImageButton(EM_DRAWING_TYPE emDrawingType)
{
	switch(emDrawingType)
	{
	case DRAWING_TYPE_Image:
	case DRAWING_TYPE_Button:
		return TRUE;
		break;
	default:
		break;
	}
	return FALSE;
}

BOOL CConfigNode::GetAllImageButtonName(CList <CString,CString> &csImageButtonNameList,BOOL bLeafNode) const
{
	POSITION pos = m_configNodeList.GetHeadPosition();
	int i;
	for(i=0; i<m_configNodeList.GetCount(); i++)
	{
		CConfigNode *pConfigNode = m_configNodeList.GetNext(pos);
		if((pConfigNode != NULL))
		{
			if(::IsDrawingTypeImageButton(pConfigNode->GetDrawingType()))
			{
				if(!bLeafNode || (bLeafNode && !pConfigNode->IsHaveChildNode()))
				{
					csImageButtonNameList.AddTail(pConfigNode->GetNodeName());
				}
			}
			pConfigNode->GetAllImageButtonName(csImageButtonNameList,bLeafNode);
		}
	}
	return TRUE;
}

CString GetSpaces(int iLength,int iMaxLength)
{
	if(iMaxLength > iLength)
	{
		int iSpacesNum = iMaxLength-iLength;
		CString csSpaces;
		int i;
		for(i=0; i<iSpacesNum; i++)
		{
			csSpaces += ' ';
		}
		return csSpaces;
	}
	return _T("");
}

BOOL CConfigNode::Write(FILE *fp,const CString &csFileName,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode)
{
	if(fp == NULL)
		return FALSE;

	USES_CONVERSION;

	fwprintf(fp,L"-- %s.lua\n-- Author:\n-- Date:\n-- Last modification:\n-- Description:\n-- Note:\n\n",A2W(csFileName));
	fwprintf(fp,L"%s.s_controls =\n{\n",A2W(csFileName));

	int iNodeNameMaxLength = 0;
	CConfigNode::GetAllNodeNameMaxLength(iNodeNameMaxLength,emDrawingTypeArr,bLeafNode);
	int iImageButtonNameMaxLength = 0;
	CConfigNode::GetAllImageButtonNameMaxLength(iImageButtonNameMaxLength,bLeafNode);

	CList <CString,CString> csAllConfigNodeNameList;
	CConfigNode::GetAllConfigNodeName(csAllConfigNodeNameList,emDrawingTypeArr,bLeafNode);

	POSITION pos = csAllConfigNodeNameList.GetHeadPosition();
	int i;
	for(i=0; i<csAllConfigNodeNameList.GetCount(); i++)
	{
		CString &csString = csAllConfigNodeNameList.GetNext(pos);
		fwprintf(fp,L"\t%s%s = %d,\n",A2W(csString),A2W(::GetSpaces(csString.GetLength(),iNodeNameMaxLength)),i+1);
	}
	fwprintf(fp,L"};\n");

	fwprintf(fp,L"\n%s.s_controlConfig = \n{\n",A2W(csFileName));
	pos = m_configNodeList.GetHeadPosition();
	for(i=0; i<m_configNodeList.GetCount(); i++)
	{
		CConfigNode *pConfigNode = m_configNodeList.GetNext(pos);
		if(pConfigNode != NULL)
		{
			CList<CString,CString> csViewNameList;
			pConfigNode->WriteControlConfig(fp,csFileName,iNodeNameMaxLength,csViewNameList,emDrawingTypeArr,bLeafNode);
		}
	}
	fwprintf(fp,L"};\n");

	pos = m_configNodeList.GetHeadPosition();
	for(i=0; i<m_configNodeList.GetCount(); i++)
	{
		CConfigNode *pConfigNode = m_configNodeList.GetNext(pos);
		if(pConfigNode != NULL)
		{
			pConfigNode->WriteControlFuncDefine(fp,csFileName,emDrawingTypeArr,bLeafNode);
		}
	}

	fwprintf(fp,L"\n%s.s_controlFuncMap = \n{\n",A2W(csFileName));
	pos = m_configNodeList.GetHeadPosition();
	for(i=0; i<m_configNodeList.GetCount(); i++)
	{
		CConfigNode *pConfigNode = m_configNodeList.GetNext(pos);
		if(pConfigNode != NULL)
		{
			pConfigNode->WriteControlFuncMap(fp,csFileName,iImageButtonNameMaxLength,emDrawingTypeArr,bLeafNode);
		}
	}
	fwprintf(fp,L"};\n");

	return TRUE;
}

CString GetParentViewName(const CList<CString,CString> &csViewNameList)
{
	CString csParentViewName;

	POSITION pos = csViewNameList.GetHeadPosition();
	int i;
	for(i=0; i<csViewNameList.GetCount(); i++)
	{
		const CString &csViewName = csViewNameList.GetNext(pos);
		
		CString csName;
		csName.Format(_T("\"%s\", "),csViewName);
		csParentViewName += csName;
	}
	return csParentViewName;
}

BOOL CConfigNode::GetAllNodeNameMaxLength(int &iNodeNameMaxLength,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode)
{
	POSITION pos = m_configNodeList.GetHeadPosition();
	int i;
	for(i=0; i<m_configNodeList.GetCount(); i++)
	{
		CConfigNode *pConfigNode = m_configNodeList.GetNext(pos);
		if((pConfigNode != NULL))
		{
			if(::IsDrawingTypeInArr(pConfigNode->GetDrawingType(),emDrawingTypeArr))
			{
				if(!bLeafNode || (bLeafNode && !pConfigNode->IsHaveChildNode()))
				{
					int iNodeNameLength = pConfigNode->GetNodeName().GetLength();
					if(iNodeNameMaxLength < iNodeNameLength)
					{
						iNodeNameMaxLength = iNodeNameLength;
					}
				}
			}
			pConfigNode->GetAllNodeNameMaxLength(iNodeNameMaxLength,emDrawingTypeArr,bLeafNode);
		}
	}
	return TRUE;
}

BOOL CConfigNode::GetAllImageButtonNameMaxLength(int &iNodeNameMaxLength,BOOL bLeafNode)
{
	POSITION pos = m_configNodeList.GetHeadPosition();
	int i;
	for(i=0; i<m_configNodeList.GetCount(); i++)
	{
		CConfigNode *pConfigNode = m_configNodeList.GetNext(pos);
		if((pConfigNode != NULL))
		{
			if(::IsDrawingTypeImageButton(pConfigNode->GetDrawingType()))
			{
				if(!bLeafNode || (bLeafNode && !pConfigNode->IsHaveChildNode()))
				{
					int iNodeNameLength = pConfigNode->GetNodeName().GetLength();
					if(iNodeNameMaxLength < iNodeNameLength)
					{
						iNodeNameMaxLength = iNodeNameLength;
					}
				}
			}
			pConfigNode->GetAllImageButtonNameMaxLength(iNodeNameMaxLength,bLeafNode);
		}
	}
	return TRUE;
}

BOOL CConfigNode::WriteControlConfig(FILE *fp,const CString &csFileName,int iNodeNameMaxLength,CList<CString,CString> &csViewNameList,
	const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode)
{
	USES_CONVERSION;

	if(::IsDrawingTypeInArr(m_emDrawingType,emDrawingTypeArr))
	{
		if(!bLeafNode || (bLeafNode && !IsHaveChildNode()))
		{
			fwprintf(fp,L"\t[%s.s_controls.%s]%s = {%s\"%s\"},\n",A2W(csFileName),A2W(m_csNodeName),A2W(::GetSpaces(m_csNodeName.GetLength(),iNodeNameMaxLength)),A2W(::GetParentViewName(csViewNameList)),A2W(m_csNodeName));
		}
	}

	POSITION pos = m_configNodeList.GetHeadPosition();
	int i;
	for(i=0; i<m_configNodeList.GetCount(); i++)
	{
		CConfigNode *pConfigNode = m_configNodeList.GetNext(pos);
		if(pConfigNode == NULL)
			continue;

		csViewNameList.AddTail(m_csNodeName);
		pConfigNode->WriteControlConfig(fp,csFileName,iNodeNameMaxLength,csViewNameList,emDrawingTypeArr,bLeafNode);
		csViewNameList.RemoveTail();
	}
	return TRUE;
}

CString FirstCharToUpper(const CString &csString)
{
	if(csString.GetLength() > 0)
	{
		CString csRet = csString;
		csRet.SetAt(0,_totupper(csRet.GetAt(0)));
		return csRet;
	}
	else
		return csString;
}

BOOL CConfigNode::WriteControlFuncDefine(FILE *fp,const CString &csFileName,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode)
{
	USES_CONVERSION;

	if(::IsDrawingTypeImageButton(m_emDrawingType))
	{
		if(!bLeafNode || (bLeafNode && !IsHaveChildNode()))
		{
			fwprintf(fp,L"\n%s.on%sClick = function(self)\nend\n",A2W(csFileName),A2W(::FirstCharToUpper(m_csNodeName)));
		}
	}
	POSITION pos = m_configNodeList.GetHeadPosition();
	int i;
	for(i=0; i<m_configNodeList.GetCount(); i++)
	{
		CConfigNode *pConfigNode = m_configNodeList.GetNext(pos);
		if(pConfigNode != NULL)
		{
			pConfigNode->WriteControlFuncDefine(fp,csFileName,emDrawingTypeArr,bLeafNode);
		}
	}
	return TRUE;
}

BOOL CConfigNode::WriteControlFuncMap(FILE *fp,const CString &csFileName,int iNodeNameMaxLength,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode)
{
	USES_CONVERSION;

	if(::IsDrawingTypeImageButton(m_emDrawingType))
	{
		if(!bLeafNode || (bLeafNode && !IsHaveChildNode()))
		{
			fwprintf(fp,L"\t[%s.s_controls.%s]%s = %s.on%sClick;\n",A2W(csFileName),A2W(m_csNodeName),A2W(::GetSpaces(m_csNodeName.GetLength(),iNodeNameMaxLength)),A2W(csFileName),A2W(::FirstCharToUpper(m_csNodeName)));
		}
	}
	POSITION pos = m_configNodeList.GetHeadPosition();
	int i;
	for(i=0; i<m_configNodeList.GetCount(); i++)
	{
		CConfigNode *pConfigNode = m_configNodeList.GetNext(pos);
		if(pConfigNode != NULL)
		{
			pConfigNode->WriteControlFuncMap(fp,csFileName,iNodeNameMaxLength,emDrawingTypeArr,bLeafNode);
		}
	}
	return TRUE;
}


CCDrawingBaseNode::CCDrawingBaseNode(CDrawingBase *pDrawingBase)
{
	m_pDrawingBase = NULL;
	if(pDrawingBase != NULL)
	{
		m_pDrawingBase = pDrawingBase->Clone();
	}
}

CCDrawingBaseNode::~CCDrawingBaseNode()
{
	if(m_pDrawingBase != NULL)
	{
		delete m_pDrawingBase;
		m_pDrawingBase = NULL;
	}

	int i;
	for(i=0; i<m_drawingBaseChildArray.GetSize(); i++)
	{
		if(m_drawingBaseChildArray.GetAt(i) != NULL)
		{
			delete m_drawingBaseChildArray.GetAt(i);
			m_drawingBaseChildArray[i] = NULL;
		}
	}
	m_drawingBaseChildArray.RemoveAll();
}

CCDrawingBaseNode* CCDrawingBaseNode::AddCDrawingBaseNode(CDrawingBase *pDrawingBase)
{
	CCDrawingBaseNode *pCDrawingBaseNode = new CCDrawingBaseNode(pDrawingBase);
	if(pCDrawingBaseNode != NULL)
	{
		m_drawingBaseChildArray.Add(pCDrawingBaseNode);
	}
	return pCDrawingBaseNode;
}

int CCDrawingBaseNode::GetCDrawingBaseNodeChildNum() const
{
	return m_drawingBaseChildArray.GetSize();
}

CCDrawingBaseNode* CCDrawingBaseNode::GetCDrawingBaseNode(int index)
{
	if(index >= 0 && index < m_drawingBaseChildArray.GetSize())
		return m_drawingBaseChildArray.GetAt(index);

	return NULL;
}

void CCDrawingBaseNode::SetCDrawingBase(CDrawingBase *pDrawingBase)
{
	if(m_pDrawingBase != NULL)
	{
		delete m_pDrawingBase;
		m_pDrawingBase = NULL;
	}
	if(pDrawingBase != NULL)
	{
		m_pDrawingBase = pDrawingBase->Clone();
	}
}

CDrawingBase* CCDrawingBaseNode::GetCDrawingBase() const
{
	return m_pDrawingBase;
}

long GetTimeIndex(const CArray <long,long> &lTimeArray,int index)
{
	if(index < lTimeArray.GetSize())
		return lTimeArray.GetAt(index);
	else
		return 0;
}

void CCDrawingBaseNode::ResetDrawingTime(const CArray <long,long> &lTimeArray,int &index)
{
	if(m_pDrawingBase != NULL)
	{
		m_pDrawingBase->SetTime(::GetTimeIndex(lTimeArray,index));
		index++;
	}

	int i;
	for(i=0; i<m_drawingBaseChildArray.GetSize(); i++)
	{
		if(m_drawingBaseChildArray.GetAt(i) != NULL)
		{
			m_drawingBaseChildArray.GetAt(i)->ResetDrawingTime(lTimeArray,index);
		}
	}
}

int CCDrawingBaseNode::GetAllCDrawingBaseNum() const
{
	int iAllCDrawingBaseNum = 0;
	if(m_pDrawingBase != NULL)
	{
		iAllCDrawingBaseNum++;
	}

	int i;
	for(i=0; i<m_drawingBaseChildArray.GetSize(); i++)
	{
		if(m_drawingBaseChildArray.GetAt(i) != NULL)
		{
			iAllCDrawingBaseNum += m_drawingBaseChildArray.GetAt(i)->GetAllCDrawingBaseNum();
		}
	}
	return iAllCDrawingBaseNum;
}

CCDrawingBaseNode* CCDrawingBaseNode::Clone()
{
	CCDrawingBaseNode *pCDrawingBaseNode = new CCDrawingBaseNode(m_pDrawingBase);
	if(pCDrawingBaseNode != NULL)
	{
		int i;
		for(i=0; i<m_drawingBaseChildArray.GetSize(); i++)
		{
			if(m_drawingBaseChildArray.GetAt(i) != NULL)
			{
				pCDrawingBaseNode->m_drawingBaseChildArray.Add(m_drawingBaseChildArray.GetAt(i)->Clone());
			}
		}
	}
	return pCDrawingBaseNode;
}


void CopyCStringArray(CStringArray &csDestArray,const CStringArray &csSourceArray)
{
	csDestArray.RemoveAll();
	int i;
	for(i=0; i<csSourceArray.GetSize(); i++)
	{
		csDestArray.Add(csSourceArray.GetAt(i));
	}
}


IMPLEMENT_COMMAND(CCmdAddNode, CCommand, CMD_ADD_NODE)

CCmdAddNode::CCmdAddNode(HWND hWnd,CCDrawingBaseNode *pCDrawingBaseNode,const CStringArray &csParentTrackingTreeName,const CString &csPrevItemName)
{
	m_hWnd = hWnd;

	m_pCDrawingBaseNode = NULL;
	if(pCDrawingBaseNode != NULL)
	{
		m_pCDrawingBaseNode = pCDrawingBaseNode->Clone();
	}

	::CopyCStringArray(m_csParentTrackingTreeName,csParentTrackingTreeName);
	m_csPrevItemName = csPrevItemName;
}

CCmdAddNode::~CCmdAddNode()
{
	if(m_pCDrawingBaseNode != NULL)
	{
		delete m_pCDrawingBaseNode;
		m_pCDrawingBaseNode = NULL;
	}
}

CCDrawingBaseNode* CCmdAddNode::GetCDrawingBaseNode() const
{
	return m_pCDrawingBaseNode;
}

void CCmdAddNode::GetParentTrackingTreeName(CStringArray &csParentTrackingTreeName) const
{
	int i;
	for(i=0; i<m_csParentTrackingTreeName.GetSize(); i++)
	{
		csParentTrackingTreeName.Add(m_csParentTrackingTreeName.GetAt(i));
	}
}

CString CCmdAddNode::GetPrevItemName() const
{
	return m_csPrevItemName;
}

BOOL CCmdAddNode::Execute()
{
	::SendMessage(m_hWnd,WM_CMD_NODE_CHANGE,(WPARAM)this,NULL);
	return TRUE;
}

CCommand* CCmdAddNode::GetUndoCommand() const
{
	return new CCmdDeleteNode(m_hWnd,m_pCDrawingBaseNode,m_csParentTrackingTreeName,m_csPrevItemName);
}

CCommand* CCmdAddNode::GetRedoCommand() const
{
	return new CCmdAddNode(m_hWnd,m_pCDrawingBaseNode,m_csParentTrackingTreeName,m_csPrevItemName);
}

void CCmdAddNode::Sprint(CString& strLabel) const
{
	if(strLabel.IsEmpty())
	{
		if(m_pCDrawingBaseNode != NULL)
		{
			CDrawingBase *pDrawingBase = m_pCDrawingBaseNode->GetCDrawingBase();
			if(pDrawingBase != NULL)
			{
				CString csName;
				pDrawingBase->GetName(csName);
				strLabel += csName;
			}
		}
	}
	else
	{
		strLabel = _T("");
		if(m_pCDrawingBaseNode != NULL)
		{
			CDrawingBase *pDrawingBase = m_pCDrawingBaseNode->GetCDrawingBase();
			if(pDrawingBase != NULL)
			{
				CString csName;
				pDrawingBase->GetName(csName);
				strLabel = _T("����[")+csName+_T("]�ڵ�");
			}
		}
	}
}


IMPLEMENT_COMMAND(CCmdDeleteNode, CCommand, CMD_DELETE_NODE)

CCmdDeleteNode::CCmdDeleteNode(HWND hWnd,CCDrawingBaseNode *pCDrawingBaseNode,const CStringArray &csParentTrackingTreeName,const CString &csPrevItemName)
{
	m_hWnd = hWnd;

	m_pCDrawingBaseNode = NULL;
	if(pCDrawingBaseNode != NULL)
	{
		m_pCDrawingBaseNode = pCDrawingBaseNode->Clone();
	}

	::CopyCStringArray(m_csParentTrackingTreeName,csParentTrackingTreeName);
	m_csPrevItemName = csPrevItemName;
}

CCmdDeleteNode::~CCmdDeleteNode()
{
	if(m_pCDrawingBaseNode != NULL)
	{
		delete m_pCDrawingBaseNode;
		m_pCDrawingBaseNode = NULL;
	}
}

CCDrawingBaseNode* CCmdDeleteNode::GetCDrawingBaseNode() const
{
	return m_pCDrawingBaseNode;
}

void CCmdDeleteNode::GetParentTrackingTreeName(CStringArray &csParentTrackingTreeName) const
{
	int i;
	for(i=0; i<m_csParentTrackingTreeName.GetSize(); i++)
	{
		csParentTrackingTreeName.Add(m_csParentTrackingTreeName.GetAt(i));
	}
}

CString CCmdDeleteNode::GetPrevItemName() const
{
	return m_csPrevItemName;
}

BOOL CCmdDeleteNode::Execute()
{
	::SendMessage(m_hWnd,WM_CMD_NODE_CHANGE,(WPARAM)this,NULL);
	return TRUE;
}

CCommand* CCmdDeleteNode::GetUndoCommand() const
{
	return new CCmdAddNode(m_hWnd,m_pCDrawingBaseNode,m_csParentTrackingTreeName,m_csPrevItemName);
}

CCommand* CCmdDeleteNode::GetRedoCommand() const
{
	return new CCmdDeleteNode(m_hWnd,m_pCDrawingBaseNode,m_csParentTrackingTreeName,m_csPrevItemName);
}

void CCmdDeleteNode::Sprint(CString& strLabel) const
{
	if(strLabel.IsEmpty())
	{
		if(m_pCDrawingBaseNode != NULL)
		{
			CDrawingBase *pDrawingBase = m_pCDrawingBaseNode->GetCDrawingBase();
			if(pDrawingBase != NULL)
			{
				CString csName;
				pDrawingBase->GetName(csName);
				strLabel += csName;
			}
		}
	}
	else
	{
		strLabel = _T("");
		if(m_pCDrawingBaseNode != NULL)
		{
			CDrawingBase *pDrawingBase = m_pCDrawingBaseNode->GetCDrawingBase();
			if(pDrawingBase != NULL)
			{
				CString csName;
				pDrawingBase->GetName(csName);
				strLabel = _T("ɾ��[")+csName+_T("]�ڵ�");
			}
		}
	}
}



IMPLEMENT_COMMAND(CCmdPropNode, CCommand, CMD_PROP_NODE)

CCmdPropNode::CCmdPropNode(HWND hWnd,EM_UI_PROP_TYPE uiPropType,CDrawingBase *pOldDrawingBase,CDrawingBase *pNewDrawingBase,const CStringArray &csCurrentTrackingTreeName)
{
	m_hWnd = hWnd;

	m_uiPropType = uiPropType;

	m_pOldDrawingBase = NULL;
	if(pOldDrawingBase != NULL)
	{
		m_pOldDrawingBase = pOldDrawingBase->Clone();
	}

	m_pNewDrawingBase = NULL;
	if(pNewDrawingBase != NULL)
	{
		m_pNewDrawingBase = pNewDrawingBase->Clone();
	}

	::CopyCStringArray(m_csCurrentTrackingTreeName,csCurrentTrackingTreeName);
}

CCmdPropNode::~CCmdPropNode()
{
	if(m_pOldDrawingBase != NULL)
	{
		delete m_pOldDrawingBase;
		m_pOldDrawingBase = NULL;
	}
	if(m_pNewDrawingBase != NULL)
	{
		delete m_pNewDrawingBase;
		m_pNewDrawingBase = NULL;
	}
}

EM_UI_PROP_TYPE CCmdPropNode::GetUiPropType() const
{
	return m_uiPropType;
}

CDrawingBase* CCmdPropNode::GetOldDrawingBase() const
{
	return m_pOldDrawingBase;
}

CDrawingBase* CCmdPropNode::GetNewDrawingBase() const
{
	return m_pNewDrawingBase;
}

void CCmdPropNode::GetCurrentTrackingTreeName(CStringArray &csCurrentTrackingTreeName) const
{
	int i;
	for(i=0; i<m_csCurrentTrackingTreeName.GetSize(); i++)
	{
		csCurrentTrackingTreeName.Add(m_csCurrentTrackingTreeName.GetAt(i));
	}
}

BOOL CCmdPropNode::Execute()
{
	::SendMessage(m_hWnd,WM_CMD_NODE_CHANGE,(WPARAM)this,NULL);
	return TRUE;
}

CCommand* CCmdPropNode::GetUndoCommand() const
{
	return new CCmdPropNode(m_hWnd,m_uiPropType,m_pNewDrawingBase,m_pOldDrawingBase,m_csCurrentTrackingTreeName);
}

CCommand* CCmdPropNode::GetRedoCommand() const
{
	return new CCmdPropNode(m_hWnd,m_uiPropType,m_pOldDrawingBase,m_pNewDrawingBase,m_csCurrentTrackingTreeName);
}

void CCmdPropNode::Sprint(CString& strLabel) const
{
	if(strLabel.IsEmpty())
	{
		CString csUIPropTypeName = GetUIPropTypeName(m_uiPropType);
		if(!csUIPropTypeName.IsEmpty())
		{
			if(m_pOldDrawingBase != NULL)
			{
				CString csName;
				m_pOldDrawingBase->GetName(csName);
				strLabel += csName+_T(" - ");
			}
			strLabel += csUIPropTypeName;
		}
	}
	else
	{
		strLabel = _T("");
		CString csUIPropTypeName = GetUIPropTypeName(m_uiPropType);
		if(!csUIPropTypeName.IsEmpty())
		{
			if(m_pOldDrawingBase != NULL)
			{
				CString csName;
				m_pOldDrawingBase->GetName(csName);
				strLabel += _T("�޸�[")+csName+_T("]���� - ");
			}
			strLabel += csUIPropTypeName;
		}
	}
}


IMPLEMENT_COMMAND(CCmdMoveNode, CCommand, CMD_MOVE_NODE)

CCmdMoveNode::CCmdMoveNode(HWND hWnd,CCDrawingBaseNode *pCDrawingBaseNode,const CStringArray &csParentTrackingTreeName,const CString &csPrevItemName,
	const CStringArray &csMoveParentTrackingTreeName,const CString &csMovePrevItemName)
{
	m_hWnd = hWnd;

	m_pCDrawingBaseNode = NULL;
	if(pCDrawingBaseNode != NULL)
	{
		m_pCDrawingBaseNode = pCDrawingBaseNode->Clone();
	}

	::CopyCStringArray(m_csParentTrackingTreeName,csParentTrackingTreeName);
	m_csPrevItemName = csPrevItemName;
	::CopyCStringArray(m_csMoveParentTrackingTreeName,csMoveParentTrackingTreeName);
	m_csMovePrevItemName = csMovePrevItemName;
}

CCmdMoveNode::~CCmdMoveNode()
{
	if(m_pCDrawingBaseNode != NULL)
	{
		delete m_pCDrawingBaseNode;
		m_pCDrawingBaseNode = NULL;
	}
}

CCDrawingBaseNode* CCmdMoveNode::GetCDrawingBaseNode() const
{
	return m_pCDrawingBaseNode;
}

void CCmdMoveNode::GetParentTrackingTreeName(CStringArray &csParentTrackingTreeName) const
{
	int i;
	for(i=0; i<m_csParentTrackingTreeName.GetSize(); i++)
	{
		csParentTrackingTreeName.Add(m_csParentTrackingTreeName.GetAt(i));
	}
}

CString CCmdMoveNode::GetPrevItemName() const
{
	return m_csPrevItemName;
}

void CCmdMoveNode::GetMoveParentTrackingTreeName(CStringArray &csMoveParentTrackingTreeName) const
{
	int i;
	for(i=0; i<m_csMoveParentTrackingTreeName.GetSize(); i++)
	{
		csMoveParentTrackingTreeName.Add(m_csMoveParentTrackingTreeName.GetAt(i));
	}
}

CString CCmdMoveNode::GetMovePrevItemName() const
{
	return m_csMovePrevItemName;
}

BOOL CCmdMoveNode::Execute()
{
	::SendMessage(m_hWnd,WM_CMD_NODE_CHANGE,(WPARAM)this,NULL);
	return TRUE;
}

CCommand* CCmdMoveNode::GetUndoCommand() const
{
	return new CCmdMoveNode(m_hWnd,m_pCDrawingBaseNode,m_csMoveParentTrackingTreeName,m_csMovePrevItemName,m_csParentTrackingTreeName,m_csPrevItemName);
}

CCommand* CCmdMoveNode::GetRedoCommand() const
{
	return new CCmdMoveNode(m_hWnd,m_pCDrawingBaseNode,m_csParentTrackingTreeName,m_csPrevItemName,m_csMoveParentTrackingTreeName,m_csMovePrevItemName);
}

void CCmdMoveNode::Sprint(CString& strLabel) const
{
	if(strLabel.IsEmpty())
	{
		if(m_pCDrawingBaseNode != NULL)
		{
			CDrawingBase *pDrawingBase = m_pCDrawingBaseNode->GetCDrawingBase();
			if(pDrawingBase != NULL)
			{
				CString csName;
				pDrawingBase->GetName(csName);
				strLabel += csName;
			}
		}
	}
	else
	{
		strLabel = _T("");
		if(m_pCDrawingBaseNode != NULL)
		{
			CDrawingBase *pDrawingBase = m_pCDrawingBaseNode->GetCDrawingBase();
			if(pDrawingBase != NULL)
			{
				CString csName;
				pDrawingBase->GetName(csName);
				strLabel = _T("�ƶ�[")+csName+_T("]�ڵ�");
			}
		}
	}
}


bool GetProp(xmlNodePtr pCurrentNode,const char* tag,CString &value)
{
	if(xmlHasProp(pCurrentNode ,(xmlChar*)tag))
	{
		xmlChar* strAttr = xmlGetProp(pCurrentNode, (xmlChar*)tag);
		value = strAttr;
		if(0 != strAttr )
		{
			xmlFree(strAttr);
			return true;
		}
	}
	return false;
}

bool GetProp(xmlNodePtr pCurrentNode,const char* tag,bool &value)
{
	CString csValue;
	if(!GetProp(pCurrentNode,tag,csValue))
		return false;

	value = (csValue == _T("true"))? true : false;
	return true;
}

bool GetProp(xmlNodePtr pCurrentNode,const char* tag,int &value)
{
	CString csValue;
	if(!GetProp(pCurrentNode,tag,csValue))
		return false;

	value = ::CStringToInt(csValue);
	return true;
}

bool GetProp(xmlNodePtr pCurrentNode,const char* tag,long &value)
{
	CString csValue;
	if(!GetProp(pCurrentNode,tag,csValue))
		return false;

	value = ::CStringToLong(csValue);
	return true;
}

bool GetProp(xmlNodePtr pCurrentNode,const char* tag,float &value)
{
	CString csValue;
	if(!GetProp(pCurrentNode,tag,csValue))
		return false;

	value = ::CStringToFloat(csValue);
	return true;
}

char* GetProp (xmlNodePtr pCurrentNode,const char* tag)
{
	if(xmlHasProp(pCurrentNode ,(xmlChar*)tag))
	{
		xmlChar* strAttr = xmlGetProp(pCurrentNode, (xmlChar*)tag);
		if ( 0 != strAttr )
		{
			int len = strlen((const char*)strAttr);
			char* ret = new char[len+1];
			ret[len] = '\0';
			strcpy(ret,(const char*)strAttr);
			xmlFree(strAttr);
			return ret;
		}
	}
	return 0;
}

char * ConvertEx( const char *encFrom, const char *encTo, const char * in)
{
	static char bufout[10240];
	const char* sin;
	char* sout;
	int lenin, lenout, ret;
	iconv_t c_pt;
	if ((c_pt = iconv_open(encTo, encFrom)) == (iconv_t)-1)
	{
		CString strMsg;
		strMsg.Format(_T("iconv_open false: %s ==> %s\n"), encFrom, encTo);
		return NULL;
	}
	iconv(c_pt, NULL, NULL, NULL, NULL);
	lenin = strlen(in) + 1;
	lenout = 10240;
	sin   = (const char *)in;
	sout   = (char*)bufout;
	ret = iconv(c_pt, &sin, (size_t *)&lenin, &sout, (size_t *)&lenout);

	if (ret == -1)
	{
		iconv_close(c_pt);
		CString strMsg;
		strMsg.Format(_T("iconv false: %s ==> %s\n"), encFrom, encTo);
		return NULL;
	}
	iconv_close(c_pt);
	return bufout;
}

void nest_load_xml(CCDrawingBaseNode *pCDrawingBaseNode,xmlNodePtr pXmlNode,int& iParseError )
{
	if ( 0 == pXmlNode || 1 == iParseError)
		return;

	if(pCDrawingBaseNode == NULL)
		return;

	do
	{
		//��ǰ�ڵ�
		CString csType;
		if(!GetProp(pXmlNode,TAG_Type,csType))
		{
//			log_printf(THIS_TAG,"δָ������ %s",strXmlFile);
			iParseError = 1;
			break;
		}
		CString csTypeName;
		if(!GetProp(pXmlNode,TAG_TypeName,csTypeName))
		{
//			log_printf(THIS_TAG,"δָ������ %s",strXmlFile);
			iParseError = 1;
			break;
		}
		EM_DRAWING_TYPE type = ::GetDrawingType(csTypeName);

		long time;
		if (!GetProp(pXmlNode,TAG_CreateTime,time))
		{
//			log_printf(THIS_TAG,"������time %s",strXmlFile);
			iParseError = 1;
			break;
		}
		int x;
		if ( !GetProp(pXmlNode,TAG_XName,x))
		{
//			log_printf(THIS_TAG,"������x����(����x=10) %s",strXmlFile);
			iParseError = 1;
			break;
		}
		int y;
		if ( !GetProp(pXmlNode,TAG_YName,y))
		{
//			log_printf(THIS_TAG,"������y����(����y=5) %s",strXmlFile);
			iParseError = 1;
			break;
		}
		int width = 0;
		GetProp(pXmlNode,TAG_WidthName,width );
		if (width < 0 )
		{
			width = 0;
		}
		int height = 0;
		GetProp(pXmlNode,TAG_HeightName,height );
		if ( height < 0 )
		{
			height = 0;
		}

		int topLeftX = 0;
		int topLeftY = 0;
		int bottomRightX = 0;
		int bottomRightY = 0;
		GetProp(pXmlNode,TAG_TopLeftX,topLeftX );
		GetProp(pXmlNode,TAG_TopLeftY,topLeftY );
		GetProp(pXmlNode,TAG_BottomRightX,bottomRightX );
		GetProp(pXmlNode,TAG_BottomRightY,bottomRightY );

		bool bVisible;
		bool bAdaptiveWidth;
		bool bAdaptiveHeight;
		GetProp(pXmlNode,TAG_VisibleName,bVisible );
		GetProp(pXmlNode,TAG_AdaptiveWidthName,bAdaptiveWidth );
		GetProp(pXmlNode,TAG_AdaptiveHeightName,bAdaptiveHeight );
		int iNodeAlign = TextkAlignTopLeft;
		GetProp(pXmlNode,TAG_NodeAlign,iNodeAlign );

		CDrawingBase *pDrawingBase = ::NewCDrawingBase(type);
		if(pDrawingBase != NULL)
		{
			pDrawingBase->SetName(CString((const char*)pXmlNode->name));
			pDrawingBase->SetTime(time);
			pDrawingBase->SetPos(x,y);
			pDrawingBase->SetSize(width,height);
			pDrawingBase->SetFillRegion(topLeftX,topLeftY,bottomRightX,bottomRightY);
			pDrawingBase->SetVisible(bVisible);
			pDrawingBase->SetFillParent(bAdaptiveWidth,bAdaptiveHeight);
			pDrawingBase->SetAlign(iNodeAlign);

			switch(pDrawingBase->GetDrawingType())
			{
			case DRAWING_TYPE_Base:
				break;
			case DRAWING_TYPE_ImageBase:
				break;
			case DRAWING_TYPE_Empty:
				break;
			case DRAWING_TYPE_Node:
				break;
			case DRAWING_TYPE_Image:
				{
					CString csFileName;
					GetProp(pXmlNode,TAG_FileName,csFileName);
					//packFile
					CString csPickFile;
					GetProp(pXmlNode,TAG_LuaName,csPickFile);
					//grid
					int leftWidth = 0;
					int rightWidth = 0;
					int topWidth = 0;
					int bottomWidth = 0;
					GetProp(pXmlNode,TAG_9GridLeft,leftWidth );
					GetProp(pXmlNode,TAG_9GridRight,rightWidth );
					GetProp(pXmlNode,TAG_9GridTop,topWidth );
					GetProp(pXmlNode,TAG_9GridBottom,bottomWidth );
					if ( leftWidth < 0 )
						leftWidth = 0;
					if ( rightWidth < 0 )
						rightWidth = 0;
					if ( topWidth < 0 )
						topWidth = 0;
					if ( bottomWidth < 0 )
						bottomWidth = 0;

					CDrawingImage *pDrawingImage = CDrawingImage::CDrawingBaseToCDrawingImage(pDrawingBase);
					if(pDrawingImage != NULL)
					{
						pDrawingImage->SetFile(csFileName);
						pDrawingImage->SetPackFile(csPickFile);
						pDrawingImage->SetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);
					}
				}
				break;
			case DRAWING_TYPE_Images:
				break;
			case DRAWING_TYPE_Button:
			case DRAWING_TYPE_CheckBox:
			case DRAWING_TYPE_RadioButton:
				{
					CString csFileName;
					CString csFile2Name;
					GetProp(pXmlNode,TAG_FileName,csFileName);
					GetProp(pXmlNode,TAG_File2Name,csFile2Name);
					//packFile
					CString csPickFile;
					GetProp(pXmlNode,TAG_LuaName,csPickFile);
					//grid
					int leftWidth = 0;
					int rightWidth = 0;
					int topWidth = 0;
					int bottomWidth = 0;
					GetProp(pXmlNode,TAG_9GridLeft,leftWidth );
					GetProp(pXmlNode,TAG_9GridRight,rightWidth );
					GetProp(pXmlNode,TAG_9GridTop,topWidth );
					GetProp(pXmlNode,TAG_9GridBottom,bottomWidth );
					if ( leftWidth < 0 )
						leftWidth = 0;
					if ( rightWidth < 0 )
						rightWidth = 0;
					if ( topWidth < 0 )
						topWidth = 0;
					if ( bottomWidth < 0 )
						bottomWidth = 0;

					CDrawingButton *pDrawingButton = CDrawingButton::CDrawingBaseToCDrawingButton(pDrawingBase);
					if(pDrawingButton != NULL)
					{
						pDrawingButton->SetFile(csFileName);
						pDrawingButton->SetFile2(csFile2Name);
						pDrawingButton->SetPackFile(csPickFile);
						pDrawingButton->SetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);
					}
				}
				break;
			case DRAWING_TYPE_GroupNode:
				break;
			case DRAWING_TYPE_GroupItem:
				break;
			case DRAWING_TYPE_CheckBoxGroup:
				break;
			case DRAWING_TYPE_RadioButtonGroup:
				break;
			case DRAWING_TYPE_Text:
			case DRAWING_TYPE_TextView:
			case DRAWING_TYPE_EditTextView:
			case DRAWING_TYPE_EditText:
				{
					//string data
					CStringW csStr;
//					GetProp(pXmlNode,TAG_StringDataName,csStr);
					char *strVal = GetProp(pXmlNode,TAG_StringDataName);
					if ( 0 == strVal )
					{
//						log_printf(THIS_TAG,"�ַ���Ϊ�� %s",strXmlFile);
						iParseError = 1;
						break;
					}
//					char* strc = ConvertEx("UTF-8",theApp.m_Config.m_encode.c_str(),strVal);
//					csStr = 0==strc ? _T("error") : CString(strc);
					csStr = CWCharArr(::UTF8ToUnicode(strVal));
					if(strVal != NULL)
					{
						delete strVal;
						strVal = NULL;
					}

					CStringW csFontName;
					char *strFontName = GetProp(pXmlNode,TAG_FontName);
					if(strFontName != NULL)
					{
						csFontName = CWCharArr(::UTF8ToUnicode(strFontName));
					}
					if(strFontName != NULL)
					{
						delete strFontName;
						strFontName = NULL;
					}
					// font size
					int iFontSize = 0;
					GetProp(pXmlNode,TAG_FontSize,iFontSize );
					// align
					int iTextAlign;
					GetProp(pXmlNode,TAG_TextAlign,iTextAlign );
					// color
					CString csColor;
					COLORREF color = 0;
					GetProp(pXmlNode,TAG_Color,csColor);
					if (!csColor.IsEmpty())
					{
						string strColor = string(CCharArr(csColor));
						int pos = strColor.find("0x");
						if ( 0 == pos )
						{
							strColor = strColor.substr(2);
							color = convertFromHex(string(CCharArr(csColor)));
						}
					}

					if(type == DRAWING_TYPE_Text || type == DRAWING_TYPE_EditText)
					{
						CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(pDrawingBase);
						if(pDrawingText != NULL)
						{
							pDrawingText->SetStr(csStr);
							pDrawingText->SetFontName(csFontName);
							pDrawingText->SetFontSize(iFontSize);
							pDrawingText->SetTextAlign(iTextAlign);
							pDrawingText->SetColor(color);
						}
					}
					else if(type == DRAWING_TYPE_TextView || type == DRAWING_TYPE_EditTextView)
					{
						CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(pDrawingBase);
						if(pDrawingTextView != NULL)
						{
							pDrawingTextView->SetStr(csStr);
							pDrawingTextView->SetFontName(csFontName);
							pDrawingTextView->SetFontSize(iFontSize);
							pDrawingTextView->SetTextAlign(iTextAlign);
							pDrawingTextView->SetColor(color);
						}
					}
				}
				break;
			case DRAWING_TYPE_ScrollableNode:
				break;
			case DRAWING_TYPE_ScrollBar:
				break;
			case DRAWING_TYPE_TabView:
				break;
			case DRAWING_TYPE_TableView:
				break;
			case DRAWING_TYPE_GridView:
				break;
			case DRAWING_TYPE_ViewPager:
				break;
			case DRAWING_TYPE_ListView:
				break;
			case DRAWING_TYPE_ScrollView:
				break;
			case DRAWING_TYPE_Slider:
				break;
			case DRAWING_TYPE_Switch:
				break;
			case DRAWING_TYPE_DrawingCustom:
				break;
			case DRAWING_TYPE_CustomNode:
				break;
			case DRAWING_TYPE_CustomControl:
				{
					CDrawingCustomControl *pDrawingCustomControl = CDrawingCustomControl::CDrawingBaseToCDrawingCustomControl(pDrawingBase);
					if(pDrawingCustomControl != NULL)
					{
						xmlChar* szCustomName = xmlGetProp(pXmlNode,BAD_CAST TAG_CustomName);
						pDrawingCustomControl->SetCustomName(CString(szCustomName));

						xmlChar* szCustomNum = xmlGetProp(pXmlNode,BAD_CAST TAG_CustomNum);
						int iCustomNum = ::CStringToInt(CString(szCustomNum));

						CArray <CCustomData,CCustomData> customDataArray;
						int j;
						for(j=0; j<iCustomNum && j<CUSTOM_PAR_NUM; j++)
						{
							CString csCustomProp = TAG_CustomProp + ::IntToCString(j+1);
							CString csCustomType = TAG_CustomType + ::IntToCString(j+1);
							CString csCustomData = TAG_CustomData + ::IntToCString(j+1);

							xmlChar* szPropName = xmlGetProp(pXmlNode,BAD_CAST (char*)CCharArr(csCustomProp));
							xmlChar* szDataType = xmlGetProp(pXmlNode,BAD_CAST (char*)CCharArr(csCustomType));
							xmlChar* szData = xmlGetProp(pXmlNode,BAD_CAST (char*)CCharArr(csCustomData));
							customDataArray.Add(CCustomData(CString(szPropName),::GetCustomDataType(CString(szDataType)),CString(szData)));
						}
						pDrawingCustomControl->SetCustomData(customDataArray);
					}
				}
				break;
			default:
				break;
			};
		}

		if(pDrawingBase != NULL)
		{
			pCDrawingBaseNode->SetCDrawingBase(pDrawingBase);

			xmlNodePtr pChildXmlNode;
			pChildXmlNode = pXmlNode->xmlChildrenNode;
			while ( 0 != pChildXmlNode && 1 != iParseError )
			{
				CCDrawingBaseNode *pChildCDrawingBaseNode = pCDrawingBaseNode->AddCDrawingBaseNode(NULL);
				nest_load_xml(pChildCDrawingBaseNode,pChildXmlNode,iParseError);
				pChildXmlNode = pChildXmlNode->next;
			}

			delete pDrawingBase;
			pDrawingBase = NULL;
		}
	} while(0);
}

int load_xml(const char *strXmlFile,CCDrawingBaseNode **ppCDrawingBaseNode )
{	
	if (0 == strXmlFile || '\0' == strXmlFile[0])
		return -1;

	int iParseError=0;
	xmlDocPtr pDoc = 0;
	xmlNodePtr pRoot=0;
	// ��һ��:����xml,���ɱ�Ҫ�����Ƶ�,��������id���ɵ�

	xmlKeepBlanksDefault(0);
	pDoc = xmlReadFile(strXmlFile ,"UTF-8",XML_PARSE_RECOVER);
	if( 0 == pDoc )
	{
		return -1;
	}
	pRoot = xmlDocGetRootElement(pDoc);

	if( 0 != pRoot )
	{
		if(ppCDrawingBaseNode != NULL)
		{
			*ppCDrawingBaseNode = new CCDrawingBaseNode(NULL);
			nest_load_xml(*ppCDrawingBaseNode,pRoot,iParseError);
		}
	}
	xmlFreeDoc(pDoc);
	xmlCleanupParser();
	if ( 1 == iParseError )
	{
		return -1;
	}

	return 1;
}

int nest_save_xml (CCDrawingBaseNode *pCDrawingBaseNode,xmlDocPtr xmlDoc,xmlNodePtr pXmlParent)
{
	if(pCDrawingBaseNode == NULL)
		return -1;

	CDrawingBase *pDrawingBase = pCDrawingBaseNode->GetCDrawingBase();
	if(pDrawingBase == NULL)
		return -1;

	EM_DRAWING_TYPE type = pDrawingBase->GetDrawingType();
	CString csName;
	long time;
	int x = 0;
	int y = 0;
	int width = 0;
	int height = 0;
	int topLeftX = 0;
	int topLeftY = 0;
	int bottomRightX = 0;
	int bottomRightY = 0;
	bool bVisible = true;
	bool bAdaptiveWidth = false;
	bool bAdaptiveHeight = false;
	int iNodeAlign = TextkAlignTopLeft;
	pDrawingBase->GetName(csName);
	time = pDrawingBase->GetTime();
	pDrawingBase->GetPos(x,y);
	pDrawingBase->GetSize(width,height);
	pDrawingBase->GetFillRegion(topLeftX,topLeftY,bottomRightX,bottomRightY);
	pDrawingBase->GetVisible(bVisible);
	pDrawingBase->GetFillParent(bAdaptiveWidth,bAdaptiveHeight);
	pDrawingBase->GetAlign(iNodeAlign);

	xmlNodePtr pXmlNode;
	if ( 0 == pXmlParent )
	{
		pXmlParent = xmlNewDocNode(xmlDoc, NULL, BAD_CAST (char*)CCharArr(csName), NULL);
		if ( 0 == pXmlParent)
		{
			xmlFreeDoc(xmlDoc);
			xmlDoc = 0;
			return -1;
		}
		xmlDocSetRootElement(xmlDoc, pXmlParent);
		pXmlNode = pXmlParent;
	}
	else
	{
		pXmlNode = xmlNewNode(NULL, BAD_CAST (char*)CCharArr(csName));
		xmlAddChild(pXmlParent, pXmlNode);
	}

	char buf[32];
	xmlNewProp(pXmlNode, BAD_CAST TAG_Type, BAD_CAST (char*)CCharArr(pDrawingBase->GetOldType()));
	xmlNewProp(pXmlNode, BAD_CAST TAG_TypeName, BAD_CAST (char*)CCharArr(pDrawingBase->GetDrawingTypeName()));

	sprintf(buf,"%ld",time );
	xmlNewProp(pXmlNode, BAD_CAST TAG_CreateTime, BAD_CAST buf);

	sprintf(buf,"%d",x );
	xmlNewProp(pXmlNode, BAD_CAST TAG_XName, BAD_CAST buf);

	sprintf(buf,"%d",y );
	xmlNewProp(pXmlNode, BAD_CAST TAG_YName, BAD_CAST buf);

	sprintf(buf,"%d",width );
	xmlNewProp(pXmlNode, BAD_CAST TAG_WidthName, BAD_CAST buf);

	sprintf(buf,"%d",height );
	xmlNewProp(pXmlNode, BAD_CAST TAG_HeightName, BAD_CAST buf);


	if(topLeftX > 0 || topLeftY > 0 || bottomRightX > 0 || bottomRightY > 0)
	{
		sprintf(buf,"%d",topLeftX );
		xmlNewProp(pXmlNode, BAD_CAST TAG_TopLeftX, BAD_CAST buf);

		sprintf(buf,"%d",topLeftY );
		xmlNewProp(pXmlNode, BAD_CAST TAG_TopLeftY, BAD_CAST buf);

		sprintf(buf,"%d",bottomRightX );
		xmlNewProp(pXmlNode, BAD_CAST TAG_BottomRightX, BAD_CAST buf);

		sprintf(buf,"%d",bottomRightY );
		xmlNewProp(pXmlNode, BAD_CAST TAG_BottomRightY, BAD_CAST buf);
	}



	sprintf(buf,"%s",bVisible?"true":"false" );
	xmlNewProp(pXmlNode, BAD_CAST TAG_VisibleName, BAD_CAST buf);

	sprintf(buf,"%s",bAdaptiveWidth?"true":"false" );
	xmlNewProp(pXmlNode, BAD_CAST TAG_AdaptiveWidthName, BAD_CAST buf);

	sprintf(buf,"%s",bAdaptiveHeight?"true":"false" );
	xmlNewProp(pXmlNode, BAD_CAST TAG_AdaptiveHeightName, BAD_CAST buf);

	sprintf(buf,"%d",iNodeAlign);
	xmlNewProp(pXmlNode, BAD_CAST TAG_NodeAlign, BAD_CAST buf);
	
	switch(type)
	{
	case DRAWING_TYPE_Base:
		break;
	case DRAWING_TYPE_ImageBase:
		break;
	case DRAWING_TYPE_Empty:
		break;
	case DRAWING_TYPE_Node:
		break;
	case DRAWING_TYPE_Image:
		{
			CDrawingImage *pDrawingImage = CDrawingImage::CDrawingBaseToCDrawingImage(pDrawingBase);
			if(pDrawingImage != NULL)
			{
				CString csFileName;
				pDrawingImage->GetFile(csFileName);
				CString csPickFile;
				pDrawingImage->GetPackFile(csPickFile);
				int leftWidth = 0;
				int rightWidth = 0;
				int topWidth = 0;
				int bottomWidth = 0;
				pDrawingImage->GetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);

				xmlNewProp(pXmlNode, BAD_CAST TAG_FileName, BAD_CAST (char*)CCharArr(csFileName));
				xmlNewProp(pXmlNode, BAD_CAST TAG_LuaName, BAD_CAST (char*)CCharArr(csPickFile));

				sprintf(buf,"%d",leftWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridLeft, BAD_CAST buf);

				sprintf(buf,"%d",rightWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridRight, BAD_CAST buf);

				sprintf(buf,"%d",topWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridTop, BAD_CAST buf);

				sprintf(buf,"%d",bottomWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridBottom, BAD_CAST buf);
			}
		}
		break;
	case DRAWING_TYPE_Images:
		break;
	case DRAWING_TYPE_Button:
	case DRAWING_TYPE_CheckBox:
	case DRAWING_TYPE_RadioButton:
		{
			CDrawingButton *pDrawingButton = CDrawingButton::CDrawingBaseToCDrawingButton(pDrawingBase);
			if(pDrawingButton != NULL)
			{
				CString csFileName;
				CString csFile2Name;
				pDrawingButton->GetFile(csFileName);
				pDrawingButton->GetFile2(csFile2Name);
				CString csPickFile;
				pDrawingButton->GetPackFile(csPickFile);
				int leftWidth = 0;
				int rightWidth = 0;
				int topWidth = 0;
				int bottomWidth = 0;
				pDrawingButton->GetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);

				xmlNewProp(pXmlNode, BAD_CAST TAG_FileName, BAD_CAST (char*)CCharArr(csFileName));
				xmlNewProp(pXmlNode, BAD_CAST TAG_File2Name, BAD_CAST (char*)CCharArr(csFile2Name));
				xmlNewProp(pXmlNode, BAD_CAST TAG_LuaName, BAD_CAST (char*)CCharArr(csPickFile));

				sprintf(buf,"%d",leftWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridLeft, BAD_CAST buf);

				sprintf(buf,"%d",rightWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridRight, BAD_CAST buf);

				sprintf(buf,"%d",topWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridTop, BAD_CAST buf);

				sprintf(buf,"%d",bottomWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridBottom, BAD_CAST buf);
			}
		}
		break;
	case DRAWING_TYPE_GroupNode:
		break;
	case DRAWING_TYPE_GroupItem:
		break;
	case DRAWING_TYPE_CheckBoxGroup:
		break;
	case DRAWING_TYPE_RadioButtonGroup:
		break;
	case DRAWING_TYPE_Text:
	case DRAWING_TYPE_TextView:
	case DRAWING_TYPE_EditTextView:
	case DRAWING_TYPE_EditText:
		{
			CStringW csStr;
			CStringW csFontName;
			int iFontSize = 0;
			int iTextAlign;
			COLORREF color = 0;
			if(type == DRAWING_TYPE_Text || type == DRAWING_TYPE_EditText)
			{
				CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(pDrawingBase);
				if(pDrawingText != NULL)
				{
					pDrawingText->GetStr(csStr);
					pDrawingText->GetFontName(csFontName);
					pDrawingText->GetFontSize(iFontSize);
					pDrawingText->GetTextAlign(iTextAlign);
					pDrawingText->GetColor(color);
				}
			}
			else if(type == DRAWING_TYPE_TextView || type == DRAWING_TYPE_EditTextView)
			{
				CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(pDrawingBase);
				if(pDrawingTextView != NULL)
				{
					pDrawingTextView->GetStr(csStr);
					pDrawingTextView->GetFontName(csStr);
					pDrawingTextView->GetFontSize(iFontSize);
					pDrawingTextView->GetTextAlign(iTextAlign);
					pDrawingTextView->GetColor(color);
				}
			}

			xmlNewProp(pXmlNode, BAD_CAST TAG_FontName, BAD_CAST (char*)::UnicodeToUTF8(CWCharArr(csFontName)));
			sprintf(buf,"%d",iFontSize);
			xmlNewProp(pXmlNode, BAD_CAST TAG_FontSize, BAD_CAST buf);
			sprintf(buf,"%d",iTextAlign);
			xmlNewProp(pXmlNode, BAD_CAST TAG_TextAlign, BAD_CAST buf);
			sprintf(buf,"0x%06X",color);
			xmlNewProp(pXmlNode, BAD_CAST TAG_Color, BAD_CAST buf);
//			char* strc = ConvertEx(theApp.m_Config.m_encode.c_str(),"UTF-8",CCharArr(csStr));
//			xmlNewProp(pXmlNode, BAD_CAST TAG_StringDataName, BAD_CAST (0==strc?"error":strc));
			CCharArr charArr = ::UnicodeToUTF8(CWCharArr(csStr));
			xmlNewProp(pXmlNode, BAD_CAST TAG_StringDataName, BAD_CAST (char*)charArr);
		}
		break;
	case DRAWING_TYPE_ScrollableNode:
		break;
	case DRAWING_TYPE_ScrollBar:
		break;
	case DRAWING_TYPE_TabView:
		break;
	case DRAWING_TYPE_TableView:
		break;
	case DRAWING_TYPE_GridView:
		break;
	case DRAWING_TYPE_ViewPager:
		break;
	case DRAWING_TYPE_ListView:
		break;
	case DRAWING_TYPE_ScrollView:
		break;
	case DRAWING_TYPE_Slider:
		break;
	case DRAWING_TYPE_Switch:
		break;
	case DRAWING_TYPE_DrawingCustom:
		break;
	case DRAWING_TYPE_CustomNode:
		break;
	case DRAWING_TYPE_CustomControl:
		{
			CDrawingCustomControl *pDrawingCustomControl = CDrawingCustomControl::CDrawingBaseToCDrawingCustomControl(pDrawingBase);
			if(pDrawingCustomControl != NULL)
			{
				CArray <CCustomData,CCustomData> customDataArray;
				pDrawingCustomControl->GetCustomData(customDataArray);

				xmlNewProp(pXmlNode,BAD_CAST TAG_CustomName,BAD_CAST (char*)CCharArr(pDrawingCustomControl->GetCustomName()));
				xmlNewProp(pXmlNode,BAD_CAST TAG_CustomNum,BAD_CAST (char*)CCharArr(::IntToCString(customDataArray.GetSize())));

				int j;
				for(j=0; j<customDataArray.GetSize(); j++)
				{
					CString csCustomProp = TAG_CustomProp + ::IntToCString(j+1);
					CString csCustomType = TAG_CustomType + ::IntToCString(j+1);
					CString csCustomData = TAG_CustomData + ::IntToCString(j+1);
					xmlNewProp(pXmlNode,BAD_CAST (char*)CCharArr(csCustomProp),BAD_CAST (char*)CCharArr(customDataArray.GetAt(j).GetCustomPropName()));
					xmlNewProp(pXmlNode,BAD_CAST (char*)CCharArr(csCustomType),BAD_CAST (char*)CCharArr(::GetCustomDataType(customDataArray.GetAt(j).GetCustomDataType())));
					xmlNewProp(pXmlNode,BAD_CAST (char*)CCharArr(csCustomData),BAD_CAST (char*)CCharArr(customDataArray.GetAt(j).GetCustomData()));
				}
			}
		}
		break;
	default:
		break;
	};

	int i;
	for(i=0; i<pCDrawingBaseNode->GetCDrawingBaseNodeChildNum(); i++)
	{
		CCDrawingBaseNode *pChildCDrawingBaseNode = pCDrawingBaseNode->GetCDrawingBaseNode(i);
		if(pChildCDrawingBaseNode != NULL)
		{
			nest_save_xml(pChildCDrawingBaseNode,xmlDoc,pXmlNode);
		}
	}
	return 1;
}
int save_xml ( const char* strXmlFile,CCDrawingBaseNode *pCDrawingBaseNode)
{
	xmlKeepBlanksDefault(0);
	xmlIndentTreeOutput = 1;
	int iRet = -1;
	xmlDocPtr xmlDoc = xmlNewDoc(BAD_CAST XML_DEFAULT_VERSION);
	if ( 0 == xmlDoc)
	{
		return iRet;
	}
	iRet = nest_save_xml(pCDrawingBaseNode,xmlDoc,0);
	if ( iRet > 0 )
	{
		iRet = xmlSaveFormatFileEnc(strXmlFile, xmlDoc, "utf-8", 1);
	}
	xmlFreeDoc(xmlDoc);
	return iRet;
}

CCopyTreeData::CCopyTreeData()
{
	m_pCDrawingBaseNode = NULL;

	m_bLoadData = FALSE;
}

CCopyTreeData::~CCopyTreeData()
{
	CCriticalSectionEx criticalSectionEx(&m_criticalSection);

	if(m_pCDrawingBaseNode != NULL)
	{
		delete m_pCDrawingBaseNode;
		m_pCDrawingBaseNode = NULL;
	}
}

BOOL CCopyTreeData::LoadData(CString csSelDirectoryName,CString csSelFileName,CXTreeCtrl &treeCtrl)
{
	CCriticalSectionEx criticalSectionEx(&m_criticalSection);

	if(m_pCDrawingBaseNode != NULL)
	{
		delete m_pCDrawingBaseNode;
		m_pCDrawingBaseNode = NULL;
	}

	m_csSelDirectoryName = csSelDirectoryName;
	m_csSelFileName = csSelFileName;

	HTREEITEM hRoot = treeCtrl.GetRootItem();
	CDrawingBase *pDrawingBase = (CDrawingBase*)treeCtrl.GetItemData(hRoot);
	m_pCDrawingBaseNode = new CCDrawingBaseNode(pDrawingBase);
	::GetCDrawingBaseNode(treeCtrl,hRoot,m_pCDrawingBaseNode);

	m_bLoadData = TRUE;

	return TRUE;
}

CString CCopyTreeData::GetSelDirecotryName()
{
	CCriticalSectionEx criticalSectionEx(&m_criticalSection);

	return m_csSelDirectoryName;
}

CString CCopyTreeData::GetSelFileName()
{
	CCriticalSectionEx criticalSectionEx(&m_criticalSection);

	return m_csSelFileName;
}

CCDrawingBaseNode* CCopyTreeData::CloneData()
{
	CCriticalSectionEx criticalSectionEx(&m_criticalSection);

	if(m_pCDrawingBaseNode != NULL)
	{
		return m_pCDrawingBaseNode->Clone();
	}

	return NULL;
}

BOOL CCopyTreeData::IsLoadData()
{
	CCriticalSectionEx criticalSectionEx(&m_criticalSection);

	return m_bLoadData;
}

void CCopyTreeData::SaveData()
{
	CCriticalSectionEx criticalSectionEx(&m_criticalSection);

	m_bLoadData = FALSE;
}



void nest_load_xml(CXTreeCtrl& treeCtrl, HTREEITEM hItem ,xmlNodePtr pXmlNode,int& iParseError )
{
	if ( 0 == pXmlNode || 1 == iParseError)
		return;

	do
	{
		//��ǰ�ڵ�
		CString csType;
		if(!GetProp(pXmlNode,TAG_Type,csType))
		{
//			log_printf(THIS_TAG,"δָ������ %s",strXmlFile);
			iParseError = 1;
			break;
		}
		CString csTypeName;
		if(!GetProp(pXmlNode,TAG_TypeName,csTypeName))
		{
//			log_printf(THIS_TAG,"δָ������ %s",strXmlFile);
			iParseError = 1;
			break;
		}
		EM_DRAWING_TYPE type = ::GetDrawingType(csTypeName);

		long time;
		if (!GetProp(pXmlNode,TAG_CreateTime,time))
		{
//			log_printf(THIS_TAG,"������time %s",strXmlFile);
			iParseError = 1;
			break;
		}
		int x;
		if ( !GetProp(pXmlNode,TAG_XName,x))
		{
//			log_printf(THIS_TAG,"������x����(����x=10) %s",strXmlFile);
			iParseError = 1;
			break;
		}
		int y;
		if ( !GetProp(pXmlNode,TAG_YName,y))
		{
//			log_printf(THIS_TAG,"������y����(����y=5) %s",strXmlFile);
			iParseError = 1;
			break;
		}
		int width = 0;
		GetProp(pXmlNode,TAG_WidthName,width );
		if (width < 0 )
		{
			width = 0;
		}
		int height = 0;
		GetProp(pXmlNode,TAG_HeightName,height );
		if ( height < 0 )
		{
			height = 0;
		}

		int topLeftX = 0;
		int topLeftY = 0;
		int bottomRightX = 0;
		int bottomRightY = 0;
		GetProp(pXmlNode,TAG_TopLeftX,topLeftX );
		GetProp(pXmlNode,TAG_TopLeftY,topLeftY );
		GetProp(pXmlNode,TAG_BottomRightX,bottomRightX );
		GetProp(pXmlNode,TAG_BottomRightY,bottomRightY );

		bool bVisible;
		bool bAdaptiveWidth;
		bool bAdaptiveHeight;
		GetProp(pXmlNode,TAG_VisibleName,bVisible );
		GetProp(pXmlNode,TAG_AdaptiveWidthName,bAdaptiveWidth );
		GetProp(pXmlNode,TAG_AdaptiveHeightName,bAdaptiveHeight );
		int iNodeAlign = TextkAlignTopLeft;
		GetProp(pXmlNode,TAG_NodeAlign,iNodeAlign );

		CDrawingBase *pDrawingBase = ::NewCDrawingBase(type);
		if(pDrawingBase != NULL)
		{
			pDrawingBase->SetName(CString((const char*)pXmlNode->name));
			pDrawingBase->SetTime(time);
			pDrawingBase->SetPos(x,y);
			pDrawingBase->SetSize(width,height);
			pDrawingBase->SetFillRegion(topLeftX,topLeftY,bottomRightX,bottomRightY);
			pDrawingBase->SetVisible(bVisible);
			pDrawingBase->SetFillParent(bAdaptiveWidth,bAdaptiveHeight);
			pDrawingBase->SetAlign(iNodeAlign);

			switch(pDrawingBase->GetDrawingType())
			{
			case DRAWING_TYPE_Base:
				break;
			case DRAWING_TYPE_ImageBase:
				break;
			case DRAWING_TYPE_Empty:
				break;
			case DRAWING_TYPE_Node:
				break;
			case DRAWING_TYPE_Image:
				{
					CString csFileName;
					GetProp(pXmlNode,TAG_FileName,csFileName);
					//packFile
					CString csPickFile;
					GetProp(pXmlNode,TAG_LuaName,csPickFile);
					//grid
					int leftWidth = 0;
					int rightWidth = 0;
					int topWidth = 0;
					int bottomWidth = 0;
					GetProp(pXmlNode,TAG_9GridLeft,leftWidth );
					GetProp(pXmlNode,TAG_9GridRight,rightWidth );
					GetProp(pXmlNode,TAG_9GridTop,topWidth );
					GetProp(pXmlNode,TAG_9GridBottom,bottomWidth );
					if ( leftWidth < 0 )
						leftWidth = 0;
					if ( rightWidth < 0 )
						rightWidth = 0;
					if ( topWidth < 0 )
						topWidth = 0;
					if ( bottomWidth < 0 )
						bottomWidth = 0;

					CDrawingImage *pDrawingImage = CDrawingImage::CDrawingBaseToCDrawingImage(pDrawingBase);
					if(pDrawingImage != NULL)
					{
						pDrawingImage->SetFile(csFileName);
						pDrawingImage->SetPackFile(csPickFile);
						pDrawingImage->SetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);
					}
				}
				break;
			case DRAWING_TYPE_Images:
				break;
			case DRAWING_TYPE_Button:
			case DRAWING_TYPE_CheckBox:
			case DRAWING_TYPE_RadioButton:
				{
					CString csFileName;
					CString csFile2Name;
					GetProp(pXmlNode,TAG_FileName,csFileName);
					GetProp(pXmlNode,TAG_File2Name,csFile2Name);
					//packFile
					CString csPickFile;
					GetProp(pXmlNode,TAG_LuaName,csPickFile);
					//grid
					int leftWidth = 0;
					int rightWidth = 0;
					int topWidth = 0;
					int bottomWidth = 0;
					GetProp(pXmlNode,TAG_9GridLeft,leftWidth );
					GetProp(pXmlNode,TAG_9GridRight,rightWidth );
					GetProp(pXmlNode,TAG_9GridTop,topWidth );
					GetProp(pXmlNode,TAG_9GridBottom,bottomWidth );
					if ( leftWidth < 0 )
						leftWidth = 0;
					if ( rightWidth < 0 )
						rightWidth = 0;
					if ( topWidth < 0 )
						topWidth = 0;
					if ( bottomWidth < 0 )
						bottomWidth = 0;

					CDrawingButton *pDrawingButton = CDrawingButton::CDrawingBaseToCDrawingButton(pDrawingBase);
					if(pDrawingButton != NULL)
					{
						pDrawingButton->SetFile(csFileName);
						pDrawingButton->SetFile2(csFile2Name);
						pDrawingButton->SetPackFile(csPickFile);
						pDrawingButton->SetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);
					}
				}
				break;
			case DRAWING_TYPE_GroupNode:
				break;
			case DRAWING_TYPE_GroupItem:
				break;
			case DRAWING_TYPE_CheckBoxGroup:
				break;
			case DRAWING_TYPE_RadioButtonGroup:
				break;
			case DRAWING_TYPE_Text:
			case DRAWING_TYPE_TextView:
			case DRAWING_TYPE_EditTextView:
			case DRAWING_TYPE_EditText:
				{
					//string data
					CStringW csStr;
//					GetProp(pXmlNode,TAG_StringDataName,csStr);
					char *strVal = GetProp(pXmlNode,TAG_StringDataName);
					if ( 0 == strVal )
					{
//						log_printf(THIS_TAG,"�ַ���Ϊ�� %s",strXmlFile);
						iParseError = 1;
						break;
					}
//					char* strc = ConvertEx("UTF-8",theApp.m_Config.m_encode.c_str(),strVal);
//					csStr = 0==strc ? _T("error") : CString(strc);
					csStr = CWCharArr(::UTF8ToUnicode(strVal));
					if(strVal != NULL)
					{
						delete strVal;
						strVal = NULL;
					}

					CStringW csFontName;
					char *strFontName = GetProp(pXmlNode,TAG_FontName);
					if(strFontName != NULL)
					{
						csFontName = CWCharArr(::UTF8ToUnicode(strFontName));
					}
					if(strFontName != NULL)
					{
						delete strFontName;
						strFontName = NULL;
					}
					// font size
					int iFontSize = 0;
					GetProp(pXmlNode,TAG_FontSize,iFontSize );
					// align
					int iTextAlign;
					GetProp(pXmlNode,TAG_TextAlign,iTextAlign );
					// color
					CString csColor;
					COLORREF color = 0;
					GetProp(pXmlNode,TAG_Color,csColor);
					if (!csColor.IsEmpty())
					{
						string strColor = string(CCharArr(csColor));
						int pos = strColor.find("0x");
						if ( 0 == pos )
						{
							strColor = strColor.substr(2);
							color = convertFromHex(string(CCharArr(csColor)));
						}
					}

					if(type == DRAWING_TYPE_Text || type == DRAWING_TYPE_EditText)
					{
						CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(pDrawingBase);
						if(pDrawingText != NULL)
						{
							pDrawingText->SetStr(csStr);
							pDrawingText->SetFontName(csFontName);
							pDrawingText->SetFontSize(iFontSize);
							pDrawingText->SetTextAlign(iTextAlign);
							pDrawingText->SetColor(color);
						}
					}
					else if(type == DRAWING_TYPE_TextView || type == DRAWING_TYPE_EditTextView)
					{
						CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(pDrawingBase);
						if(pDrawingTextView != NULL)
						{
							pDrawingTextView->SetStr(csStr);
							pDrawingTextView->SetFontName(csFontName);
							pDrawingTextView->SetFontSize(iFontSize);
							pDrawingTextView->SetTextAlign(iTextAlign);
							pDrawingTextView->SetColor(color);
						}
					}
				}
				break;
			case DRAWING_TYPE_ScrollableNode:
				break;
			case DRAWING_TYPE_ScrollBar:
				break;
			case DRAWING_TYPE_TabView:
				break;
			case DRAWING_TYPE_TableView:
				break;
			case DRAWING_TYPE_GridView:
				break;
			case DRAWING_TYPE_ViewPager:
				break;
			case DRAWING_TYPE_ListView:
				break;
			case DRAWING_TYPE_ScrollView:
				break;
			case DRAWING_TYPE_Slider:
				break;
			case DRAWING_TYPE_Switch:
				break;
			case DRAWING_TYPE_DrawingCustom:
				break;
			case DRAWING_TYPE_CustomNode:
				break;
			case DRAWING_TYPE_CustomControl:
				{
					CDrawingCustomControl *pDrawingCustomControl = CDrawingCustomControl::CDrawingBaseToCDrawingCustomControl(pDrawingBase);
					if(pDrawingCustomControl != NULL)
					{
						xmlChar* szCustomName = xmlGetProp(pXmlNode,BAD_CAST TAG_CustomName);
						pDrawingCustomControl->SetCustomName(CString(szCustomName));

						xmlChar* szCustomNum = xmlGetProp(pXmlNode,BAD_CAST TAG_CustomNum);
						int iCustomNum = ::CStringToInt(CString(szCustomNum));

						CArray <CCustomData,CCustomData> customDataArray;
						int j;
						for(j=0; j<iCustomNum && j<CUSTOM_PAR_NUM; j++)
						{
							CString csCustomProp = TAG_CustomProp + ::IntToCString(j+1);
							CString csCustomType = TAG_CustomType + ::IntToCString(j+1);
							CString csCustomData = TAG_CustomData + ::IntToCString(j+1);

							xmlChar* szPropName = xmlGetProp(pXmlNode,BAD_CAST (char*)CCharArr(csCustomProp));
							xmlChar* szDataType = xmlGetProp(pXmlNode,BAD_CAST (char*)CCharArr(csCustomType));
							xmlChar* szData = xmlGetProp(pXmlNode,BAD_CAST (char*)CCharArr(csCustomData));
							customDataArray.Add(CCustomData(CString(szPropName),::GetCustomDataType(CString(szDataType)),CString(szData)));
						}
						pDrawingCustomControl->SetCustomData(customDataArray);
					}
				}
				break;
			default:
				break;
			};
		}

		if(pDrawingBase != NULL)
		{
			int iImageId = ::GetImageId(pDrawingBase);
			CString csName;
			pDrawingBase->GetName(csName);
			HTREEITEM hChildItem = treeCtrl.InsertItem(csName, iImageId,iImageId,hItem);
			treeCtrl.SetItemData(hChildItem,(DWORD_PTR)pDrawingBase);

			xmlNodePtr pChildXmlNode;
			pChildXmlNode = pXmlNode->xmlChildrenNode;
			while ( 0 != pChildXmlNode && 1 != iParseError )
			{
				nest_load_xml(treeCtrl,hChildItem,pChildXmlNode,iParseError);
				pChildXmlNode = pChildXmlNode->next;
			}
		}
	} while(0);
}

int load_xml(const char *strXmlFile,CXTreeCtrl& treeCtrl,HTREEITEM hRoot )
{	
	if (0 == strXmlFile || '\0' == strXmlFile[0])
		return -1;

	int iParseError=0;
	xmlDocPtr pDoc = 0;
	xmlNodePtr pRoot=0;
	// ��һ��:����xml,���ɱ�Ҫ�����Ƶ�,��������id���ɵ�

	xmlKeepBlanksDefault(0);
	pDoc = xmlReadFile(strXmlFile ,"UTF-8",XML_PARSE_RECOVER);
	if( 0 == pDoc )
	{
		return -1;
	}
	pRoot = xmlDocGetRootElement(pDoc);

	if( 0 != pRoot )
	{
		nest_load_xml(treeCtrl,hRoot,pRoot,iParseError);
	}
	xmlFreeDoc(pDoc);
	xmlCleanupParser();
	if ( 1 == iParseError )
	{
		return -1;
	}

	return 1;
}


int nest_save_xml ( CXTreeCtrl& treeCtrl,HTREEITEM hItem,xmlDocPtr xmlDoc,xmlNodePtr pXmlParent)
{
	CDrawingBase *pDrawingBase = (CDrawingBase*)treeCtrl.GetItemData(hItem);
	if(pDrawingBase == NULL)
		return -1;

	EM_DRAWING_TYPE type = pDrawingBase->GetDrawingType();
	CString csName;
	long time;
	int x = 0;
	int y = 0;
	int width = 0;
	int height = 0;
	int topLeftX = 0;
	int topLeftY = 0;
	int bottomRightX = 0;
	int bottomRightY = 0;
	bool bVisible = true;
	bool bAdaptiveWidth = false;
	bool bAdaptiveHeight = false;
	int iNodeAlign = TextkAlignTopLeft;
	pDrawingBase->GetName(csName);
	time = pDrawingBase->GetTime();
	pDrawingBase->GetPos(x,y);
	pDrawingBase->GetSize(width,height);
	pDrawingBase->GetFillRegion(topLeftX,topLeftY,bottomRightX,bottomRightY);
	pDrawingBase->GetVisible(bVisible);
	pDrawingBase->GetFillParent(bAdaptiveWidth,bAdaptiveHeight);
	pDrawingBase->GetAlign(iNodeAlign);

	xmlNodePtr pXmlNode;
	if ( 0 == pXmlParent )
	{
		pXmlParent = xmlNewDocNode(xmlDoc, NULL, BAD_CAST (char*)CCharArr(csName), NULL);
		if ( 0 == pXmlParent)
		{
			xmlFreeDoc(xmlDoc);
			xmlDoc = 0;
			return -1;
		}
		xmlDocSetRootElement(xmlDoc, pXmlParent);
		pXmlNode = pXmlParent;
	}
	else
	{
		pXmlNode = xmlNewNode(NULL, BAD_CAST (char*)CCharArr(csName));
		xmlAddChild(pXmlParent, pXmlNode);
	}

	char buf[32];
	xmlNewProp(pXmlNode, BAD_CAST TAG_Type, BAD_CAST (char*)CCharArr(pDrawingBase->GetOldType()));
	xmlNewProp(pXmlNode, BAD_CAST TAG_TypeName, BAD_CAST (char*)CCharArr(pDrawingBase->GetDrawingTypeName()));

	sprintf(buf,"%ld",time );
	xmlNewProp(pXmlNode, BAD_CAST TAG_CreateTime, BAD_CAST buf);

	sprintf(buf,"%d",x );
	xmlNewProp(pXmlNode, BAD_CAST TAG_XName, BAD_CAST buf);

	sprintf(buf,"%d",y );
	xmlNewProp(pXmlNode, BAD_CAST TAG_YName, BAD_CAST buf);

	sprintf(buf,"%d",width );
	xmlNewProp(pXmlNode, BAD_CAST TAG_WidthName, BAD_CAST buf);

	sprintf(buf,"%d",height );
	xmlNewProp(pXmlNode, BAD_CAST TAG_HeightName, BAD_CAST buf);


	if(topLeftX > 0 || topLeftY > 0 || bottomRightX > 0 || bottomRightY > 0)
	{
		sprintf(buf,"%d",topLeftX );
		xmlNewProp(pXmlNode, BAD_CAST TAG_TopLeftX, BAD_CAST buf);

		sprintf(buf,"%d",topLeftY );
		xmlNewProp(pXmlNode, BAD_CAST TAG_TopLeftY, BAD_CAST buf);

		sprintf(buf,"%d",bottomRightX );
		xmlNewProp(pXmlNode, BAD_CAST TAG_BottomRightX, BAD_CAST buf);

		sprintf(buf,"%d",bottomRightY );
		xmlNewProp(pXmlNode, BAD_CAST TAG_BottomRightY, BAD_CAST buf);
	}



	sprintf(buf,"%s",bVisible?"true":"false" );
	xmlNewProp(pXmlNode, BAD_CAST TAG_VisibleName, BAD_CAST buf);

	sprintf(buf,"%s",bAdaptiveWidth?"true":"false" );
	xmlNewProp(pXmlNode, BAD_CAST TAG_AdaptiveWidthName, BAD_CAST buf);

	sprintf(buf,"%s",bAdaptiveHeight?"true":"false" );
	xmlNewProp(pXmlNode, BAD_CAST TAG_AdaptiveHeightName, BAD_CAST buf);

	sprintf(buf,"%d",iNodeAlign);
	xmlNewProp(pXmlNode, BAD_CAST TAG_NodeAlign, BAD_CAST buf);
	
	switch(type)
	{
	case DRAWING_TYPE_Base:
		break;
	case DRAWING_TYPE_ImageBase:
		break;
	case DRAWING_TYPE_Empty:
		break;
	case DRAWING_TYPE_Node:
		break;
	case DRAWING_TYPE_Image:
		{
			CDrawingImage *pDrawingImage = CDrawingImage::CDrawingBaseToCDrawingImage(pDrawingBase);
			if(pDrawingImage != NULL)
			{
				CString csFileName;
				pDrawingImage->GetFile(csFileName);
				CString csPickFile;
				pDrawingImage->GetPackFile(csPickFile);
				int leftWidth = 0;
				int rightWidth = 0;
				int topWidth = 0;
				int bottomWidth = 0;
				pDrawingImage->GetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);

				xmlNewProp(pXmlNode, BAD_CAST TAG_FileName, BAD_CAST (char*)CCharArr(csFileName));
				xmlNewProp(pXmlNode, BAD_CAST TAG_LuaName, BAD_CAST (char*)CCharArr(csPickFile));

				sprintf(buf,"%d",leftWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridLeft, BAD_CAST buf);

				sprintf(buf,"%d",rightWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridRight, BAD_CAST buf);

				sprintf(buf,"%d",topWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridTop, BAD_CAST buf);

				sprintf(buf,"%d",bottomWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridBottom, BAD_CAST buf);
			}
		}
		break;
	case DRAWING_TYPE_Images:
		break;
	case DRAWING_TYPE_Button:
	case DRAWING_TYPE_CheckBox:
	case DRAWING_TYPE_RadioButton:
		{
			CDrawingButton *pDrawingButton = CDrawingButton::CDrawingBaseToCDrawingButton(pDrawingBase);
			if(pDrawingButton != NULL)
			{
				CString csFileName;
				CString csFile2Name;
				pDrawingButton->GetFile(csFileName);
				pDrawingButton->GetFile2(csFile2Name);
				CString csPickFile;
				pDrawingButton->GetPackFile(csPickFile);
				int leftWidth = 0;
				int rightWidth = 0;
				int topWidth = 0;
				int bottomWidth = 0;
				pDrawingButton->GetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);

				xmlNewProp(pXmlNode, BAD_CAST TAG_FileName, BAD_CAST (char*)CCharArr(csFileName));
				xmlNewProp(pXmlNode, BAD_CAST TAG_File2Name, BAD_CAST (char*)CCharArr(csFile2Name));
				xmlNewProp(pXmlNode, BAD_CAST TAG_LuaName, BAD_CAST (char*)CCharArr(csPickFile));

				sprintf(buf,"%d",leftWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridLeft, BAD_CAST buf);

				sprintf(buf,"%d",rightWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridRight, BAD_CAST buf);

				sprintf(buf,"%d",topWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridTop, BAD_CAST buf);

				sprintf(buf,"%d",bottomWidth);
				xmlNewProp(pXmlNode, BAD_CAST TAG_9GridBottom, BAD_CAST buf);
			}
		}
		break;
	case DRAWING_TYPE_GroupNode:
		break;
	case DRAWING_TYPE_GroupItem:
		break;
	case DRAWING_TYPE_CheckBoxGroup:
		break;
	case DRAWING_TYPE_RadioButtonGroup:
		break;
	case DRAWING_TYPE_Text:
	case DRAWING_TYPE_TextView:
	case DRAWING_TYPE_EditTextView:
	case DRAWING_TYPE_EditText:
		{
			CStringW csStr;
			CStringW csFontName;
			int iFontSize = 0;
			int iTextAlign;
			COLORREF color = 0;
			if(type == DRAWING_TYPE_Text || type == DRAWING_TYPE_EditText)
			{
				CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(pDrawingBase);
				if(pDrawingText != NULL)
				{
					pDrawingText->GetStr(csStr);
					pDrawingText->GetFontName(csFontName);
					pDrawingText->GetFontSize(iFontSize);
					pDrawingText->GetTextAlign(iTextAlign);
					pDrawingText->GetColor(color);
				}
			}
			else if(type == DRAWING_TYPE_TextView || type == DRAWING_TYPE_EditTextView)
			{
				CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(pDrawingBase);
				if(pDrawingTextView != NULL)
				{
					pDrawingTextView->GetStr(csStr);
					pDrawingTextView->GetFontName(csFontName);
					pDrawingTextView->GetFontSize(iFontSize);
					pDrawingTextView->GetTextAlign(iTextAlign);
					pDrawingTextView->GetColor(color);
				}
			}

			xmlNewProp(pXmlNode, BAD_CAST TAG_FontName, BAD_CAST (char*)::UnicodeToUTF8(CWCharArr(csFontName)));
			sprintf(buf,"%d",iFontSize);
			xmlNewProp(pXmlNode, BAD_CAST TAG_FontSize, BAD_CAST buf);
			sprintf(buf,"%d",iTextAlign);
			xmlNewProp(pXmlNode, BAD_CAST TAG_TextAlign, BAD_CAST buf);
			sprintf(buf,"0x%06X",color);
			xmlNewProp(pXmlNode, BAD_CAST TAG_Color, BAD_CAST buf);
//			char* strc = ConvertEx(theApp.m_Config.m_encode.c_str(),"UTF-8",CCharArr(csStr));
//			xmlNewProp(pXmlNode, BAD_CAST TAG_StringDataName, BAD_CAST (0==strc?"error":strc));
			CCharArr charArr = ::UnicodeToUTF8(CWCharArr(csStr));
			xmlNewProp(pXmlNode, BAD_CAST TAG_StringDataName, BAD_CAST (char*)charArr);
		}
		break;
	case DRAWING_TYPE_ScrollableNode:
		break;
	case DRAWING_TYPE_ScrollBar:
		break;
	case DRAWING_TYPE_TabView:
		break;
	case DRAWING_TYPE_TableView:
		break;
	case DRAWING_TYPE_GridView:
		break;
	case DRAWING_TYPE_ViewPager:
		break;
	case DRAWING_TYPE_ListView:
		break;
	case DRAWING_TYPE_ScrollView:
		break;
	case DRAWING_TYPE_Slider:
		break;
	case DRAWING_TYPE_Switch:
		break;
	case DRAWING_TYPE_DrawingCustom:
		break;
	case DRAWING_TYPE_CustomNode:
		break;
	case DRAWING_TYPE_CustomControl:
		{
			CDrawingCustomControl *pDrawingCustomControl = CDrawingCustomControl::CDrawingBaseToCDrawingCustomControl(pDrawingBase);
			if(pDrawingCustomControl != NULL)
			{
				CArray <CCustomData,CCustomData> customDataArray;
				pDrawingCustomControl->GetCustomData(customDataArray);

				xmlNewProp(pXmlNode,BAD_CAST TAG_CustomName,BAD_CAST (char*)CCharArr(pDrawingCustomControl->GetCustomName()));
				xmlNewProp(pXmlNode,BAD_CAST TAG_CustomNum,BAD_CAST (char*)CCharArr(::IntToCString(customDataArray.GetSize())));

				int j;
				for(j=0; j<customDataArray.GetSize(); j++)
				{
					CString csCustomProp = TAG_CustomProp + ::IntToCString(j+1);
					CString csCustomType = TAG_CustomType + ::IntToCString(j+1);
					CString csCustomData = TAG_CustomData + ::IntToCString(j+1);
					xmlNewProp(pXmlNode,BAD_CAST (char*)CCharArr(csCustomProp),BAD_CAST (char*)CCharArr(customDataArray.GetAt(j).GetCustomPropName()));
					xmlNewProp(pXmlNode,BAD_CAST (char*)CCharArr(csCustomType),BAD_CAST (char*)CCharArr(::GetCustomDataType(customDataArray.GetAt(j).GetCustomDataType())));
					xmlNewProp(pXmlNode,BAD_CAST (char*)CCharArr(csCustomData),BAD_CAST (char*)CCharArr(customDataArray.GetAt(j).GetCustomData()));
				}
			}
		}
		break;
	default:
		break;
	};

	if (treeCtrl.ItemHasChildren(hItem))
	{
		HTREEITEM hChildItem = treeCtrl.GetChildItem(hItem);
		while( 0 != hChildItem )
		{
			nest_save_xml(treeCtrl,hChildItem,xmlDoc,pXmlNode);
			hChildItem =treeCtrl.GetNextItem(hChildItem, TVGN_NEXT);  
		}
	}
	return 1;
}
int save_xml ( const char* strXmlFile,CXTreeCtrl& treeCtrl)
{
	xmlKeepBlanksDefault(0);
	xmlIndentTreeOutput = 1;
	int iRet = -1;
	xmlDocPtr xmlDoc = xmlNewDoc(BAD_CAST XML_DEFAULT_VERSION);
	if ( 0 == xmlDoc)
	{
		return iRet;
	}
	HTREEITEM hRoot = treeCtrl.GetRootItem();
	if ( 0 != hRoot )
	{
		iRet = nest_save_xml(treeCtrl,hRoot,xmlDoc,0);
		if ( iRet > 0 )
		{
			iRet = xmlSaveFormatFileEnc(strXmlFile, xmlDoc, "utf-8", 1);
		}
	}
	xmlFreeDoc(xmlDoc);
	return iRet;
}

#include <fcntl.h>
#include <io.h>

int nest_gen_lua ( CXTreeCtrl& treeCtrl,HTREEITEM hItem,FILE* fp,const char* strName,int& depth)
{
	USES_CONVERSION;

	CDrawingBase *pDrawingBase = (CDrawingBase*)treeCtrl.GetItemData(hItem);
	if(pDrawingBase == NULL)
		return -1;

	EM_DRAWING_TYPE type = pDrawingBase->GetDrawingType();
	
	if ( hItem == treeCtrl.GetRootItem())
	{
		fwprintf(fp,L"%s=\n",A2W(strName));
	}
	else
	{
		fwprintf(fp,L"\n");
	}
	int blank;
	blank = depth;
	while ( blank > 0 )
	{
		blank --;
		fwprintf(fp,L"	");
	}
	fwprintf(fp,L"{");

	fwprintf(fp,L"\n");
	blank = depth;
	while ( blank >= 0 )
	{
		blank --;
		fwprintf(fp,L"	");
	}

	fwprintf(fp,L"name=\"%s\"",A2W(strName));
	fwprintf(fp,L",%s=%s",A2W(TAG_Type),A2W(pDrawingBase->GetOldType()));
	fwprintf(fp,L",%s=\"%s\"",A2W(TAG_TypeName),A2W(pDrawingBase->GetDrawingTypeName()));
	fwprintf(fp,L",%s=%ld",A2W(TAG_CreateTime),pDrawingBase->GetTime());

	int x = 0;
	int y = 0;
	int width = 0;
	int height = 0;
	pDrawingBase->GetPos(x,y);
	pDrawingBase->GetSize(width,height);
	fwprintf(fp,L",%s=%d",A2W(TAG_XName),x);
	fwprintf(fp,L",%s=%d",A2W(TAG_YName),y);
	fwprintf(fp,L",%s=%d",A2W(TAG_WidthName),width);
	fwprintf(fp,L",%s=%d",A2W(TAG_HeightName),height);

	int topLeftX = 0;
	int topLeftY = 0;
	int bottomRightX = 0;
	int bottomRightY = 0;
	pDrawingBase->GetFillRegion(topLeftX,topLeftY,bottomRightX,bottomRightY);
	if(topLeftX > 0 || topLeftY > 0 || bottomRightX > 0 || bottomRightY > 0)
	{
		fwprintf(fp,L",%s=%d",A2W(TAG_TopLeftX),topLeftX);
		fwprintf(fp,L",%s=%d",A2W(TAG_TopLeftY),topLeftY);
		fwprintf(fp,L",%s=%d",A2W(TAG_BottomRightX),bottomRightX);
		fwprintf(fp,L",%s=%d",A2W(TAG_BottomRightY),bottomRightY);
	}

	bool bVisible = true;
	pDrawingBase->GetVisible(bVisible);
	bool bAdaptiveWidth = false;
	bool bAdaptiveHeight = false;
	pDrawingBase->GetFillParent(bAdaptiveWidth,bAdaptiveHeight);
	int iNodeAlign = 0;
	pDrawingBase->GetAlign(iNodeAlign);

	fwprintf(fp,L",%s=%d",A2W(TAG_VisibleName),bVisible);
	fwprintf(fp,L",%s=%d",A2W(TAG_AdaptiveWidthName),bAdaptiveWidth);
	fwprintf(fp,L",%s=%d",A2W(TAG_AdaptiveHeightName),bAdaptiveHeight);

	fwprintf(fp,L",%s=%s",A2W(TAG_NodeAlign),A2W(::GetAlignTypeName(iNodeAlign)));

	switch(type)
	{
	case DRAWING_TYPE_Base:
		break;
	case DRAWING_TYPE_ImageBase:
		break;
	case DRAWING_TYPE_Empty:
		break;
	case DRAWING_TYPE_Node:
		break;
	case DRAWING_TYPE_Image:
		{
			CDrawingImage *pDrawingImage = CDrawingImage::CDrawingBaseToCDrawingImage(pDrawingBase);
			if(pDrawingImage != NULL)
			{
				CString csFileName;
				pDrawingImage->GetFile(csFileName);
				CString csPickFile;
				pDrawingImage->GetPackFile(csPickFile);
				int leftWidth = 0;
				int rightWidth = 0;
				int topWidth = 0;
				int bottomWidth = 0;
				pDrawingImage->GetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);

				fwprintf(fp,L",%s=\"%s\"",A2W(TAG_FileName),A2W(csFileName));

				if ( !csPickFile.IsEmpty() )
				{
					int pos1 = csPickFile.Find('.');
					if ( pos1 > 0 )
					{
						fwprintf(fp,L",%s=\"%s\"",A2W(TAG_LuaName),A2W(csPickFile));
					}
				}

				if ( leftWidth > 0 || rightWidth > 0 || topWidth > 0 || bottomWidth > 0 )
				{
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridLeft),leftWidth);
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridRight),rightWidth);
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridTop),topWidth);
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridBottom),bottomWidth);
				}
			}
		}
		break;
	case DRAWING_TYPE_Images:
		break;
	case DRAWING_TYPE_Button:
	case DRAWING_TYPE_CheckBox:
	case DRAWING_TYPE_RadioButton:
		{
			CDrawingButton *pDrawingButton = CDrawingButton::CDrawingBaseToCDrawingButton(pDrawingBase);
			if(pDrawingButton != NULL)
			{
				CString csFileName;
				CString csFile2Name;
				pDrawingButton->GetFile(csFileName);
				pDrawingButton->GetFile2(csFile2Name);
				CString csPickFile;
				pDrawingButton->GetPackFile(csPickFile);
				int leftWidth = 0;
				int rightWidth = 0;
				int topWidth = 0;
				int bottomWidth = 0;
				pDrawingButton->GetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);

				fwprintf(fp,L",%s=\"%s\"",A2W(TAG_FileName),A2W(csFileName));
				if(!csFile2Name.IsEmpty())
					fwprintf(fp,L",%s=\"%s\"",A2W(TAG_File2Name),A2W(csFile2Name));

				if ( !csPickFile.IsEmpty() )
				{
					int pos1 = csPickFile.Find('.');
					if ( pos1 > 0 )
					{
						fwprintf(fp,L",%s=\"%s\"",A2W(TAG_LuaName),A2W(csPickFile));
					}
				}

				if ( leftWidth > 0 || rightWidth > 0 || topWidth > 0 || bottomWidth > 0 )
				{
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridLeft),leftWidth);
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridRight),rightWidth);
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridTop),topWidth);
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridBottom),bottomWidth);
				}
			}
		}
		break;
	case DRAWING_TYPE_GroupNode:
		break;
	case DRAWING_TYPE_GroupItem:
		break;
	case DRAWING_TYPE_CheckBoxGroup:
		break;
	case DRAWING_TYPE_RadioButtonGroup:
		break;
	case DRAWING_TYPE_Text:
	case DRAWING_TYPE_TextView:
	case DRAWING_TYPE_EditTextView:
	case DRAWING_TYPE_EditText:
		{
			CStringW csStr;
			CStringW csFontName;
			int iFontSize = 0;
			int iTextAlign;
			COLORREF color = 0;
			if(type == DRAWING_TYPE_Text || type == DRAWING_TYPE_EditText)
			{
				CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(pDrawingBase);
				if(pDrawingText != NULL)
				{
					pDrawingText->GetStr(csStr);
					pDrawingText->GetFontName(csFontName);
					pDrawingText->GetFontSize(iFontSize);
					pDrawingText->GetTextAlign(iTextAlign);
					pDrawingText->GetColor(color);
				}
			}
			else if(type == DRAWING_TYPE_TextView || type == DRAWING_TYPE_EditTextView)
			{
				CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(pDrawingBase);
				if(pDrawingTextView != NULL)
				{
					pDrawingTextView->GetStr(csStr);
					pDrawingTextView->GetFontName(csFontName);
					pDrawingTextView->GetFontSize(iFontSize);
					pDrawingTextView->GetTextAlign(iTextAlign);
					pDrawingTextView->GetColor(color);
				}
			}
			fwprintf(fp,L",%s=\"%s\"",A2W(TAG_FontName),csFontName);
			fwprintf(fp,L",%s=%d",A2W(TAG_FontSize),iFontSize);
			fwprintf(fp,L",%s=%s",A2W(TAG_TextAlign),A2W(::GetAlignTypeName(iTextAlign)));

			//fwprintf(fp,L",%s=\"0x%06X\""),CText1::tagColor.c_str(),pText->color);

			fwprintf(fp,L",colorRed=%d",GetRValue(color));
			fwprintf(fp,L",colorGreen=%d",GetGValue(color));
			fwprintf(fp,L",colorBlue=%d",GetBValue(color));

			//char* strc = Convert(theApp.m_Config.m_encode.c_str(),"UTF-8",pText->strStringData.c_str());
			//char* strc = mcbs2utf8(pText->strStringData.c_str());

			//
			CStringW content = csStr;
			content.Replace(L"&lt;",L"<");
			content.Replace(L"&gt;",L">");
			content.Replace(L"&quot;",L"\"");
			content.Replace(L"&amp;",L"&");

			fwprintf(fp,L",%s=[[%s]]",A2W(TAG_StringDataName),content);
			//delete[] strc;
		}
		break;
	case DRAWING_TYPE_ScrollableNode:
		break;
	case DRAWING_TYPE_ScrollBar:
		break;
	case DRAWING_TYPE_TabView:
		break;
	case DRAWING_TYPE_TableView:
		break;
	case DRAWING_TYPE_GridView:
		break;
	case DRAWING_TYPE_ViewPager:
		break;
	case DRAWING_TYPE_ListView:
		break;
	case DRAWING_TYPE_ScrollView:
		break;
	case DRAWING_TYPE_Slider:
		break;
	case DRAWING_TYPE_Switch:
		break;
	case DRAWING_TYPE_DrawingCustom:
		break;
	case DRAWING_TYPE_CustomNode:
		break;
	case DRAWING_TYPE_CustomControl:
		{
			CDrawingCustomControl *pDrawingCustomControl = CDrawingCustomControl::CDrawingBaseToCDrawingCustomControl(pDrawingBase);
			if(pDrawingCustomControl != NULL)
			{
				fwprintf(fp,A2W(pDrawingCustomControl->GetLuaCustomName()));

				CArray <CCustomData,CCustomData> customDataArray;
				pDrawingCustomControl->GetCustomData(customDataArray);

				int j;
				for(j=0; j<customDataArray.GetSize(); j++)
				{
					fwprintf(fp,A2W(customDataArray.GetAt(j).GetLuaCustomData()));
				}
			}
		}
		break;
	default:
		break;
	};

	if (treeCtrl.ItemHasChildren(hItem))
	{
		HTREEITEM hChildItem = treeCtrl.GetChildItem(hItem);
		while( 0 != hChildItem )
		{
			fwprintf(fp,L",");
			CString strText = treeCtrl.GetItemText(hChildItem);
			depth++;
			nest_gen_lua(treeCtrl,hChildItem,fp,CCharArr(strText),depth);
			depth--;
			hChildItem =treeCtrl.GetNextItem(hChildItem, TVGN_NEXT);  
		}
	}

	fwprintf(fp,L"\n");
	blank = depth;
	while ( blank > 0 )
	{
		blank --;
		fwprintf(fp,L"	");
	}	
	fwprintf(fp,L"}");

	return 1;
}

int gen_lua ( const char* strFile,const char* strName,CXTreeCtrl& treeCtrl )
{
	USES_CONVERSION;

	int iRet = -1;
	FILE* fp = _wfopen(A2W(strFile),L"w");
	if ( NULL == fp )
	{
		return iRet;
	}
	_setmode(_fileno(fp), _O_U8TEXT);

	HTREEITEM hRoot = treeCtrl.GetRootItem();
	if ( 0 != hRoot )
	{
		int depth = 0;
		iRet = nest_gen_lua(treeCtrl,hRoot,fp,strName,depth);
	}
	fclose(fp);
	return iRet;
}


int nest_gen_lua (CCDrawingBaseNode *pCDrawingBaseNode,BOOL bRoot,FILE* fp,const char* strName,int& depth)
{
	USES_CONVERSION;

	if(pCDrawingBaseNode == NULL)
		return -1;

	CDrawingBase *pDrawingBase = pCDrawingBaseNode->GetCDrawingBase();
	if(pDrawingBase == NULL)
		return -1;

	EM_DRAWING_TYPE type = pDrawingBase->GetDrawingType();
	
	if (bRoot)
	{
		fwprintf(fp,L"%s=\n",A2W(strName));
	}
	else
	{
		fwprintf(fp,L"\n");
	}
	int blank;
	blank = depth;
	while ( blank > 0 )
	{
		blank --;
		fwprintf(fp,L"	");
	}
	fwprintf(fp,L"{");

	fwprintf(fp,L"\n");
	blank = depth;
	while ( blank >= 0 )
	{
		blank --;
		fwprintf(fp,L"	");
	}

	fwprintf(fp,L"name=\"%s\"",A2W(strName));
	fwprintf(fp,L",%s=%s",A2W(TAG_Type),A2W(pDrawingBase->GetOldType()));
	fwprintf(fp,L",%s=\"%s\"",A2W(TAG_TypeName),A2W(pDrawingBase->GetDrawingTypeName()));
	fwprintf(fp,L",%s=%ld",A2W(TAG_CreateTime),pDrawingBase->GetTime());

	int x = 0;
	int y = 0;
	int width = 0;
	int height = 0;
	pDrawingBase->GetPos(x,y);
	pDrawingBase->GetSize(width,height);
	fwprintf(fp,L",%s=%d",A2W(TAG_XName),x);
	fwprintf(fp,L",%s=%d",A2W(TAG_YName),y);
	fwprintf(fp,L",%s=%d",A2W(TAG_WidthName),width);
	fwprintf(fp,L",%s=%d",A2W(TAG_HeightName),height);

	int topLeftX = 0;
	int topLeftY = 0;
	int bottomRightX = 0;
	int bottomRightY = 0;
	pDrawingBase->GetFillRegion(topLeftX,topLeftY,bottomRightX,bottomRightY);
	if(topLeftX > 0 || topLeftY > 0 || bottomRightX > 0 || bottomRightY > 0)
	{
		fwprintf(fp,L",%s=%d",A2W(TAG_TopLeftX),topLeftX);
		fwprintf(fp,L",%s=%d",A2W(TAG_TopLeftY),topLeftY);
		fwprintf(fp,L",%s=%d",A2W(TAG_BottomRightX),bottomRightX);
		fwprintf(fp,L",%s=%d",A2W(TAG_BottomRightY),bottomRightY);
	}

	bool bVisible = true;
	pDrawingBase->GetVisible(bVisible);
	bool bAdaptiveWidth = false;
	bool bAdaptiveHeight = false;
	pDrawingBase->GetFillParent(bAdaptiveWidth,bAdaptiveHeight);
	int iNodeAlign = 0;
	pDrawingBase->GetAlign(iNodeAlign);

	fwprintf(fp,L",%s=%d",A2W(TAG_VisibleName),bVisible);
	fwprintf(fp,L",%s=%d",A2W(TAG_AdaptiveWidthName),bAdaptiveWidth);
	fwprintf(fp,L",%s=%d",A2W(TAG_AdaptiveHeightName),bAdaptiveHeight);

	fwprintf(fp,L",%s=%s",A2W(TAG_NodeAlign),A2W(::GetAlignTypeName(iNodeAlign)));

	switch(type)
	{
	case DRAWING_TYPE_Base:
		break;
	case DRAWING_TYPE_ImageBase:
		break;
	case DRAWING_TYPE_Empty:
		break;
	case DRAWING_TYPE_Node:
		break;
	case DRAWING_TYPE_Image:
		{
			CDrawingImage *pDrawingImage = CDrawingImage::CDrawingBaseToCDrawingImage(pDrawingBase);
			if(pDrawingImage != NULL)
			{
				CString csFileName;
				pDrawingImage->GetFile(csFileName);
				CString csPickFile;
				pDrawingImage->GetPackFile(csPickFile);
				int leftWidth = 0;
				int rightWidth = 0;
				int topWidth = 0;
				int bottomWidth = 0;
				pDrawingImage->GetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);

				fwprintf(fp,L",%s=\"%s\"",A2W(TAG_FileName),A2W(csFileName));

				if ( !csPickFile.IsEmpty() )
				{
					int pos1 = csPickFile.Find('.');
					if ( pos1 > 0 )
					{
						fwprintf(fp,L",%s=\"%s\"",A2W(TAG_LuaName),A2W(csPickFile));
					}
				}

				if ( leftWidth > 0 || rightWidth > 0 || topWidth > 0 || bottomWidth > 0 )
				{
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridLeft),leftWidth);
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridRight),rightWidth);
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridTop),topWidth);
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridBottom),bottomWidth);
				}
			}
		}
		break;
	case DRAWING_TYPE_Images:
		break;
	case DRAWING_TYPE_Button:
	case DRAWING_TYPE_CheckBox:
	case DRAWING_TYPE_RadioButton:
		{
			CDrawingButton *pDrawingButton = CDrawingButton::CDrawingBaseToCDrawingButton(pDrawingBase);
			if(pDrawingButton != NULL)
			{
				CString csFileName;
				CString csFile2Name;
				pDrawingButton->GetFile(csFileName);
				pDrawingButton->GetFile2(csFile2Name);
				CString csPickFile;
				pDrawingButton->GetPackFile(csPickFile);
				int leftWidth = 0;
				int rightWidth = 0;
				int topWidth = 0;
				int bottomWidth = 0;
				pDrawingButton->GetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);

				fwprintf(fp,L",%s=\"%s\"",A2W(TAG_FileName),A2W(csFileName));
				if(!csFile2Name.IsEmpty())
					fwprintf(fp,L",%s=\"%s\"",A2W(TAG_File2Name),A2W(csFile2Name));

				if ( !csPickFile.IsEmpty() )
				{
					int pos1 = csPickFile.Find('.');
					if ( pos1 > 0 )
					{
						fwprintf(fp,L",%s=\"%s\"",A2W(TAG_LuaName),A2W(csPickFile));
					}
				}

				if ( leftWidth > 0 || rightWidth > 0 || topWidth > 0 || bottomWidth > 0 )
				{
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridLeft),leftWidth);
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridRight),rightWidth);
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridTop),topWidth);
					fwprintf(fp,L",%s=%d",A2W(TAG_9GridBottom),bottomWidth);
				}
			}
		}
		break;
	case DRAWING_TYPE_GroupNode:
		break;
	case DRAWING_TYPE_GroupItem:
		break;
	case DRAWING_TYPE_CheckBoxGroup:
		break;
	case DRAWING_TYPE_RadioButtonGroup:
		break;
	case DRAWING_TYPE_Text:
	case DRAWING_TYPE_TextView:
	case DRAWING_TYPE_EditTextView:
	case DRAWING_TYPE_EditText:
		{
			CStringW csStr;
			CStringW csFontName;
			int iFontSize = 0;
			int iTextAlign;
			COLORREF color = 0;
			if(type == DRAWING_TYPE_Text || type == DRAWING_TYPE_EditText)
			{
				CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(pDrawingBase);
				if(pDrawingText != NULL)
				{
					pDrawingText->GetStr(csStr);
					pDrawingText->GetFontName(csFontName);
					pDrawingText->GetFontSize(iFontSize);
					pDrawingText->GetTextAlign(iTextAlign);
					pDrawingText->GetColor(color);
				}
			}
			else if(type == DRAWING_TYPE_TextView || type == DRAWING_TYPE_EditTextView)
			{
				CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(pDrawingBase);
				if(pDrawingTextView != NULL)
				{
					pDrawingTextView->GetStr(csStr);
					pDrawingTextView->GetFontName(csFontName);
					pDrawingTextView->GetFontSize(iFontSize);
					pDrawingTextView->GetTextAlign(iTextAlign);
					pDrawingTextView->GetColor(color);
				}
			}
			fwprintf(fp,L",%s=\"%s\"",A2W(TAG_FontName),csFontName);
			fwprintf(fp,L",%s=%d",A2W(TAG_FontSize),iFontSize);
			fwprintf(fp,L",%s=%s",A2W(TAG_TextAlign),A2W(::GetAlignTypeName(iTextAlign)));

			//fwprintf(fp,L",%s=\"0x%06X\""),CText1::tagColor.c_str(),pText->color);

			fwprintf(fp,L",colorRed=%d",GetRValue(color));
			fwprintf(fp,L",colorGreen=%d",GetGValue(color));
			fwprintf(fp,L",colorBlue=%d",GetBValue(color));

			//char* strc = Convert(theApp.m_Config.m_encode.c_str(),"UTF-8",pText->strStringData.c_str());
			//char* strc = mcbs2utf8(pText->strStringData.c_str());

			//
			CStringW content = csStr;
			content.Replace(L"&lt;",L"<");
			content.Replace(L"&gt;",L">");
			content.Replace(L"&quot;",L"\"");
			content.Replace(L"&amp;",L"&");

			fwprintf(fp,L",%s=[[%s]]",A2W(TAG_StringDataName),content);
			//delete[] strc;
		}
		break;
	case DRAWING_TYPE_ScrollableNode:
		break;
	case DRAWING_TYPE_ScrollBar:
		break;
	case DRAWING_TYPE_TabView:
		break;
	case DRAWING_TYPE_TableView:
		break;
	case DRAWING_TYPE_GridView:
		break;
	case DRAWING_TYPE_ViewPager:
		break;
	case DRAWING_TYPE_ListView:
		break;
	case DRAWING_TYPE_ScrollView:
		break;
	case DRAWING_TYPE_Slider:
		break;
	case DRAWING_TYPE_Switch:
		break;
	case DRAWING_TYPE_DrawingCustom:
		break;
	case DRAWING_TYPE_CustomNode:
		break;
	case DRAWING_TYPE_CustomControl:
		{
			CDrawingCustomControl *pDrawingCustomControl = CDrawingCustomControl::CDrawingBaseToCDrawingCustomControl(pDrawingBase);
			if(pDrawingCustomControl != NULL)
			{
				fwprintf(fp,A2W(pDrawingCustomControl->GetLuaCustomName()));

				CArray <CCustomData,CCustomData> customDataArray;
				pDrawingCustomControl->GetCustomData(customDataArray);

				int j;
				for(j=0; j<customDataArray.GetSize(); j++)
				{
					fwprintf(fp,A2W(customDataArray.GetAt(j).GetLuaCustomData()));
				}
			}
		}
		break;
	default:
		break;
	};

	int i;
	for(i=0; i<pCDrawingBaseNode->GetCDrawingBaseNodeChildNum(); i++)
	{
		CCDrawingBaseNode *pChildCDrawingBaseNode = pCDrawingBaseNode->GetCDrawingBaseNode(i);
		if(pChildCDrawingBaseNode != NULL)
		{
			CDrawingBase *pChildDrawingBase = pChildCDrawingBaseNode->GetCDrawingBase();
			if(pChildDrawingBase != NULL)
			{
				fwprintf(fp,L",");
				CString strText;
				pChildDrawingBase->GetName(strText);
				depth++;
				nest_gen_lua(pChildCDrawingBaseNode,FALSE,fp,CCharArr(strText),depth);
				depth--;
			}
		}
	}

	fwprintf(fp,L"\n");
	blank = depth;
	while ( blank > 0 )
	{
		blank --;
		fwprintf(fp,L"	");
	}	
	fwprintf(fp,L"}");

	return 1;
}

int gen_lua ( const char* strFile,const char* strName,CCDrawingBaseNode *pCDrawingBaseNode )
{
	USES_CONVERSION;

	int iRet = -1;
	FILE* fp = _wfopen(A2W(strFile),L"w");
	if ( NULL == fp )
	{
		return iRet;
	}
	_setmode(_fileno(fp), _O_U8TEXT);

	if(pCDrawingBaseNode != NULL)
	{
		int depth = 0;
		iRet = nest_gen_lua(pCDrawingBaseNode,TRUE,fp,strName,depth);
	}
	fclose(fp);
	return iRet;
}


int String_nest_gen_lua (CCDrawingBaseNode *pCDrawingBaseNode,BOOL bRoot,FILE* fp,const char* strFileName,CStringArray &csNameArray)
{
	USES_CONVERSION;

	if(pCDrawingBaseNode == NULL)
		return -1;

	CDrawingBase *pDrawingBase = pCDrawingBaseNode->GetCDrawingBase();
	if(pDrawingBase == NULL)
		return -1;

	EM_DRAWING_TYPE type = pDrawingBase->GetDrawingType();
	CString csName;
	pDrawingBase->GetName(csName);

	switch(type)
	{
	case DRAWING_TYPE_Text:
	case DRAWING_TYPE_TextView:
	case DRAWING_TYPE_EditTextView:
	case DRAWING_TYPE_EditText:
		{
			CStringW csStr;
			if(type == DRAWING_TYPE_Text || type == DRAWING_TYPE_EditText)
			{
				CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(pDrawingBase);
				if(pDrawingText != NULL)
				{
					pDrawingText->GetStr(csStr);
				}
			}
			else if(type == DRAWING_TYPE_TextView || type == DRAWING_TYPE_EditTextView)
			{
				CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(pDrawingBase);
				if(pDrawingTextView != NULL)
				{
					pDrawingTextView->GetStr(csStr);
				}
			}

			//
			CStringW content = csStr;
			content.Replace(L"&lt;",L"<");
			content.Replace(L"&gt;",L">");
			content.Replace(L"&quot;",L"\"");
			content.Replace(L"&amp;",L"&");

			CString csStringName = csName;
			if(::IsNameInArray(csStringName,csNameArray))
			{
				csStringName = ::GetDifferentName(csNameArray,csStringName);
			}
			csNameArray.Add(csStringName);

			fwprintf(fp,L"%s_%s=[[%s]]\r\n",A2W(strFileName),A2W(csStringName),content);
		}
		break;
	default:
		break;
	};

	int i;
	for(i=0; i<pCDrawingBaseNode->GetCDrawingBaseNodeChildNum(); i++)
	{
		CCDrawingBaseNode *pChildCDrawingBaseNode = pCDrawingBaseNode->GetCDrawingBaseNode(i);
		if(pChildCDrawingBaseNode != NULL)
		{
			CDrawingBase *pChildDrawingBase = pChildCDrawingBaseNode->GetCDrawingBase();
			if(pChildDrawingBase != NULL)
			{
				String_nest_gen_lua(pChildCDrawingBaseNode,FALSE,fp,strFileName,csNameArray);
			}
		}
	}

	return 1;
}

int String_gen_lua ( const char* strFile,const char* strFileName,CCDrawingBaseNode *pCDrawingBaseNode )
{
	USES_CONVERSION;

	int iRet = -1;
	FILE* fp = _wfopen(A2W(strFile),L"w");
	if ( NULL == fp )
	{
		return iRet;
	}
	_setmode(_fileno(fp), _O_U8TEXT);

	if(pCDrawingBaseNode != NULL)
	{
		CStringArray csNameArray;
		iRet = String_nest_gen_lua(pCDrawingBaseNode,TRUE,fp,strFileName,csNameArray);
	}
	fclose(fp);
	return iRet;
}

int XmlToLua(CString csXmlPath,CString csLuaPath)
{
	if(!::IsFileExist(csXmlPath))
		return -1;

	CCDrawingBaseNode *pCDrawingBaseNode = NULL;
	::load_xml(CCharArr(csXmlPath),&pCDrawingBaseNode);

	CString csLuaName = ::GetFileName(csLuaPath,FALSE);
	::gen_lua(CCharArr(csLuaPath),CCharArr(csLuaName),pCDrawingBaseNode);

	if(pCDrawingBaseNode != NULL)
	{
		delete pCDrawingBaseNode;
		pCDrawingBaseNode = NULL;
	}

	return 0;
}

 int nest_gen_config_lua ( CXTreeCtrl& treeCtrl,HTREEITEM hItem,CConfigNode *pConfigNode)
{
	USES_CONVERSION;

	if(pConfigNode == NULL)
		return 0;

	HTREEITEM hChildItem = treeCtrl.GetChildItem(hItem);
	while(0 != hChildItem )
	{
		CString strText = treeCtrl.GetItemText(hChildItem);
		CDrawingBase *pDrawingBase = (CDrawingBase*)treeCtrl.GetItemData(hChildItem);
		if(pDrawingBase != NULL)
		{
			CConfigNode *pChildConfigNode = pConfigNode->AddConfigNode(pDrawingBase->GetDrawingType(),strText);

			if(treeCtrl.ItemHasChildren(hChildItem))
			{
				nest_gen_config_lua(treeCtrl,hChildItem,pChildConfigNode);
			}
		}

		hChildItem = treeCtrl.GetNextItem(hChildItem, TVGN_NEXT);  
	}
	return 1;
}

int gen_config_lua ( const char* strFile,const char* strName,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode,CXTreeCtrl& treeCtrl )
{
	USES_CONVERSION;

	int iRet = -1;
	FILE* fp = _wfopen(A2W(strFile),L"w");
	if ( NULL == fp )
	{
		return iRet;
	}
	_setmode(_fileno(fp), _O_U8TEXT);

	HTREEITEM hRoot = treeCtrl.GetRootItem();
	if ( 0 != hRoot )
	{
		CString strText = treeCtrl.GetItemText(hRoot);
	
		CConfigNode rootConfigNode(DRAWING_TYPE_Node,strText);
		iRet = nest_gen_config_lua(treeCtrl,hRoot,&rootConfigNode);

		rootConfigNode.Write(fp,CString(strName),emDrawingTypeArr,bLeafNode);
	}
	fclose(fp);
	return iRet;
}

// CLeftDialog �Ի���

IMPLEMENT_DYNAMIC(CLeftDialog, CDialogEx)

CLeftDialog::CLeftDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CLeftDialog::IDD, pParent)
{
	m_bTreeNodeReName = FALSE;

	m_pStartDrawingBase = NULL;

	m_pCopyDrawingBaseNode = NULL;

	m_hSaveXMLThread = NULL;
	m_dwSaveXMLThreadId = 0;

	m_bModifyData = FALSE;
	m_bCopyTreeModifyData = FALSE;
}

CLeftDialog::~CLeftDialog()
{
	ReleaseAllData();
}

void CLeftDialog::DeleteAllTreeItems()
{
	if(m_treeCtrl.m_hWnd != NULL)
	{
		HTREEITEM hRoot = m_treeCtrl.GetRootItem();
		::DeleteItemData(m_treeCtrl,hRoot);
		m_treeCtrl.DeleteAllItems();
	}
}

BOOL CLeftDialog::IsModifyData()
{
	return m_bModifyData;
}

void CLeftDialog::ReleaseAllData()
{
	if(m_hSaveXMLThread != NULL)
	{
		::PostThreadMessage(m_dwSaveXMLThreadId,WM_QUIT,0,0);
		::WaitForSingleObject(m_hSaveXMLThread,INFINITE);

		m_hSaveXMLThread = NULL;
		m_dwSaveXMLThreadId = 0;
	}

	DeleteAllTreeItems();

	if(m_pStartDrawingBase != NULL)
	{
		delete m_pStartDrawingBase;
		m_pStartDrawingBase = NULL;
	}
	if(m_pCopyDrawingBaseNode != NULL)
	{
		delete m_pCopyDrawingBaseNode;
		m_pCopyDrawingBaseNode= NULL;
	}
}

const CDrawingBase* CLeftDialog::GetSelDrawingBase()
{
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return NULL;

	return (CDrawingBase*)m_treeCtrl.GetItemData(hSelectItem);
}

bool GetTreeTimeMap(CXTreeCtrl &treeCtrl,HTREEITEM hTreeItem,map<long,bool> &lTimeMap)
{
	if(hTreeItem == NULL)
		return false;

	CDrawingBase *pDrawingBase = (CDrawingBase *)treeCtrl.GetItemData(hTreeItem);
	if(pDrawingBase != NULL)
	{
		lTimeMap[pDrawingBase->GetTime()] = true;
	}

	HTREEITEM hChildItem = treeCtrl.GetChildItem(hTreeItem);
	if(treeCtrl.ItemHasChildren(hTreeItem))
	{
		while (hChildItem != NULL)
		{
			GetTreeTimeMap(treeCtrl,hChildItem,lTimeMap);
			hChildItem = treeCtrl.GetNextSiblingItem(hChildItem);
		}
	}
	return true;
}

bool CLeftDialog::GetTreeTimeMap(map<long,bool> &lTimeMap)
{
	lTimeMap.clear();
	
	return ::GetTreeTimeMap(m_treeCtrl,m_treeCtrl.GetRootItem(),lTimeMap);
}

void CLeftDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_TREE, m_treeCtrl);
}


BEGIN_MESSAGE_MAP(CLeftDialog, CDialogEx)
	ON_BN_CLICKED(IDOK, &CLeftDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CLeftDialog::OnBnClickedCancel)
	ON_WM_SIZE()
	ON_WM_CONTEXTMENU()
	ON_WM_TIMER()
	ON_NOTIFY(NM_CLICK, IDC_TREE, &CLeftDialog::OnNMClickTree)
	ON_NOTIFY(NM_RCLICK, IDC_TREE, &CLeftDialog::OnNMRClickTree)
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE, &CLeftDialog::OnTvnSelchangedTree)
	ON_NOTIFY(TVN_SELCHANGING, IDC_TREE, &CLeftDialog::OnTvnSelchangingTree)

	ON_MESSAGE(WM_TREEITEM_MOVE_NEXT,MessageTreeItemMoveNext)
	ON_MESSAGE(WM_TREEITEM_MOVE_CHILD,MessageTreeItemMoveChild)
	ON_MESSAGE(WM_CMD_NODE_CHANGE,MessageCmdNodeChange)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_TREE, &CLeftDialog::OnNMCustomdrawTree)
	ON_NOTIFY(TVN_BEGINLABELEDIT, IDC_TREE, &CLeftDialog::OnTvnBeginlabeleditTree)
	ON_NOTIFY(TVN_ENDLABELEDIT, IDC_TREE, &CLeftDialog::OnTvnEndlabeleditTree)
END_MESSAGE_MAP()

// CLeftDialog ��Ϣ��������

void CLeftDialog::LoadXml(const CString &csSelDirectoryName,const CString &csSelFileName)
{
	m_csSelDirectoryName = csSelDirectoryName;
	m_csSelFileName = csSelFileName;

	HTREEITEM hRoot = m_treeCtrl.GetRootItem();
	::DeleteItemData(m_treeCtrl,hRoot);
	m_treeCtrl.DeleteAllItems();

	if(csSelDirectoryName.IsEmpty() || csSelFileName.IsEmpty())
	{
		m_treeCtrl.EnableWindow(FALSE);
		return;
	}
	m_treeCtrl.EnableWindow(TRUE);

	CString csXmlFilePath = EDITOR_DIRECTORY+_T("\\")+m_csSelDirectoryName+_T("\\")+m_csSelFileName;
	load_xml(CCharArr(csXmlFilePath),m_treeCtrl,NULL);

	CString csTmpFilePath = SCRIPTS_DIRECTORY + _T("\\tmp.lua");
	gen_lua(CCharArr(csTmpFilePath),"root",m_treeCtrl);
	DeleteWellText();
	LuaInterface* pLuaInterface = GetLuaInterface();
	if(pLuaInterface != NULL)
	{
		pLuaInterface->ToLua("editor.lua");
	}

	hRoot = m_treeCtrl.GetRootItem();
	m_treeCtrl.Expand(hRoot,TVE_EXPAND);
	m_treeCtrl.SelectItem(hRoot);

	ResetHistory();

	((CMainFrame*)AfxGetMainWnd())->UpdateStatusBarPane1(_T("����XML"));
	((CMainFrame*)AfxGetMainWnd())->UpdateXml();

	m_bModifyData = FALSE;
	m_bCopyTreeModifyData = FALSE;

	::LoadEditorXML("D:\\editor.xml",m_uiControl);
}

CString CLeftDialog::GetSelDirectoryName() const
{
	return m_csSelDirectoryName;
}

CString CLeftDialog::GetSelFileName() const
{
	return m_csSelFileName;
}

CString CLeftDialog::GetXmlPath() const
{
	CString csXmlFilePath = EDITOR_DIRECTORY+_T("\\")+m_csSelDirectoryName+_T("\\")+m_csSelFileName;
	return csXmlFilePath;
}

CString CLeftDialog::GetLuaPath() const
{
	CString csFileName = m_csSelFileName.Left(m_csSelFileName.GetLength()-4);
	CString csLuaFilePath = VIEW_DIRECTORY+_T("\\")+m_csSelDirectoryName+_T("\\")+csFileName+_T(".lua");
	return csLuaFilePath;
}

int CLeftDialog::SaveXml()
{
	CString csXmlDirectory = EDITOR_DIRECTORY+_T("\\")+m_csSelDirectoryName;
	::CreateMultipleDirectory(csXmlDirectory);
	CString csXmlFilePath = csXmlDirectory+_T("\\")+m_csSelFileName;
	int iRet = ::save_xml(CCharArr(csXmlFilePath),m_treeCtrl);

	m_bModifyData = FALSE;
	m_bCopyTreeModifyData = FALSE;

	return iRet;
}

int CLeftDialog::GenLua()
{
	SaveXml();

	CString csFileName = m_csSelFileName.Left(m_csSelFileName.GetLength()-4);
	CString csLuaDirectory = VIEW_DIRECTORY+_T("\\")+m_csSelDirectoryName;
	::CreateMultipleDirectory(csLuaDirectory);
	CString csLuaFilePath = csLuaDirectory+_T("\\")+csFileName+_T(".lua");
	int iRet = ::gen_lua(CCharArr(csLuaFilePath),CCharArr(csFileName),m_treeCtrl);

	CString csStringLuaDirectory = TMP_DIRECTORY+_T("\\")+m_csSelDirectoryName;
	::CreateMultipleDirectory(csStringLuaDirectory);
	CString csStringLuaFilePath = csStringLuaDirectory+_T("\\")+csFileName+_T("_string.lua");
	HTREEITEM hRoot = m_treeCtrl.GetRootItem();
	CDrawingBase *pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hRoot);
	CCDrawingBaseNode *pCDrawingBaseNode = new CCDrawingBaseNode(pDrawingBase);
	::GetCDrawingBaseNode(m_treeCtrl,hRoot,pCDrawingBaseNode);
	::String_gen_lua(CCharArr(csStringLuaFilePath),CCharArr(csFileName),pCDrawingBaseNode);
	if(pCDrawingBaseNode != NULL)
	{
		delete pCDrawingBaseNode;
		pCDrawingBaseNode = NULL;
	}

	CString csTmpFilePath = SCRIPTS_DIRECTORY + _T("\\tmp.lua");
	gen_lua(CCharArr(csTmpFilePath),"root",m_treeCtrl);
	DeleteWellText();
	LuaInterface* pLuaInterface = GetLuaInterface();
	if(pLuaInterface != NULL)
	{
		pLuaInterface->ToLua("editor.lua");
	}

	//����lua�ɹ���ѡ�и��ڵ� ��ΪToLua��DrawingId�����˱仯����Ҫ����ѡ��ڵ㣬�����ʱ�޸Ŀؼ����Բ���Ч
	m_treeCtrl.SelectItem(hRoot);

	return iRet;
}

int CLeftDialog::GenConfigLua(const CString &csFilePath,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode)
{
	CString csFileName = ::GetFileName(csFilePath,FALSE);
	return ::gen_config_lua(CCharArr(csFilePath),CCharArr(csFileName),emDrawingTypeArr,bLeafNode,m_treeCtrl);
}

HTREEITEM GetTreeItem(CXTreeCtrl &treeCtrl,HTREEITEM hItem,const CStringArray &uiTreePathArray,int index)
{
	if(hItem == NULL)
		return NULL;

	if(index<0 || index >= uiTreePathArray.GetSize())
		return NULL;

	HTREEITEM hNextItem = hItem;
	while(hNextItem != NULL)
	{
		CString csItemName = treeCtrl.GetItemText(hNextItem);
		if(csItemName == uiTreePathArray.GetAt(index))
		{
			if(index == uiTreePathArray.GetSize()-1)
				return hNextItem;
			else
				return GetTreeItem(treeCtrl,treeCtrl.GetChildItem(hNextItem),uiTreePathArray,index+1);
		}

		hNextItem = treeCtrl.GetNextItem(hNextItem, TVGN_NEXT);
	}

	return NULL;
}

void CLeftDialog::ChangeEditorDrawingId()
{
	int iEditorDrawingId = GetEditorDrawingId();
	CStringArray uiTreePathArray;
	::GetUITreePathArray(iEditorDrawingId,uiTreePathArray);

	HTREEITEM hRoot = m_treeCtrl.GetRootItem();
	HTREEITEM hFoundItem = ::GetTreeItem(m_treeCtrl,hRoot,uiTreePathArray,0);
	m_treeCtrl.SelectItem(hFoundItem);

	if(m_pStartDrawingBase != NULL)
	{
		delete m_pStartDrawingBase;
		m_pStartDrawingBase = NULL;
	}
	if(hFoundItem != NULL)
	{
		CDrawingBase *pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hFoundItem);
		if(pDrawingBase != NULL)
		{
			m_pStartDrawingBase = pDrawingBase->Clone();
		}
	}
}

int CLeftDialog::GetTreeSelectItemDrawingId() const
{
	AnimInterface *pAnimInterface =  GetAnimInterface();
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem != NULL)
	{
		CString csName = m_treeCtrl.GetItemText(hSelectItem);
		CString csParentName = ::TrackingTreeName(m_treeCtrl,hSelectItem);
		int iSelectItemDrawingId = pAnimInterface->drawing_tracking_by_name(CCharArr(csName),CCharArr(csParentName));
		return iSelectItemDrawingId;
	}
	return -1;
}

void CLeftDialog::ChangeEditorDrawingSeat(double dX,double dY,double dWidth,double dHeight,BOOL bLButtonUp)
{
	//�жϵ�ǰѡ�����Խڵ�DrawingId��UI�ؼ���ѡ��ڵ�DrawingId�Ƿ���ͬ����ͬ��ı�����λ��
	AnimInterface *pAnimInterface = ::GetAnimInterface();
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return;

	CString csName = m_treeCtrl.GetItemText(hSelectItem);
	CString csParentName = ::TrackingTreeName(m_treeCtrl,hSelectItem);

	CDrawingBase *pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hSelectItem);
	if(pDrawingBase == NULL)
		return;

	//�жϵ�ǰUI�ؼ���Ԫ����������ѡ��Ԫ���Ƿ�һ��
	BOOL bSameEditorDrawing = FALSE;
	if(hSelectItem == m_treeCtrl.GetRootItem())
	{
		const char *strName = pAnimInterface->drawing_get_name(::GetEditorDrawingId());
		if(strName != NULL)
		{
			bSameEditorDrawing = (csName == strName);
		}
	}
	else
	{
		int iSelectItemDrawingId = pAnimInterface->drawing_tracking_by_name(CCharArr(csName),CCharArr(csParentName));
		bSameEditorDrawing = (::GetEditorDrawingId() == iSelectItemDrawingId);
	}
	if(bSameEditorDrawing && (pDrawingBase != NULL))
	{
		lua_Number x = 0;
		lua_Number y = 0;

		lua_State *L = GetLuaState();
		lua_getglobal(L,"editor_calcSetPos");
		if(lua_isfunction(L,-1))
		{
			lua_pushstring(L,CCharArr(pDrawingBase->GetLuaScriptsName()));
			lua_pushnumber(L,dX);
			lua_pushnumber(L,dY);
			if(lua_pcall(L,3,2,0) == 0)
			{
				x = lua_tonumber(L,-2);
				y = lua_tonumber(L,-1);
				lua_pop(L,2);
			}
		}
		else
		{
			lua_pop(L,1);	//pop editor_calcSetPos

			static BOOL bShowMsg = TRUE;
			if(bShowMsg)
			{
				MessageBox(_T("function editor_calcSetPos not exist"),NULL,MB_ICONWARNING|MB_OK);
			}
			bShowMsg = FALSE;
		}

		pDrawingBase->SetPos((int)x,(int)y);
		pDrawingBase->SetSize((int)dWidth,(int)dHeight);

		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_DRAWING_BASE,(WPARAM)pDrawingBase,NULL);

		if(bLButtonUp)
		{
			if((m_pStartDrawingBase != NULL) && (m_pStartDrawingBase->GetDrawingType() == pDrawingBase->GetDrawingType()))
			{
				CStringArray csCurrentTrackingTreeName;
				::GetTrackingTreeName(m_treeCtrl,hSelectItem,csCurrentTrackingTreeName);

				Do(new CCmdPropNode(GetSafeHwnd(),UI_PROP_xy,m_pStartDrawingBase,pDrawingBase,csCurrentTrackingTreeName),TRUE);
/*				if(m_pStartDrawingBase != NULL)
				{
					delete m_pStartDrawingBase;
					m_pStartDrawingBase = NULL;
				}*/
			}
		}
	}
}

void CLeftDialog::ChangeUIProp(const CDrawingBase *pUIPropDrawingBase,WPARAM wParam,LPARAM lParam,BOOL bAddHistory)
{
	AnimInterface *pAnimInterface = GetAnimInterface();
	if(pAnimInterface == NULL)
		return;
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return;

	CString csName = m_treeCtrl.GetItemText(hSelectItem);
	CString csParentName = ::TrackingTreeName(m_treeCtrl,hSelectItem);

	CDrawingBase *pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hSelectItem);
	if(pDrawingBase == NULL)
		return;
	if(pDrawingBase != pUIPropDrawingBase)
		return;
	int iSelectItemDrawingId = ::DrawingTrackingByName(CCharArr(csName),CCharArr(csParentName));
	if(::GetEditorDrawingId() != iSelectItemDrawingId)
		return;

	CDrawingBase *pNewDrawingBase = pDrawingBase->Clone();
	if(pNewDrawingBase == NULL)
		return;

	EM_UI_PROP_TYPE emUIPropType = (EM_UI_PROP_TYPE)wParam;
	switch(emUIPropType)
	{
	case UI_PROP_x:
		{
			int x,y;
			if(pNewDrawingBase->GetPos(x,y))
			{
				pNewDrawingBase->SetPos(lParam,y);
//				pAnimInterface->drawing_set_position(iSelectItemDrawingId,lParam,y);
			}
		}
		break;
	case UI_PROP_y:
		{
			int x,y;
			if(pNewDrawingBase->GetPos(x,y))
			{
				pNewDrawingBase->SetPos(x,lParam);
//				pAnimInterface->drawing_set_position(iSelectItemDrawingId,x,lParam);
			}
		}
		break;
	case UI_PROP_width:
		{
			int width,height;
			if(pNewDrawingBase->GetSize(width,height))
			{
				pNewDrawingBase->SetSize(lParam,height);
//				pAnimInterface->drawing_set_size(iSelectItemDrawingId,lParam,height);
			}
		}
		break;
	case UI_PROP_height:
		{
			int width,height;
			if(pNewDrawingBase->GetSize(width,height))
			{
				pNewDrawingBase->SetSize(width,lParam);
//				pAnimInterface->drawing_set_size(iSelectItemDrawingId,width,lParam);
			}
		}
		break;
	case UI_PROP_topLeftX:
	case UI_PROP_topLeftY:
	case UI_PROP_bottomRightX:
	case UI_PROP_bottomRightY:
		{
			int iFillRegion = lParam;

			int topLeftX = 0;
			int topLeftY = 0;
			int bottomRightX = 0;
			int bottomRightY = 0;
			pNewDrawingBase->GetFillRegion(topLeftX,topLeftY,bottomRightX,bottomRightY);
			switch(emUIPropType)
			{
			case UI_PROP_topLeftX:
				topLeftX = iFillRegion;
				break;
			case UI_PROP_topLeftY:
				topLeftY = iFillRegion;
				break;
			case UI_PROP_bottomRightX:
				bottomRightX = iFillRegion;
				break;
			case UI_PROP_bottomRightY:
				bottomRightY = iFillRegion;
				break;
			default:
				break;
			}
			pNewDrawingBase->SetFillRegion(topLeftX,topLeftY,bottomRightX,bottomRightY);
//			CString csLuaScripts = pNewDrawingBase->GetLuaScriptsSetFillRegion();
//			pAnimInterface->exec_lua(CCharArr(csLuaScripts));
		}
		break;
	case UI_PROP_iAlign:
		{
			int iAlign = lParam;
			pNewDrawingBase->SetAlign(iAlign);
//			CString csLuaScripts = pNewDrawingBase->GetLuaScriptsSetAlign();
//			pAnimInterface->exec_lua(CCharArr(csLuaScripts));
		}
		break;
	case UI_PROP_bAdaptiveWidth:
	case UI_PROP_bAdaptiveHeight:
		{
			bool bAdaptive = lParam ? true : false;

			bool bAdaptiveWidth = false;
			bool bAdaptiveHeight = false;
			pNewDrawingBase->GetFillParent(bAdaptiveWidth,bAdaptiveHeight);
			switch(emUIPropType)
			{
			case UI_PROP_bAdaptiveWidth:
				bAdaptiveWidth = bAdaptive;
				break;
			case UI_PROP_bAdaptiveHeight:
				bAdaptiveHeight = bAdaptive;
				break;
			default:
				break;
			}
			pNewDrawingBase->SetFillParent(bAdaptiveWidth,bAdaptiveHeight);
//			CString csLuaScripts = pNewDrawingBase->GetLuaScriptsSetFillParent();
//			pAnimInterface->exec_lua(CCharArr(csLuaScripts));
		}
		break;
	case UI_PROP_color:
		{
			COLORREF color = lParam;
			pNewDrawingBase->SetColor(color);
//			CString csLuaScripts = pNewDrawingBase->GetLuaScriptsSetColor();
//			pAnimInterface->exec_lua(CCharArr(csLuaScripts));
		}
		break;
	case UI_PROP_alpha:
		break;
	case UI_PROP_bVisible:
		{
			bool bVisible = lParam ? true : false;
			pNewDrawingBase->SetVisible(bVisible);
//			CString csLuaScripts = pNewDrawingBase->GetLuaScriptsSetVisible();
//			pAnimInterface->exec_lua(CCharArr(csLuaScripts));
		}
		break;
	case UI_PROP_strName:
		{
			CString *pStr = (CString*)lParam;
			if(pStr == NULL)
				return;

			pNewDrawingBase->SetName(*pStr);
		}
		break;
	case UI_PROP_strLuaName:
		{
			CString *pStr = (CString*)lParam;
			if(pStr == NULL)
				return;

			pNewDrawingBase->SetPackFile(*pStr);
//			CString csLuaScripts = pNewDrawingBase->GetLuaScriptsSetPackFile();
//			pAnimInterface->exec_lua(CCharArr(csLuaScripts));
		}
		break;
	case UI_PROP_gLeft:
	case UI_PROP_gRight:
	case UI_PROP_gTop:
	case UI_PROP_gBottom:
		{
			int i9Grid = lParam;

			switch(pNewDrawingBase->GetDrawingType())
			{
			case DRAWING_TYPE_Image:
			case DRAWING_TYPE_Button:
			case DRAWING_TYPE_CheckBox:
			case DRAWING_TYPE_RadioButton:
				{
					CDrawingImage *pDrawingImage = CDrawingImage::CDrawingBaseToCDrawingImage(pNewDrawingBase);
					if(pDrawingImage != NULL)
					{
						int leftWidth = 0;
						int rightWidth = 0;
						int topWidth = 0;
						int bottomWidth = 0;
						pDrawingImage->GetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);
						switch(emUIPropType)
						{
						case UI_PROP_gLeft:
							leftWidth = i9Grid;
							break;
						case UI_PROP_gRight:
							rightWidth = i9Grid;
							break;
						case UI_PROP_gTop:
							topWidth = i9Grid;
							break;
						case UI_PROP_gBottom:
							bottomWidth = i9Grid;
							break;
						default:
							break;
						}
						pDrawingImage->SetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);
	//					CString csLuaScripts = pDrawingImage->GetLuaScriptsSetGrid9();
	//					pAnimInterface->exec_lua(CCharArr(csLuaScripts));
					}
				}
				break;
			default:
				break;
			}
		}
		break;
	case UI_PROP_csFile:
		{
			CString *pStr = (CString*)lParam;
			if(pStr == NULL)
				return;

			switch(pNewDrawingBase->GetDrawingType())
			{
			case DRAWING_TYPE_Image:
				{
					CDrawingImage *pDrawingImage = CDrawingImage::CDrawingBaseToCDrawingImage(pNewDrawingBase);
					if(pDrawingImage != NULL)
					{
						pDrawingImage->SetFile(*pStr);
	//					CString csLuaScripts = pDrawingImage->GetLuaScriptsSetFile();
	//					pAnimInterface->exec_lua(CCharArr(csLuaScripts));
					}
				}
				break;
			case DRAWING_TYPE_Button:
			case DRAWING_TYPE_CheckBox:
			case DRAWING_TYPE_RadioButton:
				{
					CDrawingButton *pDrawingButton = CDrawingButton::CDrawingBaseToCDrawingButton(pNewDrawingBase);
					if(pDrawingButton != NULL)
					{
						pDrawingButton->SetFile(*pStr);
	//					CString csLuaScripts = pDrawingButton->GetLuaScriptsSetFile();
	//					pAnimInterface->exec_lua(CCharArr(csLuaScripts));
					}
				}
				break;
			default:
				break;
			}
		}
		break;
	case UI_PROP_csFile2:
		{
			CString *pStr = (CString*)lParam;
			if(pStr == NULL)
				return;

			switch(pNewDrawingBase->GetDrawingType())
			{
			case DRAWING_TYPE_Button:
			case DRAWING_TYPE_CheckBox:
			case DRAWING_TYPE_RadioButton:
				{
					CDrawingButton *pDrawingButton = CDrawingButton::CDrawingBaseToCDrawingButton(pNewDrawingBase);
					if(pDrawingButton != NULL)
					{
						pDrawingButton->SetFile2(*pStr);
					}
				}
				break;
			default:
				break;
			}
		}
		break;
	case UI_PROP_csStr:
		{
			CStringW *pStr = (CStringW*)lParam;
			if(pStr == NULL)
				return;

			switch(pNewDrawingBase->GetDrawingType())
			{
			case DRAWING_TYPE_Text:
			case DRAWING_TYPE_EditText:
				{
					CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(pNewDrawingBase);
					if(pDrawingText != NULL)
					{
						pDrawingText->SetStr(*pStr);
					}
				}
				break;
			case DRAWING_TYPE_TextView:
			case DRAWING_TYPE_EditTextView:
				{
					CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(pNewDrawingBase);
					if(pDrawingTextView != NULL)
					{
						pDrawingTextView->SetStr(*pStr);
					}
				}
				break;
			default:
				break;
			}
		}
		break;
	case UI_PROP_csFontName:
		{
			CStringW *pStr = (CStringW*)lParam;
			if(pStr == NULL)
				return;

			switch(pNewDrawingBase->GetDrawingType())
			{
			case DRAWING_TYPE_Text:
			case DRAWING_TYPE_EditText:
				{
					CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(pNewDrawingBase);
					if(pDrawingText != NULL)
					{
						pDrawingText->SetFontName(*pStr);
					}
				}
				break;
			case DRAWING_TYPE_TextView:
			case DRAWING_TYPE_EditTextView:
				{
					CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(pNewDrawingBase);
					if(pDrawingTextView != NULL)
					{
						pDrawingTextView->SetFontName(*pStr);
					}
				}
				break;
			default:
				break;
			}
		}
		break;
	case UI_PROP_iFontSize:
		{
			int iFontSize = lParam;

			switch(pNewDrawingBase->GetDrawingType())
			{
			case DRAWING_TYPE_Text:
			case DRAWING_TYPE_EditText:
				{
					CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(pNewDrawingBase);
					if(pDrawingText != NULL)
					{
						pDrawingText->SetFontSize(iFontSize);
					}
				}
				break;
			case DRAWING_TYPE_TextView:
			case DRAWING_TYPE_EditTextView:
				{
					CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(pNewDrawingBase);
					if(pDrawingTextView != NULL)
					{
						pDrawingTextView->SetFontSize(iFontSize);
					}
				}
				break;
			default:
				break;
			}
		}
		break;
	case UI_PROP_iTextAlign:
		{
			int iTextAlign = lParam;

			switch(pNewDrawingBase->GetDrawingType())
			{
			case DRAWING_TYPE_Text:
			case DRAWING_TYPE_EditText:
				{
					CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(pNewDrawingBase);
					if(pDrawingText != NULL)
					{
						pDrawingText->SetTextAlign(iTextAlign);
					}
				}
				break;
			case DRAWING_TYPE_TextView:
			case DRAWING_TYPE_EditTextView:
				{
					CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(pNewDrawingBase);
					if(pDrawingTextView != NULL)
					{
						pDrawingTextView->SetTextAlign(iTextAlign);
					}
				}
				break;
			default:
				break;
			}
		}
		break;
	case UI_PROP_Custom:
		{
			CArray <CCustomData,CCustomData> *pCustomDataArray = (CArray <CCustomData,CCustomData> *)lParam;
			if(pCustomDataArray != NULL)
			{
				CDrawingCustomControl *pDrawingCustomControl = CDrawingCustomControl::CDrawingBaseToCDrawingCustomControl(const_cast<CDrawingBase*>(pNewDrawingBase));
				if(pDrawingCustomControl != NULL)
				{
					CArray <CCustomData,CCustomData> customDataArray;
					pDrawingCustomControl->GetCustomData(customDataArray);
					if(customDataArray.GetSize() == pCustomDataArray->GetSize())
					{
						pDrawingCustomControl->SetCustomData(*pCustomDataArray);
					}
				}
			}
		}
		break;
	default:
		break;
	}

	//ֻ����UI������ʾ�������ӵ���ʷ��¼����ʾ
	if(bAddHistory)
	{
		CStringArray csCurrentTrackingTreeName;
		::GetTrackingTreeName(m_treeCtrl,hSelectItem,csCurrentTrackingTreeName);

		CDrawingBase *pOldDrawingBase = pDrawingBase->Clone();
		*pDrawingBase = *pNewDrawingBase;

		Do(new CCmdPropNode(GetSafeHwnd(),emUIPropType,pOldDrawingBase,pDrawingBase,csCurrentTrackingTreeName),TRUE);

		if(pOldDrawingBase != NULL)
		{
			delete pOldDrawingBase;
			pOldDrawingBase = NULL;
		}
	}
	else
	{
		CStringW csLuaScripts = pNewDrawingBase->GetLuaScriptsSetAll();
		LuaInterface* pLuaInterface = GetLuaInterface();
#ifdef ExecBuffer_UTF8
		pLuaInterface->ExecBuffer(::UnicodeToUTF8(CWCharArr(csLuaScripts)));
#else
		pLuaInterface->ExecBuffer(CCharArr(csLuaScripts));
#endif
	}
	if(pNewDrawingBase != NULL)
	{
		delete pNewDrawingBase;
		pNewDrawingBase = NULL;
	}
}

//��ȡ��������
BOOL GetAbsolutePos(const char* strName,const char* strParent,double &dX,double &dY)
{
	AnimInterface *pAnimInterface = GetAnimInterface();
	if(pAnimInterface == NULL)
		return FALSE;

	int iDrawingId = pAnimInterface->drawing_tracking_by_name(strName,strParent);
	double ox,oy;
	double x,y;
	if((pAnimInterface->drawing_get_offset(iDrawingId,ox,oy) == 0)
		&& (pAnimInterface->drawing_get_position(iDrawingId,x,y) == 0))
	{
		dX = ox+x;
		dY = oy+y;
		return TRUE;
	}
	return FALSE;
}

int CLeftDialog::AddNewNode(EM_DRAWING_TYPE type,CString csDrawingTypeName,BOOL bControl,int x,int y)
{
	CStringArray csAllTreeItemName;
	GetAllTreeItemName(csAllTreeItemName);
	CString csTypeName = csDrawingTypeName.IsEmpty() ? ::GetDrawingTypeName(type) : csDrawingTypeName;
	CString csNodeName = ::GetDifferentName(csAllTreeItemName,csTypeName);

	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return -1;
	HTREEITEM hParentItem = m_treeCtrl.GetParentItem(hSelectItem);
	if(hParentItem == NULL && bControl)
	{
		AfxMessageBox(_T("��������Ϊroot��ͬ���ڵ㣬�ɿ�Ctrl�����ӵ�root���ӽڵ�"));
		return -1;
	}

	CString csItemName = m_treeCtrl.GetItemText(hSelectItem);
	CDrawingBase *pCurrentDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hSelectItem);
	if(pCurrentDrawingBase == NULL)
		return -1;
	CDrawingBase *pParentDrawingBase = NULL;
	if(hParentItem != NULL)
	{
		pParentDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hParentItem);
	}
	if(bControl && pParentDrawingBase == NULL)
		return -1;

	//CheckBox RadioBoxֻ��������CheckBoxGroup RadioBoxGroup��
	EM_DRAWING_TYPE emParentType = !bControl ? pCurrentDrawingBase->GetDrawingType() : pParentDrawingBase->GetDrawingType();
	switch(type)
	{
	case DRAWING_TYPE_CheckBox:
		{
			if(emParentType != DRAWING_TYPE_CheckBoxGroup)
			{
				MessageBox(_T("CheckBoxֻ��������CheckBoxGroup��"),NULL,MB_ICONWARNING|MB_OK);
				return -1;
			}
		}
		break;
	case DRAWING_TYPE_RadioButton:
		{
			if(emParentType != DRAWING_TYPE_RadioButtonGroup)
			{
				MessageBox(_T("RadioButtonֻ��������RadioButtonGroup��"),NULL,MB_ICONWARNING|MB_OK);
				return -1;
			}
		}
		break;
	default:
		break;
	}

	CDrawingBase *pDrawingBase = ::NewCDrawingBase(type);
	if(pDrawingBase == NULL)
		return -1;

	if(pDrawingBase->GetDrawingType() == DRAWING_TYPE_CustomControl)
	{
		CDrawingCustomControl *pDrawingCustomControl = CDrawingCustomControl::CDrawingBaseToCDrawingCustomControl(pDrawingBase);
		if(pDrawingCustomControl != NULL)
		{
			pDrawingCustomControl->SetCustomName(csDrawingTypeName);
			CArray <CCustomData,CCustomData> customDataArray;
			((CMainFrame*)AfxGetMainWnd())->GetCustomData(csDrawingTypeName,customDataArray);
			pDrawingCustomControl->SetCustomData(customDataArray);
		}
	}
/*
	int iParentsX = 0;
	int iParentsY = 0;
	if(!bControl)
	{
		::GetParentsPos(m_treeCtrl,hSelectItem,iParentsX,iParentsY);
	}
	else
	{
		::GetParentsPos(m_treeCtrl,hParentItem,iParentsX,iParentsY);
	}
*/
	pDrawingBase->SetName(csNodeName);
	::InitDrawingBase(pDrawingBase);

	HTREEITEM hTrackingParentItem = !bControl ? hSelectItem : hParentItem;
	CString csName = m_treeCtrl.GetItemText(hTrackingParentItem);
	CString csParentName = ::TrackingTreeName(m_treeCtrl,hTrackingParentItem);
	double parentX = 0;
	double parentY = 0;
	::GetAbsolutePos(CCharArr(csName),CCharArr(csParentName),parentX,parentY);
	pDrawingBase->SetPos((int)(x-parentX),(int)(y-parentY));//(x-iParentsX,y-iParentsY);

	//��סCtrl�����ӵ��ֵܽڵ� �������ӵ��ӽڵ�
//	HTREEITEM hTrackingParentItem = !bControl ? hSelectItem : hParentItem;
	HTREEITEM hTrackingPrevItem = ::GetLastChildTreeItem(m_treeCtrl,hTrackingParentItem);
	CStringArray csParentTrackingTreeName;
	CString csPrevItemName;
	::GetParentPrevTrackingTreeName(m_treeCtrl,hTrackingParentItem,hTrackingPrevItem,csParentTrackingTreeName,csPrevItemName);
	
	//����UIԪ��ʱ�������µ�Drawing Time��������ԭ��Drawing Time��ͬ
	pDrawingBase->SetTime(::GetDifferentDrawingTime(pDrawingBase->GetTime()));
	CCDrawingBaseNode *pCDrawingBaseNode = new CCDrawingBaseNode(pDrawingBase);
	Do(new CCmdAddNode(GetSafeHwnd(),pCDrawingBaseNode,csParentTrackingTreeName,csPrevItemName),TRUE);

	if(pCDrawingBaseNode != NULL)
	{
		delete pCDrawingBaseNode;
		pCDrawingBaseNode = NULL;
	}
	if(pDrawingBase != NULL)
	{
		delete pDrawingBase;
		pDrawingBase = NULL;
	}

	return 0;
}

void CLeftDialog::GetAllTreeItemName(CStringArray &csAllTreeItemName)
{
	HTREEITEM hRoot = m_treeCtrl.GetRootItem();
	::GetTreeItemName(m_treeCtrl,hRoot,csAllTreeItemName);
}

void CLeftDialog::OnStatusChange()
{
	CString str;
	str.Format(_T("  P=%03d, U=%03d, R=%03d, C=%03d  "), m_iCommandHistoryUndoPos, m_iCommandHistoryUndoCount, m_iCommandHistoryRedoCount, m_iCommandHistoryCleanCount);

	int iCommandHistoryNum = (m_iCommandHistoryUndoCount+m_iCommandHistoryRedoCount);
	
	CList <int,int> iHistoryTypeList;
	CStringList csHistoryNameList;
	int i;
	int iCommandHistoryUndoPos = m_iCommandHistoryUndoPos;
	for(i=0; i<m_iCommandHistoryUndoCount; i++)
	{
		int iHistoryType = -1;
		CString csHistoryName;
		iCommandHistoryUndoPos = ICommandHistory::PrevPos(iCommandHistoryUndoPos);
		if(m_commandHistory[iCommandHistoryUndoPos] != NULL)
		{
			iHistoryType = m_commandHistory[iCommandHistoryUndoPos]->GetID()-1;
			m_commandHistory[iCommandHistoryUndoPos]->Sprint(csHistoryName);
		}

		iHistoryTypeList.AddHead(iHistoryType);
		csHistoryNameList.AddHead(csHistoryName);
	}
	iCommandHistoryUndoPos = m_iCommandHistoryUndoPos;
	for(i=0; i<m_iCommandHistoryRedoCount; i++)
	{
		int iHistoryType = -1;
		CString csHistoryName;
		if(m_commandHistory[iCommandHistoryUndoPos] != NULL)
		{
			iHistoryType = m_commandHistory[iCommandHistoryUndoPos]->GetID()-1;
			m_commandHistory[iCommandHistoryUndoPos]->Sprint(csHistoryName);
		}
		iCommandHistoryUndoPos = ICommandHistory::NextPos(iCommandHistoryUndoPos);

		iHistoryTypeList.AddTail(iHistoryType);
		csHistoryNameList.AddTail(csHistoryName);
	}

	CArray <int,int> iTypeArr;
	CStringArray csHistoryNameArr;

	POSITION typePosition = iHistoryTypeList.GetHeadPosition();
	POSITION namePosition = csHistoryNameList.GetHeadPosition();
	for(i=0; i<csHistoryNameList.GetCount(); i++)
	{
		iTypeArr.Add(iHistoryTypeList.GetAt(typePosition));
		iHistoryTypeList.GetNext(typePosition);

		csHistoryNameArr.Add(csHistoryNameList.GetAt(namePosition));
		csHistoryNameList.GetNext(namePosition);
	}

	((CMainFrame*)AfxGetMainWnd())->UpdateHistory(m_iCommandHistoryUndoPos,m_iCommandHistoryUndoCount,m_iCommandHistoryRedoCount,iTypeArr,csHistoryNameArr);
}

void CLeftDialog::OnCommandExecute(const CCommand* pCmd)
{
	CString strLabel;
	pCmd->Sprint(strLabel);
	CString str;
	str.Format(_T("Last command: %s"), strLabel);

//	((CMainFrame*)AfxGetMainWnd())->UpdateStatusBarPane1(str);
}

void CLeftDialog::OnBnClickedOk()
{
}


void CLeftDialog::OnBnClickedCancel()
{
}

DWORD ThreadSaveXML(LPVOID lpParameter)
{
	CCopyTreeData *pCopyTreeData = (CCopyTreeData*)lpParameter;
	if(pCopyTreeData == NULL)
		return -1;

	while(TRUE)
	{
		MSG msg;
		if(::PeekMessage(&msg,NULL,0,0,PM_REMOVE))
		{
			if(msg.message == WM_QUIT)
				break;

			::TranslateMessage(&msg);
			::DispatchMessage(&msg);
		}

		if(pCopyTreeData->IsLoadData())
		{
			pCopyTreeData->SaveData();

			CString csSelDirectoryName = pCopyTreeData->GetSelDirecotryName();
			CString csSelFileName = pCopyTreeData->GetSelFileName();
			CCDrawingBaseNode *pCDrawingBaseNode = pCopyTreeData->CloneData();
			if(pCDrawingBaseNode != NULL)
			{
				CString csFileName = csSelFileName.Left(csSelFileName.GetLength()-4);
				CString csXmlDirectory = TMP_DIRECTORY+_T("\\")+csSelDirectoryName+_T("\\")+csFileName+_T("_bak");
				::CreateMultipleDirectory(csXmlDirectory);
				CTime time = CTime::GetCurrentTime();
				CString csXmlFilePath;
				csXmlFilePath.Format(_T("%s\\%s_%04d-%02d-%02d-%02d-%02d-%02d.xml"),csXmlDirectory,csFileName,
					time.GetYear(),time.GetMonth(),time.GetDay(),time.GetHour(),time.GetMinute(),time.GetSecond());

				::save_xml(CCharArr(csXmlFilePath),pCDrawingBaseNode);

				delete pCDrawingBaseNode;
				pCDrawingBaseNode = NULL;
			}
		}
		Sleep(100);
	}

	return 0;
}

BOOL CLeftDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	m_ImageList.Create(16,16, ILC_COLOR24 | ILC_MASK,0,0);
	CBitmap bitmap;
	bitmap.LoadBitmap(IDB_BITMAP_TREE);
	m_ImageList.Add(&bitmap,RGB(255,255,255));
//	m_ImageList.Create(IDB_BITMAP_TREE, 16, 0, RGB(255, 0, 255));
	m_treeCtrl.SetImageList(&m_ImageList,TVSIL_NORMAL);

	CString csSelDirectoryName;
	CString csSelFileName;
	csSelDirectoryName = theApp.m_Config.m_group.c_str();
	csSelFileName = theApp.m_Config.m_xml.c_str();

	LoadXml(csSelDirectoryName,csSelFileName);

	SetTimer(TIMER_COPY_TREE_DATA,60*1000,NULL);

	m_hSaveXMLThread = ::CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)ThreadSaveXML,(LPVOID)&m_copyTreeData,0,&m_dwSaveXMLThreadId);

	m_toolTipCtrl.Create(this);
	m_toolTipCtrl.SetMaxTipWidth(200);
	m_toolTipCtrl.AddTool(&m_treeCtrl,_T("�϶��ڵ�ʱ\r\n�Ȱ�סShift�������԰ѽڵ��϶�ΪĿ����ӽڵ㣻\r\n�Ȱ�סCTRL�������԰ѽڵ��϶�ΪĿ�����һ��ͬ���ڵ�"));

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CLeftDialog::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	if(m_treeCtrl.m_hWnd != NULL)
	{
		CRect clientRect;
		GetClientRect(clientRect);
		m_treeCtrl.MoveWindow(clientRect);
	}
}

void CLeftDialog::OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/)
{
}

void CLeftDialog::OnTimer(UINT_PTR nIDEvent)
{
	switch(nIDEvent)
	{
	case TIMER_COPY_TREE_DATA:
		{
			if(m_bCopyTreeModifyData)
			{
				m_bCopyTreeModifyData = FALSE;
				m_copyTreeData.LoadData(m_csSelDirectoryName,m_csSelFileName,m_treeCtrl);
			}
		}
		break;
	default:
		break;
	}

	__super::OnTimer(nIDEvent);
}

void CLeftDialog::OnNMClickTree(NMHDR *pNMHDR, LRESULT *pResult)
{
}

void CLeftDialog::OnNMRClickTree(NMHDR *pNMHDR, LRESULT *pResult)
{
	CPoint point;
	GetCursorPos(&point);
	m_treeCtrl.ScreenToClient(&point);
	UINT tflag;
	HTREEITEM hItem = m_treeCtrl.HitTest(point, &tflag);
	CString strDependency;
	if ( (NULL != hItem) && ( tflag & TVHT_ONITEMLABEL ))
	{
		m_treeCtrl.SelectItem(hItem);
	}

	BOOL bClickItem = (hItem != NULL);
	CDrawingBase *pDrawingBase = NULL;
	if(hItem != NULL)
	{
		pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hItem);
	}
	EM_DRAWING_TYPE emDrawingType = (EM_DRAWING_TYPE)-1;
	if(pDrawingBase != NULL)
	{
		emDrawingType = pDrawingBase->GetDrawingType();
	}

	CMenu xmlMenu;
	xmlMenu.LoadMenu(IDR_MENU_XML);
	CMenu *pSubXmlMenu = xmlMenu.GetSubMenu(0);
	//ɾ���Ҽ������ӽڵ㹦��
	pSubXmlMenu->DeleteMenu(0,MF_BYPOSITION);
	pSubXmlMenu->DeleteMenu(0,MF_BYPOSITION);
/*	switch(emDrawingType)
	{
	case DRAWING_TYPE_RadioButtonGroup:
	case DRAWING_TYPE_CheckBoxGroup:
		{
			int nID = (emDrawingType == DRAWING_TYPE_RadioButtonGroup) ? ID_XML_ADD_RADIO_BOX : ID_XML_ADD_CHECK_BOX;
			pSubXmlMenu->DeleteMenu(0,MF_BYPOSITION);
			pSubXmlMenu->ModifyMenu(0,MF_BYPOSITION|MF_STRING, nID, _T("����")+::GetDrawingTypeName(emDrawingType));
		}
		break;
	default:
		break;
	}*/
	CMenu menu;
	menu.Attach(pSubXmlMenu->m_hMenu);

	BOOL bRoot = (m_treeCtrl.GetParentItem(hItem) != NULL);
	menu.EnableMenuItem(ID_XML_RENAME,!bRoot);
	menu.EnableMenuItem(ID_XML_DELETE,!bRoot);
	menu.EnableMenuItem(ID_EDIT_CUT,!IsCanCut());
	menu.EnableMenuItem(ID_EDIT_COPY,!IsCanCopy());
	menu.EnableMenuItem(ID_EDIT_PASTE,!IsCanPaste());
	menu.EnableMenuItem(ID_EDIT_PASTE_CHILD,!IsCanPaste());
	menu.EnableMenuItem(ID_SAVE_CUSTOM,!bRoot);
//	menu.EnableMenuItem(ID_LOAD_CUSTOM,!bRoot);
	menu.EnableMenuItem(ID_XML_RELOAD,bRoot);
	menu.EnableMenuItem(ID_XML_EXPORT,bRoot);
	menu.EnableMenuItem(ID_XML_EXPORT_ADV,bRoot);

	CPoint screenPoint;
	::GetCursorPos(&screenPoint);
	menu.TrackPopupMenu(TPM_LEFTALIGN |TPM_RIGHTBUTTON,screenPoint.x,screenPoint.y,this);
}


void ReCreateWellText ( int iDrawingId)
{
	AnimInterface *pAnimInterface = GetAnimInterface();

	if ( -1 == iDrawingId ) return;
	double ox,oy;
	pAnimInterface->drawing_get_offset(iDrawingId,ox,oy);
	double x1,y1,w1,h1;
	pAnimInterface->drawing_get_rect(iDrawingId,x1,y1,w1,h1);
	x1 += ox;
	y1 += oy;
	ReCreateWellText((int)x1,(int)y1,(int)(x1+w1),(int)(y1+h1),::GetWellRed(),::GetWellGreen(),::GetWellBlue());

}

//
int DrawingTrackingByName(const char* strName,const char* strParent)
{
	AnimInterface *pAnimInterface = GetAnimInterface();
	if(pAnimInterface == NULL)
		return -1;

	int iEditorDrawingId = ::GetEditorDrawingId();
	//�жϵ�ǰ�Ƿ�����Ϊroot�ڵ�
	if((CString(strName) == _T("root")) && CString(strParent).IsEmpty())
	{
		int iRootDrawingId = iEditorDrawingId;
		CString csName = pAnimInterface->drawing_get_name(iRootDrawingId);
		while ( true )
		{
			if(csName == _T("root"))
				break;

			iRootDrawingId = pAnimInterface->drawing_get_parent(iRootDrawingId);
			csName = pAnimInterface->drawing_get_name(iRootDrawingId);
			if ( -1 == iRootDrawingId )
			{
				break;
			}
		}
		return iRootDrawingId;
	}
	else
	{
		return pAnimInterface->drawing_tracking_by_name(strName,strParent);
	}
}
/*
void SendCmdFlash(CStringW csLuaScriptName)
{
	AnimInterface *pAnimInterface = GetAnimInterface();
	if(pAnimInterface == NULL)
		return;

	lua_Integer iDrawingId = -1;

	lua_State *L = GetLuaState();
	lua_getglobal(L,"editor_getDrawingId");
	if(lua_isfunction(L,-1))
	{
		lua_pushstring(L,CCharArr(csLuaScriptName));
		if(lua_pcall(L,1,1,0) == 0)
		{
			iDrawingId = lua_tointeger(L,-1);
			lua_pop(L,1);
		}
	}
	else
	{
		lua_pop(L,1);
	}

	int iEditorDrawingId = iDrawingId;
	::SetEditorDrawingId(iEditorDrawingId);

	if ( -1 != iEditorDrawingId )
	{
		double fx,fy,fw,fh;
		pAnimInterface->drawing_get_rect(iEditorDrawingId,fx,fy,fw,fh);

		if ( ::GetShowWell() )
		{
			ReCreateWellText(iEditorDrawingId);
		}
	}
	else
	{
		DeleteWellText();
	}
}
*/
void SendCmdFlash(const char* strName,const char* strParent)
{
	AnimInterface *pAnimInterface = GetAnimInterface();
	if ( 0 != pAnimInterface )
	{
		int iEditorDrawingId = ::DrawingTrackingByName(strName,strParent);
		::SetEditorDrawingId(iEditorDrawingId);

		if ( -1 != iEditorDrawingId )
		{
			double fx,fy,fw,fh;
			pAnimInterface->drawing_get_rect(iEditorDrawingId,fx,fy,fw,fh);

			if ( ::GetShowWell() )
			{
				ReCreateWellText(iEditorDrawingId);
			}
		}
		else
		{
			DeleteWellText();
		}
	}
}

void CLeftDialog::SelectChangedTree()
{
	CDrawingBase *pDrawingBase = NULL;
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem != NULL)
	{
		pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hSelectItem);

		CString csName = m_treeCtrl.GetItemText(hSelectItem);
		CString csParentName = ::TrackingTreeName(m_treeCtrl,hSelectItem);
		::SendCmdFlash(CCharArr(csName),CCharArr(csParentName));
	}
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_DRAWING_BASE,(WPARAM)pDrawingBase,NULL);
}

void CLeftDialog::OnTvnSelchangedTree(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);

	SelectChangedTree();

	*pResult = 0;
}

void CLeftDialog::OnTvnSelchangingTree(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);

	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_TREE_SELCHANGING,NULL,NULL);

	*pResult = 0;
}

void GetBrotherNames(CMapStringToString &brotherNames, CXTreeCtrl &treeCtrl, HTREEITEM hItem)
{
	brotherNames.RemoveAll();
	brotherNames.SetAt(_T("root"),_T("root"));

	HTREEITEM hPrevItem = hItem;
	while(hPrevItem != NULL)
	{
		CString strText = treeCtrl.GetItemText(hPrevItem);
		brotherNames.SetAt(strText,strText);
		hPrevItem = treeCtrl.GetPrevSiblingItem(hPrevItem);
	}
	HTREEITEM hNextItem = hItem;
	while (hNextItem != NULL)
	{
		CString strText = treeCtrl.GetItemText(hNextItem);
		brotherNames.SetAt(strText,strText);
		hNextItem = treeCtrl.GetNextSiblingItem(hNextItem);
	}
}

void GetChildsNames(CMapStringToString &childsNames, CXTreeCtrl &treeCtrl, HTREEITEM hItem )
{
	childsNames.RemoveAll();
	childsNames.SetAt(_T("root"),_T("root"));

	HTREEITEM hChildItem = treeCtrl.GetChildItem(hItem);

	if (treeCtrl.ItemHasChildren(hItem))
	{
		while (hChildItem != NULL)
		{
			CString strText = treeCtrl.GetItemText(hChildItem);
			childsNames.SetAt(strText,strText);
			hChildItem = treeCtrl.GetNextSiblingItem(hChildItem);
		}
	}
}

void CLeftDialog::XMLAddView()
{
	HTREEITEM hItem = m_treeCtrl.GetSelectedItem();

	CMapStringToString childsNames;
	::GetChildsNames(childsNames,m_treeCtrl,hItem);

	CString strDependency;
	if ( strDependency.GetLength() > 0 )
	{
		CDialogName dlg;
		dlg.SetCompareName2(&childsNames);
		EnableKeyHook(true);
		if ( IDOK != dlg.DoModal())
		{
			EnableKeyHook(true);
			return;
		}
		EnableKeyHook(true);
		CString strName = dlg.GetName();
		CString strViewName = strDependency;
	}
	else
	{
		CDialogName2 dlg2;
		dlg2.SetCompareName2(&childsNames);
		EnableKeyHook(false);
		if ( IDOK != dlg2.DoModal())
		{
			EnableKeyHook(true);
			return;
		}
		EnableKeyHook(true);
		CString strName = dlg2.GetName();
		CString strViewName = dlg2.GetViewName();

		XMLAddDrawingBase(::GetDrawingType(strViewName),strName);
	}
}

void CLeftDialog::XMLAddName(EM_DRAWING_TYPE type)
{
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return;

	CMapStringToString childsNames;
	::GetChildsNames(childsNames,m_treeCtrl,hSelectItem);

	CDialogName dlg;
	dlg.SetCompareName2(&childsNames);
	EnableKeyHook(false);
	if ( IDOK != dlg.DoModal())
	{
		EnableKeyHook(true);
		return;
	}
	EnableKeyHook(true);
	CString strName = dlg.GetName();

	XMLAddDrawingBase(type,strName);
}

void CLeftDialog::XMLAddDrawingBase(EM_DRAWING_TYPE type,CString strName)
{
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return;
	CDrawingBase *pCurrentDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hSelectItem);
	if(pCurrentDrawingBase == NULL)
		return;

	CDrawingBase *pDrawingBase = ::NewCDrawingBase(type);
	if(pDrawingBase == NULL)
		return;

	pDrawingBase->SetName(strName);
	::InitDrawingBase(pDrawingBase);


	HTREEITEM hTrackingParentItem = hSelectItem;
	HTREEITEM hTrackingPrevItem = ::GetLastChildTreeItem(m_treeCtrl,hTrackingParentItem);
	CStringArray csParentTrackingTreeName;
	CString csPrevItemName;
	::GetParentPrevTrackingTreeName(m_treeCtrl,hTrackingParentItem,hTrackingPrevItem,csParentTrackingTreeName,csPrevItemName);
	
	//����UIԪ��ʱ�������µ�Drawing Time��������ԭ��Drawing Time��ͬ
	pDrawingBase->SetTime(::GetDifferentDrawingTime(pDrawingBase->GetTime()));
	CCDrawingBaseNode *pCDrawingBaseNode = new CCDrawingBaseNode(pDrawingBase);
	Do(new CCmdAddNode(GetSafeHwnd(),pCDrawingBaseNode,csParentTrackingTreeName,csPrevItemName),TRUE);
	if(pCDrawingBaseNode != NULL)
	{
		delete pCDrawingBaseNode;
		pCDrawingBaseNode = NULL;
	}
	if(pDrawingBase != NULL)
	{
		delete pDrawingBase;
		pDrawingBase = NULL;
	}
}

void CLeftDialog::XMLAddImage()
{
	XMLAddName(DRAWING_TYPE_Image);
}

void CLeftDialog::XMLAddText()
{
	XMLAddName(DRAWING_TYPE_Text);
}

void CLeftDialog::XMLAddTextView()
{
	XMLAddName(DRAWING_TYPE_TextView);
}

void CLeftDialog::XMLAddEditText()
{
	XMLAddName(DRAWING_TYPE_EditText);
}

void CLeftDialog::XMLAddEditTextView()
{
	XMLAddName(DRAWING_TYPE_EditTextView);
}

void CLeftDialog::XMLAddButton()
{
	XMLAddName(DRAWING_TYPE_Button);
}

void CLeftDialog::XMLReload()
{
	if(m_bModifyData)
	{
		CString strMsg = _T("���¼��ؽ���ʧδ������޸�,ȷ�����¼�����? ");
		int mb = MessageBox(strMsg,NULL,MB_YESNO|MB_ICONQUESTION);
		if ( IDNO == mb )
			return;
	}

	LoadXml(m_csSelDirectoryName,m_csSelFileName);

	((CMainFrame*)AfxGetMainWnd())->UpdateStatusBarPane1(_T("���¼���XML"));
}

void CLeftDialog::XMLExport()
{
	EnableKeyHook(false);
	DoExport(-1.0f);
	EnableKeyHook(true);
}

void CLeftDialog::DoExport ( double scale )
{
	BOOL bSaveAs = FALSE;
	if ( scale < 0 )
	{
		scale = 1.0f;
		bSaveAs = TRUE;
	}
	const TCHAR szFilter[] = _T("XML Files (*.xml)|*.xml|All Files (*.*)|*.*||");
	const TCHAR szExt[] = _T("xml");

	CFileDialog dlg(FALSE, szExt, _T(""), 
		OFN_READONLY |OFN_NONETWORKBUTTON, szFilter, this);

	CString csScriptsDirectory = SCRIPTS_DIRECTORY;
	if ( bSaveAs )
	{
		dlg.m_ofn.lpstrTitle = _T("����Ϊxml�ļ�");
		//CString str1 = theApp.GetGroupsPath() + _T("\\") + m_strGroup + _T("\\");
		//dlg.m_ofn.lpstrInitialDir = theApp.GetGroupsPath() + _T("\\") + m_strGroup + _T("\\");
		dlg.m_ofn.lpstrInitialDir = csScriptsDirectory;
	}
	else
	{
		dlg.m_ofn.lpstrTitle = _T("����Ϊxml�ļ�");
		dlg.m_ofn.lpstrInitialDir = csScriptsDirectory;
	}
	

	EnableKeyHook(false);
	if(dlg.DoModal() == IDOK)
	{
		CString strExport = dlg.GetPathName();
		CString strXml = EDITOR_DIRECTORY + _T("\\") + m_csSelDirectoryName + _T("\\") + m_csSelFileName;
		int size = export_xml(CCharArr(strXml),CCharArr(strExport),scale);
		if ( size < 0 )
		{
			CString strMsg;
			if ( bSaveAs )
			{
				strMsg.Format(_T("����Ϊ��%s��\r\n\r\n����%s��ʧ��."),strXml.LockBuffer(),strExport.LockBuffer());
			}
			else
			{
				strMsg.Format(_T("������%s��\r\n\r\n����%s��ʧ��."),strXml.LockBuffer(),strExport.LockBuffer());
			}
			
			strXml.UnlockBuffer();
			strExport.UnlockBuffer();
			AfxMessageBox(strMsg);
		}
		else
		{
			CString strMsg;
			if ( bSaveAs )
			{
				strMsg.Format(_T("����Ϊ��%s��\r\n\r\n����%s���ɹ�."),strXml.LockBuffer(),strExport.LockBuffer());
			}
			else
			{
				strMsg.Format(_T("������%s��\r\n\r\n����%s���ɹ�."),strXml.LockBuffer(),strExport.LockBuffer());
			}
			
			strXml.UnlockBuffer();
			strExport.UnlockBuffer();
			AfxMessageBox(strMsg);
		}
	}
	EnableKeyHook(true);
}

void CLeftDialog::XMLExportAdv()
{
	CDialogWHScale dlg;
	EnableKeyHook(false);
	if ( IDOK == dlg.DoModal())
	{
		double scale = dlg.m_scale;
		DoExport(scale);
	}
	EnableKeyHook(true);
}

void CLeftDialog::XMLRename()
{
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
	{
		AfxMessageBox(_T("δѡ�нڵ�"));
		return;
	}
	HTREEITEM hParentItem = m_treeCtrl.GetParentItem(hSelectItem);
	if(hParentItem == NULL)
	{
		AfxMessageBox(_T("����������root�ڵ�"));
		return;
	}

	if(hSelectItem != NULL && hSelectItem != m_treeCtrl.GetRootItem())
	{
		m_bTreeNodeReName = TRUE;
		m_treeCtrl.EditLabel(hSelectItem);
	}
/*
	CString csNodeName = m_treeCtrl.GetItemText(hSelectItem);
	CDrawingBase *pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hSelectItem);
	if(pDrawingBase == NULL)
		return;

	CMapStringToString brotherNames;
	::GetBrotherNames(brotherNames,m_treeCtrl,hSelectItem);
	CDialogName dlg;
	dlg.SetInitName(csNodeName);
	dlg.SetCompareName2(&brotherNames);
	EnableKeyHook(false);
	if ( IDOK != dlg.DoModal())
	{
		EnableKeyHook(true);
		return;
	}
	EnableKeyHook(true);
	CString strName = dlg.GetName();

	ChangeUIProp(pDrawingBase,UI_PROP_strName,(LPARAM)&strName,TRUE);
*/
/*	CDrawingBase *pOldDrawingBase = pDrawingBase->Clone();
	//
	pDrawingBase->SetName(strName);

	CStringArray csCurrentTrackingTreeName;
	::GetTrackingTreeName(m_treeCtrl,hSelectItem,csCurrentTrackingTreeName);
	Do(new CCmdPropNode(GetSafeHwnd(),pOldDrawingBase,pDrawingBase,csCurrentTrackingTreeName),TRUE);
	if(pOldDrawingBase != NULL)
	{
		delete pOldDrawingBase;
		pOldDrawingBase = NULL;
	}
*/
}

BOOL CLeftDialog::IsCanDelete()
{
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return FALSE;
	HTREEITEM hParentItem = m_treeCtrl.GetParentItem(hSelectItem);
	if(hParentItem == NULL)
		return FALSE;

	return TRUE;
}

void CLeftDialog::Delete()
{
	XMLDelete();
}

void CLeftDialog::XMLDelete()
{
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
	{
		AfxMessageBox(_T("δѡ�нڵ�"));
		return;
	}
	HTREEITEM hParentItem = m_treeCtrl.GetParentItem(hSelectItem);
	if(hParentItem == NULL)
	{
		AfxMessageBox(_T("����ɾ��root�ڵ�"));
		return;
	}

	CString csNodeName = m_treeCtrl.GetItemText(hSelectItem);
	CString strMsg = _T("ȷ��Ҫɾ�� ") + csNodeName + _T(" ?\r\n\r\n����������Ѿ�ʹ���˴˶���,ɾ��֮��ᵼ�³����޷�����!");
	int mb = MessageBox(strMsg,NULL,MB_OKCANCEL | MB_ICONWARNING);
	if (mb != IDOK)
		return;

	CString strName = m_treeCtrl.GetItemText(hSelectItem);

	DeleteSelectItem();
}

BOOL CLeftDialog::DeleteSelectItem()
{
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return FALSE;
	HTREEITEM hParentItem = m_treeCtrl.GetParentItem(hSelectItem);
	if(hParentItem == NULL)
		return FALSE;

	HTREEITEM hTrackingParentItem = hParentItem;
	HTREEITEM hTrackingPrevItem = m_treeCtrl.GetPrevSiblingItem(hSelectItem);
	CStringArray csParentTrackingTreeName;
	CString csPrevItemName;
	::GetParentPrevTrackingTreeName(m_treeCtrl,hTrackingParentItem,hTrackingPrevItem,csParentTrackingTreeName,csPrevItemName);
	CDrawingBase *pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hSelectItem);
	if(pDrawingBase == NULL)
		return FALSE;

	CCDrawingBaseNode *pCDrawingBaseNode = new CCDrawingBaseNode(pDrawingBase);
	::GetCDrawingBaseNode(m_treeCtrl,hSelectItem,pCDrawingBaseNode);
	Do(new CCmdDeleteNode(GetSafeHwnd(),pCDrawingBaseNode,csParentTrackingTreeName,csPrevItemName),TRUE);
	if(pCDrawingBaseNode != NULL)
	{
		delete pCDrawingBaseNode;
		pCDrawingBaseNode = NULL;
	}
/*
	CString strName = m_treeCtrl.GetItemText(hSelectItem);
	CDrawingBase *pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hSelectItem);
	if(pDrawingBase == NULL)
		return FALSE;
	CDrawingBase *pParentDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hParentItem);
	if(pParentDrawingBase == NULL)
		return FALSE;

	AnimInterface *pAnimInterface =  GetAnimInterface();
	CString csLuaScripts = ::GetLuaScriptsRemoveChild(pParentDrawingBase,pDrawingBase);
	pAnimInterface->exec_lua(CCharArr(csLuaScripts));

	m_treeCtrl.DeleteItem(hSelectItem);

	delete pDrawingBase;
	pDrawingBase = NULL;
*/
	return TRUE;
}

void SetClipboardData(HWND hWnd,CString csString)
{
	UINT format = ::RegisterClipboardFormat(_T("CUSTOM_FORMAT"));
	if(::OpenClipboard(hWnd))
	{
		EmptyClipboard();
		HGLOBAL clipBuffer = GlobalAlloc(GMEM_DDESHARE, sizeof(TCHAR)*(csString.GetLength()+1));
		LPVOID pGlobal = GlobalLock(clipBuffer);
		memcpy(pGlobal,(void*)(LPCTSTR)csString,sizeof(TCHAR)*(csString.GetLength()+1));
		GlobalUnlock(clipBuffer);
		SetClipboardData(format,clipBuffer);
		CloseClipboard();
	}
}

BOOL GetClipboardData(HWND hWnd,CString &csString)
{
	UINT format = RegisterClipboardFormat(_T("CUSTOM_FORMAT"));
	if(::OpenClipboard(hWnd))
	{
		HANDLE hData = GetClipboardData(format);
		LPVOID pGlobal = GlobalLock(hData);
		int iSize = GlobalSize(pGlobal);
		TCHAR *pString = (iSize > 0) ? (new TCHAR[iSize]) : NULL;
		if(pString != NULL)
		{
			memcpy(pString,pGlobal,iSize);
		}
		GlobalUnlock(hData);
		CloseClipboard();

		if(pString != NULL)
		{
			csString = pString;

			delete pString;
			pString = NULL;
			return TRUE;
		}
	}
	return FALSE;
}

void CLeftDialog::XMLCut()
{
	if(!IsCanCut())
		return;

	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return;

	CString strName = m_treeCtrl.GetItemText(hSelectItem);

	XMLCopy();
	DeleteSelectItem();

	((CMainFrame*)AfxGetMainWnd())->UpdateStatusBarPane1(_T("���нڵ�:")+strName);
}

void CLeftDialog::XMLCopy()
{
	if(!IsCanCopy())
		return;


	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return;

	if(m_pCopyDrawingBaseNode != NULL)
	{
		delete m_pCopyDrawingBaseNode;
		m_pCopyDrawingBaseNode = NULL;
	}

	CDrawingBase *pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hSelectItem);
	m_pCopyDrawingBaseNode = new CCDrawingBaseNode(pDrawingBase);
	::GetCDrawingBaseNode(m_treeCtrl,hSelectItem,m_pCopyDrawingBaseNode);

/*	xmlDocPtr xmlDoc = xmlNewDoc(BAD_CAST XML_DEFAULT_VERSION);
	if(xmlDoc == NULL)
		return;
	int iRet = nest_save_xml(m_treeCtrl,hSelectItem,xmlDoc,0);
	if ( iRet > 0 )
	{
		xmlChar *pXmlChar = NULL;
		int size = 0;
		xmlDocDumpMemoryEnc(xmlDoc,&pXmlChar,&size,"utf-8");

		if(pXmlChar != NULL)
		{
			::SetClipboardData(GetSafeHwnd(),CString(pXmlChar));
		}
	}
	xmlFreeDoc(xmlDoc);
*/
	CString strName = m_treeCtrl.GetItemText(hSelectItem);
	((CMainFrame*)AfxGetMainWnd())->UpdateStatusBarPane1(_T("���ƽڵ�:")+strName);
}

void CLeftDialog::XMLPaste(BOOL bChild)
{
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return;
	if(!bChild && (hSelectItem == m_treeCtrl.GetRootItem()))
	{
		AfxMessageBox(_T("����ճ��Ϊroot��ͬ���ڵ�"));
		return;
	}

	AddCCDrawingBaseNode(m_pCopyDrawingBaseNode,hSelectItem,bChild);

/*
	//ճ��������������Ϣ
	if(m_pCopyDrawingBaseNode != NULL)
	{
		delete m_pCopyDrawingBaseNode;
		m_pCopyDrawingBaseNode = NULL;
	}*/

/*
	CString csString;
	::GetClipboardData(GetSafeHwnd(),csString);
	if(csString.IsEmpty())
		return;

	CCharArr szString = csString;
	int iParseError=0;
	xmlKeepBlanksDefault(0);
	xmlDocPtr pDoc = xmlReadMemory(szString ,strlen(szString),"","UTF-8",XML_PARSE_RECOVER);
	if(pDoc == NULL)
		return;
	xmlNodePtr pRoot = xmlDocGetRootElement(pDoc);
	if(pRoot == NULL)
		return;
	nest_load_xml(m_treeCtrl,hSelectItem,pRoot,iParseError);
	xmlFreeDoc(pDoc);
	xmlCleanupParser();
	if ( 1 == iParseError )
		return;
*/

	((CMainFrame*)AfxGetMainWnd())->UpdateStatusBarPane1(_T("ճ���ڵ�"));
}

void CLeftDialog::Cut()
{
	XMLCut();
}

void CLeftDialog::Copy()
{
	XMLCopy();
}

void CLeftDialog::Paste()
{
	XMLPaste(FALSE);
}

void CLeftDialog::Undo()
{
	if(IsCanUndo())
	{
		ICommandHistory::Undo();
	}
}

void CLeftDialog::Redo()
{
	if(IsCanRedo())
	{
		ICommandHistory::Redo();
	}
}

BOOL CLeftDialog::IsCanCut()
{
	if(m_treeCtrl.m_hWnd == NULL)
		return FALSE;

	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return FALSE;

	if(hSelectItem == m_treeCtrl.GetRootItem())
		return FALSE;

	return TRUE;
}

BOOL CLeftDialog::IsCanCopy()
{
	if(m_treeCtrl.m_hWnd == NULL)
		return FALSE;

	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return FALSE;

	if(hSelectItem == m_treeCtrl.GetRootItem())
		return FALSE;

	return TRUE;
}

BOOL CLeftDialog::IsCanPaste()
{
	return (m_pCopyDrawingBaseNode != NULL);
/*
	CString csString;
	::GetClipboardData(GetSafeHwnd(),csString);
	return !csString.IsEmpty();*/
}

BOOL CLeftDialog::IsCanUndo()
{
	return ICommandHistory::CanUndo();
}

BOOL CLeftDialog::IsCanRedo()
{
	return ICommandHistory::CanRedo();
}

void CLeftDialog::SetHistory(int iCommandHistoryPos)
{
	if(iCommandHistoryPos < m_iCommandHistoryUndoCount)
	{
		int iUndoNum = (m_iCommandHistoryUndoCount-iCommandHistoryPos);
		int i;
		for(i=0; i<iUndoNum; i++)
		{
			if(IsCanUndo())
				Undo();
		}
	}
	else if(iCommandHistoryPos > m_iCommandHistoryUndoCount)
	{
		int iRedoNum = (iCommandHistoryPos-m_iCommandHistoryUndoCount);
		int i;
		for(i=0; i<iRedoNum; i++)
		{
			if(IsCanRedo())
				Redo();
		}
	}
}

void CLeftDialog::XMLSaveCustom()
{
	const TCHAR szFilter[] = _T("XML Files (*.xml)|*.xml|All Files (*.*)|*.*||");
	const TCHAR szExt[] = _T("xml");
	CFileDialog dlg(FALSE, szExt, _T(""), OFN_READONLY |OFN_NONETWORKBUTTON, szFilter, this);
	CString csScriptsDirectory = SCRIPTS_DIRECTORY;
	dlg.m_ofn.lpstrTitle = _T("�����ؼ�Ϊxml�ļ�");
	dlg.m_ofn.lpstrInitialDir = csScriptsDirectory;
	if(dlg.DoModal() != IDOK)
		return;
	CString csFilePath = dlg.GetPathName();

	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return;

	xmlKeepBlanksDefault(0);
	xmlIndentTreeOutput = 1;
	xmlDocPtr xmlDoc = xmlNewDoc(BAD_CAST XML_DEFAULT_VERSION);
	if(xmlDoc == NULL)
		return;
	int iRet = nest_save_xml(m_treeCtrl,hSelectItem,xmlDoc,0);
	if ( iRet > 0 )
	{
		iRet = xmlSaveFormatFileEnc(CCharArr(csFilePath), xmlDoc, "utf-8", 1);
	}
	xmlFreeDoc(xmlDoc);
}

BOOL CLeftDialog::AddCCDrawingBaseNode(CCDrawingBaseNode *pCDrawingBaseNode,HTREEITEM hItem,BOOL bChild)
{
	if(pCDrawingBaseNode == NULL)
		return FALSE;

	if(hItem == NULL)
		return FALSE;

	CCDrawingBaseNode *pAddCDrawingBaseNode = pCDrawingBaseNode->Clone();
	//�ж��Ƿ����������������������ɽڵ�����
	CDrawingBase *pDrawingBase = pAddCDrawingBaseNode->GetCDrawingBase();
	if(pDrawingBase != NULL)
	{
		CStringArray csAllTreeItemName;
		GetAllTreeItemName(csAllTreeItemName);
		CString csName;
		pDrawingBase->GetName(csName);
		if(::IsNameInArray(csName,csAllTreeItemName))
		{
			CString csNodeName = ::GetDifferentName(csAllTreeItemName,csName);//pDrawingBase->GetDrawingTypeName());
			pDrawingBase->SetName(csNodeName);
		}
	}

	//����UIԪ��ʱ�������µ�Drawing Time��������ԭ��Drawing Time��ͬ
	int iSize = pAddCDrawingBaseNode->GetAllCDrawingBaseNum();
	CArray <long,long> lTimeArray;
	::GetDifferentDrawingTime(iSize,lTimeArray);
	int index = 0;
	pAddCDrawingBaseNode->ResetDrawingTime(lTimeArray,index);

	//ճ�����ӽڵ���ֵܽڵ�
	if(bChild)
	{
		HTREEITEM hTrackingParentItem = hItem;
		HTREEITEM hTrackingPrevItem = ::GetLastChildTreeItem(m_treeCtrl,hTrackingParentItem);
		CStringArray csParentTrackingTreeName;
		CString csPrevItemName;
		::GetParentPrevTrackingTreeName(m_treeCtrl,hTrackingParentItem,hTrackingPrevItem,csParentTrackingTreeName,csPrevItemName);

		Do(new CCmdAddNode(GetSafeHwnd(),pAddCDrawingBaseNode,csParentTrackingTreeName,csPrevItemName),TRUE);
	}
	else
	{
		HTREEITEM hTrackingParentItem = m_treeCtrl.GetParentItem(hItem);
		HTREEITEM hTrackingPrevItem = hItem;
		CStringArray csParentTrackingTreeName;
		CString csPrevItemName;
		::GetParentPrevTrackingTreeName(m_treeCtrl,hTrackingParentItem,hTrackingPrevItem,csParentTrackingTreeName,csPrevItemName);

		Do(new CCmdAddNode(GetSafeHwnd(),pAddCDrawingBaseNode,csParentTrackingTreeName,csPrevItemName),TRUE);
	}
	if(pAddCDrawingBaseNode != NULL)
	{
		delete pAddCDrawingBaseNode;
		pAddCDrawingBaseNode = NULL;
	}

	return TRUE;
}

void CLeftDialog::XMLLoadCustom()
{
	const TCHAR szFilter[] = _T("XML Files (*.xml)|*.xml|All Files (*.*)|*.*||");
	const TCHAR szExt[] = _T("xml");
	CFileDialog dlg(TRUE, szExt, _T(""), OFN_READONLY |OFN_NONETWORKBUTTON, szFilter, this);
	CString csScriptsDirectory = SCRIPTS_DIRECTORY;
	dlg.m_ofn.lpstrTitle = _T("�����Զ���ؼ�");
	dlg.m_ofn.lpstrInitialDir = csScriptsDirectory;
	if(dlg.DoModal() != IDOK)
		return;
	CString csFilePath = dlg.GetPathName();

	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hSelectItem == NULL)
		return;

	CCDrawingBaseNode *pLoadCDrawingBaseNode = NULL;
	::load_xml(CCharArr(csFilePath),&pLoadCDrawingBaseNode);

	AddCCDrawingBaseNode(pLoadCDrawingBaseNode,hSelectItem,TRUE);

	if(pLoadCDrawingBaseNode != NULL)
	{
		delete pLoadCDrawingBaseNode;
		pLoadCDrawingBaseNode = NULL;
	}

/*	int iParseError=0;
	xmlKeepBlanksDefault(0);
	xmlDocPtr pDoc = xmlReadFile(CCharArr(csFilePath) ,"UTF-8",XML_PARSE_RECOVER);
	if(pDoc == NULL)
		return;
	xmlNodePtr pRoot = xmlDocGetRootElement(pDoc);
	if(pRoot == NULL)
		return;
	nest_load_xml(m_treeCtrl,hSelectItem,pRoot,iParseError);
	xmlFreeDoc(pDoc);
	xmlCleanupParser();
	if ( 1 == iParseError )
		return;*/
}

BOOL CLeftDialog::OnCommand(WPARAM wParam, LPARAM lParam)
{
	switch(wParam)
	{
	case ID_XML_ADD_VIEW:
		XMLAddView();
		break;
	case ID_XML_ADD_IMAGE:
		XMLAddImage();
		break;
	case ID_XML_ADD_TEXT:
		XMLAddText();
		break;
	case ID_XML_ADD_TEXTVIEW:
		XMLAddTextView();
		break;
	case ID_XML_ADD_EDITTEXT:
		XMLAddEditText();
		break;
	case ID_XML_ADD_EDITTEXTVIEW:
		XMLAddEditTextView();
		break;
	case ID_XML_ADD_BUTTON:
		XMLAddButton();
		break;
	case ID_XML_ADD_RADIO_BOX:
		XMLAddName(DRAWING_TYPE_RadioButton);
		break;
	case ID_XML_ADD_CHECK_BOX:
		XMLAddName(DRAWING_TYPE_CheckBox);
		break;
	case ID_XML_RELOAD:
		XMLReload();
		break;
	case ID_XML_EXPORT:
		XMLExport();
		break;
	case ID_XML_EXPORT_ADV:
		XMLExportAdv();
		break;
	case ID_XML_RENAME:
		XMLRename();
		break;
	case ID_XML_DELETE:
		XMLDelete();
		break;
	case ID_EDIT_CUT:
		XMLCut();
		break;
	case ID_EDIT_COPY:
		XMLCopy();
		break;
	case ID_EDIT_PASTE:
		XMLPaste(FALSE);
		break;
	case ID_EDIT_PASTE_CHILD:
		XMLPaste(TRUE);
		break;
	case ID_SAVE_CUSTOM:
		XMLSaveCustom();
		break;
	case ID_LOAD_CUSTOM:
		XMLLoadCustom();
		break;
	default:
		break;
	}

	return CDialogEx::OnCommand(wParam, lParam);
}

LRESULT CLeftDialog::MessageTreeItemMoveNext(WPARAM wParam,LPARAM lParam)
{
	HTREEITEM hItemDragS = (HTREEITEM)wParam;
	HTREEITEM hItemDragD = (HTREEITEM)lParam;
	if(hItemDragS == NULL || hItemDragD == NULL)
		return -1;

	CDrawingBase *pDrawingBaseS = (CDrawingBase*)m_treeCtrl.GetItemData(hItemDragS);
	CDrawingBase *pDrawingBaseD = (CDrawingBase*)m_treeCtrl.GetItemData(hItemDragD);
	if(pDrawingBaseS == NULL || pDrawingBaseD == NULL)
		return -1;

	HTREEITEM hParentItem = m_treeCtrl.GetParentItem(hItemDragD);
	if(hParentItem == NULL)
		return -1;
	CDrawingBase *pParentDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hParentItem);
	if(pParentDrawingBase == NULL)
		return -1;

	HTREEITEM hTrackingParentItem = m_treeCtrl.GetParentItem(hItemDragS);
	HTREEITEM hTrackingPrevItem = m_treeCtrl.GetPrevSiblingItem(hItemDragS);
	CStringArray csParentTrackingTreeName;
	CString csPrevItemName;
	::GetParentPrevTrackingTreeName(m_treeCtrl,hTrackingParentItem,hTrackingPrevItem,csParentTrackingTreeName,csPrevItemName);
	HTREEITEM hMoveTrackingParentItem = m_treeCtrl.GetParentItem(hItemDragD);
	HTREEITEM hMoveTrackingPrevItem = hItemDragD;//ע���ƶ���Ŀ�Ľڵ����һ�ֵܽڵ� ��ǰ���ֵܽڵ㼴ΪĿ�Ľڵ�
	CStringArray csMoveParentTrackingTreeName;
	CString csMovePrevItemName;
	::GetParentPrevTrackingTreeName(m_treeCtrl,hMoveTrackingParentItem,hMoveTrackingPrevItem,csMoveParentTrackingTreeName,csMovePrevItemName);

	CCDrawingBaseNode *pCDrawingBaseNode = new CCDrawingBaseNode(pDrawingBaseS);
	::GetCDrawingBaseNode(m_treeCtrl,hItemDragS,pCDrawingBaseNode);
	Do(new CCmdMoveNode(GetSafeHwnd(),pCDrawingBaseNode,csParentTrackingTreeName,csPrevItemName,csMoveParentTrackingTreeName,csMovePrevItemName),TRUE);
	if(pCDrawingBaseNode != NULL)
	{
		delete pCDrawingBaseNode;
		pCDrawingBaseNode = NULL;
	}

	return 1;
}

LRESULT CLeftDialog::MessageTreeItemMoveChild(WPARAM wParam,LPARAM lParam)
{
	HTREEITEM hItemDragS = (HTREEITEM)wParam;
	HTREEITEM hItemDragD = (HTREEITEM)lParam;
	if(hItemDragS == NULL || hItemDragD == NULL)
		return -1;

	CDrawingBase *pDrawingBaseS = (CDrawingBase*)m_treeCtrl.GetItemData(hItemDragS);
	CDrawingBase *pDrawingBaseD = (CDrawingBase*)m_treeCtrl.GetItemData(hItemDragD);
	if(pDrawingBaseS == NULL || pDrawingBaseD == NULL)
		return -1;

	HTREEITEM hTrackingParentItem = m_treeCtrl.GetParentItem(hItemDragS);
	HTREEITEM hTrackingPrevItem = m_treeCtrl.GetPrevSiblingItem(hItemDragS);
	CStringArray csParentTrackingTreeName;
	CString csPrevItemName;
	::GetParentPrevTrackingTreeName(m_treeCtrl,hTrackingParentItem,hTrackingPrevItem,csParentTrackingTreeName,csPrevItemName);
	HTREEITEM hMoveTrackingParentItem = hItemDragD;//ע���ƶ���Ŀ�Ľڵ���ӽڵ� ��ǰ���ֵܽڵ�ΪĿ�Ľڵ�����һ���ӽڵ�
	HTREEITEM hMoveTrackingPrevItem = ::GetLastChildTreeItem(m_treeCtrl,hItemDragD);
	CStringArray csMoveParentTrackingTreeName;
	CString csMovePrevItemName;
	::GetParentPrevTrackingTreeName(m_treeCtrl,hMoveTrackingParentItem,hMoveTrackingPrevItem,csMoveParentTrackingTreeName,csMovePrevItemName);

	CCDrawingBaseNode *pCDrawingBaseNode = new CCDrawingBaseNode(pDrawingBaseS);
	::GetCDrawingBaseNode(m_treeCtrl,hItemDragS,pCDrawingBaseNode);
	Do(new CCmdMoveNode(GetSafeHwnd(),pCDrawingBaseNode,csParentTrackingTreeName,csPrevItemName,csMoveParentTrackingTreeName,csMovePrevItemName),TRUE);
	if(pCDrawingBaseNode != NULL)
	{
		delete pCDrawingBaseNode;
		pCDrawingBaseNode = NULL;
	}
/*
	AnimInterface *pAnimInterface = GetAnimInterface();
	CString csLuaScripts = ::GetLuaScriptsAddChild(pDrawingBaseD,pDrawingBaseS);
	pAnimInterface->exec_lua(CCharArr(csLuaScripts));

	CStringArray csSourceTrackingTreeName;
	CStringArray csDestTrackingTreeName;
	::GetTrackingTreeName(m_treeCtrl,hItemDragS,csSourceTrackingTreeName);
	::GetTrackingTreeName(m_treeCtrl,hItemDragD,csDestTrackingTreeName);
*/

	return 1;
}

BOOL CLeftDialog::CmdAddNode(CCmdAddNode *pCmdAddNode)
{
	if(pCmdAddNode == NULL)
		return FALSE;

	CCDrawingBaseNode *pCDrawingBaseNode = pCmdAddNode->GetCDrawingBaseNode();
	CStringArray csParentTrackingTreeName;
	pCmdAddNode->GetParentTrackingTreeName(csParentTrackingTreeName);
	CString csPrevItemName = pCmdAddNode->GetPrevItemName();
	BOOL bAddChild = csPrevItemName.IsEmpty();

	if(pCDrawingBaseNode == NULL)
		return FALSE;

	HTREEITEM hRoot = m_treeCtrl.GetRootItem();
	HTREEITEM hCurrentItem = ::GetTreeItem(m_treeCtrl,hRoot,csParentTrackingTreeName,0);
	if(hCurrentItem == NULL)
		return FALSE;

	CDrawingBase *pNodeDrawingBase = pCDrawingBaseNode->GetCDrawingBase();
	if(pNodeDrawingBase == NULL)
		return FALSE;

	CDrawingBase *pDrawingBase = pNodeDrawingBase->Clone();
	if(pDrawingBase == NULL)
		return FALSE;

	CString csNodeName;
	pDrawingBase->GetName(csNodeName);
	int iImageId = ::GetImageId(pDrawingBase);
	CDrawingBase *pCurrentDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hCurrentItem);
	HTREEITEM hNewItem = NULL;
	if(bAddChild)
	{
		::AddNodeToUIEditor(pCurrentDrawingBase,pDrawingBase);

		hNewItem = m_treeCtrl.InsertItem(csNodeName,iImageId,iImageId,hCurrentItem,TVI_FIRST);
	}
	else
	{
		::AddNodeToUIEditor(pCurrentDrawingBase,pDrawingBase);

		csParentTrackingTreeName.Add(csPrevItemName);
		HTREEITEM hPrevItem = ::GetTreeItem(m_treeCtrl,hRoot,csParentTrackingTreeName,0);
		hNewItem = m_treeCtrl.InsertItem(csNodeName,iImageId,iImageId,hCurrentItem,hPrevItem);
	}
	if(hNewItem != NULL)
	{
		m_treeCtrl.SetItemData(hNewItem,(DWORD_PTR)pDrawingBase);
		m_treeCtrl.SelectItem(hNewItem);
	}

	int i;
	for(i=0; i<pCDrawingBaseNode->GetCDrawingBaseNodeChildNum(); i++)
	{
		AddCopyDrawingBaseNodeToChild(m_treeCtrl,hNewItem,pCDrawingBaseNode->GetCDrawingBaseNode(i));
	}

	//���µ�����ǰ�ڵ����ڲ��level
	ResetLevel(hCurrentItem);

	return TRUE;
}

BOOL CLeftDialog::CmdDeleteNode(CCmdDeleteNode *pCmdDeleteNode)
{
	if(pCmdDeleteNode == NULL)
		return FALSE;

	CCDrawingBaseNode *pCDrawingBaseNode = pCmdDeleteNode->GetCDrawingBaseNode();
	CStringArray csParentTrackingTreeName;
	pCmdDeleteNode->GetParentTrackingTreeName(csParentTrackingTreeName);
	CString csPrevItemName = pCmdDeleteNode->GetPrevItemName();

	if(pCDrawingBaseNode == NULL)
		return FALSE;

	HTREEITEM hRoot = m_treeCtrl.GetRootItem();
	HTREEITEM hCurrentItem = ::GetTreeItem(m_treeCtrl,hRoot,csParentTrackingTreeName,0);
	if(hCurrentItem == NULL)
		return FALSE;

	CDrawingBase *pNodeDrawingBase = pCDrawingBaseNode->GetCDrawingBase();
	if(pNodeDrawingBase == NULL)
		return FALSE;

	CString csNodeName;
	pNodeDrawingBase->GetName(csNodeName);
	csParentTrackingTreeName.Add(csNodeName);
	HTREEITEM hDeleteItem = ::GetTreeItem(m_treeCtrl,hRoot,csParentTrackingTreeName,0);
	if(hDeleteItem == NULL)
		return FALSE;

	CDrawingBase *pParentDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hCurrentItem);
	if(pParentDrawingBase == NULL)
		return FALSE;
	CDrawingBase *pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hDeleteItem);
	if(pDrawingBase == NULL)
		return FALSE;

	AnimInterface *pAnimInterface =  GetAnimInterface();
	CStringW csLuaScripts = ::GetLuaScriptsRemoveChild(pParentDrawingBase,pDrawingBase);
	LuaInterface* pLuaInterface = GetLuaInterface();
#ifdef ExecBuffer_UTF8
	pLuaInterface->ExecBuffer(::UnicodeToUTF8(CWCharArr(csLuaScripts)));
#else
	pLuaInterface->ExecBuffer(CCharArr(csLuaScripts));
#endif

	::DeleteItemData(m_treeCtrl,hDeleteItem);
	m_treeCtrl.DeleteItem(hDeleteItem);

	//���µ�����ǰ�ڵ����ڲ��level
	ResetLevel(hCurrentItem);

	return TRUE;
}

BOOL CLeftDialog::CmdPropNode(CCmdPropNode *pCmdPropNode)
{
	if(pCmdPropNode == NULL)
		return FALSE;

	CDrawingBase *pOldDrawingBase = pCmdPropNode->GetOldDrawingBase();
	CDrawingBase *pNewDrawingBase = pCmdPropNode->GetNewDrawingBase();
	if(pOldDrawingBase == NULL)
		return FALSE;
	if(pNewDrawingBase == NULL)
		return FALSE;
	CStringArray csCurrentTrackingTreeName;
	pCmdPropNode->GetCurrentTrackingTreeName(csCurrentTrackingTreeName);
	//�ڵ����������
	csCurrentTrackingTreeName.RemoveAt(csCurrentTrackingTreeName.GetSize()-1);
	CString csOldName;
	pOldDrawingBase->GetName(csOldName);
	csCurrentTrackingTreeName.Add(csOldName);

	HTREEITEM hRoot = m_treeCtrl.GetRootItem();
	HTREEITEM hCurrentItem = ::GetTreeItem(m_treeCtrl,hRoot,csCurrentTrackingTreeName,0);
	if(hCurrentItem == NULL)
		return FALSE;

	CDrawingBase *pCurrentDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hCurrentItem);
	if(pCurrentDrawingBase == NULL)
		return FALSE;

	*pCurrentDrawingBase = *pNewDrawingBase;

	AnimInterface *pAnimInterface = GetAnimInterface();

	//�޸�CheckBox,RadioButtonͼƬ���޸�������Ϣ��luaδ�ṩ�޸Ľӿڣ�����ɾ�������´���
	BOOL bReCreate = FALSE;
/*	switch(pCurrentDrawingBase->GetDrawingType())
	{
	case DRAWING_TYPE_CheckBox:
	case DRAWING_TYPE_RadioButton:
	case DRAWING_TYPE_Text:
	case DRAWING_TYPE_TextView:
	case DRAWING_TYPE_EditTextView:
	case DRAWING_TYPE_EditText:*/
		{
			HTREEITEM hParentItem = m_treeCtrl.GetParentItem(hCurrentItem);
			if(hParentItem != NULL)
			{
				CDrawingBase *pParentDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hParentItem);
				if(pParentDrawingBase != NULL)
				{
					CStringW csLuaScripts = pNewDrawingBase->GetLuaScriptsRecreate();//::GetLuaScriptsRemoveChild(pParentDrawingBase,pNewDrawingBase);
					LuaInterface* pLuaInterface = GetLuaInterface();
#ifdef ExecBuffer_UTF8
					pLuaInterface->ExecBuffer(::UnicodeToUTF8(CWCharArr(csLuaScripts)));
#else
					pLuaInterface->ExecBuffer(CCharArr(csLuaScripts));
#endif

					bReCreate = TRUE;
				}
			}
		}
/*		break;
	default:
		break;
	}*/
	if(!bReCreate)
	{
		CStringW csLuaScripts = pNewDrawingBase->GetLuaScriptsSetAll();
		LuaInterface* pLuaInterface = GetLuaInterface();
#ifdef ExecBuffer_UTF8
		pLuaInterface->ExecBuffer(::UnicodeToUTF8(CWCharArr(csLuaScripts)));
#else
		pLuaInterface->ExecBuffer(CCharArr(csLuaScripts));
#endif
	}

	//�޸����� ͬʱ�޸����ڵ�����
	if(pCmdPropNode->GetUiPropType() == UI_PROP_strName)
	{
		CString strName;
		pNewDrawingBase->GetName(strName);
		m_treeCtrl.SetItemText(hCurrentItem,strName);
	}
/*
	HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
	if(hCurrentItem == hSelectItem)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_DRAWING_BASE,(WPARAM)pCurrentDrawingBase,NULL);
	}*/

	//���µ�����ǰ�ڵ����ڲ��level
	ResetLevel(hCurrentItem);

	return TRUE;
}

BOOL CLeftDialog::CmdMoveNode(CCmdMoveNode *pCmdMoveNode)
{
	if(pCmdMoveNode == NULL)
		return FALSE;

	CCDrawingBaseNode *pCDrawingBaseNode = pCmdMoveNode->GetCDrawingBaseNode();
	CStringArray csParentTrackingTreeName;
	pCmdMoveNode->GetParentTrackingTreeName(csParentTrackingTreeName);
	CString csPrevItemName = pCmdMoveNode->GetPrevItemName();
	CStringArray csMoveParentTrackingTreeName;
	pCmdMoveNode->GetMoveParentTrackingTreeName(csMoveParentTrackingTreeName);
	CString csMovePrevItemName = pCmdMoveNode->GetMovePrevItemName();

	if(pCDrawingBaseNode == NULL)
		return FALSE;

	CDrawingBase* pDrawingBase = pCDrawingBaseNode->GetCDrawingBase();
	if(pDrawingBase == NULL)
		return FALSE;

	CString csNodeName;
	pDrawingBase->GetName(csNodeName);

	HTREEITEM hRoot = m_treeCtrl.GetRootItem();
	HTREEITEM hCtrlParentS = ::GetTreeItem(m_treeCtrl,hRoot,csParentTrackingTreeName,0);
	csParentTrackingTreeName.Add(csNodeName);
	HTREEITEM hItemDragS = ::GetTreeItem(m_treeCtrl,hRoot,csParentTrackingTreeName,0);
	if(hItemDragS == NULL)
		return FALSE;
	HTREEITEM hCtrlParentD = ::GetTreeItem(m_treeCtrl,hRoot,csMoveParentTrackingTreeName,0);
	if(hCtrlParentD == NULL)
		return FALSE;
	csMoveParentTrackingTreeName.Add(csMovePrevItemName);
	HTREEITEM hItemDragD = ::GetTreeItem(m_treeCtrl,hRoot,csMoveParentTrackingTreeName,0);

	CDrawingBase *pParentDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hCtrlParentD);
	if(pParentDrawingBase == NULL)
		return FALSE;
	CDrawingBase *pDrawingBaseS = (CDrawingBase*)m_treeCtrl.GetItemData(hItemDragS);
	if(pDrawingBaseS == NULL)
		return FALSE;

	HTREEITEM htiNew = m_treeCtrl.CopyBranch(hItemDragS,hCtrlParentD,hItemDragD);
	m_treeCtrl.DeleteItem(hItemDragS);
	m_treeCtrl.SelectItem(htiNew);

	AnimInterface *pAnimInterface = GetAnimInterface();
	CStringW csLuaScripts = ::GetLuaScriptsAddChild(pParentDrawingBase,pDrawingBaseS);
	LuaInterface* pLuaInterface = GetLuaInterface();
#ifdef ExecBuffer_UTF8
	pLuaInterface->ExecBuffer(::UnicodeToUTF8(CWCharArr(csLuaScripts)));
#else
	pLuaInterface->ExecBuffer(CCharArr(csLuaScripts));
#endif

	//���µ�����ǰ�ڵ����ڲ��level
	ResetLevel(htiNew);

	return TRUE;
}

void CLeftDialog::ResetLevel(HTREEITEM hItem)
{
	if(hItem == NULL)
		return;

	HTREEITEM hParentItem = m_treeCtrl.GetParentItem(hItem);
	if(hParentItem == NULL)
		return;

	CDrawingBase *pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hParentItem);
	if(pDrawingBase == NULL)
		return;

	CCDrawingBaseNode *pCDrawingBaseNode = new CCDrawingBaseNode(pDrawingBase);
	::GetCDrawingBaseNode(m_treeCtrl,hParentItem,pCDrawingBaseNode);
	if(pCDrawingBaseNode != NULL)
	{
		int iLevel = 0;

		int i;
		for(i=0; i<pCDrawingBaseNode->GetCDrawingBaseNodeChildNum(); i++)
		{
			CCDrawingBaseNode *pCDrawingBaseNodeChild = pCDrawingBaseNode->GetCDrawingBaseNode(i);
			if(pCDrawingBaseNodeChild == NULL)
				continue;

			CDrawingBase *pChildDrawingBase = pCDrawingBaseNodeChild->GetCDrawingBase();
			if(pChildDrawingBase == NULL)
				continue;

			AnimInterface *pAnimInterface = GetAnimInterface();
			CStringW csLuaScripts = pChildDrawingBase->GetLuaScriptsSetLevel(iLevel);
			LuaInterface* pLuaInterface = GetLuaInterface();
#ifdef ExecBuffer_UTF8
			pLuaInterface->ExecBuffer(::UnicodeToUTF8(CWCharArr(csLuaScripts)));
#else
			pLuaInterface->ExecBuffer(CCharArr(csLuaScripts));
#endif

			iLevel++;
		}
	}
	if(pCDrawingBaseNode != NULL)
	{
		delete pCDrawingBaseNode;
		pCDrawingBaseNode = NULL;
	}
}

LRESULT CLeftDialog::MessageCmdNodeChange(WPARAM wParam,LPARAM lParam)
{
	CCommand *pCommand = (CCommand*)wParam;

	CString strLabel = _T("NodeChange");
	pCommand->Sprint(strLabel);
	((CMainFrame*)AfxGetMainWnd())->UpdateStatusBarPane1(strLabel);

	switch(pCommand->GetID())
	{
	case CMD_ADD_NODE:
		{
			CmdAddNode((CCmdAddNode*)pCommand);

			m_bModifyData = TRUE;
			m_bCopyTreeModifyData = TRUE;
		}
		break;
	case CMD_DELETE_NODE:
		{
			CmdDeleteNode((CCmdDeleteNode*)pCommand);

			m_bModifyData = TRUE;
			m_bCopyTreeModifyData = TRUE;
		}
		break;
	case CMD_PROP_NODE:
		{
			CmdPropNode((CCmdPropNode*)pCommand);

			m_bModifyData = TRUE;
			m_bCopyTreeModifyData = TRUE;
		}
		break;
	case CMD_MOVE_NODE:
		{
			CmdMoveNode((CCmdMoveNode*)pCommand);

			m_bModifyData = TRUE;
			m_bCopyTreeModifyData = TRUE;
		}
		break;
	default:
		break;
	}

	SelectChangedTree();

	return 0;
}


BOOL CLeftDialog::TreeKeyDown(WPARAM wParam,LPARAM lParam)
{
	BOOL bCtrl = (GetAsyncKeyState(VK_CONTROL) < 0);
	switch(wParam)
	{
	case 'x':
	case 'X':
		if(bCtrl)
		{
			Cut();
		}
		break;
	case 'c':
	case 'C':
		if(bCtrl)
		{
			Copy();
		}
		break;
	case 'v':
	case 'V':
		if(bCtrl)
		{
			Paste();
		}
		break;
	case 'z':
	case 'Z':
		if(bCtrl)
		{
			Undo();
		}
		break;
	case 'y':
	case 'Y':
		if(bCtrl)
		{
			Redo();
		}
		break;
	case VK_DELETE:
		{
			Delete();
		}
		break;
	case VK_F2:
		{
			HTREEITEM hSelectItem = m_treeCtrl.GetSelectedItem();
			if(hSelectItem != NULL && hSelectItem != m_treeCtrl.GetRootItem())
			{
				m_bTreeNodeReName = TRUE;
				m_treeCtrl.EditLabel(hSelectItem);
			}
		}
		break;
	default:
		break;
	}
	return FALSE;
}

BOOL CLeftDialog::TreeEditKeyDown(WPARAM wParam,LPARAM lParam)
{
	switch(wParam)
	{
	case VK_ESCAPE:
	case VK_TAB:
	case VK_RETURN:
		{
			BOOL bCancleWithoutSave = (wParam == VK_ESCAPE);
			m_treeCtrl.EndEditLabelNow(bCancleWithoutSave);
			return TRUE;
		}
		break;
	default:
		break;
	}
	return FALSE;
}

BOOL CLeftDialog::PreTranslateMessage(MSG* pMsg)
{
	switch(pMsg->message)
	{
	case WM_LBUTTONDOWN:
		{
		}
		break;
	case WM_KEYDOWN:
		{
			CEdit *pEdit = m_treeCtrl.GetEditControl();
			if(pMsg->hwnd == m_treeCtrl.m_hWnd)
			{
				if(TreeKeyDown(pMsg->wParam,pMsg->lParam))
					return TRUE;
			}
			else if((pEdit != NULL) && (pEdit->m_hWnd == pMsg->hwnd))
			{
				if(TreeEditKeyDown(pMsg->wParam,pMsg->lParam))
					return TRUE;
			}
		}
		break;
	default:
		break;
	}

	m_toolTipCtrl.RelayEvent(pMsg);

	return __super::PreTranslateMessage(pMsg);
}


void CLeftDialog::OnNMCustomdrawTree(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);

	LPNMTVCUSTOMDRAW pCustomDraw = (LPNMTVCUSTOMDRAW)pNMHDR;
	switch (pCustomDraw->nmcd.dwDrawStage)
	{
	case CDDS_PREPAINT:
		{
			// Need to process this case and set pResult to CDRF_NOTIFYITEMDRAW, 
			// otherwise parent will never receive CDDS_ITEMPREPAINT notification. (GGH) 
			*pResult = CDRF_NOTIFYITEMDRAW;
			return;
		}
		break;
	case CDDS_ITEMPREPAINT:
		if(IsWindowEnabled())
		{
			if ((pCustomDraw->nmcd.uItemState & (CDIS_FOCUS))==0
				&&(pCustomDraw->nmcd.uItemState & (CDIS_SELECTED))==CDIS_SELECTED) // selected
			{ 
				pCustomDraw->clrTextBk=RGB(255, 255, 255);
				pCustomDraw->clrText = RGB(0, 0, 0);
			}
			*pResult = CDRF_NOTIFYPOSTPAINT;
			return;
		}
		else
		{
			*pResult = CDRF_DODEFAULT ;
			return;
		}
		break;
	case CDDS_ITEMPOSTPAINT:
		if(IsWindowEnabled())
		{
			if ((pCustomDraw->nmcd.uItemState & (CDIS_FOCUS))==0
				&&(pCustomDraw->nmcd.uItemState & (CDIS_SELECTED))==CDIS_SELECTED) // selected
			{
				CRect rcText;  
				HTREEITEM hItem=(HTREEITEM) pCustomDraw->nmcd.dwItemSpec;
				m_treeCtrl.GetItemRect(hItem, &rcText,true); 
				CString csText = m_treeCtrl.GetItemText(hItem);
				
				CDC* pDC = CDC::FromHandle(pCustomDraw->nmcd.hdc);
				pDC->SetBkMode(TRANSPARENT);
				pDC->FillRect(&rcText,&CBrush(RGB(51,153,255)));
				COLORREF oldTextColor = pDC->SetTextColor(RGB(255,255,255));
				pDC->TextOut(rcText.left+2,rcText.top+2,csText);
				pDC->SetTextColor(oldTextColor);
			}
			*pResult = CDRF_SKIPDEFAULT;
			return;
		}
		else
		{
			*pResult = CDRF_DODEFAULT ;
			return;
		}
		break;
	default:
		break;
	}
	
	*pResult = 0;
}

void CLeftDialog::OnTvnBeginlabeleditTree(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTVDISPINFO pTVDispInfo = reinterpret_cast<LPNMTVDISPINFO>(pNMHDR);

	if(m_bTreeNodeReName)
	{
		*pResult = 0;
	}
	else
	{
		*pResult = -1;
	}
}


void CLeftDialog::OnTvnEndlabeleditTree(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMTVDISPINFO pTVDispInfo = reinterpret_cast<LPNMTVDISPINFO>(pNMHDR);

	m_bTreeNodeReName = FALSE;

	if(pTVDispInfo->item.pszText != NULL)
	{
		HTREEITEM hSelectItem = pTVDispInfo->item.hItem;

		CString strName = pTVDispInfo->item.pszText;

		if(strName == m_treeCtrl.GetItemText(hSelectItem))
		{
			*pResult = 0;
			return;
		}

		BOOL bRename = TRUE;

		CMapStringToString brotherNames;
		::GetBrotherNames(brotherNames,m_treeCtrl,hSelectItem);
		CString strValue;
		if(strName.IsEmpty())
		{
			bRename = FALSE;
			MessageBox(_T("���Ʋ���Ϊ��."),NULL,MB_ICONWARNING|MB_OK);
		}
		if(brotherNames.Lookup(strName,strValue))
		{
			bRename = FALSE;
			MessageBox(_T("�������ѱ�ʹ��."),NULL,MB_ICONWARNING|MB_OK);
		}
		if(!check_name(strName,FALSE))
		{
			bRename = FALSE;
			MessageBox(_T("������Ӣ����ĸ��ͷ,�����ֺ��»���."),NULL,MB_ICONWARNING|MB_OK);
		}
		if(bRename)
		{
			CDrawingBase *pDrawingBase = (CDrawingBase*)m_treeCtrl.GetItemData(hSelectItem);
			if(pDrawingBase != NULL)
			{
				ChangeUIProp(pDrawingBase,UI_PROP_strName,(LPARAM)&strName,TRUE);
			}
		}
	}

	*pResult = 0;
}

