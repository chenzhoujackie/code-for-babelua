// OutputConfigDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "OutputConfigDialog.h"
#include "afxdialogex.h"

#include "RightDialog.h"

BOOL IsDrawingTypeInArr(EM_DRAWING_TYPE emDrawingType,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr)
{
	int i;
	for(i=0; i<emDrawingTypeArr.GetSize(); i++)
	{
		if(emDrawingType == emDrawingTypeArr[i])
			return TRUE;
	}
	return FALSE;
}

BOOL WriteOutputConfigDrawingType(EM_DRAWING_TYPE emDrawingType,BOOL bData)
{
	return ::WritePrivateProfileString(_T("OutputConfig"),::GetDrawingTypeName(emDrawingType),::IntToCString(bData),SETTING_FILE_PATH);
}

BOOL GetOutputConfigDrawingType(EM_DRAWING_TYPE emDrawingType)
{
	return ::GetPrivateProfileInt(_T("OutputConfig"),::GetDrawingTypeName(emDrawingType),FALSE,SETTING_FILE_PATH);
}

BOOL WriteIsOutputConfig()
{
	return ::WritePrivateProfileString(_T("OutputConfig"),_T("IsOutputConfig"),::IntToCString(TRUE),SETTING_FILE_PATH);
}

BOOL GetIsOutputConfig()
{
	return ::GetPrivateProfileInt(_T("OutputConfig"),_T("IsOutputConfig"),FALSE,SETTING_FILE_PATH);
}


// COutputConfigDialog �Ի���

IMPLEMENT_DYNAMIC(COutputConfigDialog, CDialogEx)

COutputConfigDialog::COutputConfigDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(COutputConfigDialog::IDD, pParent)
{
	m_bLeafNode = FALSE;
}

COutputConfigDialog::~COutputConfigDialog()
{
}

void COutputConfigDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST, m_listBox);
}


BEGIN_MESSAGE_MAP(COutputConfigDialog, CDialogEx)
	ON_BN_CLICKED(IDOK, &COutputConfigDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDC_BUTTON_FILE_PATH, &COutputConfigDialog::OnBnClickedButtonFilePath)
END_MESSAGE_MAP()


// COutputConfigDialog ��Ϣ��������

void COutputConfigDialog::InitData(CString csOutputPath)
{
	m_csOutputPath = csOutputPath;
}

CString COutputConfigDialog::GetOutputPath() const
{
	return m_csOutputPath;
}

BOOL COutputConfigDialog::GetLeafNode() const
{
	return m_bLeafNode;
}

void COutputConfigDialog::GetDrawingTypeArr(CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr) const
{
	emDrawingTypeArr.SetSize(m_emDrawingTypeArr.GetSize());
	int i;
	for(i=0; i<emDrawingTypeArr.GetSize(); i++)
	{
		emDrawingTypeArr[i] = m_emDrawingTypeArr[i];
	}
}

BOOL IsInitOutputType(EM_DRAWING_TYPE type)
{
	switch(type)
	{
	case DRAWING_TYPE_Node:
	case DRAWING_TYPE_Image:
	case DRAWING_TYPE_Button:
		return TRUE;
		break;
	default:
		break;
	}
	return FALSE;
}

BOOL COutputConfigDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetIcon(hIcon, FALSE);

	m_bLeafNode = ::GetPrivateProfileInt(_T("OutputConfig"),_T("LeafNode"),FALSE,SETTING_FILE_PATH);

	((CButton*)GetDlgItem(IDC_CHECK_LEAF_NODE))->SetCheck(m_bLeafNode);
	GetDlgItem(IDC_EDIT_FILE_PATH)->SetWindowText(m_csOutputPath);

	CStringArray csDrawingNameArray;
	CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> typeArray;
	::GetAddNodeDrawingTypeArray(csDrawingNameArray,typeArray);

	BOOL bIsOutputConfig = GetIsOutputConfig();
	int i;
	for(i=0; i<csDrawingNameArray.GetSize(); i++)
	{
		int nIndex = m_listBox.AddString(csDrawingNameArray[i]);
		if(bIsOutputConfig)
		{
			m_listBox.SetCheck(i,::GetOutputConfigDrawingType(typeArray.GetAt(i)));
		}
		else
		{
			m_listBox.SetCheck(i,::IsInitOutputType(typeArray.GetAt(i)));
		}
		m_listBox.SetItemData(nIndex,typeArray.GetAt(i));
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void COutputConfigDialog::OnBnClickedOk()
{
	m_bLeafNode = ((CButton*)GetDlgItem(IDC_CHECK_LEAF_NODE))->GetCheck();
	GetDlgItem(IDC_EDIT_FILE_PATH)->GetWindowText(m_csOutputPath);

	if(::IsFileExist(m_csOutputPath))
	{
		CString csInfo;
		csInfo.Format(_T("%s�Ѵ��ڡ�\r\nҪ�滻����"),m_csOutputPath);
		if(MessageBox(csInfo,NULL,MB_YESNO | MB_ICONWARNING) != IDYES)
			return;
	}
	
	int i;
	for(i=0; i<m_listBox.GetCount(); i++)
	{
		if(m_listBox.GetCheck(i))
		{
			m_emDrawingTypeArr.Add((EM_DRAWING_TYPE)m_listBox.GetItemData(i));
		}
	}

	::WriteIsOutputConfig();
	::WritePrivateProfileString(_T("OutputConfig"),_T("LeafNode"),::IntToCString(m_bLeafNode),SETTING_FILE_PATH);
	CStringArray csDrawingNameArray;
	CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> typeArray;
	::GetAddNodeDrawingTypeArray(csDrawingNameArray,typeArray);
	for(i=0; i<csDrawingNameArray.GetSize(); i++)
	{
		::WriteOutputConfigDrawingType(typeArray.GetAt(i),::IsDrawingTypeInArr(typeArray.GetAt(i),m_emDrawingTypeArr));
	}

	CDialogEx::OnOK();
}


void COutputConfigDialog::OnBnClickedButtonFilePath()
{
	CFileDialog fileDlg(FALSE, _T("lua"), m_csOutputPath, OFN_HIDEREADONLY, _T("Lua Files (*.lua)|*.lua|All Files (*.*)|*.*||"), this);
	if(fileDlg.DoModal() != IDOK)
		return;

	CString csFilePath = fileDlg.GetPathName();

	GetDlgItem(IDC_EDIT_FILE_PATH)->SetWindowText(csFilePath);
}
