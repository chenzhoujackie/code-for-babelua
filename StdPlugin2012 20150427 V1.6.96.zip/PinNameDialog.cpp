// PinNameDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "PinNameDialog.h"
#include "afxdialogex.h"


class CLuaState
{
public:
	CLuaState()
	{
		L = luaL_newstate();
		if(L != NULL)
		{
			luaL_openlibs(L);
		}
	}
	~CLuaState()
	{
		if(L != NULL)
		{
			lua_close(L);
			L = NULL;
		}
	}
	operator lua_State*() const
	{
		return L;
	}
	bool IsLuaStateNull() const
	{
		return (L == NULL);
	}
protected:
	lua_State *L;
};


CPinImage::CPinImage()
{
	m_x = 0;
	m_y = 0;
	m_width = 0;
	m_height = 0;
}

CPinImage::~CPinImage()
{
}

void stackDump(lua_State* L)
{
	int i = 0;
	int top = lua_gettop(L);
	for (i = 1; i <= top; ++i)
	{
		int t = lua_type(L, i);
		switch (t)
		{
		case LUA_TSTRING:
			{
				printf("'%s' ", lua_tostring(L, i));
			}
			break;
		case LUA_TBOOLEAN:
			{
				printf(lua_toboolean(L, i) ? "true " : "false ");
			}
			break;
		case LUA_TNUMBER:
			{
				printf("%g ", lua_tonumber(L, i));
			}
			break;
		default:
			{
				printf("%s ", lua_typename(L, t));
			}
			break;
		}
	}
}

void EnumPinMapTableItem(lua_State *L, const char* lpszTableName,vector <CPinImage> &pinImageArray)
{
	lua_getglobal(L, lpszTableName);
	if(lua_isnil(L,-1))
	{
		lua_pop(L, 1);
		return;
	}

	int it = lua_gettop(L);
	lua_pushnil(L);
	while(lua_next(L, it))
	{
		/* uses 'key' (at index -2) and 'value' (at index -1) */
		/* do whatever you like with the key and the value */
		std::string key = lua_tostring(L, -2);
//		std::string value = lua_tostring(L, -1);
		int type = lua_type(L, -1);
		switch(type)
		{
		case LUA_TTABLE:
			{
				CPinImage pinImage;
				pinImage.m_imageName = key.c_str();

				int subIt = lua_gettop(L);
				lua_pushnil(L);
				while(lua_next(L, subIt))
				{
					std::string subKey = lua_tostring(L, -2);
					if(subKey == "file")
					{
						pinImage.m_file = lua_tostring(L, -1);
					}
					else if(subKey == "x")
					{
						pinImage.m_x = lua_tointeger(L, -1);
					}
					else if(subKey == "y")
					{
						pinImage.m_y = lua_tointeger(L, -1);
					}
					else if(subKey == "width")
					{
						pinImage.m_width = lua_tointeger(L, -1);
					}
					else if(subKey == "height")
					{
						pinImage.m_height = lua_tointeger(L, -1);
					}

					lua_pop(L, 1);
				}

				pinImageArray.push_back(pinImage);
			}
			break;
		default:
			break;
		}
		lua_pop(L, 1);
	}
	lua_pop(L, 1);
}

// CPinNameDialog �Ի���

IMPLEMENT_DYNAMIC(CPinNameDialog, CDialogEx)

CPinNameDialog::CPinNameDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CPinNameDialog::IDD, pParent)
{
	m_bFind = false;
	m_pBitmap = NULL;
}

CPinNameDialog::~CPinNameDialog()
{
	if(m_pBitmap != NULL)
	{
		delete m_pBitmap;
		m_pBitmap = NULL;
	}
}

void CPinNameDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST, m_listBox);
}


BEGIN_MESSAGE_MAP(CPinNameDialog, CDialogEx)
	ON_BN_CLICKED(IDC_BUTTON_OPEN_PIN, &CPinNameDialog::OnBnClickedButtonOpenPin)
	ON_BN_CLICKED(IDOK, &CPinNameDialog::OnBnClickedOk)
	ON_LBN_SELCHANGE(IDC_LIST, &CPinNameDialog::OnLbnSelchangeList)
	ON_EN_CHANGE(IDC_EDIT_IMAGE_NAME, &CPinNameDialog::OnEnChangeEditImageName)
	ON_LBN_DBLCLK(IDC_LIST, &CPinNameDialog::OnLbnDblclkList)
END_MESSAGE_MAP()


// CPinNameDialog ��Ϣ��������

void CPinNameDialog::InitData(CString csPinName,CString csPinPath,CString csPngName)
{
	m_csPinName = csPinName;
	m_csPinPath = csPinPath;

	m_csPngName = csPngName;
}

CString CPinNameDialog::GetPngName()
{
	return m_csPngName;
}

BOOL CPinNameDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	CRect viewRect;
	GetDlgItem(IDC_STATIC_VIEW)->GetWindowRect(viewRect);
	ScreenToClient(viewRect);
	CString csWndClass = AfxRegisterWndClass(CS_VREDRAW | CS_HREDRAW,
		::LoadCursor(NULL, IDC_ARROW),
		(HBRUSH) ::GetStockObject(WHITE_BRUSH),
		::LoadIcon(NULL, IDI_APPLICATION));
	viewRect.DeflateRect(10,20,10,10);
	m_imageWnd.Create(csWndClass,_T(""),WS_CHILD | WS_VISIBLE,viewRect,this,0x1001);

	if(::IsFileExist(m_csPinPath))
	{
		lua_State *L = ::GetLuaState();
		int ret = luaL_dofile(L, m_csPinPath);
		if(ret == 0)
		{
			CString csPinMapName = ::GetFileName(m_csPinPath,FALSE)+_T("_map");
			EnumPinMapTableItem(L, csPinMapName,m_pinImageArray);
		}
		else
		{
			lua_pop(L,1);
		}
	}

	int i;
	for(i=0; i<m_pinImageArray.size(); i++)
	{
		int index = m_listBox.AddString(m_pinImageArray[i].m_imageName);
		m_listBox.SetItemData(index,i);

		if(m_csPngName == m_pinImageArray[i].m_imageName)
			m_listBox.SetCurSel(index);
	}

	GetDlgItem(IDC_EDIT_PIN_NAME)->SetWindowText(m_csPinName);
	GetDlgItem(IDC_EDIT_IMAGE_NAME)->SetWindowText(m_csPngName);

	return TRUE;
}

void CPinNameDialog::OnBnClickedButtonOpenPin()
{
	ShellExecute(NULL,NULL,"explorer","/select, "+m_csPinPath,NULL,SW_SHOW);
}

void CPinNameDialog::OnBnClickedOk()
{
	GetDlgItem(IDC_EDIT_IMAGE_NAME)->GetWindowText(m_csPngName);

	CDialogEx::OnOK();
}


void CPinNameDialog::OnLbnSelchangeList()
{
	int index = m_listBox.GetCurSel();
	if(index >= 0)
	{
		CString strText;
		m_listBox.GetText(index,strText);
		GetDlgItem(IDC_EDIT_IMAGE_NAME)->SetWindowText(strText);
	}
}

void CPinNameDialog::OnEnChangeEditImageName()
{
	CString strPngName;
	GetDlgItem(IDC_EDIT_IMAGE_NAME)->GetWindowText(strPngName);

	int i;
	for(i=0; i<m_pinImageArray.size(); i++)
	{
		if(m_pinImageArray[i].m_imageName == strPngName)
			break;
	}

	for(i=0; i<m_listBox.GetCount(); i++)
	{
		CString strText;
		m_listBox.GetText(i,strText);
		if(strPngName == strText)
		{
			m_listBox.SetCurSel(i);
			break;
		}
	}

	m_bFind = false;
	if(i < m_pinImageArray.size())
	{
		m_bFind = true;
		m_curPinImage = m_pinImageArray[i];
	}

	if(m_pBitmap != NULL)
	{
		delete m_pBitmap;
		m_pBitmap = NULL;
	}
	CString strImagePath = IMAGES_DIRECTORY+_T("\\")+m_curPinImage.m_file;
	m_pBitmap = m_bFind ? Bitmap::FromFile(CWCharArr(strImagePath)) : NULL;
	m_imageWnd.SetImage(m_pBitmap, m_curPinImage.m_x, m_curPinImage.m_y, m_curPinImage.m_width, m_curPinImage.m_height);
}

void CPinNameDialog::OnLbnDblclkList()
{
	OnBnClickedOk();
}
