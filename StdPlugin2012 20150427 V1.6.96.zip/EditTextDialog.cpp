﻿// EditTextDialog.cpp : 实现文件
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "EditTextDialog.h"
#include "afxdialogex.h"


// CEditTextDialog 对话框

IMPLEMENT_DYNAMIC(CEditTextDialog, CDialogEx)

CEditTextDialog::CEditTextDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CEditTextDialog::IDD, pParent)
{

}

CEditTextDialog::~CEditTextDialog()
{
}

void CEditTextDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CEditTextDialog, CDialogEx)
	ON_BN_CLICKED(IDOK, &CEditTextDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CEditTextDialog::OnBnClickedCancel)
END_MESSAGE_MAP()


// CEditTextDialog 消息处理程序

void CEditTextDialog::SetTitle(LPCTSTR lpszTitle)
{
	m_csTitle = lpszTitle;
}

void CEditTextDialog::SetEditText(CStringW csText)
{
	m_csEditText = csText;
}

CStringW CEditTextDialog::GetEditText() const
{
	return m_csEditText;
}

BOOL CEditTextDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetIcon(hIcon, FALSE);

	::SetWindowTextW(GetDlgItem(IDC_EDIT1)->GetSafeHwnd(),m_csEditText);
//	GetDlgItem(IDC_EDIT1)->SetWindowText(m_csEditText);

	if(!m_csTitle.IsEmpty())
	{
		SetWindowText(m_csTitle);
	}
	else
	{
		CString csAppTitle;
		csAppTitle.LoadString(AFX_IDS_APP_TITLE);
		SetWindowText(csAppTitle);
	}

	return TRUE;
}


CCharArr UnicodeToUTF8Ex(CWCharArr wcharArr)
{
	int iLen = WideCharToMultiByte(CP_UTF8, 0, wcharArr, -1, NULL, 0, NULL, NULL);
	char *pchData = new char[iLen];
	if(pchData != NULL)
	{
		WideCharToMultiByte(CP_UTF8,0,wcharArr,(int)wcslen(wcharArr),pchData,iLen,NULL,NULL);
		pchData[iLen-1] = '\0';
	}

	CCharArr charArr;
	if(pchData != NULL)
	{
		charArr = pchData;

		delete []pchData;
		pchData = NULL;
	}
	return charArr;
}

void CEditTextDialog::OnBnClickedOk()
{
//	GetDlgItem(IDC_EDIT1)->GetWindowText(m_csEditText);

	m_csEditText = ::GetWindowTextW(GetDlgItem(IDC_EDIT1));

	CDialogEx::OnOK();
}


void CEditTextDialog::OnBnClickedCancel()
{
	CDialogEx::OnCancel();
}
