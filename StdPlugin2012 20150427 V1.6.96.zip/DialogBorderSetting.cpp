// DialogBorderSetting.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "DialogBorderSetting.h"
#include "afxdialogex.h"


// CDialogBorderSetting �Ի���

IMPLEMENT_DYNAMIC(CDialogBorderSetting, CDialogEx)

CDialogBorderSetting::CDialogBorderSetting(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDialogBorderSetting::IDD, pParent)
{

}

CDialogBorderSetting::~CDialogBorderSetting()
{
}

void CDialogBorderSetting::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
//	DDX_Control(pDX, IDC_COMBO1, m_List);
}


BEGIN_MESSAGE_MAP(CDialogBorderSetting, CDialogEx)
	ON_BN_CLICKED(IDOK, &CDialogBorderSetting::OnBnClickedOk)
END_MESSAGE_MAP()


// CDialogBorderSetting ��Ϣ��������

BOOL CDialogBorderSetting::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	HICON hIcon = LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_MAINFRAME));
	SetIcon(hIcon, FALSE);

/*	int i;
	for(i=0; i<COMBO_COLOR_NUM; i++)
	{
		m_List.InsertString(-1,::GetComboColorString(i));
	}
*/
	COLORREF color = RGB(::GetBorderRed(),::GetBorderGreen(),::GetBorderBlue());
/*	int index = ::GetComboColorIndex(color);
	m_List.SetCurSel(index);*/
	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_BORDER))->SetColor(color);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CDialogBorderSetting::OnBnClickedOk()
{
/*	int iBorderColor = m_List.GetCurSel();

	COLORREF color = ::GetComboColorCOLORREF(iBorderColor);*/
	COLORREF color = ((CMFCColorButton*)GetDlgItem(IDC_MFCCOLORBUTTON_BORDER))->GetColor();
	::SetBorderRed(GetRValue(color));
	::SetBorderGreen(GetGValue(color));
	::SetBorderBlue(GetBValue(color));

	::WritePrivateProfileString(_T("setting"),_T("BorderColor"),::COLORREFToRGBCString(color),SETTING_FILE_PATH);
/*
	int iBorderRed = ::GetBorderRed();
	int iBorderGreen = ::GetBorderGreen();
	int iBorderBlue = ::GetBorderBlue();
	switch(iBorderColor)
	{
	case 0:
		iBorderRed = 255;
		iBorderGreen = 255;
		iBorderBlue = 255;
		break;
	case 1:
		iBorderRed = 0;
		iBorderGreen = 0;
		iBorderBlue = 0;
		break;
	case 2:
		iBorderRed = 255;
		iBorderGreen = 0;
		iBorderBlue = 0;
		break;
	case 3:
		iBorderRed = 0;
		iBorderGreen = 255;
		iBorderBlue = 0;
		break;
	case 4:
		iBorderRed = 0;
		iBorderGreen = 0;
		iBorderBlue = 255;
		break;
	case 5:
		iBorderRed = 255;
		iBorderGreen = 255;
		iBorderBlue = 0;
		break;
	case 6:
		iBorderRed = 255;
		iBorderGreen = 0;
		iBorderBlue = 255;
		break;
	default:
		break;
	}
	::SetBorderRed(iBorderRed);
	::SetBorderGreen(iBorderGreen);
	::SetBorderBlue(iBorderBlue);
*/
	CDialogEx::OnOK();
}
