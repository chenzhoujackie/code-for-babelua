#pragma once
#include "afxcmn.h"

#include "AddNodeWnd.h"
#include "TreeCtrl2.h"
#include "XTreeCtrl.h"
#include "Command.h"
#include "CommandHistory.h"

#define WM_CHANGE_DRAWING_BASE			WM_USER+3118
#define WM_TREE_SELCHANGING				WM_USER+3119
#define WM_GET_TREE_DRAWING_TIMES		WM_USER+3120

class CConfigNode
{
public:
	CConfigNode* AddConfigNode(EM_DRAWING_TYPE emDrawingType,const CString &csNodeName);	//�����ӽڵ� ���ؽڵ�ָ��
	EM_DRAWING_TYPE GetDrawingType() const;							//��ȡ�ڵ�����
	CString GetNodeName() const;									//��ȡ�ڵ�����
	BOOL IsHaveChildNode() const;									//�Ƿ�����ӽڵ�
	BOOL GetConfigNodeName(CStringArray &csConfigNodeNameArr) const;//��ȡ�ӽڵ�����
	BOOL GetAllConfigNodeName(CList <CString,CString> &csAllConfigNodeNameList,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode);//��ȡ���нڵ����� ������ɸѡ
	BOOL GetAllImageButtonName(CList <CString,CString> &csImageButtonNameList,BOOL bLeafNode) const;//��ȡ�����ӽڵ�Image Button���� ������ɸѡ
	BOOL Write(FILE *fp,const CString &csFileName,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode);	//дconfig�ļ� ������ɸѡ
private:
	BOOL GetAllNodeNameMaxLength(int &iNodeNameMaxLength,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode);	//��ȡ�ڵ�������󳤶� ������ɸѡ
	BOOL GetAllImageButtonNameMaxLength(int &iNodeNameMaxLength,BOOL bLeafNode);
	BOOL WriteControlConfig(FILE *fp,const CString &csFileName,int iNodeNameMaxLength,CList<CString,CString> &csViewNameList,
		const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode);
	BOOL WriteControlFuncDefine(FILE *fp,const CString &csFileName,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode);
	BOOL WriteControlFuncMap(FILE *fp,const CString &csFileName,int iNodeNameMaxLength,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode);
public:
	CConfigNode(EM_DRAWING_TYPE emDrawingType,const CString &csNodeName);
	~CConfigNode();
protected:
	EM_DRAWING_TYPE m_emDrawingType;								//�ڵ�����
	CString m_csNodeName;											//�ڵ�����
	CList <CConfigNode*,CConfigNode*> m_configNodeList;				//�ӽڵ�
};

//
class CCDrawingBaseNode
{
public:
	CCDrawingBaseNode* AddCDrawingBaseNode(CDrawingBase *pDrawingBase);
	int GetCDrawingBaseNodeChildNum() const;
	CCDrawingBaseNode* GetCDrawingBaseNode(int index);
	void SetCDrawingBase(CDrawingBase *pDrawingBase);
	CDrawingBase* GetCDrawingBase() const;
	void ResetDrawingTime(const CArray <long,long> &lTimeArray,int &index);	//��������Drawing Time��ÿ������һ��index+1
	int GetAllCDrawingBaseNum() const;
	CCDrawingBaseNode* Clone();
public:
	CCDrawingBaseNode(CDrawingBase *pDrawingBase);
	~CCDrawingBaseNode();
private:
	CDrawingBase *m_pDrawingBase;
	CArray <CCDrawingBaseNode*,CCDrawingBaseNode*> m_drawingBaseChildArray;
};


enum
{
	CMD_NULL = 0,
	CMD_ADD_NODE,
	CMD_DELETE_NODE,
	CMD_PROP_NODE,
	CMD_MOVE_NODE
};

void CopyCStringArray(CStringArray &csDestArray,const CStringArray &csSourceArray);

#define WM_CMD_NODE_CHANGE			WM_USER+3321
class CCmdAddNode : public CCommand
{
public:
	CCDrawingBaseNode* GetCDrawingBaseNode() const;
	void GetParentTrackingTreeName(CStringArray &csParentTrackingTreeName) const;
	CString GetPrevItemName() const;

	DECLARE_COMMAND(CCmdAddNode)
public:
	CCmdAddNode(HWND hWnd,CCDrawingBaseNode *pCDrawingBaseNode,const CStringArray &csParentTrackingTreeName,const CString &csPrevItemName);
	~CCmdAddNode();

// Overrides
public:
	virtual BOOL Execute();
	virtual CCommand* GetUndoCommand() const;
	virtual CCommand* GetRedoCommand() const;
	virtual void Sprint(CString& strLabel) const;

// Attributes
protected:
	HWND m_hWnd;

	CCDrawingBaseNode *m_pCDrawingBaseNode;		//�ڵ�����
	CStringArray m_csParentTrackingTreeName;	//��ǰ�ڵ㸸�ڵ����νṹ·��
	CString m_csPrevItemName;					//��ǰ�ڵ�ǰ���ֵܽڵ����ƣ�������Ϊ�գ���ýڵ�����ǰ�棩
};

class CCmdDeleteNode : public CCommand
{
public:
	CCDrawingBaseNode* GetCDrawingBaseNode() const;
	void GetParentTrackingTreeName(CStringArray &csParentTrackingTreeName) const;
	CString GetPrevItemName() const;

	DECLARE_COMMAND(CCmdDeleteNode)
public:
	CCmdDeleteNode(HWND hWnd,CCDrawingBaseNode *pCDrawingBaseNode,const CStringArray &csParentTrackingTreeName,const CString &csPrevItemName);
	~CCmdDeleteNode();

// Overrides
public:
	virtual BOOL Execute();
	virtual CCommand* GetUndoCommand() const;
	virtual CCommand* GetRedoCommand() const;
	virtual void Sprint(CString& strLabel) const;

// Attributes
protected:
	HWND m_hWnd;

	CCDrawingBaseNode *m_pCDrawingBaseNode;		//�ڵ�����
	CStringArray m_csParentTrackingTreeName;	//��ǰ�ڵ㸸�ڵ����νṹ·��
	CString m_csPrevItemName;					//��ǰ�ڵ�ǰ���ֵܽڵ����ƣ�������Ϊ�գ���ýڵ�����ǰ�棩
};

class CCmdPropNode : public CCommand
{
public:
	EM_UI_PROP_TYPE GetUiPropType() const;
	CDrawingBase* GetOldDrawingBase() const;
	CDrawingBase* GetNewDrawingBase() const;
	void GetCurrentTrackingTreeName(CStringArray &csCurrentTrackingTreeName) const;

	DECLARE_COMMAND(CCmdPropNode)
public:
	CCmdPropNode(HWND hWnd,EM_UI_PROP_TYPE uiPropType,CDrawingBase *pOldDrawingBase,CDrawingBase *pNewDrawingBase,const CStringArray &csCurrentTrackingTreeName);
	~CCmdPropNode();

// Overrides
public:
	virtual BOOL Execute();
	virtual CCommand* GetUndoCommand() const;
	virtual CCommand* GetRedoCommand() const;
	virtual void Sprint(CString& strLabel) const;

// Attributes
protected:
	HWND m_hWnd;

	EM_UI_PROP_TYPE m_uiPropType;				//
	CDrawingBase *m_pOldDrawingBase;			//ԭ�ڵ�����
	CDrawingBase *m_pNewDrawingBase;			//�½ڵ�����
	CStringArray m_csCurrentTrackingTreeName;	//��ǰ�ڵ����νṹ·��
};

class CCmdMoveNode : public CCommand
{
public:
	CCDrawingBaseNode* GetCDrawingBaseNode() const;
	void GetParentTrackingTreeName(CStringArray &csParentTrackingTreeName) const;
	CString GetPrevItemName() const;
	void GetMoveParentTrackingTreeName(CStringArray &csMoveParentTrackingTreeName) const;
	CString GetMovePrevItemName() const;

	DECLARE_COMMAND(CCmdMoveNode)
public:
	CCmdMoveNode(HWND hWnd,CCDrawingBaseNode *pCDrawingBaseNode,const CStringArray &csParentTrackingTreeName,const CString &csPrevItemName,
		const CStringArray &csMoveParentTrackingTreeName,const CString &csMovePrevItemName);
	~CCmdMoveNode();

// Overrides
public:
	virtual BOOL Execute();
	virtual CCommand* GetUndoCommand() const;
	virtual CCommand* GetRedoCommand() const;
	virtual void Sprint(CString& strLabel) const;

// Attributes
protected:
	HWND m_hWnd;

	CCDrawingBaseNode *m_pCDrawingBaseNode;		//�ڵ�����
	CStringArray m_csParentTrackingTreeName;	//��ǰ�ڵ㸸�ڵ����νṹ·��
	CString m_csPrevItemName;					//��ǰ�ڵ�ǰ���ֵܽڵ����ƣ�������Ϊ�գ���ýڵ�����ǰ�棩
	CStringArray m_csMoveParentTrackingTreeName;//�ƶ����Ľڵ㸸�ڵ����νṹ·��
	CString m_csMovePrevItemName;				//�ƶ����Ľڵ�ǰ���ֵܽڵ����ƣ�������Ϊ�գ���ýڵ�����ǰ�棩
};


#define TIMER_COPY_TREE_DATA		1
//
class CCopyTreeData
{
public:
	BOOL LoadData(CString csSelDirectoryName,CString csSelFileName,CXTreeCtrl &treeCtrl);
	CString GetSelDirecotryName();
	CString GetSelFileName();
	CCDrawingBaseNode* CloneData();		//���ؽ����Ҫ�ⲿ�ͷ��ڴ�
	BOOL IsLoadData();
	void SaveData();
public:
	CCopyTreeData();
	~CCopyTreeData();
protected:
	CCDrawingBaseNode *m_pCDrawingBaseNode;		//�ڵ�����
	CString m_csSelDirectoryName;				//�ļ�������
	CString m_csSelFileName;					//xml�ļ�����

	BOOL m_bLoadData;							//�Ƿ�������νṹ����

	CCriticalSection m_criticalSection;
};

int load_xml(const char *strXmlFile,CCDrawingBaseNode **ppCDrawingBaseNode);	//pCDrawingBaseNode���ⲿ�ͷ�
int save_xml(const char* strXmlFile,CCDrawingBaseNode *pCDrawingBaseNode);
int gen_lua(const char* strFile,const char* strName,CCDrawingBaseNode *pCDrawingBaseNode);
int XmlToLua(CString csXmlPath,CString csLuaPath);

BOOL IsNameInArray(const CString &csName,const CStringArray &csNameArray);

int DrawingTrackingByName(const char* strName,const char* strParent);

// CLeftDialog �Ի���

class CLeftDialog : public CDialogEx , public ICommandHistory
{
public:
	void LoadXml(const CString &csSelDirectoryName,const CString &csSelFileName);
	CString GetSelDirectoryName() const;
	CString GetSelFileName() const;
	CString GetXmlPath() const;
	CString GetLuaPath() const;
	int SaveXml();
	int GenLua();
	int GenConfigLua(const CString &csFilePath,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode);
	void ChangeEditorDrawingId();
	int GetTreeSelectItemDrawingId() const;
	void ChangeEditorDrawingSeat(double dX,double dY,double dWidth,double dHeight,BOOL bLButtonUp);
	void ChangeUIProp(const CDrawingBase *pUIPropDrawingBase,WPARAM wParam,LPARAM lParam,BOOL bAddHistory);
	int AddNewNode(EM_DRAWING_TYPE type,CString csDrawingTypeName,BOOL bControl,int x,int y);
	void GetAllTreeItemName(CStringArray &csAllTreeItemName);
	void Cut();
	void Copy();
	void Paste();
	void Undo();
	void Redo();
	void Delete();
	BOOL IsCanCut();
	BOOL IsCanCopy();
	BOOL IsCanPaste();
	BOOL IsCanUndo();
	BOOL IsCanRedo();
	BOOL IsCanDelete();
	void SetHistory(int iCommandHistoryPos);
	BOOL IsModifyData();
	void ReleaseAllData();
	const CDrawingBase* GetSelDrawingBase();
	bool GetTreeTimeMap(map<long,bool> &lTimeMap);
public:
	virtual void OnStatusChange();
	virtual void OnCommandExecute(const CCommand* pCmd);
private:
	void XMLAddName(EM_DRAWING_TYPE type);
	void XMLAddDrawingBase(EM_DRAWING_TYPE type,CString strName);
	BOOL DeleteSelectItem();
	void XMLAddView();
	void XMLAddImage();
	void XMLAddText();
	void XMLAddTextView();
	void XMLAddEditText();
	void XMLAddEditTextView();
	void XMLAddButton();
	void XMLReload();
	void XMLExport();
	void XMLExportAdv();
	void XMLRename();
	void XMLDelete();
	void XMLCut();
	void XMLCopy();
	void XMLPaste(BOOL bChild);
	void XMLSaveCustom();
	void XMLLoadCustom();
private:
	void DoExport(double scale);
	void SelectChangedTree();
	void DeleteAllTreeItems();
	BOOL AddCCDrawingBaseNode(CCDrawingBaseNode *pCDrawingBaseNode,HTREEITEM hItem,BOOL bChild);
	void ResetLevel(HTREEITEM hItem);

	BOOL TreeKeyDown(WPARAM wParam,LPARAM lParam);
	BOOL TreeEditKeyDown(WPARAM wParam,LPARAM lParam);
private:
	CImageList m_ImageList;
//	CTreeCtrl2 m_treeCtrl;
	CXTreeCtrl m_treeCtrl;				//UI��
	BOOL m_bTreeNodeReName;

	CString m_csSelDirectoryName;		//ѡ����ļ�������
	CString m_csSelFileName;			//ѡ����ļ�����

	CDrawingBase *m_pStartDrawingBase;	//��¼���ѡ��UIԪ��ʱ��ʼλ��

	CCDrawingBaseNode *m_pCopyDrawingBaseNode;	//��¼���ƽڵ�����

	CCopyTreeData m_copyTreeData;		//�������νṹ����
	HANDLE m_hSaveXMLThread;			//����xml�߳�
	DWORD m_dwSaveXMLThreadId;

	BOOL m_bModifyData;					//��ǰ�����Ƿ��޸�
	BOOL m_bCopyTreeModifyData;			//

	CToolTipCtrl m_toolTipCtrl;

	UIControl m_uiControl;

	DECLARE_DYNAMIC(CLeftDialog)

public:
	CLeftDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CLeftDialog();

// �Ի�������
	enum { IDD = IDD_LEFT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/);
	afx_msg void OnTimer(UINT_PTR nIDEvent);

	afx_msg void OnNMClickTree(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMRClickTree(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTvnSelchangedTree(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTvnSelchangingTree(NMHDR *pNMHDR, LRESULT *pResult);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);

	LRESULT MessageTreeItemMoveNext(WPARAM wParam,LPARAM lParam);
	LRESULT MessageTreeItemMoveChild(WPARAM wParam,LPARAM lParam);
	BOOL CmdAddNode(CCmdAddNode *pCmdAddNode);
	BOOL CmdDeleteNode(CCmdDeleteNode *pCmdDeleteNode);
	BOOL CmdPropNode(CCmdPropNode *pCmdPropNode);
	BOOL CmdMoveNode(CCmdMoveNode *pCmdMoveNode);
	LRESULT MessageCmdNodeChange(WPARAM wParam,LPARAM lParam);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	afx_msg void OnNMCustomdrawTree(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTvnBeginlabeleditTree(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnTvnEndlabeleditTree(NMHDR *pNMHDR, LRESULT *pResult);
};
