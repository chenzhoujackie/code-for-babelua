#include "StdAfx.h"
#include <afxcoll.h>

#pragma warning(disable:4786)
#include <string>
#include <vector>
using namespace std;

#include "StdPlugin.h"
#include "TreeCtrl2.h"
#include "XmlTools.h"

#include <math.h>
#include <stdio.h>
#include "stdarg.h"

#include <atlconv.h>
#include "tchar.h"

#include <libxml/parser.h>
#include <libxml/tree.h>

void AfxMessageBox2(CString str)
{
	HWND hWnd = 0;
	CWnd* pWnd = AfxGetMainWnd();
	if ( NULL != pWnd )
	{
		hWnd = pWnd->GetSafeHwnd();
	}
	MSGBOXPARAMS Param;
	Param.cbSize = sizeof(MSGBOXPARAMS);
	Param.dwContextHelpId = 0;
	//Param.dwLanguageId = LANG_CHINESE;
	Param.dwStyle = MB_USERICON;
	Param.hInstance = AfxGetInstanceHandle();;
	Param.hwndOwner = NULL;
	Param.lpfnMsgBoxCallback = NULL;
	Param.lpszCaption = NULL;
	Param.lpszIcon = MAKEINTRESOURCE(IDR_MAINFRAME);
	Param.lpszText = str;
	::MessageBoxIndirect(&Param);
}

const int kTextAlignCenter=0;
const int kTextAlignTop=1;
const int kTextAlignTopRight=2;
const int kTextAlignRight=3;
const int kTextAlignBottomRight=4;
const int kTextAlignBottom=5;
const int kTextAlignBottomLeft=6;
const int kTextAlignLeft=7;
const int kTextAlignTopLeft=8;

char* getAlignType ( int iType )
{
	static char strAlignType[32];
	switch(iType)
	{
	case kTextAlignCenter:
		strcpy(strAlignType,"kAlignCenter");
		break;
	case kTextAlignTop:
		strcpy(strAlignType,"kAlignTop");
		break;
	case kTextAlignTopRight:
		strcpy(strAlignType,"kAlignTopRight");
		break;
	case kTextAlignRight:
		strcpy(strAlignType,"kAlignRight");
		break;
	case kTextAlignBottomRight:
		strcpy(strAlignType,"kAlignBottomRight");
		break;
	case kTextAlignBottom:
		strcpy(strAlignType,"kAlignBottom");
		break;
	case kTextAlignBottomLeft:
		strcpy(strAlignType,"kAlignBottomLeft");
		break;
	case kTextAlignLeft:
		strcpy(strAlignType,"kAlignLeft");
		break;
	case kTextAlignTopLeft:
		strcpy(strAlignType,"kAlignTopLeft");
		break;
	default:
		strcpy(strAlignType,"kAlignCenter");
		break;
	}
	return &(strAlignType[0]);
}

CView1::CView1()
{
	x = 0;
	y = 0;
	width = 0;
	height = 0;
	iType = VIEW_TYPE_VIEW;
	iNodeAlign = kTextAlignTopLeft;

	gleft = gright = gtop = gbottom = 0;

	topleftx = toplefty = bottomrightx = bottomrighty = 0;

	bVisible = true;
	bAdaptiveWidth = false;
	bAdaptiveHeight = false;

	time_t rawtime; 
	time ( &rawtime );
	t = rawtime - 1350000000;
}
CView1::~CView1()
{
}

string CView1::tagType="type";
string CView1::tagTypeName="typeName";
string CView1::tagXName="x";
string CView1::tagCreateTime="time";
string CView1::tagYName="y";
string CView1::tagWidthName="width";
string CView1::tagHeightName="height";
string CView1::tagNodeAlign = "nodeAlign";
string CView1::tagVisibleName="visible";
string CView1::tagLuaName="packFile";

string CView1::tagTopLeftX ="fillTopLeftX";
string CView1::tagTopLeftY="fillTopLeftY";
string CView1::tagBottomRightX="fillBottomRightX";
string CView1::tagBottomRightY="fillBottomRightY";

string CView1::tag9GridLeft="gridLeft";
string CView1::tag9GridRight="gridRight";
string CView1::tag9GridTop="gridTop";
string CView1::tag9GridBottom="gridBottom";

string CView1::tagView1Name="View";//View
string CView1::tagAdaptiveWidthName = "fillParentWidth";
string CView1::tagAdaptiveHeightName = "fillParentHeight";

CImage1::CImage1()
:CView1()
{
	iType = VIEW_TYPE_IMAGE;
}
CImage1::~CImage1()
{
}
string CImage1::tagImage1Name="Image";//Image
string CImage1::tagFileName="file";//Image

CText1::CText1()
:CView1()
{
	iFontSize = 24;
	iTextAlign = 0;
	iType = VIEW_TYPE_TEXT;
	color = 0xFFFFFF;
}
CText1::~CText1()
{
}


string CText1::tagTextName="Text";//text
string CText1::tagTextViewName="TextView";//textview

string CText1::tagEditTextName="EditText";//text
string CText1::tagEditTextViewName="EditTextView";//textview

string CText1::tagStringDataName="string";//
string CText1::tagFontSize="fontSize";
string CText1::tagTextAlign="textAlign";
string CText1::tagAlign="align";
string CText1::tagColor="color";


CButton1::CButton1()
:CImage1()
{
	iType = VIEW_TYPE_BUTTON;
}
CButton1::~CButton1()
{
}
string  CButton1::tagButton1Name="Button";
string CButton1::tagFile2Name="file2";

CButton2::CButton2()
:CImage1()
{
	iType = VIEW_TYPE_BUTTON2;
}
CButton2::~CButton2()
{
}

string CButton2::tagButton2Name="Button2";
string CButton2::tagFile2Name="file2";



CString GetViewTypeNameCn ( CView1* pView )
{
	static char strViewTypeCn[32];
	switch ( pView->iType )
	{
	case VIEW_TYPE_VIEW:
		strcpy(strViewTypeCn,pView->strViewNameEx.c_str());
		return CString(strViewTypeCn);
	case VIEW_TYPE_IMAGE:
		return _T("ͼƬ");
	case VIEW_TYPE_BUTTON:
		return _T("��ť1");
	case VIEW_TYPE_BUTTON2:
		return _T("��ť2");
	case VIEW_TYPE_TEXT:
		return _T("�����ı�");
	case VIEW_TYPE_TEXTVIEW:
		return _T("�����ı�");
	case VIEW_TYPE_EDITTEXT:
		return _T("���б༭��");
	case VIEW_TYPE_EDITTEXTVIEW:
		return _T("���б༭��");
	default:
		return _T("Unknown");
	}
}
char* getViewTypeName ( CView1* pView )
{
	static char strViewType[32];
	switch ( pView->iType )
	{
	case VIEW_TYPE_VIEW:
		strcpy(strViewType,pView->strViewNameEx.c_str());
		break;
	case VIEW_TYPE_IMAGE:
		strcpy(strViewType,CImage1::tagImage1Name.c_str());
		break;
	case VIEW_TYPE_BUTTON:
		strcpy(strViewType,CButton1::tagButton1Name.c_str());
		break;
	case VIEW_TYPE_BUTTON2:
		strcpy(strViewType,CButton2::tagButton2Name.c_str());
		break;
	case VIEW_TYPE_TEXT:
		strcpy(strViewType,CText1::tagTextName.c_str());
		break;
	case VIEW_TYPE_TEXTVIEW:
		strcpy(strViewType,CText1::tagTextViewName.c_str());
		break;
	case VIEW_TYPE_EDITTEXT:
		strcpy(strViewType,CText1::tagEditTextName.c_str());
		break;
	case VIEW_TYPE_EDITTEXTVIEW:
		strcpy(strViewType,CText1::tagEditTextViewName.c_str());
		break;
	default:
		strcpy(strViewType,"Unknown");
		break;
	}
	return &(strViewType[0]);
}

#include <iconv.h>
char * Convert( const char *encFrom, const char *encTo, const char * in)
{
	static char bufout[10240];
	const char* sin;
	char* sout;
	int mode, lenin, lenout, ret, nline;
	iconv_t c_pt;
	if ((c_pt = iconv_open(encTo, encFrom)) == (iconv_t)-1)
	{
		CString strMsg;
		strMsg.Format(_T("iconv_open false: %s ==> %s\n"), encFrom, encTo);
		AfxMessageBox2(strMsg);
		return NULL;
	}
	iconv(c_pt, NULL, NULL, NULL, NULL);
	lenin = strlen(in) + 1;
	lenout = 10240;
	sin   = (const char *)in;
	sout   = (char*)bufout;
	ret = iconv(c_pt, &sin, (size_t *)&lenin, &sout, (size_t *)&lenout);

	if (ret == -1)
	{
		iconv_close(c_pt);
		CString strMsg;
		strMsg.Format(_T("iconv false: %s ==> %s\n"), encFrom, encTo);
		AfxMessageBox2(strMsg);
		return NULL;
	}
	iconv_close(c_pt);
	return bufout;
}

#define THIS_TAG "XmlDrawing"
static char sprint_buf[1024];

void log_printf(const char* tag,const char *fmt, ...)
{
	va_list args;
	va_start(args, fmt);
	vsprintf(sprint_buf,fmt,args);
	va_end(args);

	AfxMessageBox2(CString(sprint_buf));

}
int convertFromHex(string hex)
{
	int value = 0;

	int a = 0;
	int b = hex.length() - 1;
	for (; b >= 0; a++, b--)
	{
		if (hex[b] >= '0' && hex[b] <= '9')
		{
			value += (hex[b] - '0') * (1 << (a * 4));
		}
		else
		{
			switch (hex[b])
			{
			case 'A':
			case 'a':
				value += 10 * (1 << (a * 4));
				break;

			case 'B':
			case 'b':
				value += 11 * (1 << (a * 4));
				break;

			case 'C':
			case 'c':
				value += 12 * (1 << (a * 4));
				break;

			case 'D':
			case 'd':
				value += 13 * (1 << (a * 4));
				break;

			case 'E':
			case 'e':
				value += 14 * (1 << (a * 4));
				break;

			case 'F':
			case 'f':
				value += 15 * (1 << (a * 4));
				break;

			default:

				break;
			}
		}
	}

	return value;
}

/////////////////////////////////////////////////////////////////////////////////////////////


//����ĺ��������ǣ�ֻ�гɹ��˲��޸�&�����ֵ
static bool GetProp ( const char* strFile,xmlNodePtr pCurrentNode,const char* tag, int& iVal )
{
	if(xmlHasProp(pCurrentNode ,(xmlChar*)tag))
	{
		xmlChar* strAttr = xmlGetProp(pCurrentNode, (xmlChar*)tag);
		if ( 0 != strAttr )
		{
			iVal = atoi((const char*)strAttr);	
			xmlFree(strAttr);
			return true;
		}
		if ( 0 != strFile ) log_printf(THIS_TAG,"%s %s null value",strFile,tag);
	}
	return false;
}
static bool GetProp ( const char* strFile,xmlNodePtr pCurrentNode,const char* tag, long& lVal )
{
	if(xmlHasProp(pCurrentNode ,(xmlChar*)tag))
	{
		xmlChar* strAttr = xmlGetProp(pCurrentNode, (xmlChar*)tag);
		if ( 0 != strAttr )
		{
			lVal = atol((const char*)strAttr);	
			xmlFree(strAttr);
			return true;
		}
		if ( 0 != strFile ) log_printf(THIS_TAG,"%s %s null value",strFile,tag);
	}
	return false;
}

static bool GetProp ( const char* strFile,xmlNodePtr pCurrentNode,const char* tag, unsigned char& ucVal )
{
	if(xmlHasProp(pCurrentNode ,(xmlChar*)tag))
	{
		xmlChar* strAttr = xmlGetProp(pCurrentNode, (xmlChar*)tag);
		if ( 0 != strAttr )
		{
			int iVal = atoi((const char*)strAttr);
			if ( iVal >= 0 && iVal < 256 )
			{
				ucVal = (unsigned char)iVal;
				return true;
			}
			xmlFree(strAttr);
		}
		if ( 0 != strFile ) log_printf(THIS_TAG,"%s %s null value",strFile,tag);
	}
	return false;
}

static bool GetProp ( const char* strFile,xmlNodePtr pCurrentNode,const char* tag, bool& bVal )
{
	if(xmlHasProp(pCurrentNode ,(xmlChar*)tag))
	{
		xmlChar* strAttr = xmlGetProp(pCurrentNode, (xmlChar*)tag);
		if ( 0 != strAttr )
		{
			if ( 0 == _strcmpi((const char*)strAttr,"true"))
			{
				bVal = true;
			}
			else
			{
				bVal = false;
			}
			xmlFree(strAttr);
			return true;
		}
		if ( 0 != strFile ) log_printf(THIS_TAG,"%s %s null value",strFile,tag);
	}
	return false;
}

static bool GetProp ( const char* strFile,xmlNodePtr pCurrentNode,const char* tag, float& fVal )
{
	if(xmlHasProp(pCurrentNode ,(xmlChar*)tag))
	{
		xmlChar* strAttr = xmlGetProp(pCurrentNode, (xmlChar*)tag);
		if ( 0 != strAttr )
		{
			fVal = (float)atof((const char*)strAttr);
			xmlFree(strAttr);
			return true;
		}
		if ( 0 != strFile ) log_printf(THIS_TAG,"%s %s null value",strFile,tag);
	}
	return false;
}
static char* GetProp ( const char* strFile,xmlNodePtr pCurrentNode,const char* tag)
{
	if(xmlHasProp(pCurrentNode ,(xmlChar*)tag))
	{
		xmlChar* strAttr = xmlGetProp(pCurrentNode, (xmlChar*)tag);
		if ( 0 != strAttr )
		{
			int len = strlen((const char*)strAttr);
			char* ret = new char[len+1];
			ret[len] = '\0';
			strcpy(ret,(const char*)strAttr);
			xmlFree(strAttr);
			return ret;
		}
		if ( 0 != strFile ) log_printf(THIS_TAG,"%s %s null value",strFile,tag);
	}
	return 0;
}



#define ret_error_(func,id) log_printf(THIS_TAG,"%s %d failed",func,id);return -1;
/////////////////////////////////////////////////////////////////////////////////////////////
void nest_load_xml ( const char* strXmlFile,CTreeCtrl2& TreeCtrl, HTREEITEM hItem ,xmlNodePtr pXmlNode,int& iParseError )
{
	if ( 0 == pXmlNode || 1 == iParseError)
	{
		return;
	}
	char* strVal;
	xmlNodePtr pChildXmlNode;
	do
	{
		//��ǰ�ڵ�
		int iType;
		if ( !GetProp(strXmlFile,pXmlNode,CView1::tagType.c_str(),iType))
		{
			log_printf(THIS_TAG,"δָ������ %s",strXmlFile);
			iParseError = 1;
			break;
		}
		CView1* pView = 0;
		if ( VIEW_TYPE_VIEW == iType )
		{
			pView = new CView1();
			strVal = GetProp(strXmlFile,pXmlNode,CView1::tagTypeName.c_str());
			if ( 0 == strVal )
			{
				log_printf(THIS_TAG,"View����Ϊ�� %s",strXmlFile);
				/*
				iParseError = 1;
				break;
				*/
				pView->strViewNameEx = string(CView1::tagView1Name);
			}
			else
			{
				pView->strViewNameEx = string(strVal);
			}

			

		}
		if ( VIEW_TYPE_IMAGE == iType )
		{
			CImage1* pImage = new CImage1();
			pView = pImage;

			strVal = GetProp(strXmlFile,pXmlNode,CImage1::tagFileName.c_str());
			if ( 0 == strVal )
			{
				log_printf(THIS_TAG,"ͼƬ�ļ���Ϊ�� %s",strXmlFile);
				iParseError = 1;
				break;
			}
			pImage->strFile = string(strVal);

			//packFile
			strVal = GetProp(strXmlFile,pXmlNode,CView1::tagLuaName.c_str());
			if ( NULL != strVal )
			{
				pView->strLuaName = string(strVal);
			}

			//grid
			GetProp(strXmlFile,pXmlNode,CView1::tag9GridLeft.c_str(),pView->gleft );
			GetProp(strXmlFile,pXmlNode,CView1::tag9GridRight.c_str(),pView->gright );
			GetProp(strXmlFile,pXmlNode,CView1::tag9GridTop.c_str(),pView->gtop );
			GetProp(strXmlFile,pXmlNode,CView1::tag9GridBottom.c_str(),pView->gbottom );

			if ( pView->gleft < 0 ) pView->gleft = 0;
			if ( pView->gright < 0 ) pView->gright = 0;
			if ( pView->gtop < 0 ) pView->gtop = 0;
			if ( pView->gbottom < 0 ) pView->gbottom = 0;

		}
		if ( VIEW_TYPE_BUTTON == iType )
		{
			CButton1* pButton = new CButton1();
			pView = pButton;

			strVal = GetProp(strXmlFile,pXmlNode,CButton1::tagFileName.c_str());
			if ( 0 == strVal )
			{
				log_printf(THIS_TAG,"ͼƬ�ļ���Ϊ�� %s",strXmlFile);
				iParseError = 1;
				break;
			}
			pButton->strFile = string(strVal);

			strVal = GetProp(strXmlFile,pXmlNode,CButton1::tagFile2Name.c_str());
			if ( 0 != strVal )
			{
				pButton->strFile2 = string(strVal);
			}
			

			//packFile
			strVal = GetProp(strXmlFile,pXmlNode,CView1::tagLuaName.c_str());
			if ( NULL != strVal )
			{
				pView->strLuaName = string(strVal);
			}

			//grid
			GetProp(strXmlFile,pXmlNode,CView1::tag9GridLeft.c_str(),pView->gleft );
			GetProp(strXmlFile,pXmlNode,CView1::tag9GridRight.c_str(),pView->gright );
			GetProp(strXmlFile,pXmlNode,CView1::tag9GridTop.c_str(),pView->gtop );
			GetProp(strXmlFile,pXmlNode,CView1::tag9GridBottom.c_str(),pView->gbottom );

			if ( pView->gleft < 0 ) pView->gleft = 0;
			if ( pView->gright < 0 ) pView->gright = 0;
			if ( pView->gtop < 0 ) pView->gtop = 0;
			if ( pView->gbottom < 0 ) pView->gbottom = 0;

		}
		if ( VIEW_TYPE_BUTTON2 == iType )
		{
			CButton2* pButton2 = new CButton2();
			pView = pButton2;

			strVal = GetProp(strXmlFile,pXmlNode,CButton2::tagFileName.c_str());
			if ( 0 == strVal )
			{
				log_printf(THIS_TAG,"ͼƬ�ļ���Ϊ�� %s",strXmlFile);
				iParseError = 1;
				break;
			}
			pButton2->strFile = string(strVal);

			strVal = GetProp(strXmlFile,pXmlNode,CButton2::tagFile2Name.c_str());
			if ( 0 == strVal )
			{
				log_printf(THIS_TAG,"ͼƬ�ļ���2Ϊ�� %s",strXmlFile);
				iParseError = 1;
				break;
			}
			pButton2->strFile2 = string(strVal);

			//packFile
			strVal = GetProp(strXmlFile,pXmlNode,CView1::tagLuaName.c_str());
			if ( NULL != strVal )
			{
				pView->strLuaName = string(strVal);
			}

			//grid
			GetProp(strXmlFile,pXmlNode,CView1::tag9GridLeft.c_str(),pView->gleft );
			GetProp(strXmlFile,pXmlNode,CView1::tag9GridRight.c_str(),pView->gright );
			GetProp(strXmlFile,pXmlNode,CView1::tag9GridTop.c_str(),pView->gtop );
			GetProp(strXmlFile,pXmlNode,CView1::tag9GridBottom.c_str(),pView->gbottom );

			if ( pView->gleft < 0 ) pView->gleft = 0;
			if ( pView->gright < 0 ) pView->gright = 0;
			if ( pView->gtop < 0 ) pView->gtop = 0;
			if ( pView->gbottom < 0 ) pView->gbottom = 0;

		}
		if ( iType >= VIEW_TYPE_TEXT && iType <= VIEW_TYPE_EDITTEXTVIEW )
		{
			CText1* pText = new CText1();
			if ( VIEW_TYPE_TEXT == iType )
			{
				pText->iType = VIEW_TYPE_TEXT;
				pView = pText;

			}
			if ( VIEW_TYPE_TEXTVIEW == iType )
			{
				pText->iType = VIEW_TYPE_TEXTVIEW;
				pView = pText;
			}
			if ( VIEW_TYPE_EDITTEXT == iType )
			{
				pText->iType = VIEW_TYPE_EDITTEXT;
				pView = pText;

			}
			if ( VIEW_TYPE_EDITTEXTVIEW == iType )
			{
				pText->iType = VIEW_TYPE_EDITTEXTVIEW;
				pView = pText;
			}
			//string data
			strVal = GetProp(strXmlFile,pXmlNode,CText1::tagStringDataName.c_str());
			if ( 0 == strVal )
			{
				log_printf(THIS_TAG,"�ַ���Ϊ�� %s",strXmlFile);
				iParseError = 1;
				break;
			}
			char* strc = Convert("UTF-8",theApp.m_Config.m_encode.c_str(),strVal);
			pText->strStringData = 0==strc?"error":string(strc);

			// font size
			if ( !GetProp(strXmlFile,pXmlNode,CText1::tagFontSize.c_str(),pText->iFontSize ))
			{
				log_printf(THIS_TAG,"�����СΪ�� %s",strXmlFile);
				iParseError = 1;
				break;
			}
			// align
			if ( !GetProp(strXmlFile,pXmlNode,CText1::tagTextAlign.c_str(),pText->iTextAlign ))
			{
				if ( !GetProp(strXmlFile,pXmlNode,CText1::tagAlign.c_str(),pText->iTextAlign ))
				{
					log_printf(THIS_TAG,"���ֶ���Ϊ�� %s",strXmlFile);
					iParseError = 1;
					break;
				}
			}
			strVal = GetProp(strXmlFile,pXmlNode,CText1::tagColor.c_str());
			if ( NULL != strVal )
			{
				string strColor = string(strVal);
				int pos = strColor.find("0x");
				if ( 0 == pos )
				{
					strColor = strColor.substr(2);
					pText->color = convertFromHex(strVal);
				}
				else
				{
					log_printf(THIS_TAG,"������ɫ���� %s",strXmlFile);
				}
			}
			else
			{
				pText->color = 0;
			}

		}

		

		//type
		pView->iType = iType;
		//varible name
		pView->strVariableName = (const char*)pXmlNode->name;

		//time
		if ( !GetProp(strXmlFile,pXmlNode,CView1::tagCreateTime.c_str(),pView->t ))
		{
			log_printf(THIS_TAG,"������time %s",strXmlFile);
			iParseError = 1;
			break;
		}
		//x
		if ( !GetProp(strXmlFile,pXmlNode,CView1::tagXName.c_str(),pView->x ))
		{
			log_printf(THIS_TAG,"������x����(����x=10) %s",strXmlFile);
			iParseError = 1;
			break;
		}

		//y
		if ( !GetProp(strXmlFile,pXmlNode,CView1::tagYName.c_str(),pView->y ))
		{
			log_printf(THIS_TAG,"������y����(����y=5) %s",strXmlFile);
			iParseError = 1;
			break;
		}

		//w
		GetProp(strXmlFile,pXmlNode,CView1::tagWidthName.c_str(),pView->width );
		if ( pView->width < 0 )
		{
			pView->width = 0;
		}
		//h
		GetProp(strXmlFile,pXmlNode,CView1::tagHeightName.c_str(),pView->height );
		if ( pView->height < 0 )
		{
			pView->height = 0;
		}

		//x
		if ( !GetProp(strXmlFile,pXmlNode,CView1::tagTopLeftX.c_str(),pView->topleftx ))
		{
			pView->topleftx = 0;
		}

		//y
		if ( !GetProp(strXmlFile,pXmlNode,CView1::tagTopLeftY.c_str(),pView->toplefty ))
		{
			pView->toplefty = 0;
		}

		//x
		if ( !GetProp(strXmlFile,pXmlNode,CView1::tagBottomRightX.c_str(),pView->bottomrightx ))
		{
			pView->bottomrightx = 0;
		}

		//y
		if ( !GetProp(strXmlFile,pXmlNode,CView1::tagBottomRightY.c_str(),pView->bottomrighty ))
		{
			pView->bottomrighty = 0;
		}

		//visible
		GetProp(strXmlFile,pXmlNode,CView1::tagVisibleName.c_str(),pView->bVisible );
		GetProp(strXmlFile,pXmlNode,CView1::tagAdaptiveWidthName.c_str(),pView->bAdaptiveWidth );
		GetProp(strXmlFile,pXmlNode,CView1::tagAdaptiveHeightName.c_str(),pView->bAdaptiveHeight );

		if ( !GetProp(strXmlFile,pXmlNode,CView1::tagNodeAlign.c_str(),pView->iNodeAlign ))
		{
			pView->iNodeAlign = kTextAlignTopLeft;
		}

		int iImageId = iType;
		HTREEITEM hChildItem = TreeCtrl.InsertItem(CString(pView->strVariableName.c_str()), iImageId,iImageId,hItem);
		TreeCtrl.SetItemData2(hChildItem,pView);

		pChildXmlNode = pXmlNode->xmlChildrenNode;
		while ( 0 != pChildXmlNode && 1 != iParseError ) {
			nest_load_xml(strXmlFile,TreeCtrl,hChildItem,pChildXmlNode,iParseError);
			pChildXmlNode = pChildXmlNode->next;
		}

	} while(0);
}

int load_xml ( const char* strXmlFile,CTreeCtrl2& TreeCtrl,HTREEITEM hRoot )
{

	if (0 == strXmlFile || '\0' == strXmlFile[0])
	{
		ret_error_(__FUNCTION__,0);
	}

	int iParseError=0;
	xmlDocPtr pDoc = 0;
	xmlNodePtr pRoot=0;
	// ��һ��:����xml,���ɱ�Ҫ�����Ƶ�,��������id���ɵ�

	xmlKeepBlanksDefault(0);
	pDoc = xmlReadFile(strXmlFile ,"UTF-8",XML_PARSE_RECOVER);
	if( 0 == pDoc )
	{
		return -1;
	}
	pRoot = xmlDocGetRootElement(pDoc);
	if( 0 != pRoot )
	{
		nest_load_xml(strXmlFile,TreeCtrl,hRoot,pRoot,iParseError);
	}
	xmlFreeDoc(pDoc);
	xmlCleanupParser();
	if ( 1 == iParseError )
	{
		return -1;
	}
	//��Դ�����ͷ���,�ǺǺ�.
	return 1;
}
void nest_export_xml ( const char* strXmlFile,xmlNodePtr pXmlNode,int& iParseError,double scale )
{
	if ( 0 == pXmlNode || 1 == iParseError)
	{
		return;
	}
	xmlNodePtr pChildXmlNode;
	do
	{

		long t;
		int x,y,width,height;
		char buf[32];
		//time
		if ( !GetProp(strXmlFile,pXmlNode,CView1::tagCreateTime.c_str(),t ))
		{
			log_printf(THIS_TAG,"������time %s",strXmlFile);
			iParseError = 1;
			break;
		}
		sprintf(buf,"%ld",t );
		xmlSetProp(pXmlNode,BAD_CAST CView1::tagCreateTime.c_str(),BAD_CAST buf);

		//x
		if ( !GetProp(strXmlFile,pXmlNode,CView1::tagXName.c_str(),x ))
		{
			log_printf(THIS_TAG,"������x����(����x=10) %s",strXmlFile);
			iParseError = 1;
			break;
		}
		x *= scale;
		sprintf(buf,"%d",x );
		xmlSetProp(pXmlNode,BAD_CAST CView1::tagXName.c_str(),BAD_CAST buf);

		//y
		if ( !GetProp(strXmlFile,pXmlNode,CView1::tagYName.c_str(),y ))
		{
			log_printf(THIS_TAG,"������y����(����y=5) %s",strXmlFile);
			iParseError = 1;
			break;
		}
		y *= scale;
		sprintf(buf,"%d",y );
		xmlSetProp(pXmlNode,BAD_CAST CView1::tagYName.c_str(),BAD_CAST buf);

		//w
		if ( GetProp(strXmlFile,pXmlNode,CView1::tagWidthName.c_str(),width ) )
		{
			width *= scale;
			sprintf(buf,"%d",width );
			xmlSetProp(pXmlNode,BAD_CAST CView1::tagWidthName.c_str(),BAD_CAST buf);
		}
		//h
		if ( GetProp(strXmlFile,pXmlNode,CView1::tagHeightName.c_str(),height ))
		{
			height *= scale;
			sprintf(buf,"%d",height );
			xmlSetProp(pXmlNode,BAD_CAST CView1::tagHeightName.c_str(),BAD_CAST buf);
		}
	
		pChildXmlNode = pXmlNode->xmlChildrenNode;
		while ( 0 != pChildXmlNode && 1 != iParseError ) {
			nest_export_xml(strXmlFile,pChildXmlNode,iParseError,scale);
			pChildXmlNode = pChildXmlNode->next;
		}

	} while(0);
}

int export_xml ( const char* strXmlFile,const char* strXmlFile2,double scale )
{
	if (0 == strXmlFile || '\0' == strXmlFile[0])
	{
		ret_error_(__FUNCTION__,0);
	}

	if (0 == strXmlFile2 || '\0' == strXmlFile2[0])
	{
		ret_error_(__FUNCTION__,0);
	}

	int iParseError=0;
	xmlDocPtr pDoc = 0;
	xmlNodePtr pRoot=0;
	// ��һ��:����xml,���ɱ�Ҫ�����Ƶ�,��������id���ɵ�

	xmlKeepBlanksDefault(0);
	pDoc = xmlReadFile(strXmlFile ,"UTF-8",XML_PARSE_RECOVER);
	if( 0 == pDoc )
	{
		return -1;
	}
	pRoot = xmlDocGetRootElement(pDoc);
	if( 0 != pRoot )
	{
		nest_export_xml(strXmlFile,pRoot,iParseError,scale);
	}

	int iRet = xmlSaveFileEnc(strXmlFile2, pDoc, "utf-8");

	xmlFreeDoc(pDoc);
	xmlCleanupParser();
	if ( 1 == iParseError )
	{
		return -1;
	}
	//��Դ�����ͷ���,�ǺǺ�.
	return iRet;
}

void nest_load_xml_name ( const char* strXmlFile,xmlNodePtr pRoot,xmlNodePtr pXmlNode,CMapStringToString& Names)
{
	const char* strName = (const char*)pXmlNode->name;
	if ( pRoot != pXmlNode )
	{
		CString strValue;
		if ( Names.Lookup(CString(strName),strValue))
		{
			CString str;
			str.Format(_T("����������XML�ڵ�!\r\n\r\n����:  %s\r\n\r\n�ļ�1: ��%s�� \r\n\r\n�ļ�2: ��%s�� "),strName,strXmlFile,strValue.LockBuffer());
			strValue.UnlockBuffer();
			AfxMessageBox2(str);
		}
		else
		{
			Names.SetAt(CString(strName),CString(strXmlFile));
		}
	}
	xmlNodePtr pChildXmlNode = pXmlNode->xmlChildrenNode;
	while ( 0 != pChildXmlNode ) {
		nest_load_xml_name(strXmlFile,pRoot,pChildXmlNode,Names);
		pChildXmlNode = pChildXmlNode->next;
	}

}

int load_xml_name ( const char* strXmlFile,CMapStringToString& Names)
{

	if (0 == strXmlFile || '\0' == strXmlFile[0])
	{
		ret_error_(__FUNCTION__,0);
	}

	int iParseError=0;
	xmlDocPtr pDoc = 0;
	xmlNodePtr pRoot=0;
	// ��һ��:����xml,���ɱ�Ҫ�����Ƶ�,��������id���ɵ�

	xmlKeepBlanksDefault(0);
	pDoc = xmlReadFile(strXmlFile ,"UTF-8",XML_PARSE_RECOVER);
	if( 0 == pDoc )
	{
		return -1;
	}
	pRoot = xmlDocGetRootElement(pDoc);
	if( 0 != pRoot )
	{
		nest_load_xml_name(strXmlFile,pRoot,pRoot,Names);
	}
	xmlFreeDoc(pDoc);
	xmlCleanupParser();
	if ( 1 == iParseError )
	{
		return -1;
	}
	//��Դ�����ͷ���,�ǺǺ�.
	return 1;
}

int nest_save_xml ( CTreeCtrl2& TreeCtrl,HTREEITEM hItem,xmlDocPtr xmlDoc,xmlNodePtr pXmlParent)
{
	CView1* pView = (CView1*)TreeCtrl.GetItemData(hItem);
	int iType = pView->iType;

	xmlNodePtr pXmlNode;
	if ( 0 == pXmlParent )
	{
		pXmlParent = xmlNewDocNode(xmlDoc, NULL, BAD_CAST pView->strVariableName.c_str(), NULL);
		if ( 0 == pXmlParent)
		{
			xmlFreeDoc(xmlDoc);
			xmlDoc = 0;
			return -1;
		}
		xmlDocSetRootElement(xmlDoc, pXmlParent);
		pXmlNode = pXmlParent;
	}
	else
	{
		pXmlNode = xmlNewNode(NULL, BAD_CAST pView->strVariableName.c_str());
		xmlAddChild(pXmlParent, pXmlNode);
	}
	char buf[32];
	sprintf(buf,"%d",iType );
	xmlNewProp(pXmlNode, BAD_CAST CView1::tagType.c_str(), BAD_CAST buf);
	xmlNewProp(pXmlNode, BAD_CAST CView1::tagTypeName.c_str(), BAD_CAST getViewTypeName(pView));

	sprintf(buf,"%ld",pView->t );
	xmlNewProp(pXmlNode, BAD_CAST CView1::tagCreateTime.c_str(), BAD_CAST buf);

	sprintf(buf,"%d",pView->x );
	xmlNewProp(pXmlNode, BAD_CAST CView1::tagXName.c_str(), BAD_CAST buf);

	sprintf(buf,"%d",pView->y );
	xmlNewProp(pXmlNode, BAD_CAST CView1::tagYName.c_str(), BAD_CAST buf);

	sprintf(buf,"%d",pView->width );
	xmlNewProp(pXmlNode, BAD_CAST CView1::tagWidthName.c_str(), BAD_CAST buf);

	sprintf(buf,"%d",pView->height );
	xmlNewProp(pXmlNode, BAD_CAST CView1::tagHeightName.c_str(), BAD_CAST buf);


	if(pView->topleftx > 0 || pView->toplefty > 0 || pView->bottomrightx > 0 || pView->bottomrighty > 0)
	{
		sprintf(buf,"%d",pView->topleftx );
		xmlNewProp(pXmlNode, BAD_CAST CView1::tagTopLeftX.c_str(), BAD_CAST buf);

		sprintf(buf,"%d",pView->toplefty );
		xmlNewProp(pXmlNode, BAD_CAST CView1::tagTopLeftY.c_str(), BAD_CAST buf);

		sprintf(buf,"%d",pView->bottomrightx );
		xmlNewProp(pXmlNode, BAD_CAST CView1::tagBottomRightX.c_str(), BAD_CAST buf);

		sprintf(buf,"%d",pView->bottomrighty );
		xmlNewProp(pXmlNode, BAD_CAST CView1::tagBottomRightY.c_str(), BAD_CAST buf);
	}



	sprintf(buf,"%s",pView->bVisible?"true":"false" );
	xmlNewProp(pXmlNode, BAD_CAST CView1::tagVisibleName.c_str(), BAD_CAST buf);

	sprintf(buf,"%s",pView->bAdaptiveWidth?"true":"false" );
	xmlNewProp(pXmlNode, BAD_CAST CView1::tagAdaptiveWidthName.c_str(), BAD_CAST buf);

	sprintf(buf,"%s",pView->bAdaptiveHeight?"true":"false" );
	xmlNewProp(pXmlNode, BAD_CAST CView1::tagAdaptiveHeightName.c_str(), BAD_CAST buf);

	sprintf(buf,"%d",pView->iNodeAlign);
	xmlNewProp(pXmlNode, BAD_CAST CView1::tagNodeAlign.c_str(), BAD_CAST buf);
	
	if ( VIEW_TYPE_VIEW == iType )
	{
		
	}
	if ( VIEW_TYPE_IMAGE == iType )
	{
		CImage1* pImage = (CImage1*)pView;
		xmlNewProp(pXmlNode, BAD_CAST CImage1::tagFileName.c_str(), BAD_CAST pImage->strFile.c_str());
		xmlNewProp(pXmlNode, BAD_CAST CView1::tagLuaName.c_str(), BAD_CAST pView->strLuaName.c_str());

		sprintf(buf,"%d",pView->gleft);
		xmlNewProp(pXmlNode, BAD_CAST CView1::tag9GridLeft.c_str(), BAD_CAST buf);

		sprintf(buf,"%d",pView->gright);
		xmlNewProp(pXmlNode, BAD_CAST CView1::tag9GridRight.c_str(), BAD_CAST buf);

		sprintf(buf,"%d",pView->gtop);
		xmlNewProp(pXmlNode, BAD_CAST CView1::tag9GridTop.c_str(), BAD_CAST buf);

		sprintf(buf,"%d",pView->gbottom);
		xmlNewProp(pXmlNode, BAD_CAST CView1::tag9GridBottom.c_str(), BAD_CAST buf);

	}
	if ( VIEW_TYPE_BUTTON == iType )
	{
		CButton1* pButton = (CButton1*)pView;
		xmlNewProp(pXmlNode, BAD_CAST CButton1::tagFileName.c_str(), BAD_CAST pButton->strFile.c_str());
		xmlNewProp(pXmlNode, BAD_CAST CButton2::tagFile2Name.c_str(), BAD_CAST pButton->strFile2.c_str());
		xmlNewProp(pXmlNode, BAD_CAST CView1::tagLuaName.c_str(), BAD_CAST pView->strLuaName.c_str());

		sprintf(buf,"%d",pView->gleft);
		xmlNewProp(pXmlNode, BAD_CAST CView1::tag9GridLeft.c_str(), BAD_CAST buf);

		sprintf(buf,"%d",pView->gright);
		xmlNewProp(pXmlNode, BAD_CAST CView1::tag9GridRight.c_str(), BAD_CAST buf);

		sprintf(buf,"%d",pView->gtop);
		xmlNewProp(pXmlNode, BAD_CAST CView1::tag9GridTop.c_str(), BAD_CAST buf);

		sprintf(buf,"%d",pView->gbottom);
		xmlNewProp(pXmlNode, BAD_CAST CView1::tag9GridBottom.c_str(), BAD_CAST buf);

	}
	if ( VIEW_TYPE_BUTTON2 == iType )
	{
		CButton2* pButton2 = (CButton2*)pView;
		xmlNewProp(pXmlNode, BAD_CAST CButton2::tagFileName.c_str(), BAD_CAST pButton2->strFile.c_str());
		xmlNewProp(pXmlNode, BAD_CAST CButton2::tagFile2Name.c_str(), BAD_CAST pButton2->strFile2.c_str());
		xmlNewProp(pXmlNode, BAD_CAST CView1::tagLuaName.c_str(), BAD_CAST pView->strLuaName.c_str());

		sprintf(buf,"%d",pView->gleft);
		xmlNewProp(pXmlNode, BAD_CAST CView1::tag9GridLeft.c_str(), BAD_CAST buf);

		sprintf(buf,"%d",pView->gright);
		xmlNewProp(pXmlNode, BAD_CAST CView1::tag9GridRight.c_str(), BAD_CAST buf);

		sprintf(buf,"%d",pView->gtop);
		xmlNewProp(pXmlNode, BAD_CAST CView1::tag9GridTop.c_str(), BAD_CAST buf);

		sprintf(buf,"%d",pView->gbottom);
		xmlNewProp(pXmlNode, BAD_CAST CView1::tag9GridBottom.c_str(), BAD_CAST buf);

	}
	if ( iType >= VIEW_TYPE_TEXT && iType <= VIEW_TYPE_EDITTEXTVIEW )
	{
		CText1* pText = (CText1*)pView;
		sprintf(buf,"%d",pText->iFontSize);
		xmlNewProp(pXmlNode, BAD_CAST CText1::tagFontSize.c_str(), BAD_CAST buf);
		sprintf(buf,"%d",pText->iTextAlign);
		xmlNewProp(pXmlNode, BAD_CAST CText1::tagTextAlign.c_str(), BAD_CAST buf);
		sprintf(buf,"0x%06X",pText->color);
		xmlNewProp(pXmlNode, BAD_CAST CText1::tagColor.c_str(), BAD_CAST buf);
		char* strc = Convert(theApp.m_Config.m_encode.c_str(),"UTF-8",pText->strStringData.c_str());
		xmlNewProp(pXmlNode, BAD_CAST CText1::tagStringDataName.c_str(), BAD_CAST (0==strc?"error":strc));
	}


	if (TreeCtrl.ItemHasChildren(hItem))
	{
		HTREEITEM hChildItem = TreeCtrl.GetChildItem(hItem);
		while( 0 != hChildItem )
		{
			nest_save_xml(TreeCtrl,hChildItem,xmlDoc,pXmlNode);
			hChildItem =TreeCtrl.GetNextItem(hChildItem, TVGN_NEXT);  
		}
	}
	return 1;
}
int save_xml ( const char* strXmlFile,CTreeCtrl2& TreeCtrl ,bool bPrompt)
{
	int iRet = -1;
	xmlDocPtr xmlDoc = xmlNewDoc(BAD_CAST XML_DEFAULT_VERSION);
	if ( 0 == xmlDoc)
	{
		return iRet;
	}
	HTREEITEM hRoot = TreeCtrl.GetRootItem();
	if ( 0 != hRoot )
	{
		iRet = nest_save_xml(TreeCtrl,hRoot,xmlDoc,0);
		if ( iRet > 0 )
		{
			iRet = xmlSaveFileEnc(strXmlFile, xmlDoc, "utf-8");
		}
	}
	xmlFreeDoc(xmlDoc);
	if(bPrompt)
	{
		if ( iRet > 0 )
		{
			CString strMsg;
			strMsg.Format(_T("�ļ���%s������ɹ�."),strXmlFile);
			AfxMessageBox2(strMsg);
		}
		else
		{
			CString strMsg;
			strMsg.Format(_T("�ļ���%s������ʧ��."),strXmlFile);
			AfxMessageBox2(strMsg);
		}
	}
	return iRet;
}
#include <fcntl.h>
#include <io.h>

int nest_gen_lua ( CTreeCtrl2& TreeCtrl,HTREEITEM hItem,FILE* fp,const char* strName,int& depth)
{
	USES_CONVERSION;
	CView1* pView = (CView1*)TreeCtrl.GetItemData(hItem);
	int iType = pView->iType;
	
	if ( hItem == TreeCtrl.GetRootItem())
	{
		fwprintf(fp,L"%s=\n",A2W(strName));
	}
	else
	{
		fwprintf(fp,L"\n");
	}
	int blank;
	blank = depth;
	while ( blank > 0 )
	{
		blank --;
		fwprintf(fp,L"	");
	}
	fwprintf(fp,L"{");

	fwprintf(fp,L"\n");
	blank = depth;
	while ( blank >= 0 )
	{
		blank --;
		fwprintf(fp,L"	");
	}

	fwprintf(fp,L"name=\"%s\"",A2W(strName));
	fwprintf(fp,L",%s=%d",A2W(CView1::tagType.c_str()),iType);
	fwprintf(fp,L",%s=\"%s\"",A2W(CView1::tagTypeName.c_str()),A2W(getViewTypeName(pView)));
	fwprintf(fp,L",%s=%ld",A2W(CView1::tagCreateTime.c_str()),pView->t);

	fwprintf(fp,L",%s=%d",A2W(CView1::tagXName.c_str()),pView->x);
	fwprintf(fp,L",%s=%d",A2W(CView1::tagYName.c_str()),pView->y);
	fwprintf(fp,L",%s=%d",A2W(CView1::tagWidthName.c_str()),pView->width);
	fwprintf(fp,L",%s=%d",A2W(CView1::tagHeightName.c_str()),pView->height);

	if(pView->topleftx > 0 || pView->toplefty > 0 || pView->bottomrightx > 0 || pView->bottomrighty > 0)
	{
		fwprintf(fp,L",%s=%d",A2W(CView1::tagTopLeftX.c_str()),pView->topleftx);
		fwprintf(fp,L",%s=%d",A2W(CView1::tagTopLeftY.c_str()),pView->toplefty);
		fwprintf(fp,L",%s=%d",A2W(CView1::tagBottomRightX.c_str()),pView->bottomrightx);
		fwprintf(fp,L",%s=%d",A2W(CView1::tagBottomRightY.c_str()),pView->bottomrighty);
	}

	fwprintf(fp,L",%s=%d",A2W(CView1::tagVisibleName.c_str()),pView->bVisible?1:0);
	fwprintf(fp,L",%s=%d",A2W(CView1::tagAdaptiveWidthName.c_str()),pView->bAdaptiveWidth?1:0);
	fwprintf(fp,L",%s=%d",A2W(CView1::tagAdaptiveHeightName.c_str()),pView->bAdaptiveHeight?1:0);

	fwprintf(fp,L",%s=%s",A2W(CView1::tagNodeAlign.c_str()),A2W(getAlignType(pView->iNodeAlign)));

	if ( VIEW_TYPE_VIEW == iType )
	{
		
	}
	if ( VIEW_TYPE_IMAGE == iType )
	{
		CImage1* pImage = (CImage1*)pView;
		fwprintf(fp,L",%s=\"%s\"",A2W(CImage1::tagFileName.c_str()),A2W(pImage->strFile.c_str()));

		if ( pView->strLuaName.length() > 0)
		{
			int pos1 = pView->strLuaName.find('.');
			if ( pos1 > 0 )
			{
				fwprintf(fp,L",%s=\"%s\"",A2W(CView1::tagLuaName.c_str()),A2W(pView->strLuaName.c_str()));
			}
		}

		if ( pView->gleft > 0 || pView->gright > 0 || pView->gtop > 0 || pView->gbottom > 0 )
		{
			fwprintf(fp,L",%s=%d",A2W(CView1::tag9GridLeft.c_str()),pView->gleft);
			fwprintf(fp,L",%s=%d",A2W(CView1::tag9GridRight.c_str()),pView->gright);
			fwprintf(fp,L",%s=%d",A2W(CView1::tag9GridTop.c_str()),pView->gtop);
			fwprintf(fp,L",%s=%d",A2W(CView1::tag9GridBottom.c_str()),pView->gbottom);
		}

	}
	if ( VIEW_TYPE_BUTTON == iType )
	{
		CButton1* pButton = (CButton1*)pView;
		fwprintf(fp,L",%s=\"%s\"",A2W(CButton1::tagFileName.c_str()),A2W(pButton->strFile.c_str()));
		if(pButton->strFile2 != string(""))
			fwprintf(fp,L",%s=\"%s\"",A2W(CButton2::tagFile2Name.c_str()),A2W(pButton->strFile2.c_str()));

		if ( pView->strLuaName.length() > 0 )
		{
			int pos1 = pView->strLuaName.find('.');
			if ( pos1 > 0 )
			{
				fwprintf(fp,L",%s=\"%s\"",A2W(CView1::tagLuaName.c_str()),A2W(pView->strLuaName.c_str()));
			}
		}

		if ( pView->gleft > 0 || pView->gright > 0 || pView->gtop > 0 || pView->gbottom > 0 )
		{
			fwprintf(fp,L",%s=%d",A2W(CView1::tag9GridLeft.c_str()),pView->gleft);
			fwprintf(fp,L",%s=%d",A2W(CView1::tag9GridRight.c_str()),pView->gright);
			fwprintf(fp,L",%s=%d",A2W(CView1::tag9GridTop.c_str()),pView->gtop);
			fwprintf(fp,L",%s=%d",A2W(CView1::tag9GridBottom.c_str()),pView->gbottom);
		}
	}
	if ( VIEW_TYPE_BUTTON2 == iType )
	{
		CButton2* pButton2 = (CButton2*)pView;
		fwprintf(fp,L",%s=\"%s\"",A2W(CButton2::tagFileName.c_str()),A2W(pButton2->strFile.c_str()));
		fwprintf(fp,L",%s=\"%s\"",A2W(CButton2::tagFile2Name.c_str()),A2W(pButton2->strFile2.c_str()));

		if ( pView->strLuaName.length() > 0 )
		{
			int pos1 = pView->strLuaName.find('.');
			if ( pos1 > 0 )
			{
				fwprintf(fp,L",%s=\"%s\"",A2W(CView1::tagLuaName.c_str()),A2W(pView->strLuaName.c_str()));
			}
		}
		if ( pView->gleft > 0 || pView->gright > 0 || pView->gtop > 0 || pView->gbottom > 0 )
		{
			fwprintf(fp,L",%s=%d",A2W(CView1::tag9GridLeft.c_str()),pView->gleft);
			fwprintf(fp,L",%s=%d",A2W(CView1::tag9GridRight.c_str()),pView->gright);
			fwprintf(fp,L",%s=%d",A2W(CView1::tag9GridTop.c_str()),pView->gtop);
			fwprintf(fp,L",%s=%d",A2W(CView1::tag9GridBottom.c_str()),pView->gbottom);
		}
	}
	if ( iType >= VIEW_TYPE_TEXT && iType <= VIEW_TYPE_EDITTEXTVIEW )
	{
		CText1* pText = (CText1*)pView;

		fwprintf(fp,L",%s=%d",A2W(CText1::tagFontSize.c_str()),pText->iFontSize);
		fwprintf(fp,L",%s=%s",A2W(CText1::tagTextAlign.c_str()),A2W(getAlignType(pText->iTextAlign)));
		
		//fwprintf(fp,L",%s=\"0x%06X\""),CText1::tagColor.c_str(),pText->color);

		fwprintf(fp,L",colorRed=%d",GetRValue(pText->color));
		fwprintf(fp,L",colorGreen=%d",GetGValue(pText->color));
		fwprintf(fp,L",colorBlue=%d",GetBValue(pText->color));

		//char* strc = Convert(theApp.m_Config.m_encode.c_str(),"UTF-8",pText->strStringData.c_str());
		//char* strc = mcbs2utf8(pText->strStringData.c_str());

		//
		CString content = CString(pText->strStringData.c_str());
		content.Replace(_T("&lt;"),_T("<"));
		content.Replace(_T("&gt;"),_T(">"));
		content.Replace(_T("&quot;"),_T("\""));
		content.Replace(_T("&amp;"),_T("&"));

//		char* strData = content.LockBuffer();
		fwprintf(fp,L",%s=[[%s]]",A2W(CText1::tagStringDataName.c_str()),A2W(content));
//		content.UnlockBuffer();
		//delete[] strc;
	}

	if (TreeCtrl.ItemHasChildren(hItem))
	{
		HTREEITEM hChildItem = TreeCtrl.GetChildItem(hItem);
		while( 0 != hChildItem )
		{
			fwprintf(fp,L",");
			CString strText = TreeCtrl.GetItemText(hChildItem);
			string str_text = string(CCharArr(strText));
			depth++;
			nest_gen_lua(TreeCtrl,hChildItem,fp,str_text.c_str(),depth);
			depth--;
			hChildItem =TreeCtrl.GetNextItem(hChildItem, TVGN_NEXT);  
		}
	}

	fwprintf(fp,L"\n");
	blank = depth;
	while ( blank > 0 )
	{
		blank --;
		fwprintf(fp,L"	");
	}	
	fwprintf(fp,L"}");
	return 1;
}

bool gen_debug_lua( const char* strFile, const char* strName )
{
	USES_CONVERSION;

	FILE* fp = _wfopen(A2W(strFile),L"w");
	if ( NULL == fp ) return false;
	_setmode(_fileno(fp), _O_U8TEXT);
	//sys_set_int("drawing_id_select",id);
	fwprintf(fp,L"UIEditorSelectNode(\"%s\");",A2W(strName));
	fclose(fp);
	return true;
}

int gen_lua ( const char* strFile,const char* strName,CTreeCtrl2& TreeCtrl )
{
	USES_CONVERSION;

	int iRet = -1;
	FILE* fp = _wfopen(A2W(strFile),L"w");
	if ( NULL == fp )
	{
		return iRet;
	}
	_setmode(_fileno(fp), _O_U8TEXT);

	HTREEITEM hRoot = TreeCtrl.GetRootItem();
	if ( 0 != hRoot )
	{
		int depth = 0;
		iRet = nest_gen_lua(TreeCtrl,hRoot,fp,strName,depth);
	}
	fclose(fp);
	return iRet;
}

void create_default_lua(const char* strLuaFile)
{
	USES_CONVERSION;
	FILE* fp = _wfopen(A2W(strLuaFile),L"w");
	if ( NULL == fp )
	{
		return;
	}
	_setmode(_fileno(fp), _O_U8TEXT);
	fwprintf(fp,L"root={name=\"root\",type=0,typeName=\"View\",time=0,x=0,y=0,width=-1,height=-1,visible=1}");
	fclose(fp);

}
void create_default_xml(const char* strXmlFile)
{
	xmlDocPtr xmlDoc = xmlNewDoc(BAD_CAST XML_DEFAULT_VERSION);
	xmlNodePtr pXmlNode = xmlNewDocNode(xmlDoc, NULL, BAD_CAST "root", NULL);
	xmlDocSetRootElement(xmlDoc, pXmlNode);

	xmlNewProp(pXmlNode, BAD_CAST "type", BAD_CAST "0");
	xmlNewProp(pXmlNode, BAD_CAST "typeName", BAD_CAST "View");
	xmlNewProp(pXmlNode, BAD_CAST "time", BAD_CAST "0");
	xmlNewProp(pXmlNode, BAD_CAST "x", BAD_CAST "0");
	xmlNewProp(pXmlNode, BAD_CAST "y", BAD_CAST "0");
	xmlNewProp(pXmlNode, BAD_CAST "visible", BAD_CAST "true");

	xmlSaveFileEnc(strXmlFile, xmlDoc, "utf-8");
	xmlFreeDoc(xmlDoc);
}

BOOL check_name ( CString str, BOOL bAlert )
{
	TCHAR a = 'a';
	TCHAR z = 'z';
	TCHAR A = 'A';
	TCHAR Z = 'Z';
	TCHAR ul = '_';

	TCHAR zero = '0';
	TCHAR nine = '9';

	for ( int i = 0; i < str.GetLength(); i ++ )
	{
		TCHAR tc = str.GetAt(i);

		BOOL bCheck = FALSE;
		if ( tc >= a && tc <= z )
		{
			bCheck = TRUE;
		}
		if ( tc >= A && tc <= Z )
		{
			bCheck = TRUE;
		}
		if ( tc >= zero && tc <= nine )
		{
			if ( 0 != i )
			{
				bCheck = TRUE;
			}
		}

		if ( tc == ul )
		{
			bCheck = TRUE;
		}
		if ( !bCheck)
		{
			if ( bAlert )
			{
				AfxMessageBox2(_T("������Ӣ����ĸ��ͷ,�����ֺ��»���."));
			}
			return FALSE;
		}
	}
	return TRUE;

}