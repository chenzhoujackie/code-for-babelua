// DialogBkSetting.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "DialogBkSetting.h"
#include "afxdialogex.h"


// CDialogBkSetting �Ի���

IMPLEMENT_DYNAMIC(CDialogBkSetting, CDialogEx)

CDialogBkSetting::CDialogBkSetting(CWnd* pParent /*=NULL*/)
	: CDialogEx(CDialogBkSetting::IDD, pParent)
{

}

CDialogBkSetting::~CDialogBkSetting()
{
}

void CDialogBkSetting::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
//	DDX_Control(pDX, IDC_COMBO1, m_List);
}


BEGIN_MESSAGE_MAP(CDialogBkSetting, CDialogEx)
	ON_BN_CLICKED(IDOK, &CDialogBkSetting::OnBnClickedOk)
END_MESSAGE_MAP()


// CDialogBkSetting ��Ϣ��������

BOOL CDialogBkSetting::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��

/*	int i;
	for(i=0; i<COMBO_COLOR_NUM; i++)
	{
		m_List.InsertString(-1,::GetComboColorString(i));
	}
*/
	COLORREF color = RGB(::GetBkRed(),::GetBkGreen(),::GetBkBlue());
/*	int index = ::GetComboColorIndex(color);
	m_List.SetCurSel(index);*/
	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLOR_BOTTOM_BK))->SetColor(color);
	((CMFCColorButton*)GetDlgItem(IDC_MFCCOLOR_BOTTOM))->SetColor(::GetBottomColor());

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}


void CDialogBkSetting::OnBnClickedOk()
{
/*	int iBkColor = m_List.GetCurSel();

	COLORREF color = ::GetComboColorCOLORREF(iBkColor);*/
	COLORREF color = ((CMFCColorButton*)GetDlgItem(IDC_MFCCOLOR_BOTTOM_BK))->GetColor();
	::SetBkRed(GetRValue(color));
	::SetBkGreen(GetGValue(color));
	::SetBkBlue(GetBValue(color));

	::SetBottomColor(((CMFCColorButton*)GetDlgItem(IDC_MFCCOLOR_BOTTOM))->GetColor());

	::WritePrivateProfileString(_T("setting"),_T("BkColor"),::COLORREFToRGBCString(color),SETTING_FILE_PATH);
	::WritePrivateProfileString(_T("setting"),_T("BottomColor"),::COLORREFToRGBCString(::GetBottomColor()),SETTING_FILE_PATH);
/*
	int iBkRed = ::GetBkRed();
	int iBkGreen = ::GetBkGreen();
	int iBkBlue = ::GetBkBlue();
	switch(iBkColor)
	{
	case 0:
		iBkRed = 255;
		iBkGreen = 255;
		iBkBlue = 255;
		break;
	case 1:
		iBkRed = 0;
		iBkGreen = 0;
		iBkBlue = 0;
		break;
	case 2:
		iBkRed = 255;
		iBkGreen = 0;
		iBkBlue = 0;
		break;
	case 3:
		iBkRed = 0;
		iBkGreen = 255;
		iBkBlue = 0;
		break;
	case 4:
		iBkRed = 0;
		iBkGreen = 0;
		iBkBlue = 255;
		break;
	case 5:
		iBkRed = 255;
		iBkGreen = 255;
		iBkBlue = 0;
		break;
	case 6:
		iBkRed = 255;
		iBkGreen = 0;
		iBkBlue = 255;
		break;
	default:
		break;
	}
	::SetBkRed(iBkRed);
	::SetBkGreen(iBkGreen);
	::SetBkBlue(iBkBlue);
*/
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CDialogEx::OnOK();
}

