#pragma once
#include "afxwin.h"


// CDialogGridSetting �Ի���

class CDialogGridSetting : public CDialogEx
{
	DECLARE_DYNAMIC(CDialogGridSetting)

public:
	CDialogGridSetting(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDialogGridSetting();

// �Ի�������
	enum { IDD = IDD_DIALOG_GRID_SETTING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	int m_H;
	int m_V;
//	CComboBox m_List;
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
};
