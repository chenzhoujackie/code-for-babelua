// HistoryDockablePane.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "HistoryDockablePane.h"


// CHistoryDockablePane

IMPLEMENT_DYNAMIC(CHistoryDockablePane, CDockablePane)

CHistoryDockablePane::CHistoryDockablePane()
{

}

CHistoryDockablePane::~CHistoryDockablePane()
{
}


BEGIN_MESSAGE_MAP(CHistoryDockablePane, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
END_MESSAGE_MAP()



// CHistoryDockablePane ��Ϣ��������

void CHistoryDockablePane::UpdateHistory(int iCommandHistoryUndoPos,int iCommandHistoryUndoCount,int iCommandHistoryRedoCount,const CArray<int,int> &iTypeArr,const CStringArray &csHistoryNameArr)
{
	m_historyDialog.UpdateHistory(iCommandHistoryUndoPos,iCommandHistoryUndoCount,iCommandHistoryRedoCount,iTypeArr,csHistoryNameArr);
}


int CHistoryDockablePane::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	m_historyDialog.Create(IDD_HISTORY_DIALOG,this);
	m_historyDialog.ShowWindow(SW_SHOW);

	return 0;
}


void CHistoryDockablePane::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);

	if(m_historyDialog.m_hWnd != NULL)
	{
		CRect clientRect;
		GetClientRect(clientRect);
		m_historyDialog.MoveWindow(clientRect);
	}
}
