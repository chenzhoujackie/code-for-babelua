#pragma once


// CPromptDialog �Ի���

class CPromptDialog : public CDialogEx
{
public:
	void SetTitle(LPCTSTR lpszTitle);
	void SetStaticText1(LPCTSTR lpszText);
	void SetStaticText2(LPCTSTR lpszText);
	void SetEditText(LPCTSTR lpszText);
protected:
	CString m_csTitle;
	CString m_csStaticText1;
	CString m_csStaticText2;
	CString m_csEditText;

	DECLARE_DYNAMIC(CPromptDialog)

public:
	CPromptDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPromptDialog();

// �Ի�������
	enum { IDD = IDD_PROMPT_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
};
