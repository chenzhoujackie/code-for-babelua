#pragma once
#include "afxwin.h"


// CDialogWellSetting �Ի���

class CDialogWellSetting : public CDialogEx
{
	DECLARE_DYNAMIC(CDialogWellSetting)

public:
	CDialogWellSetting(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDialogWellSetting();

// �Ի�������
	enum { IDD = IDD_DIALOG_WELL_SETTING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
//	CComboBox m_List;
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
};
