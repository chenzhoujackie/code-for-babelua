// UIPropDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "UIPropDialog.h"
#include "afxdialogex.h"

#include "MainFrm.h"

// CUIPropDialog �Ի���

IMPLEMENT_DYNAMIC(CUIPropDialog, CDialogEx)

CUIPropDialog::CUIPropDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CUIPropDialog::IDD, pParent)
{
	m_pDrawingBase = NULL;

	m_bEditData = TRUE;

	m_bChangeUIProp = FALSE;
	m_emUIPropType = (EM_UI_PROP_TYPE)-1;
}

CUIPropDialog::~CUIPropDialog()
{
}

void CUIPropDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SPIN_NODE_X, m_nodeXSpinButtonCtrl);
	DDX_Control(pDX, IDC_SPIN_NODE_Y, m_nodeYSpinButtonCtrl);
	DDX_Control(pDX, IDC_SPIN_NODE_W, m_nodeWSpinButtonCtrl);
	DDX_Control(pDX, IDC_SPIN_NODE_H, m_nodeHSpinButtonCtrl);
	DDX_Control(pDX, IDC_STATIC_PROP_SEAT, m_propSeatStatic);
	DDX_Control(pDX, IDC_STATIC_PROP_FILL, m_propFillStatic);
	DDX_Control(pDX, IDC_EDIT_NODE_X, m_nodeXEdit);
	DDX_Control(pDX, IDC_EDIT_NODE_Y, m_nodeYEdit);
	DDX_Control(pDX, IDC_EDIT_NODE_W, m_nodeWEdit);
	DDX_Control(pDX, IDC_EDIT_NODE_H, m_nodeHEdit);
	DDX_Control(pDX, IDC_EDIT_TOPLEFTX, m_topLeftXEdit);
	DDX_Control(pDX, IDC_EDIT_TOPLEFTY, m_topLeftYEdit);
	DDX_Control(pDX, IDC_EDIT_BOTTOMRIGHTX, m_bottomRightXEdit);
	DDX_Control(pDX, IDC_EDIT_BOTTOMRIGHTY, m_bottomRightYEdit);
}


BEGIN_MESSAGE_MAP(CUIPropDialog, CDialogEx)
	ON_BN_CLICKED(IDOK, &CUIPropDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CUIPropDialog::OnBnClickedCancel)
	ON_WM_SIZE()
	ON_WM_TIMER()
	ON_EN_CHANGE(IDC_EDIT_NODE_X, &CUIPropDialog::OnEnChangeEditNodeX)
	ON_EN_CHANGE(IDC_EDIT_NODE_Y, &CUIPropDialog::OnEnChangeEditNodeY)
	ON_EN_CHANGE(IDC_EDIT_NODE_W, &CUIPropDialog::OnEnChangeEditNodeW)
	ON_EN_CHANGE(IDC_EDIT_NODE_H, &CUIPropDialog::OnEnChangeEditNodeH)
/*	ON_BN_CLICKED(IDC_BUTTON_X_SUB, &CUIPropDialog::OnBnClickedButtonXSub)
	ON_BN_CLICKED(IDC_BUTTON_X_ADD, &CUIPropDialog::OnBnClickedButtonXAdd)
	ON_BN_CLICKED(IDC_BUTTON_Y_SUB, &CUIPropDialog::OnBnClickedButtonYSub)
	ON_BN_CLICKED(IDC_BUTTON_Y_ADD, &CUIPropDialog::OnBnClickedButtonYAdd)
	ON_BN_CLICKED(IDC_BUTTON_W_SUB, &CUIPropDialog::OnBnClickedButtonWSub)
	ON_BN_CLICKED(IDC_BUTTON_W_ADD, &CUIPropDialog::OnBnClickedButtonWAdd)
	ON_BN_CLICKED(IDC_BUTTON_H_SUB, &CUIPropDialog::OnBnClickedButtonHSub)
	ON_BN_CLICKED(IDC_BUTTON_H_ADD, &CUIPropDialog::OnBnClickedButtonHAdd)*/
	ON_CBN_SELCHANGE(IDC_COMBO_ADAPTIVE, &CUIPropDialog::OnCbnSelchangeComboAdaptive)
	ON_CBN_SELCHANGE(IDC_COMBO_ADAPTIVE2, &CUIPropDialog::OnCbnSelchangeComboAdaptive2)
	ON_EN_CHANGE(IDC_EDIT_TOPLEFTX, &CUIPropDialog::OnEnChangeEditTopleftx)
	ON_EN_CHANGE(IDC_EDIT_TOPLEFTY, &CUIPropDialog::OnEnChangeEditToplefty)
	ON_EN_CHANGE(IDC_EDIT_BOTTOMRIGHTX, &CUIPropDialog::OnEnChangeEditBottomrightx)
	ON_EN_CHANGE(IDC_EDIT_BOTTOMRIGHTY, &CUIPropDialog::OnEnChangeEditBottomrighty)
	ON_CBN_SELCHANGE(IDC_COMBO_NODE_ALIGN, &CUIPropDialog::OnCbnSelchangeComboNodeAlign)
	ON_CBN_SELCHANGE(IDC_COMBO_VISIBLE, &CUIPropDialog::OnCbnSelchangeComboVisible)

	ON_MESSAGE(WM_GET_WIDTH_HEIGHT,MessageGetWidthHeight)
	ON_MESSAGE(WM_EDIT_KILLFOCUS,MessageEditKillFocus)
	ON_WM_CONTEXTMENU()
END_MESSAGE_MAP()


// CUIPropDialog ��Ϣ��������

void CUIPropDialog::InitData(const CDrawingBase *pDrawingBase)
{
	m_pDrawingBase = pDrawingBase;
	m_propButtonDialog.InitData(pDrawingBase);
	m_propTextDialog.InitData(pDrawingBase);
	m_propCustomDialog.InitData(pDrawingBase);

	ChangeDrawingBase(m_pDrawingBase);
}

const CDrawingBase* CUIPropDialog::GetDrawingBase() const
{
	return m_pDrawingBase;
}

void CUIPropDialog::SaveChangeUIProp()
{
	EndChangeUIProp();

	m_propButtonDialog.SaveChangeUIProp();
	m_propTextDialog.SaveChangeUIProp();
	m_propCustomDialog.SaveChangeUIProp();
}

void CUIPropDialog::ChangeDrawingBase(const CDrawingBase *pDrawingBase)
{
	m_bEditData = FALSE;

	CString csName;
	long time;
	int x = 0;
	int y = 0;
	int width = 0;
	int height = 0;
	int topLeftX = 0;
	int topLeftY = 0;
	int bottomRightX = 0;
	int bottomRightY = 0;
	bool bVisible = true;
	bool bAdaptiveWidth = false;
	bool bAdaptiveHeight = false;
	int iNodeAlign = TextkAlignTopLeft;
	if(pDrawingBase != NULL)
	{
		pDrawingBase->GetName(csName);
		time = pDrawingBase->GetTime();
		pDrawingBase->GetPos(x,y);
		pDrawingBase->GetSize(width,height);
		pDrawingBase->GetFillRegion(topLeftX,topLeftY,bottomRightX,bottomRightY);
		pDrawingBase->GetVisible(bVisible);
		pDrawingBase->GetFillParent(bAdaptiveWidth,bAdaptiveHeight);
		pDrawingBase->GetAlign(iNodeAlign);
	}
	GetDlgItem(IDC_EDIT_NODE_NAME)->SetWindowText(csName);
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_NODE_X),::IntToCString(x));
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_NODE_Y),::IntToCString(y));
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_NODE_W),::IntToCString(width));
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_NODE_H),::IntToCString(height));
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_TOPLEFTX),::IntToCString(topLeftX));
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_TOPLEFTY),::IntToCString(topLeftY));
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_BOTTOMRIGHTX),::IntToCString(bottomRightX));
	SetEditTextNotChangeCursorSeat((CEdit*)GetDlgItem(IDC_EDIT_BOTTOMRIGHTY),::IntToCString(bottomRightY));
	((CComboBox*)GetDlgItem(IDC_COMBO_VISIBLE))->SetCurSel(bVisible ? 0 : 1);
	((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTIVE))->SetCurSel(bAdaptiveWidth ? 1 : 0);
	((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTIVE2))->SetCurSel(bAdaptiveHeight ? 1 : 0);
	((CComboBox*)GetDlgItem(IDC_COMBO_NODE_ALIGN))->SetCurSel(iNodeAlign);

	EM_DRAWING_TYPE type = (EM_DRAWING_TYPE)-1;
	if(pDrawingBase != NULL)
		type = pDrawingBase->GetDrawingType();

	BOOL bShowPropButton = FALSE;
	BOOL bShowPropText = FALSE;
	BOOL bShowPropCustom = FALSE;
	switch(type)
	{
	case DRAWING_TYPE_Image:
	case DRAWING_TYPE_Button:
	case DRAWING_TYPE_CheckBox:
	case DRAWING_TYPE_RadioButton:
		{
			bShowPropButton = TRUE;
		}
		break;
	case DRAWING_TYPE_Text:
	case DRAWING_TYPE_TextView:
	case DRAWING_TYPE_EditTextView:
	case DRAWING_TYPE_EditText:
		{
			bShowPropText = TRUE;
		}
		break;
	case DRAWING_TYPE_CustomControl:
		{
			bShowPropCustom = TRUE;
		}
	default:
		break;
	}
	int nPropButtonCmdShow = bShowPropButton ? SW_SHOW : SW_HIDE;
	int nPropTextCmdShow = bShowPropText ? SW_SHOW : SW_HIDE;
	int nPropCustomCmdShow = bShowPropCustom ? SW_SHOW : SW_HIDE;
	if(m_propButtonDialog.m_hWnd != NULL)
		m_propButtonDialog.ShowWindow(nPropButtonCmdShow);
	if(m_propTextDialog.m_hWnd != NULL)
		m_propTextDialog.ShowWindow(nPropTextCmdShow);
	if(m_propCustomDialog.m_hWnd != NULL)
		m_propCustomDialog.ShowWindow(nPropCustomCmdShow);

	m_bEditData = TRUE;

	m_bChangeUIProp = FALSE;
	m_emUIPropType = (EM_UI_PROP_TYPE)-1;
}

BOOL CUIPropDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	m_propSeatStatic.SetBorderColor(RGB(128,128,128));
	m_propFillStatic.SetTextColor(RGB(0,128,0));
	m_propFillStatic.SetBorderColor(RGB(0,128,0));

	m_propButtonDialog.Create(IDD_PROP_BUTTON_DIALOG,this);
	m_propTextDialog.Create(IDD_PROP_TEXT_DIALOG,this);
	m_propCustomDialog.Create(IDD_PROP_CUSTOM_DIALOG,this);

	short nLower = -32768;
	short nUpper = 32767;
	m_nodeXSpinButtonCtrl.SetBuddy(GetDlgItem(IDC_EDIT_NODE_X));
	m_nodeXSpinButtonCtrl.SetRange(nLower,nUpper);
	m_nodeYSpinButtonCtrl.SetBuddy(GetDlgItem(IDC_EDIT_NODE_Y));
	m_nodeYSpinButtonCtrl.SetRange(nLower,nUpper);
	m_nodeWSpinButtonCtrl.SetBuddy(GetDlgItem(IDC_EDIT_NODE_W));
	m_nodeWSpinButtonCtrl.SetRange(0,nUpper);
	m_nodeHSpinButtonCtrl.SetBuddy(GetDlgItem(IDC_EDIT_NODE_H));
	m_nodeHSpinButtonCtrl.SetRange(0,nUpper);

	((CComboBox*)GetDlgItem(IDC_COMBO_VISIBLE))->InsertString(-1,_T("��ʾ"));
	((CComboBox*)GetDlgItem(IDC_COMBO_VISIBLE))->InsertString(-1,_T("����"));
	((CComboBox*)GetDlgItem(IDC_COMBO_VISIBLE))->SetCurSel(0);

	((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTIVE))->InsertString(-1,_T("��"));
	((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTIVE))->InsertString(-1,_T("��"));
	((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTIVE))->SetCurSel(0);

	((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTIVE2))->InsertString(-1,_T("��"));
	((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTIVE2))->InsertString(-1,_T("��"));
	((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTIVE2))->SetCurSel(0);

	LPCTSTR values[] = {
		_T("Center"),
		_T("Top"),
		_T("TopRight"),
		_T("Right"),
		_T("BottomRight"),
		_T("Bottom"),
		_T("BottomLeft"),
		_T("Left"),
		_T("TopLeft")
	};

	for(int i=0;i<sizeof(values)/sizeof(LPCTSTR);++i)
	{
		((CComboBox*)GetDlgItem(IDC_COMBO_NODE_ALIGN))->InsertString(-1,values[i]);
	}
	((CComboBox*)GetDlgItem(IDC_COMBO_NODE_ALIGN))->SetCurSel(8);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CUIPropDialog::OnBnClickedOk()
{
}


void CUIPropDialog::OnBnClickedCancel()
{
}

void CUIPropDialog::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	CRect clientRect;
	GetClientRect(clientRect);

	CRect uiPropRect(UI_PROP_DIALOG_LEFT,0,clientRect.Width(),clientRect.Height());
	if(m_propButtonDialog.m_hWnd != NULL)
	{
		m_propButtonDialog.MoveWindow(uiPropRect);
	}
	if(m_propTextDialog.m_hWnd != NULL)
	{
		m_propTextDialog.MoveWindow(uiPropRect);
	}
	if(m_propCustomDialog.m_hWnd != NULL)
	{
		m_propCustomDialog.MoveWindow(uiPropRect);
	}
}


void CUIPropDialog::OnEnChangeEditNodeX()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_X)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_x,::CStringToInt(csValue));
//#ifdef _DEBUG
//		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_x,::CStringToInt(csValue));
//#else
		ChangeUIProp(UI_PROP_x);
//#endif
	}
}


void CUIPropDialog::OnEnChangeEditNodeY()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_Y)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_y,::CStringToInt(csValue));
		ChangeUIProp(UI_PROP_y);
	}
}


void CUIPropDialog::OnEnChangeEditNodeW()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_W)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_width,::CStringToInt(csValue));
		ChangeUIProp(UI_PROP_width);
	}
}

void CUIPropDialog::OnEnChangeEditNodeH()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_H)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_height,::CStringToInt(csValue));
		ChangeUIProp(UI_PROP_height);
	}
}
/*
void CUIPropDialog::OnBnClickedButtonXSub()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_X)->GetWindowText(csValue);
	csValue = ::IntToCString(::CStringToInt(csValue)-1);
	GetDlgItem(IDC_EDIT_NODE_X)->SetWindowText(csValue);
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_x,::CStringToInt(csValue));
}


void CUIPropDialog::OnBnClickedButtonXAdd()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_X)->GetWindowText(csValue);
	csValue = ::IntToCString(::CStringToInt(csValue)+1);
	GetDlgItem(IDC_EDIT_NODE_X)->SetWindowText(csValue);
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_x,::CStringToInt(csValue));
}


void CUIPropDialog::OnBnClickedButtonYSub()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_Y)->GetWindowText(csValue);
	csValue = ::IntToCString(::CStringToInt(csValue)-1);
	GetDlgItem(IDC_EDIT_NODE_Y)->SetWindowText(csValue);
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_y,::CStringToInt(csValue));
}


void CUIPropDialog::OnBnClickedButtonYAdd()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_Y)->GetWindowText(csValue);
	csValue = ::IntToCString(::CStringToInt(csValue)+1);
	GetDlgItem(IDC_EDIT_NODE_Y)->SetWindowText(csValue);
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_y,::CStringToInt(csValue));
}


void CUIPropDialog::OnBnClickedButtonWSub()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_W)->GetWindowText(csValue);
	csValue = ::IntToCString(::CStringToInt(csValue)-1);
	GetDlgItem(IDC_EDIT_NODE_W)->SetWindowText(csValue);
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_width,::CStringToInt(csValue));
}


void CUIPropDialog::OnBnClickedButtonWAdd()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_W)->GetWindowText(csValue);
	csValue = ::IntToCString(::CStringToInt(csValue)+1);
	GetDlgItem(IDC_EDIT_NODE_W)->SetWindowText(csValue);
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_width,::CStringToInt(csValue));
}


void CUIPropDialog::OnBnClickedButtonHSub()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_H)->GetWindowText(csValue);
	csValue = ::IntToCString(::CStringToInt(csValue)-1);
	GetDlgItem(IDC_EDIT_NODE_H)->SetWindowText(csValue);
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_height,::CStringToInt(csValue));
}


void CUIPropDialog::OnBnClickedButtonHAdd()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_NODE_H)->GetWindowText(csValue);
	csValue = ::IntToCString(::CStringToInt(csValue)+1);
	GetDlgItem(IDC_EDIT_NODE_H)->SetWindowText(csValue);
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_height,::CStringToInt(csValue));
}
*/
void CUIPropDialog::OnCbnSelchangeComboAdaptive()
{
	bool bAdaptiveWidth = ((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTIVE))->GetCurSel() ? 1 : 0;
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_bAdaptiveWidth,bAdaptiveWidth);
	}
}


void CUIPropDialog::OnCbnSelchangeComboAdaptive2()
{
	bool bAdaptiveHeight = ((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTIVE2))->GetCurSel() ? 1 : 0;
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_bAdaptiveHeight,bAdaptiveHeight);
	}
}


void CUIPropDialog::OnEnChangeEditTopleftx()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_TOPLEFTX)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_topLeftX,::CStringToInt(csValue));
		ChangeUIProp(UI_PROP_topLeftX);
	}
}


void CUIPropDialog::OnEnChangeEditToplefty()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_TOPLEFTY)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_topLeftY,::CStringToInt(csValue));
		ChangeUIProp(UI_PROP_topLeftY);
	}
}


void CUIPropDialog::OnEnChangeEditBottomrightx()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_BOTTOMRIGHTX)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_bottomRightX,::CStringToInt(csValue));
		ChangeUIProp(UI_PROP_bottomRightX);
	}
}


void CUIPropDialog::OnEnChangeEditBottomrighty()
{
	CString csValue;
	GetDlgItem(IDC_EDIT_BOTTOMRIGHTY)->GetWindowText(csValue);
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_UPDATE_UI_PROP,UI_PROP_bottomRightY,::CStringToInt(csValue));
		ChangeUIProp(UI_PROP_bottomRightY);
	}
}


void CUIPropDialog::OnCbnSelchangeComboNodeAlign()
{
	int iNodeAlign= ((CComboBox*)GetDlgItem(IDC_COMBO_NODE_ALIGN))->GetCurSel();
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_iAlign,iNodeAlign);

		//���ö��뷽ʽͬʱ�������������Ϊ0 �Ա�֤����Ч��
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_x,0);
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_y,0);
	}
}


void CUIPropDialog::OnCbnSelchangeComboVisible()
{
	bool bVisible = ((CComboBox*)GetDlgItem(IDC_COMBO_VISIBLE))->GetCurSel() ? 0 : 1;
	if(m_bEditData)
	{
		::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_bVisible,bVisible);
	}
}


BOOL CUIPropDialog::PreTranslateMessage(MSG* pMsg)
{
	switch(pMsg->message)
	{
	case WM_LBUTTONDOWN:
		{
		}
		break;
	default:
		break;
	}

	return CDialogEx::PreTranslateMessage(pMsg);
}

void CUIPropDialog::OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/)
{
}

LRESULT CUIPropDialog::MessageGetWidthHeight(WPARAM wParam,LPARAM lParam)
{
//	GetDlgItem(IDC_EDIT_NODE_W)->SetWindowText(::IntToCString(wParam));
//	GetDlgItem(IDC_EDIT_NODE_H)->SetWindowText(::IntToCString(lParam));
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_width,wParam);
	::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_height,lParam);
	return 0;
}

LRESULT CUIPropDialog::MessageEditKillFocus(WPARAM wParam,LPARAM lParam)
{
	CEdit *pEdit = (CEdit*)wParam;
	CWnd *pNewWnd = (CWnd*)lParam;

	EndChangeUIProp();

	return 0;
}

void CUIPropDialog::ChangeUIProp(EM_UI_PROP_TYPE emUIPropType)
{
	m_bChangeUIProp = TRUE;
	m_emUIPropType = emUIPropType;

	SetTimer(TIMER_CHANGE_UI_PROP,CHANGE_UI_PROP_DELAY,NULL);
}

void CUIPropDialog::EndChangeUIProp()
{
	KillTimer(TIMER_CHANGE_UI_PROP);
	if(!m_bChangeUIProp)
		return;

	switch(m_emUIPropType)
	{
	case UI_PROP_x:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_NODE_X)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_x,::CStringToInt(csValue));
			}
		}
		break;
	case UI_PROP_y:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_NODE_Y)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_y,::CStringToInt(csValue));
			}
		}
		break;
	case UI_PROP_width:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_NODE_W)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_width,::CStringToInt(csValue));
			}
		}
		break;
	case UI_PROP_height:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_NODE_H)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_height,::CStringToInt(csValue));
			}
		}
		break;
	case UI_PROP_topLeftX:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_TOPLEFTX)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_topLeftX,::CStringToInt(csValue));
			}
		}
		break;
	case UI_PROP_topLeftY:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_TOPLEFTY)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_topLeftY,::CStringToInt(csValue));
			}
		}
		break;
	case UI_PROP_bottomRightX:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_BOTTOMRIGHTX)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_bottomRightX,::CStringToInt(csValue));
			}
		}
		break;
	case UI_PROP_bottomRightY:
		{
			CString csValue;
			GetDlgItem(IDC_EDIT_BOTTOMRIGHTY)->GetWindowText(csValue);
			if(m_bEditData)
			{
				::SendMessage(((CMainFrame*)AfxGetMainWnd())->GetSafeHwnd(),WM_CHANGE_UI_PROP,UI_PROP_bottomRightY,::CStringToInt(csValue));
			}
		}
		break;
	default:
		break;
	}

	m_bChangeUIProp = FALSE;
	m_emUIPropType = (EM_UI_PROP_TYPE)-1;
}

void CUIPropDialog::OnTimer(UINT_PTR nIDEvent)
{
	switch(nIDEvent)
	{
	case TIMER_CHANGE_UI_PROP:
		{
			EndChangeUIProp();
		}
		break;
	default:
		break;
	}

	CDialogEx::OnTimer(nIDEvent);
}
