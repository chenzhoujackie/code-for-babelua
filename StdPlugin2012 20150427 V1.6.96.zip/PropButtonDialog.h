#pragma once
#include "afxwin.h"

#include "XGroupBox.h"
#include "XEdit.h"

#define WM_GET_WIDTH_HEIGHT			WM_USER+1383

#define STRING_CLICK_SELECT_LUA		_T("����ѡ��lua")

// CPropButtonDialog �Ի���

class CPropButtonDialog : public CDialogEx
{
public:
	void InitData(const CDrawingBase *pDrawingBase);
	void SaveChangeUIProp();
private:
	void ChangeDrawingBase(const CDrawingBase *pDrawingBase);
	void ChangeUIProp(EM_UI_PROP_TYPE emUIPropType);
	void EndChangeUIProp();
private:
	const CDrawingBase *m_pDrawingBase;

	BOOL m_bEditData;

	BOOL m_bChangeUIProp;				//�Ƿ��޸�UI����
	EM_UI_PROP_TYPE m_emUIPropType;		//�޸ĵ�UI�������

	DECLARE_DYNAMIC(CPropButtonDialog)

public:
	CPropButtonDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CPropButtonDialog();

// �Ի�������
	enum { IDD = IDD_PROP_BUTTON_DIALOG };
	CXGroupBox m_propImageStatic;
	CXEdit m_nodeG9LeftEdit;
	CXEdit m_nodeG9RightEdit;
	CXEdit m_nodeG9TopEdit;
	CXEdit m_nodeG9BottomEdit;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	afx_msg void OnBnClickedButtonNodeImage1();
	afx_msg void OnBnClickedButtonNodeImage2();
	afx_msg void OnBnClickedButtonGetWh();
	afx_msg void OnEnChangeEditNodeG9left();
	afx_msg void OnEnChangeEditNodeG9right();
	afx_msg void OnEnChangeEditNodeG9top();
	afx_msg void OnEnChangeEditNodeG9bottom();
	afx_msg void OnBnClickedButtonGetLuaPin();
	afx_msg void OnBnClickedButtonClearLuaPin();
	afx_msg void OnContextMenu(CWnd* /*pWnd*/, CPoint /*point*/);

	LRESULT MessageEditKillFocus(WPARAM wParam,LPARAM lParam);
	afx_msg void OnBnClickedButtonClearNodeImage2();
};
