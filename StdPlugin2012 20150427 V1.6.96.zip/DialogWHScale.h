#pragma once
#include "afxwin.h"


// CDialogWHScale �Ի���

class CDialogWHScale : public CDialogEx
{
	DECLARE_DYNAMIC(CDialogWHScale)

	int m_w[20];
	int m_h[20];
	char m_wdh[20][80];
	int m_num;
public:
	CDialogWHScale(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDialogWHScale();

// �Ի�������
	enum { IDD = IDD_DIALOG_SCALE };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	CComboBox m_List1;
	CComboBox m_List2;
	double m_scale;
	afx_msg void OnBnClickedOk();
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonSetDefault();
	afx_msg void OnCbnSelchangeCombo2();
	afx_msg void OnCbnSelchangeCombo1();
};
