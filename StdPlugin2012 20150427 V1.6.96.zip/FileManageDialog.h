#pragma once
#include "afxwin.h"
#include "afxshelllistctrl.h"


// CFileManageDialog �Ի���

class CFileManageDialog : public CDialogEx
{
public:
	void InitData(CString csSelDirectoryName,CString csSelFileName);
	CString GetSelDirectoryName() const;
	CString GetSelFileName() const;
private:
	CString InitDirectoryListBox(CString csSelDirectoryName);
	void InitFileListBox(CString csDirectoryName,CString csSelFileName);
	void UpdateSelect();

	CString GetSelectPath();
	CString GetCurrentDirectory();
	void SetSelectPath(CString strSelPath);
	void UpdateCurrentDirectory(CString strCurrentDirectory);
private:
	CString m_csSelDirectoryName;
	CString m_csSelFileName;

	DECLARE_DYNAMIC(CFileManageDialog)

public:
	CFileManageDialog(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CFileManageDialog();

// �Ի�������
	enum { IDD = IDD_FILE_MANAGE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedButtonNewDirectory();
	afx_msg void OnBnClickedButtonDeleteDirectory();
	afx_msg void OnBnClickedButtonExport();
	afx_msg void OnBnClickedButtonGenLua();
	afx_msg void OnBnClickedButtonNewFile();
	afx_msg void OnBnClickedButtonDeleteFile();
	afx_msg void OnBnClickedOk();
	CListBox m_directoryListBox;
	CListBox m_fileListBox;
	afx_msg void OnLbnSelchangeListDirectory();
	afx_msg void OnLbnDblclkListFile();
	afx_msg void OnBnClickedButtonOpenDirectory();
	afx_msg void OnBnClickedButtonGenLuaSingle();
	CMFCShellListCtrl m_listCtrl;
	afx_msg void OnLvnItemchangedMfcshelllist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLvnBeginlabeleditMfcshelllist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLvnEndlabeleditMfcshelllist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMClickMfcshelllist(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMRClickMfcshelllist(NMHDR *pNMHDR, LRESULT *pResult);
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	afx_msg void OnBnClickedButtonDelete();
	afx_msg void OnBnClickedButtonUp();
};
