// CustomControlDialog.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "CustomControlDialog.h"
#include "afxdialogex.h"

#include "LeftDialog.h"

// CCustomControlDialog �Ի���

IMPLEMENT_DYNAMIC(CCustomControlDialog, CDialogEx)

CCustomControlDialog::CCustomControlDialog(CWnd* pParent /*=NULL*/)
	: CDialogEx(CCustomControlDialog::IDD, pParent)
{

}

CCustomControlDialog::~CCustomControlDialog()
{
}

void CCustomControlDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CCustomControlDialog, CDialogEx)
	ON_EN_CHANGE(IDC_EDIT_CUSTOM_NAME, &CCustomControlDialog::OnEnChangeEditCustomName)
	ON_BN_CLICKED(IDOK, &CCustomControlDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CCustomControlDialog::OnBnClickedCancel)
	ON_EN_CHANGE(IDC_EDIT_CUSTOM_PAR1, &CCustomControlDialog::OnEnChangeEditCustomPar1)
	ON_EN_CHANGE(IDC_EDIT_CUSTOM_PAR2, &CCustomControlDialog::OnEnChangeEditCustomPar2)
	ON_EN_CHANGE(IDC_EDIT_CUSTOM_PAR3, &CCustomControlDialog::OnEnChangeEditCustomPar3)
	ON_EN_CHANGE(IDC_EDIT_CUSTOM_PAR4, &CCustomControlDialog::OnEnChangeEditCustomPar4)
	ON_EN_CHANGE(IDC_EDIT_CUSTOM_PAR5, &CCustomControlDialog::OnEnChangeEditCustomPar5)
	ON_CBN_SELCHANGE(IDC_COMBO_DATA_TYPE1, &CCustomControlDialog::OnCbnSelchangeComboDataType1)
	ON_CBN_SELCHANGE(IDC_COMBO_DATA_TYPE2, &CCustomControlDialog::OnCbnSelchangeComboDataType2)
	ON_CBN_SELCHANGE(IDC_COMBO_DATA_TYPE3, &CCustomControlDialog::OnCbnSelchangeComboDataType3)
	ON_CBN_SELCHANGE(IDC_COMBO_DATA_TYPE4, &CCustomControlDialog::OnCbnSelchangeComboDataType4)
	ON_CBN_SELCHANGE(IDC_COMBO_DATA_TYPE5, &CCustomControlDialog::OnCbnSelchangeComboDataType5)
END_MESSAGE_MAP()


// CCustomControlDialog ��Ϣ��������

void CCustomControlDialog::InitData(const CStringArray &csCustomNameArray)
{
	::CopyCStringArray(m_csCustomNameArray,csCustomNameArray);
}

CString CCustomControlDialog::GetCustomName() const
{
	return m_csCustomName;
}

void CCustomControlDialog::GetCustomData(CArray <CCustomData,CCustomData> &customDataArray) const
{
	customDataArray.RemoveAll();
	int i;
	for(i=0; i<m_customDataArray.GetSize(); i++)
	{
		customDataArray.Add(m_customDataArray.GetAt(i));
	}
}

BOOL CCustomControlDialog::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	int i,j;
	for(i=0; i<CUSTOM_PAR_NUM; i++)
	{
		for(j=0; j<CUSTOM_DATA_TYPE_NUM; j++)
		{
			((CComboBox*)GetDlgItem(IDC_COMBO_DATA_TYPE1+i))->AddString(::GetComboCustomDataTypeString(j));
			((CComboBox*)GetDlgItem(IDC_COMBO_DATA_TYPE1+i))->SetCurSel(0);
		}
	}

	OnEnChangeEditCustomName();

	return TRUE;
}

void CCustomControlDialog::OnEnChangeEditCustomName()
{
	CString csCustomName;
	GetDlgItem(IDC_EDIT_CUSTOM_NAME)->GetWindowText(csCustomName);

	BOOL bEmpty = csCustomName.IsEmpty();
	BOOL bExist = ::IsNameInArray(csCustomName,m_csCustomNameArray);
	GetDlgItem(IDOK)->EnableWindow(!(bEmpty || bExist));

	CustomPropChange();
}


void CCustomControlDialog::OnBnClickedOk()
{
	GetDlgItem(IDC_EDIT_CUSTOM_NAME)->GetWindowText(m_csCustomName);

	BOOL bEmpty = m_csCustomName.IsEmpty();
	BOOL bExist = ::IsNameInArray(m_csCustomName,m_csCustomNameArray);

	if(bEmpty || bExist)
		return;

	m_customDataArray.RemoveAll();
	int i;
	for(i=0; i<CUSTOM_PAR_NUM; i++)
	{
		int iCurSel = ((CComboBox*)GetDlgItem(IDC_COMBO_DATA_TYPE1+i))->GetCurSel();
		CString csCustomParName;
		GetDlgItem(IDC_EDIT_CUSTOM_PAR1+i)->GetWindowText(csCustomParName);
		if(iCurSel >= 0 && !csCustomParName.IsEmpty())
		{
			m_customDataArray.Add(CCustomData(csCustomParName,(EM_CUSTOM_DATA_TYPE)iCurSel));
		}
	}

	CDialogEx::OnOK();
}


void CCustomControlDialog::OnBnClickedCancel()
{
	CDialogEx::OnCancel();
}

void CCustomControlDialog::CustomPropChange()
{
	CString csCustomName;
	GetDlgItem(IDC_EDIT_CUSTOM_NAME)->GetWindowText(csCustomName);

	CString csCustomControl = _T("new(")+csCustomName;
	int i;
	for(i=0; i<CUSTOM_PAR_NUM; i++)
	{
		int iCurSel = ((CComboBox*)GetDlgItem(IDC_COMBO_DATA_TYPE1+i))->GetCurSel();
		CString csCustomParName;
		GetDlgItem(IDC_EDIT_CUSTOM_PAR1+i)->GetWindowText(csCustomParName);
		if(iCurSel >= 0 && !csCustomParName.IsEmpty())
		{
			csCustomControl += _T(",");
			csCustomControl += ::GetCustomDataType((EM_CUSTOM_DATA_TYPE)iCurSel);
		}
	}
	csCustomControl += _T(")");

	GetDlgItem(IDC_STATIC_CUSTOM_CONTROL)->SetWindowText(csCustomControl);
}

void CCustomControlDialog::OnEnChangeEditCustomPar1()
{
	CustomPropChange();
}


void CCustomControlDialog::OnEnChangeEditCustomPar2()
{
	CustomPropChange();
}


void CCustomControlDialog::OnEnChangeEditCustomPar3()
{
	CustomPropChange();
}


void CCustomControlDialog::OnEnChangeEditCustomPar4()
{
	CustomPropChange();
}


void CCustomControlDialog::OnEnChangeEditCustomPar5()
{
	CustomPropChange();
}


void CCustomControlDialog::OnCbnSelchangeComboDataType1()
{
	CustomPropChange();
}


void CCustomControlDialog::OnCbnSelchangeComboDataType2()
{
	CustomPropChange();
}


void CCustomControlDialog::OnCbnSelchangeComboDataType3()
{
	CustomPropChange();
}


void CCustomControlDialog::OnCbnSelchangeComboDataType4()
{
	CustomPropChange();
}


void CCustomControlDialog::OnCbnSelchangeComboDataType5()
{
	CustomPropChange();
}
