// TreeCtrl2.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "StdPlugin.h"
#include "TreeCtrl2.h"

#include "XmlTools.h"

// CTreeCtrl2

IMPLEMENT_DYNAMIC(CTreeCtrl2, CTreeCtrl)

	CTreeCtrl2::CTreeCtrl2()
{
	m_bIsDrag = FALSE;
	m_pDragImage = NULL;
}

CTreeCtrl2::~CTreeCtrl2()
{
}

CMapStringToString* CTreeCtrl2::GetChildsNames ( HTREEITEM hItem )
{
	m_ChildsNames.RemoveAll();
	m_ChildsNames.SetAt(_T("root"),_T("root"));

	HTREEITEM hChildItem = GetChildItem(hItem);

	if (ItemHasChildren(hItem))
	{
		while (hChildItem != NULL)
		{
			CString strText = GetItemText(hChildItem);
			m_ChildsNames.SetAt(strText,strText);
			hChildItem = GetNextSiblingItem(hChildItem);
		}
	}

	return &m_ChildsNames;
}
void CTreeCtrl2::DeleteAllItems2()
{
	DeleteAllItems();

	POSITION pos = m_TreeData.GetStartPosition();
	while(pos)
	{
		HTREEITEM hItem;
		CView1* pView;
		m_TreeData.GetNextAssoc(pos, hItem,pView);
		delete pView;
	}
	m_TreeData.RemoveAll();

}
void CTreeCtrl2::SetItemData2(HTREEITEM hItem,CView1* pView)
{
	SetItemData(hItem,(DWORD_PTR)pView);
	m_TreeData.SetAt(hItem,pView);
}
void CTreeCtrl2::DeleteItem2(HTREEITEM hItem)
{
	m_TreeData.RemoveKey(hItem);
	DeleteItem(hItem);
}
BEGIN_MESSAGE_MAP(CTreeCtrl2, CTreeCtrl)
	//{{AFX_MSG_MAP(CTreeCtrl2)
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_NOTIFY_REFLECT(TVN_BEGINDRAG, OnBegindrag)
	//}}AFX_MSG_MAP
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

CImageList* CTreeCtrl2::CreateDragImageEx(HTREEITEM hItem)
{
	if(GetImageList(TVSIL_NORMAL) != NULL)
		return CreateDragImage(hItem);

	CRect rect;
	GetItemRect(hItem, rect, TRUE);
	rect.top = rect.left = 0;

	// Create bitmap
	CClientDC dc (this);
	CDC memDC;

	if(!memDC.CreateCompatibleDC(&dc))
		return NULL;

	CBitmap bitmap;
	if(!bitmap.CreateCompatibleBitmap(&dc, rect.Width(), rect.Height()))
		return NULL;

	CBitmap* pOldMemDCBitmap = memDC.SelectObject( &bitmap );
	CFont* pOldFont = memDC.SelectObject(GetFont());

	memDC.FillSolidRect(&rect, RGB(0, 255, 0)); // Here green is used as mask color
	memDC.SetTextColor(GetSysColor(COLOR_GRAYTEXT));
	memDC.TextOut(rect.left, rect.top, GetItemText(hItem));

	memDC.SelectObject( pOldFont );
	memDC.SelectObject( pOldMemDCBitmap );

	// Create imagelist
	CImageList* pImageList = new CImageList;
	pImageList->Create(rect.Width(), rect.Height(),
		ILC_COLOR | ILC_MASK, 0, 1);
	pImageList->Add(&bitmap, RGB(0, 255, 0)); // Here green is used as mask color

	return pImageList;
}
BOOL CTreeCtrl2::FirstIsParent ( HTREEITEM hFirst,HTREEITEM hItem)
{
	HTREEITEM hParent = GetParentItem(hItem);
	while ( NULL != hParent )
	{
		if ( hFirst == hParent ) return TRUE;
		hParent = GetParentItem(hParent);
	}
	return FALSE;
}
void CTreeCtrl2::OnLButtonUp(UINT nFlags, CPoint point) 
{
	if (m_bIsDrag)
	{
		BOOL bCtrl = (BOOL)GetAsyncKeyState ( VK_CONTROL );
		m_bIsDrag = FALSE;
		CImageList::DragLeave(this);
		CImageList::EndDrag();
		ReleaseCapture();

		if(m_pDragImage != NULL) 
		{ 
			delete m_pDragImage; 
			m_pDragImage = NULL; 
		} 
		SelectDropTarget(NULL);

		if ( NULL == m_hItemDrop )
			return;

		if ( FirstIsParent ( m_hItemDrag,m_hItemDrop))
		{
			return;
		}

		HTREEITEM hCtrlParent = GetParentItem(m_hItemDrop);
		if ( bCtrl && NULL == hCtrlParent )
		{
			return;
		}

		Expand( m_hItemDrop, TVE_EXPAND );

		if ( bCtrl )
		{
			HTREEITEM htiNew = CopyBranch( m_hItemDrag, hCtrlParent,m_hItemDrop);
			DeleteItem2( m_hItemDrag );
			SelectItem( htiNew );
		}
		else
		{
			HTREEITEM htiNew = CopyBranch( m_hItemDrag, m_hItemDrop, TVI_LAST );
			DeleteItem2( m_hItemDrag );
			SelectItem( htiNew );
		}

	}

	CTreeCtrl::OnLButtonUp(nFlags, point);
}

void CTreeCtrl2::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	HTREEITEM hItem;

	if ( m_bIsDrag )
	{
		//�����϶�
		POINT pt = point;
		ClientToScreen( &pt );
		CImageList::DragMove(pt);

		m_hItemDrop = NULL;
		hItem = HitTest(point, 0);
		if ( NULL == hItem )
			return;
		if ( m_hItemDrag == hItem)
			return;

		if ( FirstIsParent ( m_hItemDrag,hItem))
		{
			return;
		}

		m_hItemDrop = hItem;
		CImageList::DragShowNolock(FALSE);
		SelectDropTarget(m_hItemDrop); 

		RECT rect;
		GetClientRect( &rect );
		if( point.y < rect.top + 10 )
		{
			// We need to scroll up
			// Scroll slowly if cursor near the treeview control
			int slowscroll = 6 - (rect.top + 10 - point.y) / 20;
			CImageList::DragShowNolock(FALSE);
			SendMessage( WM_VSCROLL, SB_LINEUP);
		}
		else if( point.y > rect.bottom - 10 )
		{
			// We need to scroll down
			// Scroll slowly if cursor near the treeview control
			CImageList::DragShowNolock(FALSE);
			SendMessage( WM_VSCROLL, SB_LINEDOWN);
		}
		else
		{
			CImageList::DragShowNolock(FALSE);
		}

		CImageList::DragShowNolock(TRUE);

	}
	else
	{
		//set cursor here
	}
	CTreeCtrl::OnMouseMove(nFlags, point);
}

void CTreeCtrl2::OnBegindrag(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;
	*pResult = 0;

	BOOL bCtrl = (BOOL)GetAsyncKeyState ( VK_CONTROL );
	BOOL bShift = (BOOL)GetAsyncKeyState ( VK_SHIFT );

	if ( bCtrl || bShift )
	{
		m_hItemDrag = pNMTreeView->itemNew.hItem;
		m_hItemDrop = NULL;

		m_pDragImage = CreateDragImageEx(m_hItemDrag);  // get the image list for dragging
		if( !m_pDragImage )
			return;

		m_bIsDrag = TRUE;
		m_pDragImage->BeginDrag(0, CPoint(-15,-15));
		POINT pt = pNMTreeView->ptDrag;
		ClientToScreen( &pt );
		m_pDragImage->DragEnter(NULL, pt);
		SetCapture();
	}
}
HTREEITEM CTreeCtrl2::CopyBranch(HTREEITEM hSrcItem, HTREEITEM hDestParent, HTREEITEM hPos)
{
	DWORD_PTR pData = GetItemData(hSrcItem);
	CString strText = GetItemText(hSrcItem);
	CView1* pView = (CView1*)pData;
	int iImageId = pView->iType;
	HTREEITEM hItem=InsertItem( strText,iImageId,iImageId, hDestParent,hPos);
	SetItemData2(hItem,pView);

	if (ItemHasChildren(hSrcItem))
	{
		HTREEITEM hChildItem = GetChildItem(hSrcItem);
		while( 0 != hChildItem )
		{
			CopyBranch(hChildItem,hItem,TVI_LAST);
			hChildItem =GetNextItem(hChildItem, TVGN_NEXT);  
		}
	}
	return hItem;
}

// CTreeCtrl2 ��Ϣ��������


void CTreeCtrl2::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	CTreeCtrl::OnKeyDown(nChar, nRepCnt, nFlags);
}

BOOL CTreeCtrl2::PreTranslateMessage(MSG* pMsg)
{
	return CTreeCtrl::PreTranslateMessage(pMsg);
}
