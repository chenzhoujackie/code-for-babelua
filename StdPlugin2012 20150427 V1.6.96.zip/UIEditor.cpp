#include "stdafx.h"
#include "UIEditor.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


CString GetUpFileDirectory(CString csFileDirectory)
{
	if(csFileDirectory.GetLength() <= 0)
		return csFileDirectory;

	//����ļ���·�������\��������ɾ��\����
	if(csFileDirectory.GetAt(csFileDirectory.GetLength()-1) == '\\')
	{
		csFileDirectory = csFileDirectory.Left(csFileDirectory.GetLength()-1);
	}

	int iIndex = csFileDirectory.ReverseFind('\\');
	CString csDirectory;
	if(iIndex >= 0)
		csDirectory = csFileDirectory.Left(iIndex);
	return csDirectory;
}


LuaInterface *g_pLuaInterface = NULL;
lua_State* g_L = NULL;
HWND g_hUIWnd = NULL;
HINSTANCE g_hUIInstance = NULL;
AnimInterface *g_pAnimInterface = NULL;
CRenderBase *g_pRenderBase = NULL;
EngineInterface *g_pEngineInterface = NULL;
int g_iUIWndWidth = 800;
int g_iUIWndHeight = 480;

int g_iEditorDrawingId = -1;

BOOL g_bEditMode = TRUE;
BOOL g_bShowGrid = FALSE;
BOOL g_bShowBorder = FALSE;
BOOL g_bShowWell = FALSE;

int g_iGridHSkip = 64;
int g_iGridVSkip = 64;

int g_iGridRed = 255;
int g_iGridGreen = 255;
int g_iGridBlue = 255;

int g_iBorderRed = 255;
int g_iBorderGreen = 0;
int g_iBorderBlue = 0;

int g_iWellRed = 255;
int g_iWellGreen = 255;
int g_iWellBlue = 0;

int g_iBkRed = 0;
int g_iBkGreen = 0;
int g_iBkBlue = 0;

COLORREF g_bottomColor = RGB(255,255,255);

CString g_csDefaultFontName;

BOOL GetEditMode()
{
	return g_bEditMode;
}

BOOL GetShowGrid()
{
	return g_bShowGrid;
}

BOOL GetShowBorder()
{
	return g_bShowBorder;
}

BOOL GetShowWell()
{
	return g_bShowWell;
}

void SetEditMode(BOOL bEditMode)
{
	g_bEditMode = bEditMode;
}

void SetShowGrid(BOOL bShowGrid)
{
	g_bShowGrid = bShowGrid;
}

void SetShowBorder(BOOL bShowBorder)
{
	g_bShowBorder = bShowBorder;
}

void SetShowWell(BOOL bShowWell)
{
	g_bShowWell = bShowWell;
}

void SetGridHSkip(int iGridHSkip)
{
	g_iGridHSkip = iGridHSkip;
}

int GetGridHSkip()
{
	return g_iGridHSkip;
}

void SetGridVSkip(int iGridVSkip)
{
	g_iGridVSkip = iGridVSkip;
}

int GetGridVSkip()
{
	return g_iGridVSkip;
}

void SetGridRed(int iGridRed)
{
	g_iGridRed = iGridRed;
}

int GetGridRed()
{
	return g_iGridRed;
}

void SetGridGreen(int iGridGreen)
{
	g_iGridGreen = iGridGreen;
}

int GetGridGreen()
{
	return g_iGridGreen;
}

void SetGridBlue(int iGridBlue)
{
	g_iGridBlue = iGridBlue;
}

int GetGridBlue()
{
	return g_iGridBlue;
}

void SetBorderRed(int iBorderRed)
{
	g_iBorderRed = iBorderRed;
}

int GetBorderRed()
{
	return g_iBorderRed;
}

void SetBorderGreen(int iBorderGreen)
{
	g_iBorderGreen = iBorderGreen;
}

int GetBorderGreen()
{
	return g_iBorderGreen;
}

void SetBorderBlue(int iBorderBlue)
{
	g_iBorderBlue = iBorderBlue;
}

int GetBorderBlue()
{
	return g_iBorderBlue;
}

void SetWellRed(int iWellRed)
{
	g_iWellRed = iWellRed;
}

int GetWellRed()
{
	return g_iWellRed;
}

void SetWellGreen(int iWellGreen)
{
	g_iWellGreen = iWellGreen;
}

int GetWellGreen()
{
	return g_iWellGreen;
}

void SetWellBlue(int iWellBlue)
{
	g_iWellBlue = iWellBlue;
}

int GetWellBlue()
{
	return g_iWellBlue;
}

void SetBkRed(int iBkRed)
{
	g_iBkRed = iBkRed;
}

int GetBkRed()
{
	return g_iBkRed;
}

void SetBkGreen(int iBkGreen)
{
	g_iBkGreen = iBkGreen;
}

int GetBkGreen()
{
	return g_iBkGreen;
}

void SetBkBlue(int iBkBlue)
{
	g_iBkBlue = iBkBlue;
}

int GetBkBlue()
{
	return g_iBkBlue;
}

void SetBottomColor(COLORREF color)
{
	g_bottomColor = color;
}

COLORREF GetBottomColor()
{
	return g_bottomColor;
}

void SetDefaultFontName(CString csDefaultFontName)
{
	g_csDefaultFontName = csDefaultFontName;
}

CString GetDefaultFontName()
{
	return g_csDefaultFontName;
}

CString COLORREFToRGBCString(COLORREF color)
{
	CString csColor;
	csColor.Format(_T("%d,%d,%d"),GetRValue(color),GetGValue(color),GetBValue(color));
	return csColor;
}

COLORREF RGBCStringToCOLORREF(CString csColor)
{
	int iRed = 0;
	int iGreen = 0;
	int iBlue = 0;
	int iRet = _stscanf(csColor,_T("%d,%d,%d"),&iRed,&iGreen,&iBlue);
	return RGB(iRed,iGreen,iBlue);
}

CString COLORREFToCString(COLORREF color)
{
	CString csColor;
	csColor.Format(_T("0x%02X%02X%02X"),GetRValue(color),GetGValue(color),GetBValue(color));
	return csColor;
}

BOOL CStringToCOLORREF(CString csColor,COLORREF &color)
{
	if(csColor.GetLength() < 8)
		return FALSE;

	csColor.MakeUpper();

	int iRed = 0;
	int iGreen = 0;
	int iBlue = 0;
	int iRet = _stscanf(csColor,_T("0X%02X%02X%02X"),&iRed,&iGreen,&iBlue);
	if(iRet >= 3)
	{
		color = RGB(iRed,iGreen,iBlue);
		return TRUE;
	}

	return FALSE;
}

void ReCreateGridText ( int wskip,int hskip,int r,int g,int b,bool bOnlyDelete )
{
	static vector<int> idh;
	static vector<int> idv;

	AnimInterface *pAnimInterface = ::GetAnimInterface();
	if(pAnimInterface == NULL)
		return;

	int i,w,h;
	w = ::GetUIWndWidth();
	h = ::GetUIWndHeight();
	for ( int i = 0; i < idh.size(); i ++ )
	{
		pAnimInterface->res_delete(idh[i]);
		pAnimInterface->drawing_delete(idh[i]);
	}
	idh.clear();

	for ( int i = 0; i < idv.size(); i ++ )
	{
		pAnimInterface->res_delete(idv[i]);
		pAnimInterface->drawing_delete(idv[i]);
	}
	idv.clear();

	if ( bOnlyDelete ) return;

	char buf[32];
	int sw,sh;
	int idStart = 2500;
	for ( i = wskip; i < w; )
	{
		sprintf(buf,"%d",i);
		pAnimInterface->res_create_text_image(10,idStart,buf,0,0,r,g,b,0,"",18,0);
		pAnimInterface->res_get_image_size(idStart,sw,sh);
		pAnimInterface->drawing_create_image(10,idStart,idStart,i,0,sw,sh,0,0,0,0,0,0);
		pAnimInterface->drawing_set_parent(idStart,0);
		idv.push_back(idStart++);
		i += wskip;
	}

	for ( i = hskip; i < h; )
	{
		sprintf(buf,"%d",i);
		pAnimInterface->res_create_text_image(10,idStart,buf,0,0,r,g,b,0,"",18,0);
		pAnimInterface->res_get_image_size(idStart,sw,sh);
		pAnimInterface->drawing_create_image(10,idStart,idStart,1,i,sw,sh,0,0,0,0,0,0);
		pAnimInterface->drawing_set_parent(idStart,0);
		idv.push_back(idStart++);
		i += hskip;
	}
}

static int g_iMouseXResId1 = 2493;
static int g_iMouseYResId1 = 2494;
static int g_iMouseXResId2 = 2495;
static int g_iMouseYResId2 = 2496;
static bool g_bCreateMouseResXY = false;
static bool g_bCreateMouseDrawingXY = false;

void DeleteWellText()
{
	AnimInterface *pAnimInterface = ::GetAnimInterface();
	if ( g_bCreateMouseResXY )
	{
		g_bCreateMouseResXY = false;
		pAnimInterface->res_delete(g_iMouseXResId1);
		pAnimInterface->res_delete(g_iMouseYResId1);
		pAnimInterface->res_delete(g_iMouseXResId2);
		pAnimInterface->res_delete(g_iMouseYResId2);
	}
	if ( g_bCreateMouseDrawingXY )
	{
		g_bCreateMouseDrawingXY = false;
		pAnimInterface->drawing_delete(g_iMouseXResId1);
		pAnimInterface->drawing_delete(g_iMouseYResId1);
		pAnimInterface->drawing_delete(g_iMouseXResId2);
		pAnimInterface->drawing_delete(g_iMouseYResId2);
	}
}

void ReCreateWellText ( int x1,int y1,int x2,int y2,int r,int g,int b )
{
	AnimInterface *pAnimInterface = ::GetAnimInterface();

	if ( g_bCreateMouseResXY )
	{
		pAnimInterface->res_delete(g_iMouseXResId1);
		pAnimInterface->res_delete(g_iMouseYResId1);
		pAnimInterface->res_delete(g_iMouseXResId2);
		pAnimInterface->res_delete(g_iMouseYResId2);
	}

	g_bCreateMouseResXY = true;

	int sw11,sh11,sw12,sh12,sw21,sh21,sw22,sh22;
	char buf[80];

	sprintf(buf,"%d",x1);
	pAnimInterface->res_create_text_image(10,g_iMouseXResId1,buf,0,0,r,g,b,0,"",18,0);
	pAnimInterface->res_get_image_size(g_iMouseXResId1,sw11,sh11);

	sprintf(buf,"%d",y1);
	pAnimInterface->res_create_text_image(10,g_iMouseYResId1,buf,0,0,r,g,b,0,"",18,0);
	pAnimInterface->res_get_image_size(g_iMouseYResId1,sw12,sh12);

	sprintf(buf,"%d",x2);
	pAnimInterface->res_create_text_image(10,g_iMouseXResId2,buf,0,0,r,g,b,0,"",18,0);
	pAnimInterface->res_get_image_size(g_iMouseXResId2,sw21,sh21);

	sprintf(buf,"%d",y2);
	pAnimInterface->res_create_text_image(10,g_iMouseYResId2,buf,0,0,r,g,b,0,"",18,0);
	pAnimInterface->res_get_image_size(g_iMouseYResId2,sw22,sh22);

	if ( false == g_bCreateMouseDrawingXY )
	{
		g_bCreateMouseDrawingXY = true;

		pAnimInterface->drawing_create_image(10,g_iMouseXResId1,g_iMouseXResId1,x1+1,0,sw11,sh11,0,0,0,0,0,0);
		pAnimInterface->drawing_set_parent(g_iMouseXResId1,0);

		pAnimInterface->drawing_create_image(10,g_iMouseYResId1,g_iMouseYResId1,1,y1,sw12,sh12,0,0,0,0,0,0);
		pAnimInterface->drawing_set_parent(g_iMouseYResId1,0);

		pAnimInterface->drawing_create_image(10,g_iMouseXResId2,g_iMouseXResId2,x2+1,0,sw21,sh21,0,0,0,0,0,0);
		pAnimInterface->drawing_set_parent(g_iMouseXResId2,0);

		pAnimInterface->drawing_create_image(10,g_iMouseYResId2,g_iMouseYResId2,1,y2,sw22,sh22,0,0,0,0,0,0);
		pAnimInterface->drawing_set_parent(g_iMouseYResId2,0);

	}
	else
	{
		pAnimInterface->drawing_set_position(g_iMouseXResId1,x1+1,0);
		pAnimInterface->drawing_set_size(g_iMouseXResId1,sw11,sh11);
		pAnimInterface->drawing_set_position(g_iMouseYResId1,1,y1);
		pAnimInterface->drawing_set_size(g_iMouseYResId1,sw12,sh12);

		pAnimInterface->drawing_set_position(g_iMouseXResId2,x2+1,0);
		pAnimInterface->drawing_set_size(g_iMouseXResId2,sw21,sh21);
		pAnimInterface->drawing_set_position(g_iMouseYResId2,1,y2);
		pAnimInterface->drawing_set_size(g_iMouseYResId2,sw22,sh22);

	}
}

void ReCreateWellText ()
{
	AnimInterface *pAnimInterface = ::GetAnimInterface();

	int iDrawingId = ::GetEditorDrawingId();
	if ( -1 == iDrawingId )
		return;
	double ox,oy;
	pAnimInterface->drawing_get_offset(iDrawingId,ox,oy);
	double x1,y1,w1,h1;
	pAnimInterface->drawing_get_rect(iDrawingId,x1,y1,w1,h1);
	x1 += ox;
	y1 += oy;
	ReCreateWellText(x1,y1,x1+w1,y1+h1,::GetWellRed(),::GetWellGreen(),::GetWellBlue());
}

void DrawWell(float x, float y, float iWidth, float iHeight)
{
	CRenderBase *pRenderBase = GetRenderBase();
	if(pRenderBase == NULL)
		return;

	float line_vertices[4];

	line_vertices[0] = x;
	line_vertices[1] = -3000;
	line_vertices[2] = x;
	line_vertices[3] = 3000;

	pRenderBase->DrawLines ( line_vertices, 0, 2 );

	line_vertices[0] = x+iWidth;
	line_vertices[1] = -3000;
	line_vertices[2] = x+iWidth;
	line_vertices[3] = 3000;

	pRenderBase->DrawLines ( line_vertices, 0, 2 );

	line_vertices[0] = -3000;
	line_vertices[1] = y;
	line_vertices[2] = 3000;
	line_vertices[3] = y;

	pRenderBase->DrawLines ( line_vertices, 0, 2 );

	line_vertices[0] = -3000;
	line_vertices[1] = y+iHeight;
	line_vertices[2] = 3000;
	line_vertices[3] = y+iHeight;

	pRenderBase->DrawLines ( line_vertices, 0, 2 );
}

void DrawHLine ( float y )
{
	CRenderBase *pRenderBase = GetRenderBase();
	if(pRenderBase == NULL)
		return;

	float line_vertices[4];

	line_vertices[0] = -3000;
	line_vertices[1] = y;
	line_vertices[2] = 3000;
	line_vertices[3] = y;

	pRenderBase->DrawLines ( line_vertices, 0, 2 );
}

void DrawVLine ( float x )
{
	CRenderBase *pRenderBase = GetRenderBase();
	if(pRenderBase == NULL)
		return;

	float line_vertices[4];

	line_vertices[0] = x;
	line_vertices[1] = -3000;
	line_vertices[2] = x;
	line_vertices[3] = 3000;

	pRenderBase->DrawLines ( line_vertices, 0, 2 );
}

static bool g_bEnableKeyHook = true;
void EnableKeyHook (bool bEnable )
{
	g_bEnableKeyHook = bEnable;
}

void SetLuaInterface(LuaInterface *pLuaInterface)
{
	g_pLuaInterface = pLuaInterface;
}

LuaInterface* GetLuaInterface()
{
	return g_pLuaInterface;
}

void SetLuaState(lua_State* L)
{
	g_L = L;
}

lua_State* GetLuaState()
{
	return g_L;
}

void SetUIWnd(HWND hWnd)
{
	g_hUIWnd = hWnd;
}

HWND GetUIWnd()
{
	return g_hUIWnd;
}

void SetUIInstance(HINSTANCE hInstance)
{
	g_hUIInstance = hInstance;
}

HINSTANCE GetUIInstance()
{
	return g_hUIInstance;
}

void print_string (const char* tag,const char *fmt, ...)
{
	if ( 0 != g_pAnimInterface )
	{
		va_list args;
		va_start(args, fmt);
		g_pAnimInterface->log_vprintf(tag,fmt,args);
		va_end(args);
	}
}

void SetAnimInterface(AnimInterface* pAnimInterface)
{
	g_pAnimInterface = pAnimInterface;
}

AnimInterface* GetAnimInterface()
{
	return g_pAnimInterface;
}

void SetRenderBase(CRenderBase *pRenderBase)
{
	g_pRenderBase = pRenderBase;
}

CRenderBase* GetRenderBase()
{
	return g_pRenderBase;
}

void SetEngineInterface(EngineInterface *pEngineInterface)
{
	g_pEngineInterface = pEngineInterface;
}

EngineInterface* GetEngineInterface()
{
	return g_pEngineInterface;
}

void SetUIWndSize(int iWidth,int iHeight)
{
	g_iUIWndWidth = iWidth;
	g_iUIWndHeight = iHeight;
}

int GetUIWndWidth()
{
	return g_iUIWndWidth;
}

int GetUIWndHeight()
{
	return g_iUIWndHeight;
}

void SetEditorDrawingId(int iEditorDrawingId)
{
	g_iEditorDrawingId = iEditorDrawingId;
}

int GetEditorDrawingId()
{
	return g_iEditorDrawingId;
}

BOOL GetUIPathName(int iDrawingId,CString &strParent,CString &strName)
{
	AnimInterface *pAnimInterface = ::GetAnimInterface();
	strName = pAnimInterface->drawing_get_name(iDrawingId);
	if(!strName.IsEmpty())
	{
		int id = pAnimInterface->drawing_get_parent(iDrawingId);
		while( id > 0 )
		{
			CString strTmp;
			strTmp = pAnimInterface->drawing_get_name(id);
			if(!strTmp.IsEmpty())
			{
				strParent = strParent + strTmp;
			}
			id = pAnimInterface->drawing_get_parent(id);
		}
	}
	return TRUE;
}

BOOL GetUITreePathArray(int iDrawingId,CStringArray &uiTreePathArray)
{
	AnimInterface *pAnimInterface = ::GetAnimInterface();

	CStringList uiTreePathList;
	CString strName;
	strName = pAnimInterface->drawing_get_name(iDrawingId);
	if(!strName.IsEmpty())
	{
		uiTreePathList.AddHead(strName);
		int id = pAnimInterface->drawing_get_parent(iDrawingId);
		while( id > 0 )
		{
			CString strTmp;
			strTmp = pAnimInterface->drawing_get_name(id);
			if(!strTmp.IsEmpty())
			{
				uiTreePathList.AddHead(strTmp);
			}
			id = pAnimInterface->drawing_get_parent(id);
		}
	}
	POSITION position = uiTreePathList.GetHeadPosition();
	int i;
	for(i=0; i<uiTreePathList.GetCount(); i++)
	{
		uiTreePathArray.Add(uiTreePathList.GetNext(position));
	}
	return TRUE;
}

const CString g_csDrawingTypeNameArray[] =
{
	_T(""),	//DRAWING_TYPE_Base
	_T(""),	//DRAWING_TYPE_ImageBase
	_T(""),	//DRAWING_TYPE_Empty
	_T("View"),				//DRAWING_TYPE_Node
	_T("Image"),			//DRAWING_TYPE_Image
	_T(""),	//DRAWING_TYPE_Images
	_T("Button"),			//DRAWING_TYPE_Button
	_T(""),	//DRAWING_TYPE_GroupNode
	_T(""),	//DRAWING_TYPE_GroupItem
	_T("CheckBoxGroup"),	//DRAWING_TYPE_CheckBoxGroup
	_T("CheckBox"),			//DRAWING_TYPE_CheckBox
	_T("RadioButtonGroup"),	//DRAWING_TYPE_RadioButtonGroup
	_T("RadioButton"),		//DRAWING_TYPE_RadioButton
	_T("Text"),				//DRAWING_TYPE_Text
	_T(""),	//DRAWING_TYPE_ScrollableNode
	_T("TextView"),			//DRAWING_TYPE_TextView
	_T("EditTextView"),		//DRAWING_TYPE_EditTextView
	_T("EditText"),			//DRAWING_TYPE_EditText
	_T(""),	//DRAWING_TYPE_ScrollBar
	_T(""),	//DRAWING_TYPE_TabView
	_T(""),	//DRAWING_TYPE_TableView
	_T(""),	//DRAWING_TYPE_GridView
	_T("ViewPaper"),		//DRAWING_TYPE_ViewPager
	_T("ListView"),			//DRAWING_TYPE_ListView
	_T("ScrollView"),		//DRAWING_TYPE_ScrollView
	_T("Slider"),			//DRAWING_TYPE_Slider
	_T(""),	//DRAWING_TYPE_Switch
	_T(""),	//DRAWING_TYPE_DrawingCustom
	_T(""),	//DRAWING_TYPE_CustomNode
	_T("CustomControl")	//DRAWING_TYPE_CustomControl
};

CString GetDrawingTypeName(EM_DRAWING_TYPE type)
{
	int iSize = sizeof(g_csDrawingTypeNameArray)/sizeof(CString);
	if(type >= 0 && type < iSize)
	{
		return g_csDrawingTypeNameArray[type];
	}

	return _T("Unknown");
}

const CString g_csDrawingTypeNewLuaNameArray[] =
{
	_T(""),	//DRAWING_TYPE_Base
	_T(""),	//DRAWING_TYPE_ImageBase
	_T(""),	//DRAWING_TYPE_Empty
	_T("Node"),				//DRAWING_TYPE_Node
	_T("Image"),			//DRAWING_TYPE_Image
	_T(""),	//DRAWING_TYPE_Images
	_T("Button"),			//DRAWING_TYPE_Button
	_T(""),	//DRAWING_TYPE_GroupNode
	_T(""),	//DRAWING_TYPE_GroupItem
	_T("CheckBoxGroup"),	//DRAWING_TYPE_CheckBoxGroup
	_T("CheckBox"),			//DRAWING_TYPE_CheckBox
	_T("RadioButtonGroup"),	//DRAWING_TYPE_RadioButtonGroup
	_T("RadioButton"),		//DRAWING_TYPE_RadioButton
	_T("Text"),				//DRAWING_TYPE_Text
	_T(""),	//DRAWING_TYPE_ScrollableNode
	_T("TextView"),			//DRAWING_TYPE_TextView
	_T("EditTextView"),		//DRAWING_TYPE_EditTextView
	_T("EditText"),			//DRAWING_TYPE_EditText
	_T(""),	//DRAWING_TYPE_ScrollBar
	_T(""),	//DRAWING_TYPE_TabView
	_T(""),	//DRAWING_TYPE_TableView
	_T(""),	//DRAWING_TYPE_GridView
	_T("ViewPaper"),		//DRAWING_TYPE_ViewPager
	_T("ListView"),			//DRAWING_TYPE_ListView
	_T("ScrollView"),		//DRAWING_TYPE_ScrollView
	_T("Slider"),			//DRAWING_TYPE_Slider
	_T(""),	//DRAWING_TYPE_Switch
	_T(""),	//DRAWING_TYPE_DrawingCustom
	_T(""),	//DRAWING_TYPE_CustomNode
	_T("CustomControl")	//DRAWING_TYPE_CustomControl
};

CString GetDrawingTypeNewLuaName(EM_DRAWING_TYPE type)
{
	int iSize = sizeof(g_csDrawingTypeNewLuaNameArray)/sizeof(CString);
	if(type >= 0 && type < iSize)
	{
		return g_csDrawingTypeNewLuaNameArray[type];
	}

	return _T("");
}

const CString g_csOldTypeNameArray[] =
{
	_T("0"),
	_T("1"),
	_T("2"),
	_T("3"),
	_T("4"),
	_T("5"),
	_T("6"),
	_T("7")
};

const EM_DRAWING_TYPE g_emOldTypeArray[] =
{
	DRAWING_TYPE_Node,
	DRAWING_TYPE_Image,
	DRAWING_TYPE_Button,
	DRAWING_TYPE_Button,
	DRAWING_TYPE_Text,
	DRAWING_TYPE_TextView,
	DRAWING_TYPE_EditText,
	DRAWING_TYPE_EditTextView
};

CString GetOldType(EM_DRAWING_TYPE type)
{
	int iSize = sizeof(g_emOldTypeArray)/sizeof(CString);
	int i;
	for(i=0; i<iSize; i++)
	{
		if(type == g_emOldTypeArray[i])
			return g_csOldTypeNameArray[i];
	}
	return g_csOldTypeNameArray[0];
}

EM_DRAWING_TYPE GetDrawingType(const CString &csType)
{
	if(!csType.IsEmpty())
	{
		//Old version
		if(csType == _T("ScrollViewHor") || csType == _T("AutoScrollView"))
			return DRAWING_TYPE_ScrollView;

		int iSize = sizeof(g_csDrawingTypeNameArray)/sizeof(CString);
		int i;
		for(i=0; i<iSize; i++)
		{
			if(csType == g_csDrawingTypeNameArray[i])
				return (EM_DRAWING_TYPE)i;
		}
		return DRAWING_TYPE_CustomControl;
	}
	return (EM_DRAWING_TYPE)-1;
}

const CString g_csTextAlignTypeNameArray[] =
{
	_T("kAlignCenter"),
	_T("kAlignTop"),
	_T("kAlignTopRight"),
	_T("kAlignRight"),
	_T("kAlignBottomRight"),
	_T("kAlignBottom"),
	_T("kAlignBottomLeft"),
	_T("kAlignLeft"),
	_T("kAlignTopLeft")
};

CString GetAlignTypeName(int align)
{
	int iSize = sizeof(g_csTextAlignTypeNameArray)/sizeof(CString);
	if(align >= 0 && align <= iSize)
		return g_csTextAlignTypeNameArray[align];

	return g_csTextAlignTypeNameArray[0];
}


CCharArr UnicodeToUTF8(CWCharArr wcharArr)
{
	int iLen = WideCharToMultiByte(CP_UTF8, 0, wcharArr, -1, NULL, 0, NULL, NULL);
	char *pchData = new char[iLen];
	if(pchData != NULL)
	{
		WideCharToMultiByte(CP_UTF8,0,wcharArr,(int)wcslen(wcharArr),pchData,iLen,NULL,NULL);
		pchData[iLen-1] = '\0';
	}

	CCharArr charArr;
	if(pchData != NULL)
	{
		charArr = pchData;

		delete []pchData;
		pchData = NULL;
	}
	return charArr;
}

CWCharArr UTF8ToUnicode(CCharArr charArr)
{
	int iLen = MultiByteToWideChar(CP_UTF8,0,charArr,-1,NULL,0);
	WCHAR *pchData = new WCHAR[iLen];
	if(pchData != NULL)
	{
		MultiByteToWideChar(CP_UTF8,0,charArr,(int)strlen(charArr),pchData,iLen);
		pchData[iLen-1] = '\0';
	}

	CWCharArr wcharArr;
	if(pchData != NULL)
	{
		wcharArr = pchData;

		delete []pchData;
		pchData = NULL;
	}
	return wcharArr;
}

void SetWindowTextW(CWnd *pWnd,CStringW csText)
{
	::SetWindowTextW(pWnd->GetSafeHwnd(),csText);
}

CStringW GetWindowTextW(CWnd *pWnd)
{
	CString csText;
	pWnd->GetWindowText(csText);
	int iLength = csText.GetLength();

	int iBufferLength = iLength*2+1;
	CStringW csBuffer;
	LPWSTR lpszBuffer = csBuffer.GetBuffer(iBufferLength);
	::GetWindowTextW(pWnd->GetSafeHwnd(),lpszBuffer,iBufferLength);
	CStringW csEditText = csBuffer;
	csBuffer.ReleaseBuffer();

	return csEditText;
}


long GetDrawingTime()
{
	time_t rawtime; 
	time ( &rawtime );
	return (long)(rawtime - 1350000000);
}

CDrawingBase::CDrawingBase()
{
	SetDrawingType(DRAWING_TYPE_Base);

	m_t = ::GetDrawingTime();

	m_x = 0;
	m_y = 0;
	m_width = 200;
	m_height = 150;
	m_topLeftX = 0;
	m_topLeftY = 0;
	m_bottomRightX = 0;
	m_bottomRightY = 0;
	m_iAlign = TextkAlignTopLeft;
	m_bAdaptiveWidth = false;
	m_bAdaptiveHeight = false;
	m_color = RGB(255,255,255);
	m_alpha = 255;
	m_bVisible = true;
}

CDrawingBase::~CDrawingBase()
{
}

CDrawingBase& CDrawingBase::operator=(const CDrawingBase &drawingBase)
{
	SetDrawingType(drawingBase.GetDrawingType());

	m_t = drawingBase.m_t;
	m_x = drawingBase.m_x;
	m_y = drawingBase.m_y;
	m_width = drawingBase.m_width;
	m_height = drawingBase.m_height;
	m_topLeftX = drawingBase.m_topLeftX;
	m_topLeftY = drawingBase.m_topLeftY;
	m_bottomRightX = drawingBase.m_bottomRightX;
	m_bottomRightY = drawingBase.m_bottomRightY;
	m_iAlign = drawingBase.m_iAlign;
	m_bAdaptiveWidth = drawingBase.m_bAdaptiveWidth;
	m_bAdaptiveHeight = drawingBase.m_bAdaptiveHeight;
	m_color = drawingBase.m_color;
	m_alpha = drawingBase.m_alpha;
	m_bVisible = drawingBase.m_bVisible;
	m_strName = drawingBase.m_strName;
	m_strLuaName = drawingBase.m_strLuaName;

	return *this;
}

EM_DRAWING_TYPE CDrawingBase::GetDrawingType() const
{
	return m_type;
}

void CDrawingBase::SetDrawingType(EM_DRAWING_TYPE type)
{
	m_type = type;
}

void CDrawingBase::SetTime(long time)
{
	m_t = time;
}

long CDrawingBase::GetTime() const
{
	return m_t;
}

void CDrawingBase::SetPos(int x,int y)
{
	m_x = x;
	m_y = y;
}

BOOL CDrawingBase::GetPos(int &x,int &y) const
{
	x = m_x;
	y = m_y;
	return TRUE;
}

void CDrawingBase::SetSize(int width,int height)
{
	m_width = width;
	m_height = height;
}

BOOL CDrawingBase::GetSize(int &width,int &height) const
{
	width = m_width;
	height = m_height;
	return TRUE;
}

void CDrawingBase::SetFillRegion(int topLeftX,int topLeftY,int bottomRightX,int bottomRightY)
{
	m_topLeftX = topLeftX;
	m_topLeftY = topLeftY;
	m_bottomRightX = bottomRightX;
	m_bottomRightY = bottomRightY;
}

BOOL CDrawingBase::GetFillRegion(int &topLeftX,int &topLeftY,int &bottomRightX,int &bottomRightY) const
{
	topLeftX = m_topLeftX;
	topLeftY = m_topLeftY;
	bottomRightX = m_bottomRightX;
	bottomRightY = m_bottomRightY;
	return TRUE;
}

void CDrawingBase::SetAlign(int align)
{
	m_iAlign = align;
}

BOOL CDrawingBase::GetAlign(int &align) const
{
	align = m_iAlign;
	return TRUE;
}

void CDrawingBase::SetFillParent(bool doFillParentWidth,bool doFillParentHeight)
{
	m_bAdaptiveWidth = doFillParentWidth;
	m_bAdaptiveHeight = doFillParentHeight;
}

BOOL CDrawingBase::GetFillParent(bool &doFillParentWidth,bool &doFillParentHeight) const
{
	doFillParentWidth = m_bAdaptiveWidth;
	doFillParentHeight = m_bAdaptiveHeight;
	return TRUE;
}

void CDrawingBase::SetColor(COLORREF color)
{
	m_color = color;
}

BOOL CDrawingBase::GetColor(COLORREF &color) const
{
	color = m_color;
	return TRUE;
}

void CDrawingBase::SetTransparency(BYTE alpha)
{
	m_alpha = alpha;
}

BOOL CDrawingBase::GetTransparency(BYTE &alpha) const
{
	alpha = m_alpha;
	return FALSE;
}

void CDrawingBase::SetVisible(bool visible)
{
	m_bVisible = visible;
}

BOOL CDrawingBase::GetVisible(bool &visible) const
{
	visible = m_bVisible;
	return TRUE;
}

void CDrawingBase::SetName(CString name)
{
	m_strName = name;
}

BOOL CDrawingBase::GetName(CString &name) const
{
	name = m_strName;
	return TRUE;
}

void CDrawingBase::SetPackFile(CString pickFile)
{
	m_strLuaName = pickFile;
}

BOOL CDrawingBase::GetPackFile(CString &pickFile) const
{
	pickFile = m_strLuaName;
	return TRUE;
}

CString CDrawingBase::GetDrawingTypeName() const
{
	return ::GetDrawingTypeName(GetDrawingType());
}

CString CDrawingBase::GetOldType() const
{
	return ::GetOldType(GetDrawingType());
}

CStringW CDrawingBase::GetTAGName() const
{
	CStringW csTagName;
	csTagName.Format(L"%s=\"%s\"",CWCharArr(TAG_Name),CWCharArr(m_strName));
	return csTagName;
}

CStringW CDrawingBase::GetTAGType() const
{
	CStringW csTAGType;
	csTAGType.Format(L",%s=%s",CWCharArr(TAG_Type),CWCharArr(GetOldType()));
	return csTAGType;
}

CStringW CDrawingBase::GetTAGTypeName() const
{
	CStringW csTAGTypeName;
	csTAGTypeName.Format(L",%s=\"%s\"",CWCharArr(TAG_TypeName),CWCharArr(GetDrawingTypeName()));
	return csTAGTypeName;
}

CStringW CDrawingBase::GetTAGCreateTime() const
{
	CStringW csTAGCreateTime;
	csTAGCreateTime.Format(L",%s=%ld",CWCharArr(TAG_CreateTime),GetTime());
	return csTAGCreateTime;
}

CStringW CDrawingBase::GetTAGXName() const
{
	CStringW csTAGXName;
	csTAGXName.Format(L",%s=%d",CWCharArr(TAG_XName),m_x);
	return csTAGXName;
}

CStringW CDrawingBase::GetTAGYName() const
{
	CStringW csTAGYName;
	csTAGYName.Format(L",%s=%d",CWCharArr(TAG_YName),m_y);
	return csTAGYName;
}

CStringW CDrawingBase::GetTAGWidthName() const
{
	CStringW csTAGWidthName;
	csTAGWidthName.Format(L",%s=%d",CWCharArr(TAG_WidthName),m_width);
	return csTAGWidthName;
}

CStringW CDrawingBase::GetTAGHeightName() const
{
	CStringW csTAGHeightName;
	csTAGHeightName.Format(L",%s=%d",CWCharArr(TAG_HeightName),m_height);
	return csTAGHeightName;
}

CStringW CDrawingBase::GetTAGFillRegion() const
{
	int topLeftX = 0;
	int topLeftY = 0;
	int bottomRightX = 0;
	int bottomRightY = 0;
	GetFillRegion(topLeftX,topLeftY,bottomRightX,bottomRightY);
	CStringW csTAGFillRegion;
	if(topLeftX > 0 || topLeftY > 0 || bottomRightX > 0 || bottomRightY > 0)
	{
		CStringW csTAGTopLeftX;
		csTAGTopLeftX.Format(L",%s=%d",CWCharArr(TAG_TopLeftX),topLeftX);

		CStringW csTAGTopLeftY;
		csTAGTopLeftY.Format(L",%s=%d",CWCharArr(TAG_TopLeftY),topLeftY);

		CStringW csTAGBottomRightX;
		csTAGBottomRightX.Format(L",%s=%d",CWCharArr(TAG_BottomRightX),bottomRightX);

		CStringW csTAGBottomRightY;
		csTAGBottomRightY.Format(L",%s=%d",CWCharArr(TAG_BottomRightY),bottomRightY);

		csTAGFillRegion = csTAGTopLeftX+csTAGTopLeftY+csTAGBottomRightX+csTAGBottomRightY;
	}
	return csTAGFillRegion;
}

CStringW CDrawingBase::GetTAGVisibleName() const
{
	CStringW csTAGVisibleName;
	csTAGVisibleName.Format(L",%s=%d",CWCharArr(TAG_VisibleName),m_bVisible);
	return csTAGVisibleName;
}

CStringW CDrawingBase::GetTAGAdaptiveWidthName() const
{
	CStringW csTAGAdaptiveWidthName;
	csTAGAdaptiveWidthName.Format(L",%s=%d",CWCharArr(TAG_AdaptiveWidthName),m_bAdaptiveWidth);
	return csTAGAdaptiveWidthName;
}

CStringW CDrawingBase::GetTAGAdaptiveHeightName() const
{
	CStringW csTAGAdaptiveHeightName;
	csTAGAdaptiveHeightName.Format(L",%s=%d",CWCharArr(TAG_AdaptiveHeightName),m_bAdaptiveHeight);
	return csTAGAdaptiveHeightName;
}

CStringW CDrawingBase::GetTAGNodeAlign() const
{
	CStringW csTAGNodeAlign;
	csTAGNodeAlign.Format(L",%s=%s",CWCharArr(TAG_NodeAlign),CWCharArr(::GetAlignTypeName(m_iAlign)));
	return csTAGNodeAlign;
}

CStringW CDrawingBase::GetTAGDrawingBase() const
{
	CStringW csTAGDrawingBase;
	csTAGDrawingBase += GetTAGName();
	csTAGDrawingBase += GetTAGType();
	csTAGDrawingBase += GetTAGTypeName();
	csTAGDrawingBase += GetTAGCreateTime();
	csTAGDrawingBase += GetTAGXName();
	csTAGDrawingBase += GetTAGYName();
	csTAGDrawingBase += GetTAGWidthName();
	csTAGDrawingBase += GetTAGHeightName();
	csTAGDrawingBase += GetTAGFillRegion();
	csTAGDrawingBase += GetTAGVisibleName();
	csTAGDrawingBase += GetTAGAdaptiveWidthName();
	csTAGDrawingBase += GetTAGAdaptiveHeightName();
	csTAGDrawingBase += GetTAGNodeAlign();
	return csTAGDrawingBase;
}

CStringW CDrawingBase::GetTAGTotal() const
{
	return GetTAGDrawingBase();
}

CStringW CDrawingBase::GetLuaScriptsName() const
{
	CStringW csLuaScriptsName;
	csLuaScriptsName.Format(L"editor%d",GetTime());
	return csLuaScriptsName;
}

CStringW CDrawingBase::GetLuaScriptsSetPos() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setPos(%d,%d);"),GetLuaScriptsName(),m_x,m_y);
	csLuaScripts.Format(L"editor_setPos(%s,%d,%d);",GetLuaScriptsName(),m_x,m_y);
	return csLuaScripts;
}

CStringW CDrawingBase::GetLuaScriptsSetSize() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setSize(%d,%d);"),GetLuaScriptsName(),m_width,m_height);
	csLuaScripts.Format(L"editor_setSize(%s,%d,%d);",GetLuaScriptsName(),m_width,m_height);
	return csLuaScripts;
}

CStringW CDrawingBase::GetLuaScriptsSetFillRegion() const
{
	BOOL bFillRegion = (m_topLeftX != 0 || m_topLeftY!= 0 || m_bottomRightX!= 0 || m_bottomRightY!=0);
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setFillRegion(%s,%d,%d,%d,%d);"),GetLuaScriptsName(),bFillRegion ? _T("true") : _T("false"),m_topLeftX,m_topLeftY,m_bottomRightX,m_bottomRightY);
	csLuaScripts.Format(L"editor_setFillRegion(%s,%s,%d,%d,%d,%d);",GetLuaScriptsName(),bFillRegion ? L"true" : L"false",m_topLeftX,m_topLeftY,m_bottomRightX,m_bottomRightY);
	return csLuaScripts;
}

CStringW CDrawingBase::GetLuaScriptsSetAlign() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setAlign(%s);"),GetLuaScriptsName(),::GetAlignTypeName(m_iAlign));
	csLuaScripts.Format(L"editor_setAlign(%s,%s);",GetLuaScriptsName(),CWCharArr(::GetAlignTypeName(m_iAlign)));
	return csLuaScripts;
}

CStringW CDrawingBase::GetLuaScriptsSetFillParent() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setFillParent(%s,%s);"),GetLuaScriptsName(),m_bAdaptiveWidth ? _T("true") : _T("false"),m_bAdaptiveHeight ? _T("true") : _T("false"));
	csLuaScripts.Format(L"editor_setFillParent(%s,%s,%s);",GetLuaScriptsName(),m_bAdaptiveWidth ? L"true" : L"false",m_bAdaptiveHeight ? L"true" : L"false");
	return csLuaScripts;
}

CStringW CDrawingBase::GetLuaScriptsSetColor() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setColor(%d,%d,%d);"),GetLuaScriptsName(),GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
	csLuaScripts.Format(L"editor_setColor(%s,%d,%d,%d);",GetLuaScriptsName(),GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
	return csLuaScripts;
}

CStringW CDrawingBase::GetLuaScriptsSetTransparency() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setTransparency(%d);"),GetLuaScriptsName(),m_alpha);
	csLuaScripts.Format(L"editor_setTransparency(%s,%d);",GetLuaScriptsName(),m_alpha);
	return csLuaScripts;
}

CStringW CDrawingBase::GetLuaScriptsSetVisible() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setVisible(%s);"),GetLuaScriptsName(),m_bVisible ? _T("true") : _T("false"));
	csLuaScripts.Format(L"editor_setVisible(%s,%s);",GetLuaScriptsName(),m_bVisible ? L"true" : L"false");
	return csLuaScripts;
}

CStringW CDrawingBase::GetLuaScriptsSetName() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setName(\"%s\");"),GetLuaScriptsName(),m_strName);
	csLuaScripts.Format(L"editor_setName(%s,\"%s\");",GetLuaScriptsName(),CWCharArr(m_strName));
	return csLuaScripts;
}

CStringW CDrawingBase::GetLuaScriptsSetPackFile() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setPackFile(\"%s\");"),GetLuaScriptsName(),m_strLuaName);
	return csLuaScripts;
}

CStringW CDrawingBase::GetLuaScriptsSetLevel(int iLevel) const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setLevel(\"%d\");"),GetLuaScriptsName(),iLevel);
	csLuaScripts.Format(L"editor_setLevel(%s,\"%d\");",GetLuaScriptsName(),iLevel);
	return csLuaScripts;
}

CStringW CDrawingBase::GetDrawingTypeNewLuaName() const
{
	return CStringW(CWCharArr(::GetDrawingTypeNewLuaName(GetDrawingType())));
}

CStringW CDrawingBase::GetLuaScriptsNew() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s = new(%s);"),GetLuaScriptsName(),GetDrawingTypeNewLuaName());
//	csLuaScripts.Format(_T("%s = editor_newClass(%s);"),GetLuaScriptsName(),GetDrawingTypeNewLuaName());

	CStringW csTAGTable = L"{"+GetTAGTotal()+L"}";
	csLuaScripts.Format(L"%s = editor_newClass(%s);",GetLuaScriptsName(),csTAGTable);

	return csLuaScripts;
}

CStringW CDrawingBase::GetLuaScriptsRecreate() const
{
	CStringW csLuaScripts;
	CStringW csTAGTable = L"{"+GetTAGTotal()+L"}";
	csLuaScripts.Format(L"%s = editor_recreateClass(%s,%s);",GetLuaScriptsName(),GetLuaScriptsName(),csTAGTable);

	return csLuaScripts;
}

CStringW CDrawingBase::GetLuaScriptsSetAll() const
{
	CStringW csLuaScripts;
	csLuaScripts += GetLuaScriptsSetPos();
	csLuaScripts += GetLuaScriptsSetSize();
	csLuaScripts += GetLuaScriptsSetFillRegion();
	csLuaScripts += GetLuaScriptsSetAlign();
	csLuaScripts += GetLuaScriptsSetFillParent();
	csLuaScripts += GetLuaScriptsSetColor();
	csLuaScripts += GetLuaScriptsSetVisible();
	csLuaScripts += GetLuaScriptsSetName();
	return csLuaScripts;
}

CDrawingBase* CDrawingBase::Clone() const
{
	CDrawingBase *pDrawingBase = new CDrawingBase;
	if(pDrawingBase != NULL)
	{
		*pDrawingBase = *this;
	}
	return pDrawingBase;
}

CStringW GetLuaScriptsAddChild(CDrawingBase *pParentDrawingBase,CDrawingBase *pChildDrawingBase)
{
	CStringW csLuaScripts;
	if(pParentDrawingBase != NULL && pChildDrawingBase != NULL)
	{
		CStringW csParentNodeLuaScriptsName = pParentDrawingBase->GetLuaScriptsName();
		CStringW csChildNodeLuaScriptsName = pChildDrawingBase->GetLuaScriptsName();
//		csLuaScripts = csParentNodeLuaScriptsName+_T(":addChild(")+csChildNodeLuaScriptsName+_T(");");
		csLuaScripts = L"editor_addChild("+csParentNodeLuaScriptsName+L","+csChildNodeLuaScriptsName+L");";
	}
	return csLuaScripts;
}

CStringW GetLuaScriptsRemoveChild(CDrawingBase *pParentDrawingBase,CDrawingBase *pChildDrawingBase)
{
	CStringW csLuaScripts;
	if(pParentDrawingBase != NULL && pChildDrawingBase != NULL)
	{
		CStringW csParentNodeLuaScriptsName = pParentDrawingBase->GetLuaScriptsName();
		CStringW csChildNodeLuaScriptsName = pChildDrawingBase->GetLuaScriptsName();
//		csLuaScripts = csParentNodeLuaScriptsName+_T(":removeChild(")+csChildNodeLuaScriptsName+_T(",true);");
		csLuaScripts = L"editor_removeChild("+csParentNodeLuaScriptsName+L","+csChildNodeLuaScriptsName+L");";
	}
	return csLuaScripts;
}


CDrawingImageBase::CDrawingImageBase()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_ImageBase);

	m_gLeft = 0;
	m_gRight = 0;
	m_gTop = 0;
	m_gBottom = 0;
}

CDrawingImageBase& CDrawingImageBase::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingImageBase::operator=((CDrawingImageBase&)drawingBase);
	else
		CDrawingBase::operator=(drawingBase);

	return *this;
}

CDrawingImageBase& CDrawingImageBase::operator=(const CDrawingImageBase &drawingImageBase)
{
	CDrawingBase::operator=(drawingImageBase);

	m_gLeft = drawingImageBase.m_gLeft;
	m_gRight = drawingImageBase.m_gRight;
	m_gTop = drawingImageBase.m_gTop;
	m_gBottom = drawingImageBase.m_gBottom;

	return *this;
}

CDrawingImageBase::~CDrawingImageBase()
{
}

void CDrawingImageBase::SetGrid9(int leftWidth,int rightWidth,int topWidth,int bottomWidth)
{
	m_gLeft = leftWidth;
	m_gRight = rightWidth;
	m_gTop = topWidth;
	m_gBottom = bottomWidth;
}

BOOL CDrawingImageBase::GetGrid9(int &leftWidth,int &rightWidth,int &topWidth,int &bottomWidth) const
{
	leftWidth = m_gLeft;
	rightWidth = m_gRight;
	topWidth = m_gTop;
	bottomWidth = m_gBottom;
	return TRUE;
}

CStringW CDrawingImageBase::GetLuaScriptsSetGrid9() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setResRectPlain(%d,%d,%d,%d,%d);"),GetLuaScriptsName(),0,m_gLeft,m_gRight,m_gTop,m_gBottom);
	csLuaScripts.Format(L"editor_setResRectPlain(%s,%d,%d,%d,%d,%d);",GetLuaScriptsName(),0,m_gLeft,m_gRight,m_gTop,m_gBottom);
	return csLuaScripts;
}

CStringW CDrawingImageBase::GetLuaScriptsSetAll() const
{
	CStringW csLuaScripts;
	csLuaScripts += CDrawingBase::GetLuaScriptsSetAll();
	csLuaScripts += GetLuaScriptsSetGrid9();
	return csLuaScripts;
}

CDrawingBase* CDrawingImageBase::Clone() const
{
	CDrawingImageBase *pDrawingImageBase = new CDrawingImageBase;
	if(pDrawingImageBase != NULL)
	{
		*pDrawingImageBase = *this;
	}
	return pDrawingImageBase;
}

CDrawingImageBase* CDrawingImageBase::CDrawingBaseToCDrawingImageBase(CDrawingBase *pDrawingBase)
{
	return dynamic_cast <CDrawingImageBase *>(pDrawingBase);
}

CDrawingEmpty::CDrawingEmpty()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_Empty);
}

CDrawingEmpty& CDrawingEmpty::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingEmpty::operator=((CDrawingEmpty&)drawingBase);
	else
		CDrawingBase::operator=(drawingBase);

	return *this;
}

CDrawingEmpty& CDrawingEmpty::operator=(const CDrawingEmpty &drawingEmpty)
{
	CDrawingBase::operator=(drawingEmpty);

	return *this;
}

CDrawingEmpty::~CDrawingEmpty()
{
}


CDrawingNode::CDrawingNode()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_Node);
}

CDrawingNode& CDrawingNode::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingNode::operator=((CDrawingNode&)drawingBase);
	else
		CDrawingEmpty::operator=(drawingBase);

	return *this;
}

CDrawingNode& CDrawingNode::operator=(const CDrawingNode &drawingNode)
{
	CDrawingEmpty::operator=(drawingNode);

	return *this;
}

CDrawingNode::~CDrawingNode()
{
}

BOOL GetImageWidthHeight(CString csFile,int &width,int &height)
{
	Image *pImage = Image::FromFile(CWCharArr(csFile));
	if(pImage != NULL)
	{
		width = pImage->GetWidth();
		height = pImage->GetHeight();

		delete pImage;
		pImage = NULL;

		return TRUE;
	}
	return FALSE;
}

CDrawingImage::CDrawingImage()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_Image);
}

CDrawingImage& CDrawingImage::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingImage::operator=((CDrawingImage&)drawingBase);
	else
		CDrawingImageBase::operator=(drawingBase);

	return *this;
}

CDrawingImage& CDrawingImage::operator=(const CDrawingImage &drawingImage)
{
	CDrawingImageBase::operator=(drawingImage);

	m_csFile = drawingImage.m_csFile;

	return *this;
}

CDrawingImage::~CDrawingImage()
{
}

void CDrawingImage::SetFile(CString file)
{
	m_csFile = file;
}

BOOL CDrawingImage::GetFile(CString &file) const
{
	file = m_csFile;
	return TRUE;
}

BOOL CDrawingImage::FixFileSize()
{
	CString csFile;
	GetFile(csFile);
	int width = 0;
	int height = 0;
	if(::GetImageWidthHeight(IMAGES_DIRECTORY+_T("\\")+csFile,width,height))
	{
		CDrawingBase::SetSize(width,height);
		return TRUE;
	}
	return FALSE;
}

CStringW CDrawingImage::GetTAGFileName() const
{
	CStringW csTAGFileName;
	CString csFileName;
	GetFile(csFileName);
	if(!csFileName.IsEmpty())
		csTAGFileName.Format(L",%s=\"%s\"",CWCharArr(TAG_FileName),CWCharArr(csFileName));
	return csTAGFileName;
}

CStringW CDrawingImage::GetTAGLuaName() const
{
	CStringW csTAGLuaName;
	CString csPickFile;
	GetPackFile(csPickFile);
	if(!csPickFile.IsEmpty())
	{
		int pos1 = csPickFile.Find('.');
		if(pos1 > 0)
		{
			csTAGLuaName.Format(L",%s=\"%s\"",CWCharArr(TAG_LuaName),CWCharArr(csPickFile));
		}
	}
	return csTAGLuaName;
}

CStringW CDrawingImage::GetTAG9Grid() const
{
	CStringW csTAG9Grid;
	int leftWidth = 0;
	int rightWidth = 0;
	int topWidth = 0;
	int bottomWidth = 0;
	GetGrid9(leftWidth,rightWidth,topWidth,bottomWidth);
	if( leftWidth > 0 || rightWidth > 0 || topWidth > 0 || bottomWidth > 0 )
	{
		CStringW cs9GridLeft;
		cs9GridLeft.Format(L",%s=%d",CWCharArr(TAG_9GridLeft),leftWidth);
		CStringW cs9GridRight;
		cs9GridRight.Format(L",%s=%d",CWCharArr(TAG_9GridRight),rightWidth);
		CStringW cs9GridTop;
		cs9GridTop.Format(L",%s=%d",CWCharArr(TAG_9GridTop),topWidth);
		CStringW cs9GridBottom;
		cs9GridBottom.Format(L",%s=%d",CWCharArr(TAG_9GridBottom),bottomWidth);

		csTAG9Grid = cs9GridLeft+cs9GridRight+cs9GridTop+cs9GridBottom;
	}
	return csTAG9Grid;
}

CStringW CDrawingImage::GetTAGDrawingImage() const
{
	CStringW csTAGDrawingImage;
	csTAGDrawingImage += CDrawingBase::GetTAGDrawingBase();
	csTAGDrawingImage += GetTAGFileName();
	csTAGDrawingImage += GetTAGLuaName();
	csTAGDrawingImage += GetTAG9Grid();
	return csTAGDrawingImage;
}

CStringW CDrawingImage::GetTAGTotal() const
{
	return GetTAGDrawingImage();
}

CStringW CDrawingImage::GetLuaScriptsSetFile() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setFile(\"%s\");"),GetLuaScriptsName(),m_csFile);
	CString csPickFile;
	CDrawingBase::GetPackFile(csPickFile);
	csLuaScripts.Format(L"editor_setFile(%s,\"%s\",\"%s\");",GetLuaScriptsName(),CWCharArr(m_csFile),CWCharArr(csPickFile));
	return csLuaScripts;
}
/*
CString CDrawingImage::GetLuaScriptsNew() const
{
	CString csLuaScripts;
//	csLuaScripts.Format(_T("%s = new(%s,\"%s\");"),GetLuaScriptsName(),GetDrawingTypeNewLuaName(),m_csFile);
	csLuaScripts.Format(_T("%s = editor_newImage(%s,\"%s\");"),GetLuaScriptsName(),GetDrawingTypeNewLuaName(),m_csFile);
	return csLuaScripts;
}
*/
CStringW CDrawingImage::GetLuaScriptsSetAll() const
{
	CStringW csLuaScripts;
	csLuaScripts += CDrawingBase::GetLuaScriptsSetAll();
	csLuaScripts += GetLuaScriptsSetFile();
	return csLuaScripts;
}

CDrawingBase* CDrawingImage::Clone() const
{
	CDrawingImage *pDrawingImage = new CDrawingImage;
	if(pDrawingImage != NULL)
	{
		*pDrawingImage = *this;
	}
	return pDrawingImage;
}

CDrawingImage* CDrawingImage::CDrawingBaseToCDrawingImage(CDrawingBase *pDrawingBase)
{
	return dynamic_cast <CDrawingImage *>(pDrawingBase);
}


CDrawingImages::CDrawingImages()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_Images);
}

CDrawingImages& CDrawingImages::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingImages::operator=((CDrawingImages&)drawingBase);
	else
		CDrawingImage::operator=(drawingBase);

	return *this;
}

CDrawingImages& CDrawingImages::operator=(const CDrawingImages &drawingImages)
{
	CDrawingImage::operator=(drawingImages);

	return *this;
}

CDrawingImages::~CDrawingImages()
{
}


CDrawingButton::CDrawingButton()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_Button);
}

CDrawingButton& CDrawingButton::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingButton::operator=((CDrawingButton&)drawingBase);
	else
		CDrawingImages::operator=(drawingBase);

	return *this;
}

CDrawingButton& CDrawingButton::operator=(const CDrawingButton &drawingButton)
{
	CDrawingImages::operator=(drawingButton);

	m_csFile2 = drawingButton.m_csFile2;

	return *this;
}

CDrawingButton::~CDrawingButton()
{
}

void CDrawingButton::SetFile2(CString file)
{
	m_csFile2 = file;
}

BOOL CDrawingButton::GetFile2(CString &file) const
{
	file = m_csFile2;
	return TRUE;
}

BOOL CDrawingButton::FixFileSize()
{
	CString csFile;
	GetFile(csFile);
	int width = 0;
	int height = 0;
	if(::GetImageWidthHeight(IMAGES_DIRECTORY+_T("\\")+csFile,width,height))
	{
		CDrawingBase::SetSize(width,height);
		return TRUE;
	}
	return FALSE;
}

CStringW CDrawingButton::GetTAGFile2Name() const
{
	CString csFile2Name;
	GetFile2(csFile2Name);
	CStringW csTAGFile2Name;
	if(!csFile2Name.IsEmpty())
		csTAGFile2Name.Format(L",%s=\"%s\"",CWCharArr(TAG_File2Name),CWCharArr(csFile2Name));
	return csTAGFile2Name;
}

CStringW CDrawingButton::GetTAGDrawingButton() const
{
	CStringW csTAGDrawingButton;
	csTAGDrawingButton += CDrawingImage::GetTAGDrawingImage();
	csTAGDrawingButton += GetTAGFile2Name();
	return csTAGDrawingButton;
}

CStringW CDrawingButton::GetTAGTotal() const
{
	return GetTAGDrawingButton();
}

CStringW CDrawingButton::GetLuaScriptsSetFile2() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setFile2(\"%s\");"),GetLuaScriptsName(),m_csFile2);
	return csLuaScripts;
}
/*
CString CDrawingButton::GetLuaScriptsNew() const
{
	CString csLuaScripts;
	if(m_csFile2.IsEmpty())
//		csLuaScripts.Format(_T("%s = new(%s,\"%s\");"),GetLuaScriptsName(),GetDrawingTypeNewLuaName(),m_csFile);
		csLuaScripts.Format(_T("%s = editor_newButton(%s,\"%s\");"),GetLuaScriptsName(),GetDrawingTypeNewLuaName(),m_csFile);
	else
//		csLuaScripts.Format(_T("%s = new(%s,\"%s\",\"%s\");"),GetLuaScriptsName(),GetDrawingTypeNewLuaName(),m_csFile,m_csFile2);
		csLuaScripts.Format(_T("editor_newButton2(%s,%s,\"%s\",\"%s\");"),GetLuaScriptsName(),GetDrawingTypeNewLuaName(),m_csFile,m_csFile2);

	return csLuaScripts;
}
*/
CStringW CDrawingButton::GetLuaScriptsSetAll() const
{
	CStringW csLuaScripts;
	csLuaScripts += CDrawingImage::GetLuaScriptsSetAll();
//	csLuaScripts += GetLuaScriptsSetFile2();
	return csLuaScripts;
}

CDrawingBase* CDrawingButton::Clone() const
{
	CDrawingButton *pDrawingButton = new CDrawingButton;
	if(pDrawingButton != NULL)
	{
		*pDrawingButton = *this;
	}
	return pDrawingButton;
}

CDrawingButton* CDrawingButton::CDrawingBaseToCDrawingButton(CDrawingBase *pDrawingBase)
{
	return dynamic_cast <CDrawingButton *>(pDrawingBase);
}


CDrawingGroupNode::CDrawingGroupNode()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_GroupNode);
}

CDrawingGroupNode::~CDrawingGroupNode()
{
}


CDrawingGroupItem::CDrawingGroupItem()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_GroupItem);
}

CDrawingGroupItem& CDrawingGroupItem::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingGroupItem::operator=((CDrawingGroupItem&)drawingBase);
	else
		CDrawingImages::operator=(drawingBase);

	return *this;
}

CDrawingGroupItem& CDrawingGroupItem::operator=(const CDrawingGroupItem &drawingGroupItem)
{
	CDrawingImages::operator=((CDrawingImages&)drawingGroupItem);

	return *this;
}

CDrawingGroupItem::~CDrawingGroupItem()
{
}


CDrawingCheckBoxGroup::CDrawingCheckBoxGroup()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_CheckBoxGroup);
}

CDrawingCheckBoxGroup::~CDrawingCheckBoxGroup()
{
}


CDrawingCheckBox::CDrawingCheckBox()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_CheckBox);

	m_width = 48;
	m_height = 48;
}

CDrawingCheckBox& CDrawingCheckBox::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingCheckBox::operator=((CDrawingCheckBox&)drawingBase);
	else
		CDrawingButton::operator=(drawingBase);

	return *this;
}

CDrawingCheckBox& CDrawingCheckBox::operator=(const CDrawingCheckBox &drawingCheckBox)
{
	CDrawingButton::operator=((CDrawingButton&)drawingCheckBox);

	return *this;
}

CDrawingCheckBox::~CDrawingCheckBox()
{
}

CStringW CDrawingCheckBox::GetLuaScriptsSetAll() const
{
	CStringW csLuaScripts;
	return csLuaScripts;
}

CDrawingBase* CDrawingCheckBox::Clone() const
{
	CDrawingCheckBox *pDrawingCheckBox = new CDrawingCheckBox;
	if(pDrawingCheckBox != NULL)
	{
		*pDrawingCheckBox = *this;
	}
	return pDrawingCheckBox;
}


CDrawingRadioButtonGroup::CDrawingRadioButtonGroup()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_RadioButtonGroup);
}

CDrawingRadioButtonGroup::~CDrawingRadioButtonGroup()
{
}


CDrawingRadioButton::CDrawingRadioButton()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_RadioButton);

	m_width = 50;
	m_height = 50;
}

CDrawingRadioButton& CDrawingRadioButton::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingRadioButton::operator=((CDrawingRadioButton&)drawingBase);
	else
		CDrawingButton::operator=(drawingBase);

	return *this;
}

CDrawingRadioButton& CDrawingRadioButton::operator=(const CDrawingRadioButton &drawingRadioButton)
{
	CDrawingButton::operator=((CDrawingButton&)drawingRadioButton);

	return *this;
}

CDrawingRadioButton::~CDrawingRadioButton()
{
}

CStringW CDrawingRadioButton::GetLuaScriptsSetAll() const
{
	CStringW csLuaScripts;
	return csLuaScripts;
}

CDrawingBase* CDrawingRadioButton::Clone() const
{
	CDrawingRadioButton *pDrawingRadioButton = new CDrawingRadioButton;
	if(pDrawingRadioButton != NULL)
	{
		*pDrawingRadioButton = *this;
	}
	return pDrawingRadioButton;
}


CDrawingText::CDrawingText()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_Text);

	m_iFontSize = 24;
	m_iTextAlign = TextkAlignLeft;
}

CDrawingText& CDrawingText::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingText::operator=((CDrawingText&)drawingBase);
	else
		CDrawingImage::operator=(drawingBase);

	return *this;
}

CDrawingText& CDrawingText::operator=(const CDrawingText &drawingText)
{
	CDrawingImage::operator=(drawingText);

	m_csStr = drawingText.m_csStr;
	m_csFontName = drawingText.m_csFontName;
	m_iFontSize = drawingText.m_iFontSize;
	m_iTextAlign = drawingText.m_iTextAlign;

	return *this;
}

CDrawingText::~CDrawingText()
{
}

void CDrawingText::SetStr(CStringW str)
{
	m_csStr = str;
}

BOOL CDrawingText::GetStr(CStringW &str) const
{
	str = m_csStr;
	return TRUE;
}

void CDrawingText::SetFontName(CStringW fontName)
{
	m_csFontName = fontName;
}

BOOL CDrawingText::GetFontName(CStringW &fontName) const
{
	fontName = m_csFontName;
	return TRUE;
}

void CDrawingText::SetFontSize(int fontSize)
{
	m_iFontSize = fontSize;
}

BOOL CDrawingText::GetFontSize(int &fontSize) const
{
	fontSize = m_iFontSize;
	return TRUE;
}

void CDrawingText::SetTextAlign(int align)
{
	m_iTextAlign = align;
}

BOOL CDrawingText::GetTextAlign(int &align) const
{
	align = m_iTextAlign;
	return TRUE;
}

CStringW CDrawingText::GetTAGStr() const
{
	CStringW content = m_csStr;
	content.Replace(L"&lt;",L"<");
	content.Replace(L"&gt;",L">");
	content.Replace(L"&quot;",L"\"");
	content.Replace(L"&amp;",L"&");

	CStringW csTAGStr;
	csTAGStr.Format(L",%s=[[%s]]",CWCharArr(TAG_StringDataName),content);
	return csTAGStr;
}

CStringW CDrawingText::GetTAGFontName() const
{
	CStringW csTAGFontName;
	csTAGFontName.Format(L",%s=\"%s\"",CWCharArr(TAG_FontName),m_csFontName);
	return csTAGFontName;
}

CStringW CDrawingText::GetTAGFontSize() const
{
	CStringW csTAGFontSize;
	csTAGFontSize.Format(L",%s=%d",CWCharArr(TAG_FontSize),m_iFontSize);
	return csTAGFontSize;
}

CStringW CDrawingText::GetTAGTextAlign() const
{
	CStringW csTAGTextAlign;
	csTAGTextAlign.Format(L",%s=%s",CWCharArr(TAG_TextAlign),CWCharArr(::GetAlignTypeName(m_iTextAlign)));
	return csTAGTextAlign;
}

CStringW CDrawingText::GetTAGColor() const
{
	CStringW csTAGColor;
	csTAGColor.Format(L",colorRed=%d,colorGreen=%d,colorBlue=%d",GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
	return csTAGColor;
}

CStringW CDrawingText::GetTAGDrawingText() const
{
	CStringW csTAGDrawingText;
	csTAGDrawingText += CDrawingBase::GetTAGDrawingBase();
	csTAGDrawingText += GetTAGStr();
	csTAGDrawingText += GetTAGFontName();
	csTAGDrawingText += GetTAGFontSize();
	csTAGDrawingText += GetTAGTextAlign();
	csTAGDrawingText += GetTAGColor();
	return csTAGDrawingText;
}

CStringW CDrawingText::GetTAGTotal() const
{
	return GetTAGDrawingText();
}

CStringW CDrawingText::GetLuaScriptsSetText() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setText(\"%s\",%d,%d,%s,\"%s\",%d,%d,%d,%d);"),GetLuaScriptsName(),m_csStr,m_width,m_height,::GetAlignTypeName(m_iTextAlign),m_csFontName,m_iFontSize,GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
//	csLuaScripts.Format(_T("%s:setText(\"%s\",%d,%d,%d,%d,%d,%d);"),GetLuaScriptsName(),m_csStr,m_width,m_height,m_iFontSize,GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
//	csLuaScripts.Format(_T("%s:setText(\"%s\",%d,%d,%d,%d,%d);"),GetLuaScriptsName(),m_csStr,m_width,m_height,GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
	csLuaScripts.Format(L"editor_setText(%s,\"%s\",%d,%d,%d,%d,%d);",GetLuaScriptsName(),m_csStr,m_width,m_height,GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
	return csLuaScripts;
}
/*
CString CDrawingText::GetLuaScriptsNew() const
{
	CString csLuaScripts;
//	csLuaScripts.Format(_T("%s = new(%s,\"%s\",%d,%d,%s,\"%s\",%d,%d,%d,%d);"),GetLuaScriptsName(),GetDrawingTypeNewLuaName(),m_csStr,m_width,m_height,::GetAlignTypeName(m_iTextAlign),m_csFontName,m_iFontSize,GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
	csLuaScripts.Format(_T("%s = editor_newText(%s,\"%s\",%d,%d,%s,\"%s\",%d,%d,%d,%d);"),GetLuaScriptsName(),GetDrawingTypeNewLuaName(),m_csStr,m_width,m_height,::GetAlignTypeName(m_iTextAlign),m_csFontName,m_iFontSize,GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
	return csLuaScripts;
}
*/
CStringW CDrawingText::GetLuaScriptsSetAll() const
{
	CStringW csLuaScripts;
	csLuaScripts += CDrawingBase::GetLuaScriptsSetAll();
//	csLuaScripts += GetLuaScriptsSetText();
	return csLuaScripts;
}

CDrawingBase* CDrawingText::Clone() const
{
	CDrawingText *pDrawingText = new CDrawingText;
	if(pDrawingText != NULL)
	{
		*pDrawingText = *this;
	}
	return pDrawingText;
}

CDrawingText* CDrawingText::CDrawingBaseToCDrawingText(CDrawingBase *pDrawingBase)
{
	return dynamic_cast <CDrawingText *>(pDrawingBase);
}


CDrawingScrollableNode::CDrawingScrollableNode()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_ScrollableNode);
}

CDrawingScrollableNode& CDrawingScrollableNode::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingScrollableNode::operator=((CDrawingScrollableNode&)drawingBase);
	else
		CDrawingNode::operator=(drawingBase);

	return *this;
}

CDrawingScrollableNode& CDrawingScrollableNode::operator=(const CDrawingScrollableNode &drawingScrollableNode)
{
	CDrawingNode::operator=(drawingScrollableNode);

	return *this;
}

CDrawingScrollableNode::~CDrawingScrollableNode()
{
}


CDrawingTextView::CDrawingTextView()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_TextView);

	m_iFontSize = 24;
	m_iTextAlign = TextkAlignLeft;
}

CDrawingTextView& CDrawingTextView::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingTextView::operator=((CDrawingTextView&)drawingBase);
	else
		CDrawingScrollableNode::operator=(drawingBase);

	return *this;
}

CDrawingTextView& CDrawingTextView::operator=(const CDrawingTextView &drawingTextView)
{
	CDrawingScrollableNode::operator=(drawingTextView);

	m_csStr = drawingTextView.m_csStr;
	m_csFontName = drawingTextView.m_csFontName;
	m_iFontSize = drawingTextView.m_iFontSize;
	m_iTextAlign = drawingTextView.m_iTextAlign;

	return *this;
}

CDrawingTextView::~CDrawingTextView()
{
}

void CDrawingTextView::SetStr(CStringW str)
{
	m_csStr = str;
}

BOOL CDrawingTextView::GetStr(CStringW &str) const
{
	str = m_csStr;
	return TRUE;
}

void CDrawingTextView::SetFontName(CStringW fontName)
{
	m_csFontName = fontName;
}

BOOL CDrawingTextView::GetFontName(CStringW &fontName) const
{
	fontName = m_csFontName;
	return TRUE;
}

void CDrawingTextView::SetFontSize(int fontSize)
{
	m_iFontSize = fontSize;
}

BOOL CDrawingTextView::GetFontSize(int &fontSize) const
{
	fontSize = m_iFontSize;
	return TRUE;
}

void CDrawingTextView::SetTextAlign(int align)
{
	m_iTextAlign = align;
}

BOOL CDrawingTextView::GetTextAlign(int &align) const
{
	align = m_iTextAlign;
	return TRUE;
}

CStringW CDrawingTextView::GetTAGStr() const
{
	CStringW content = m_csStr;
	content.Replace(L"&lt;",L"<");
	content.Replace(L"&gt;",L">");
	content.Replace(L"&quot;",L"\"");
	content.Replace(L"&amp;",L"&");

	CStringW csTAGStr;
	csTAGStr.Format(L",%s=[[%s]]",CWCharArr(TAG_StringDataName),content);
	return csTAGStr;
}

CStringW CDrawingTextView::GetTAGFontName() const
{
	CStringW csTAGFontName;
	csTAGFontName.Format(L",%s=\"%s\"",CWCharArr(TAG_FontName),m_csFontName);
	return csTAGFontName;
}

CStringW CDrawingTextView::GetTAGFontSize() const
{
	CStringW csTAGFontSize;
	csTAGFontSize.Format(L",%s=%d",CWCharArr(TAG_FontSize),m_iFontSize);
	return csTAGFontSize;
}

CStringW CDrawingTextView::GetTAGTextAlign() const
{
	CStringW csTAGTextAlign;
	csTAGTextAlign.Format(L",%s=%s",CWCharArr(TAG_TextAlign),CWCharArr(::GetAlignTypeName(m_iTextAlign)));
	return csTAGTextAlign;
}

CStringW CDrawingTextView::GetTAGColor() const
{
	CStringW csTAGColor;
	csTAGColor.Format(L",colorRed=%d,colorGreen=%d,colorBlue=%d",GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
	return csTAGColor;
}

CStringW CDrawingTextView::GetTAGDrawingTextView() const
{
	CStringW csTAGDrawingText;
	csTAGDrawingText += CDrawingBase::GetTAGDrawingBase();
	csTAGDrawingText += GetTAGStr();
	csTAGDrawingText += GetTAGFontName();
	csTAGDrawingText += GetTAGFontSize();
	csTAGDrawingText += GetTAGTextAlign();
	csTAGDrawingText += GetTAGColor();
	return csTAGDrawingText;
}

CStringW CDrawingTextView::GetTAGTotal() const
{
	return GetTAGDrawingTextView();
}

CStringW CDrawingTextView::GetLuaScriptsSetText() const
{
	CStringW csLuaScripts;
//	csLuaScripts.Format(_T("%s:setText(\"%s\",%d,%d,%s,\"%s\",%d,%d,%d,%d);"),GetLuaScriptsName(),m_csStr,m_width,m_height,::GetAlignTypeName(m_iTextAlign),m_csFontName,m_iFontSize,GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
//	csLuaScripts.Format(_T("%s:setText(\"%s\",%d,%d,%d,%d,%d);"),GetLuaScriptsName(),m_csStr,m_width,m_height,GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
	csLuaScripts.Format(L"editor_setText(%s,\"%s\",%d,%d,%d,%d,%d);",GetLuaScriptsName(),m_csStr,m_width,m_height,GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
	return csLuaScripts;
}
/*
CString CDrawingTextView::GetLuaScriptsNew() const
{
	CString csLuaScripts;
//	csLuaScripts.Format(_T("%s = new(%s,\"%s\",%d,%d,%s,\"%s\",%d,%d,%d,%d);"),GetLuaScriptsName(),GetDrawingTypeNewLuaName(),m_csStr,m_width,m_height,::GetAlignTypeName(m_iTextAlign),m_csFontName,m_iFontSize,GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
	csLuaScripts.Format(_T("%s = editor_newText(%s,\"%s\",%d,%d,%s,\"%s\",%d,%d,%d,%d);"),GetLuaScriptsName(),GetDrawingTypeNewLuaName(),m_csStr,m_width,m_height,::GetAlignTypeName(m_iTextAlign),m_csFontName,m_iFontSize,GetRValue(m_color),GetGValue(m_color),GetBValue(m_color));
	return csLuaScripts;
}
*/
CStringW CDrawingTextView::GetLuaScriptsSetAll() const
{
	CStringW csLuaScripts;
	csLuaScripts += CDrawingBase::GetLuaScriptsSetAll();
//	csLuaScripts += GetLuaScriptsSetText();
	return csLuaScripts;
}

CDrawingBase* CDrawingTextView::Clone() const
{
	CDrawingTextView *pDrawingTextView = new CDrawingTextView;
	if(pDrawingTextView != NULL)
	{
		*pDrawingTextView = *this;
	}
	return pDrawingTextView;
}

CDrawingTextView* CDrawingTextView::CDrawingBaseToCDrawingTextView(CDrawingBase *pDrawingBase)
{
	return dynamic_cast <CDrawingTextView *>(pDrawingBase);
}

CDrawingEditTextView::CDrawingEditTextView()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_EditTextView);
}

CDrawingEditTextView::~CDrawingEditTextView()
{
}


CDrawingEditText::CDrawingEditText()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_EditText);
}

CDrawingEditText::~CDrawingEditText()
{
}


CDrawingScrollBar::CDrawingScrollBar()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_ScrollBar);
}

CDrawingScrollBar::~CDrawingScrollBar()
{
}


CDrawingTabView::CDrawingTabView()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_TabView);
}

CDrawingTabView::~CDrawingTabView()
{
}


CDrawingTableView::CDrawingTableView()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_TableView);
}

CDrawingTableView& CDrawingTableView::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingTableView::operator=((CDrawingTableView&)drawingBase);
	else
		CDrawingScrollableNode::operator=(drawingBase);

	return *this;
}

CDrawingTableView& CDrawingTableView::operator=(const CDrawingTableView &drawingTableView)
{
	CDrawingScrollableNode::operator=(drawingTableView);

	return *this;
}

CDrawingTableView::~CDrawingTableView()
{
}


CDrawingGridView::CDrawingGridView()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_GridView);
}

CDrawingGridView::~CDrawingGridView()
{
}


CDrawingViewPager::CDrawingViewPager()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_ViewPager);
}

CDrawingViewPager& CDrawingViewPager::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingViewPager::operator=((CDrawingViewPager&)drawingBase);
	else
		CDrawingTableView::operator=(drawingBase);

	return *this;
}

CDrawingViewPager& CDrawingViewPager::operator=(const CDrawingViewPager &drawingViewPager)
{
	CDrawingScrollableNode::operator=(drawingViewPager);

	return *this;
}

CDrawingViewPager::~CDrawingViewPager()
{
}
/*
CString CDrawingViewPager::GetLuaScriptsNew() const
{
	CString csLuaScripts;
//	csLuaScripts.Format(_T("%s = new(%s,%d,%d,%d,%d);"),GetLuaScriptsName(),GetDrawingTypeNewLuaName(),m_x,m_y,m_width,m_height);
	csLuaScripts.Format(_T("%s = editor_newViewPager(%s,%d,%d,%d,%d);"),GetLuaScriptsName(),GetDrawingTypeNewLuaName(),m_x,m_y,m_width,m_height);
	return csLuaScripts;
}
*/
CStringW CDrawingViewPager::GetLuaScriptsSetAll() const
{
	return CDrawingBase::GetLuaScriptsSetAll();
}

CDrawingBase* CDrawingViewPager::Clone() const
{
	CDrawingViewPager *pDrawingViewPager = new CDrawingViewPager;
	if(pDrawingViewPager != NULL)
	{
		*pDrawingViewPager = *this;
	}
	return pDrawingViewPager;
}


CDrawingListView::CDrawingListView()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_ListView);
}

CDrawingListView::~CDrawingListView()
{
}


CDrawingScrollView::CDrawingScrollView()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_ScrollView);
}

CDrawingScrollView::~CDrawingScrollView()
{
}


CDrawingSlider::CDrawingSlider()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_Slider);

	m_width = 322;
	m_height = 30;
}

CDrawingSlider::~CDrawingSlider()
{
}


CDrawingSwitch::CDrawingSwitch()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_Switch);
}

CDrawingSwitch::~CDrawingSwitch()
{
}


CDrawingDrawingCustom::CDrawingDrawingCustom()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_DrawingCustom);
}

CDrawingDrawingCustom::~CDrawingDrawingCustom()
{
}


CDrawingCustomNode::CDrawingCustomNode()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_CustomNode);
}

CDrawingCustomNode::~CDrawingCustomNode()
{
}


const CString g_csCustomDataTypeArray[CUSTOM_DATA_TYPE_NUM] =
{
	_T("int"),
	_T("string"),
	_T("color")
};

CString GetCustomDataType(EM_CUSTOM_DATA_TYPE emCustomDataType)
{
	if(emCustomDataType >= 0 && emCustomDataType < sizeof(g_csCustomDataTypeArray)/sizeof(CString))
		return g_csCustomDataTypeArray[emCustomDataType];

	return _T("");
}

EM_CUSTOM_DATA_TYPE GetCustomDataType(const CString &csCustomDataType)
{
	int i;
	for(i=0; i<sizeof(g_csCustomDataTypeArray)/sizeof(CString); i++)
	{
		if(csCustomDataType == g_csCustomDataTypeArray[i])
			return (EM_CUSTOM_DATA_TYPE)i;
	}
	return (EM_CUSTOM_DATA_TYPE)-1;
}

CString GetComboCustomDataTypeString(int index)
{
	return GetCustomDataType((EM_CUSTOM_DATA_TYPE)index);
}


CCustomData::CCustomData()
{
	m_emCustomDataType = CUSTOM_DATA_INT;
	m_data = 0;
}

CCustomData::CCustomData(const CString &csCustomPropName,EM_CUSTOM_DATA_TYPE emCustomDataType)
{
	m_csCustomPropName = csCustomPropName;
	m_emCustomDataType = emCustomDataType;
}

CCustomData::CCustomData(const CString &csCustomPropName,EM_CUSTOM_DATA_TYPE emCustomDataType,const CString &csCustomData)
{
	m_csCustomPropName = csCustomPropName;
	m_emCustomDataType = emCustomDataType;
	switch(m_emCustomDataType)
	{
	case CUSTOM_DATA_INT:
		SetDataInt(::CStringToInt(csCustomData));
		break;
	case CUSTOM_DATA_STRING:
		SetDataCString(csCustomData);
		break;
	case CUSTOM_DATA_COLOR:
		{
			COLORREF color = 0;
			::CStringToCOLORREF(csCustomData,color);
			SetDataCOLORREF(color);
		}
		break;
	default:
		break;
	}
}

CCustomData::CCustomData(const CCustomData &customData)
{
	*this = customData;
}

CCustomData& CCustomData::operator=(const CCustomData &customData)
{
	m_csCustomPropName = customData.m_csCustomPropName;
	m_emCustomDataType = customData.m_emCustomDataType;
	m_data = customData.m_data;

	return *this;
}

CCustomData::~CCustomData()
{
}

void CCustomData::SetCustomPropName(const CString &csCustomPropName)
{
	m_csCustomPropName = csCustomPropName;
}

void CCustomData::SetCustomDataType(EM_CUSTOM_DATA_TYPE emCustomDataType)
{
	m_emCustomDataType = emCustomDataType;
}

void CCustomData::SetDataInt(int iData)
{
	if(GetCustomDataType() == CUSTOM_DATA_INT)
	{
		m_data = iData;
	}
}

void CCustomData::SetDataCString(const CString &csData)
{
	if(GetCustomDataType() == CUSTOM_DATA_STRING)
	{
		m_data = csData;
	}
}

void CCustomData::SetDataCOLORREF(COLORREF color)
{
	if(GetCustomDataType() == CUSTOM_DATA_COLOR)
	{
		m_data = color;
	}
}

CString CCustomData::GetCustomPropName() const
{
	return m_csCustomPropName;
}

EM_CUSTOM_DATA_TYPE CCustomData::GetCustomDataType() const
{
	return m_emCustomDataType;
}

int CCustomData::GetDataInt() const
{
	if(GetCustomDataType() == CUSTOM_DATA_INT)
	{
		if(m_data.vt == VT_INT)
		{
			return (int)m_data;
		}
	}

	return 0;
}

CString CCustomData::GetDataCString() const
{
	if(GetCustomDataType() == CUSTOM_DATA_STRING)
	{
		if(m_data.vt == VT_BSTR)
		{
			return CString(m_data.bstrVal);
		}
	}

	return _T("");
}

COLORREF CCustomData::GetDataCOLORREF() const
{
	if(GetCustomDataType() == CUSTOM_DATA_COLOR)
	{
		if(m_data.vt == VT_INT || m_data.vt == VT_UI4)
		{
			return (COLORREF)m_data;
		}
	}

	return 0;
}

CString CCustomData::GetCustomData() const
{
	CString csCustomData;
	switch(m_emCustomDataType)
	{
	case CUSTOM_DATA_INT:
		csCustomData.Format(_T("%d"),GetDataInt());
		break;
	case CUSTOM_DATA_STRING:
		csCustomData.Format(_T("%s"),GetDataCString());
		break;
	case CUSTOM_DATA_COLOR:
		{
			COLORREF color = GetDataCOLORREF();
			csCustomData = ::COLORREFToCString(color);
		}
		break;
	default:
		break;
	}
	return csCustomData;
}

CString CCustomData::GetTAGCustomData() const
{
	CString csTAGCustomData;
	switch(m_emCustomDataType)
	{
	case CUSTOM_DATA_INT:
		csTAGCustomData.Format(_T(",%s=%d"),m_csCustomPropName,GetDataInt());
		break;
	case CUSTOM_DATA_STRING:
		csTAGCustomData.Format(_T(",%s=\"%s\""),m_csCustomPropName,GetDataCString());
		break;
	case CUSTOM_DATA_COLOR:
		{
			COLORREF color = GetDataCOLORREF();
			csTAGCustomData.Format(_T(",%s=%s"),m_csCustomPropName,::COLORREFToCString(color));
		}
		break;
	default:
		break;
	}
	return csTAGCustomData;
}

CString CCustomData::GetLuaCustomData() const
{
	CString csLuaCustomData;
	switch(m_emCustomDataType)
	{
	case CUSTOM_DATA_INT:
		csLuaCustomData.Format(_T(",%s=%d"),m_csCustomPropName,GetDataInt());
		break;
	case CUSTOM_DATA_STRING:
		csLuaCustomData.Format(_T(",%s=[[%s]]"),m_csCustomPropName,GetDataCString());
		break;
	case CUSTOM_DATA_COLOR:
		{
			COLORREF color = GetDataCOLORREF();
			csLuaCustomData.Format(_T(",%s=%s"),m_csCustomPropName,::COLORREFToCString(color));
		}
		break;
	default:
		break;
	}

	return csLuaCustomData;
}


CDrawingCustomControl::CDrawingCustomControl()
{
	CDrawingBase::SetDrawingType(DRAWING_TYPE_CustomControl);
}

CDrawingCustomControl& CDrawingCustomControl::operator=(const CDrawingBase &drawingBase)
{
	if(drawingBase.GetDrawingType() == GetDrawingType())
		CDrawingCustomControl::operator=((CDrawingCustomControl&)drawingBase);
	else
		CDrawingBase::operator=(drawingBase);

	return *this;
}

CDrawingCustomControl& CDrawingCustomControl::operator=(const CDrawingCustomControl &drawingCustomControl)
{
	CDrawingBase::operator=(drawingCustomControl);

	m_csCustomName = drawingCustomControl.m_csCustomName;
	m_customDataArray.RemoveAll();
	int i;
	for(i=0; i<drawingCustomControl.m_customDataArray.GetSize(); i++)
	{
		m_customDataArray.Add(drawingCustomControl.m_customDataArray.GetAt(i));
	}

	return *this;
}

CDrawingCustomControl::~CDrawingCustomControl()
{
}

void CDrawingCustomControl::SetCustomName(const CString &csCustomName)
{
	m_csCustomName = csCustomName;
}

CString CDrawingCustomControl::GetCustomName() const
{
	return m_csCustomName;
}

void CDrawingCustomControl::SetCustomData(const CArray <CCustomData,CCustomData> &customDataArray)
{
	m_customDataArray.RemoveAll();
	int i;
	for(i=0; i<customDataArray.GetSize(); i++)
	{
		m_customDataArray.Add(customDataArray.GetAt(i));
	}
}

void CDrawingCustomControl::SetCustomData(int index,const CCustomData &customData)
{
	if(index >= 0 && index < m_customDataArray.GetSize())
	{
		m_customDataArray[index] = customData;
	}
}

BOOL CDrawingCustomControl::GetCustomData(CArray <CCustomData,CCustomData> &customDataArray) const
{
	customDataArray.RemoveAll();
	int i;
	for(i=0; i<m_customDataArray.GetSize(); i++)
	{
		customDataArray.Add(m_customDataArray.GetAt(i));
	}

	return TRUE;
}

CString CDrawingCustomControl::GetLuaCustomName() const
{
	CString csLuaCustomName;
	csLuaCustomName.Format(_T(",%s=\"%s\""),TAG_CustomName,m_csCustomName);
	return csLuaCustomName;
}

CStringW CDrawingCustomControl::GetTAGDrawingCustomControl() const
{
	CStringW csTAGDrawingCustomControl;
	csTAGDrawingCustomControl += CDrawingBase::GetTAGDrawingBase();
	
	csTAGDrawingCustomControl += CWCharArr(GetLuaCustomName());

	int i;
	for(i=0; i<m_customDataArray.GetSize(); i++)
	{
		csTAGDrawingCustomControl += CWCharArr(m_customDataArray.GetAt(i).GetTAGCustomData());
	}
	return csTAGDrawingCustomControl;
}

CStringW CDrawingCustomControl::GetTAGTotal() const
{
	return GetTAGDrawingCustomControl();
}

CStringW CDrawingCustomControl::GetLuaScriptsNew() const
{
	CStringW csLuaScripts;

	CStringW csTAGTable = L"{"+GetTAGTotal()+L"}";
	csLuaScripts.Format(L"%s = editor_newCustom(%s,%s);",GetLuaScriptsName(),csTAGTable,CWCharArr(m_csCustomName));

	return csLuaScripts;
}

CDrawingBase* CDrawingCustomControl::Clone() const
{
	CDrawingCustomControl *pDrawingCustomControl = new CDrawingCustomControl;
	if(pDrawingCustomControl != NULL)
	{
		*pDrawingCustomControl = *this;
	}
	return pDrawingCustomControl;
}

CDrawingCustomControl* CDrawingCustomControl::CDrawingBaseToCDrawingCustomControl(CDrawingBase *pDrawingBase)
{
	return dynamic_cast <CDrawingCustomControl *>(pDrawingBase);
}


CDrawingBase* NewCDrawingBase(EM_DRAWING_TYPE type)
{
	switch(type)
	{
	case DRAWING_TYPE_Base:
		return new CDrawingBase;
		break;
	case DRAWING_TYPE_ImageBase:
		return new CDrawingImageBase;
		break;
	case DRAWING_TYPE_Empty:
		return new CDrawingEmpty;
		break;
	case DRAWING_TYPE_Node:
		return new CDrawingNode;
		break;
	case DRAWING_TYPE_Image:
		return new CDrawingImage;
		break;
	case DRAWING_TYPE_Images:
		return new CDrawingImages;
		break;
	case DRAWING_TYPE_Button:
		return new CDrawingButton;
		break;
	case DRAWING_TYPE_GroupNode:
		return new CDrawingGroupNode;
		break;
	case DRAWING_TYPE_GroupItem:
		return new CDrawingGroupItem;
		break;
	case DRAWING_TYPE_CheckBoxGroup:
		return new CDrawingCheckBoxGroup;
		break;
	case DRAWING_TYPE_CheckBox:
		return new CDrawingCheckBox;
		break;
	case DRAWING_TYPE_RadioButtonGroup:
		return new CDrawingRadioButtonGroup;
		break;
	case DRAWING_TYPE_RadioButton:
		return new CDrawingRadioButton;
		break;
	case DRAWING_TYPE_Text:
		return new CDrawingText;
		break;
	case DRAWING_TYPE_ScrollableNode:
		return new CDrawingScrollableNode;
		break;
	case DRAWING_TYPE_TextView:
		return new CDrawingTextView;
		break;
	case DRAWING_TYPE_EditTextView:
		return new CDrawingEditTextView;
		break;
	case DRAWING_TYPE_EditText:
		return new CDrawingEditText;
		break;
	case DRAWING_TYPE_ScrollBar:
		return new CDrawingScrollBar;
		break;
	case DRAWING_TYPE_TabView:
		return new CDrawingTabView;
		break;
	case DRAWING_TYPE_TableView:
		return new CDrawingTableView;
		break;
	case DRAWING_TYPE_GridView:
		return new CDrawingGridView;
		break;
	case DRAWING_TYPE_ViewPager:
		return new CDrawingViewPager;
		break;
	case DRAWING_TYPE_ListView:
		return new CDrawingListView;
		break;
	case DRAWING_TYPE_ScrollView:
		return new CDrawingScrollView;
		break;
	case DRAWING_TYPE_Slider:
		return new CDrawingSlider;
		break;
	case DRAWING_TYPE_Switch:
		return new CDrawingSwitch;
		break;
	case DRAWING_TYPE_DrawingCustom:
		return new CDrawingDrawingCustom;
		break;
	case DRAWING_TYPE_CustomNode:
		return new CDrawingCustomNode;
		break;
	case DRAWING_TYPE_CustomControl:
		return new CDrawingCustomControl;
		break;
	default:
		break;
	}
	return NULL;
}

void InitDrawingBase(CDrawingBase *pDrawingBase)
{
	if(pDrawingBase == NULL)
		return;
	
	EM_DRAWING_TYPE type = pDrawingBase->GetDrawingType();
	CString csName;
	pDrawingBase->GetName(csName);

	switch(type)
	{
	case DRAWING_TYPE_Base:
		break;
	case DRAWING_TYPE_ImageBase:
		break;
	case DRAWING_TYPE_Empty:
		break;
	case DRAWING_TYPE_Node:
		break;
	case DRAWING_TYPE_Image:
		{
			CDrawingImage *pDrawingImage = CDrawingImage::CDrawingBaseToCDrawingImage(pDrawingBase);
			if(pDrawingImage != NULL)
			{
				pDrawingImage->SetFile(_T("ui/image.png"));
				pDrawingImage->FixFileSize();
			}
		}
		break;
	case DRAWING_TYPE_Images:
		break;
	case DRAWING_TYPE_Button:
		{
			CDrawingButton *pDrawingButton = CDrawingButton::CDrawingBaseToCDrawingButton(pDrawingBase);
			if(pDrawingButton != NULL)
			{
				pDrawingButton->SetFile(_T("ui/button.png"));
				pDrawingButton->FixFileSize();
			}
		}
		break;
	case DRAWING_TYPE_GroupNode:
		break;
	case DRAWING_TYPE_GroupItem:
		break;
	case DRAWING_TYPE_CheckBoxGroup:
		break;
	case DRAWING_TYPE_CheckBox:
		break;
	case DRAWING_TYPE_RadioButtonGroup:
		break;
	case DRAWING_TYPE_RadioButton:
		break;
	case DRAWING_TYPE_Text:
	case DRAWING_TYPE_TextView:
	case DRAWING_TYPE_EditTextView:
	case DRAWING_TYPE_EditText:
		{
			if(type == DRAWING_TYPE_Text || type == DRAWING_TYPE_EditText)
			{
				CDrawingText *pDrawingText = CDrawingText::CDrawingBaseToCDrawingText(pDrawingBase);
				if(pDrawingText != NULL)
				{
					pDrawingText->SetStr(CStringW(csName));
					pDrawingText->SetFontName((LPWSTR)CWCharArr(::GetDefaultFontName()));
				}
			}
			else if(type == DRAWING_TYPE_TextView || type == DRAWING_TYPE_EditTextView)
			{
				CDrawingTextView *pDrawingTextView = CDrawingTextView::CDrawingBaseToCDrawingTextView(pDrawingBase);
				if(pDrawingTextView != NULL)
				{
					pDrawingTextView->SetStr(CStringW(csName));
					pDrawingTextView->SetFontName((LPWSTR)CWCharArr(::GetDefaultFontName()));
				}
			}
		}
		break;
	case DRAWING_TYPE_ScrollableNode:
		break;
	case DRAWING_TYPE_ScrollBar:
		break;
	case DRAWING_TYPE_TabView:
		break;
	case DRAWING_TYPE_TableView:
		break;
	case DRAWING_TYPE_GridView:
		break;
	case DRAWING_TYPE_ViewPager:
		break;
	case DRAWING_TYPE_ListView:
		break;
	case DRAWING_TYPE_ScrollView:
		break;
	case DRAWING_TYPE_Slider:
		break;
	case DRAWING_TYPE_Switch:
		break;
	case DRAWING_TYPE_DrawingCustom:
		break;
	case DRAWING_TYPE_CustomNode:
		break;
	case DRAWING_TYPE_CustomControl:
		break;
	default:
		break;
	};
}

const CString g_csUIPropTypeNameArray[]=
{
	_T("�ƶ�X"),//UI_PROP_x
	_T("�ƶ�Y"),//UI_PROP_y
	_T("�ƶ�XY"),//UI_PROP_xy
	_T("�޸Ŀ���"),//UI_PROP_width
	_T("�޸ĸ߶�"),//UI_PROP_height
	_T("�޸�������� ���Ͻ� X"),//UI_PROP_topLeftX
	_T("�޸�������� ���Ͻ� Y"),//UI_PROP_topLeftY
	_T("�޸�������� ���½� X"),//UI_PROP_bottomRightX
	_T("�޸�������� ���½� Y"),//UI_PROP_bottomRightY
	_T("�޸Ķ��뷽ʽ"),//UI_PROP_iAlign
	_T("�޸ĸ��ڵ��"),//UI_PROP_bAdaptiveWidth
	_T("�޸ĸ��ڵ��"),//UI_PROP_bAdaptiveHeight
	_T("�޸���ɫ"),//UI_PROP_color
	_T("�޸�alpha"),//UI_PROP_alpha
	_T("�޸��Ƿ�ɼ�"),//UI_PROP_bVisible
	_T("�޸�����"),//UI_PROP_strName
	_T("�޸�ƴͼ"),//UI_PROP_strLuaName
	_T("�޸�9Grid��"),//UI_PROP_gLeft
	_T("�޸�9Grid��"),//UI_PROP_gRight
	_T("�޸�9Grid��"),//UI_PROP_gTop
	_T("�޸�9Grid��"),//UI_PROP_gBottom
	_T("�޸�ͼƬ1"),//UI_PROP_csFile
	_T("�޸�ͼƬ2"),//UI_PROP_csFile2
	_T("�޸���������"),//UI_PROP_csStr
	_T("�޸���������"),//UI_PROP_csFontName
	_T("�޸������С"),//UI_PROP_iFontSize
	_T("�޸����ֶ��뷽ʽ"),//UI_PROP_iTextAlign
	_T("�޸��Զ�������"),//UI_PROP_Custom
};

CString GetUIPropTypeName(EM_UI_PROP_TYPE emUIPropType)
{
	int iSize = sizeof(g_csUIPropTypeNameArray)/sizeof(CString);
	if(emUIPropType >= 0 && emUIPropType < iSize)
		return g_csUIPropTypeNameArray[emUIPropType];

	return _T("");
}

const CString g_csComboColorStringArray[COMBO_COLOR_NUM]=
{
	_T("��ɫ"),
	_T("��ɫ"),
	_T("��ɫ"),
	_T("��ɫ"),
	_T("��ɫ"),
	_T("��ɫ"),
	_T("��ɫ")
};

const COLORREF g_comboColorArray[COMBO_COLOR_NUM]=
{
	RGB(255,255,255),
	RGB(0,0,0),
	RGB(255,0,0),
	RGB(0,255,0),
	RGB(0,0,255),
	RGB(255,255,0),
	RGB(255,0,255)
};

CString GetComboColorString(int index)
{
	if(index >= 0 && index < COMBO_COLOR_NUM)
		return g_csComboColorStringArray[index];

	return _T("");
}

COLORREF GetComboColorCOLORREF(int index)
{
	if(index >= 0 && index < COMBO_COLOR_NUM)
		return g_comboColorArray[index];

	return RGB(0,0,0);
}

int GetComboColorIndex(COLORREF color)
{
	int i;
	for(i=0; i<COMBO_COLOR_NUM; i++)
	{
		if(color == g_comboColorArray[i])
			return i;
	}
	return -1;
}



CPropType::CPropType()
{
	m_proptype = PROPTYPE_BASE;
}

EM_PROPTYPE CPropType::GetProptype()
{
	return m_proptype;
}


CPropTypeInt::CPropTypeInt()
{
	m_proptype = PROPTYPE_INT;
}


CPropTypeDouble::CPropTypeDouble()
{
	m_proptype = PROPTYPE_DOUBLE;
}


CPropTypeData::CPropTypeData()
{
	m_proptype = PROPTYPE_DATA;
}


CPropTypeString::CPropTypeString()
{
	m_proptype = PROPTYPE_STRING;
}


CPropTypeEnum::CPropTypeEnum()
{
	m_proptype = PROPTYPE_ENUM;
}


int CPropTypeEnum::GetEnumCount()
{
	return valueLuaName.size();
}

CStringW CPropTypeEnum::GetViewName(int value)
{
	if (value >= 0 && value < valueViewName.size())
		return valueViewName[value];

	return L"";
}

CStringW CPropTypeEnum::GetLuaName(int value)
{
	if (value >= 0 && value < valueLuaName.size())
		return valueLuaName[value];

	return L"";
}


CPropTypeBool::CPropTypeBool()
{
	m_proptype = PROPTYPE_BOOL;
}

bool CPropTypeBool::GetValue(string value)
{
	return ((value == "true") ? true : false);
}

CStringW CPropTypeBool::GetLuaName(bool value)
{
	if (valueLuaName.size() >= 2)
	{
		return (value ? valueLuaName[1] : valueLuaName[0]);
	}
	else
	{
		return (value ? L"true" : L"false");
	}
}


CPropTypeImage::CPropTypeImage()
{
	m_proptype = PROPTYPE_IMAGE;
}


CPropTypePackfile::CPropTypePackfile()
{
	m_proptype = PROPTYPE_PACKFILE;
}


CPropTypeText::CPropTypeText()
{
	m_proptype = PROPTYPE_TEXT;
}

CStringW CPropTypeText::GetLuaText(CStringW text)
{
	text.Replace(L"&lt;", L"<");
	text.Replace(L"&gt;", L">");
	text.Replace(L"&quot;", L"\"");
	text.Replace(L"&amp;", L"&");

	return L"[[" + text + L"]]";
}


CPropTypeFont::CPropTypeFont()
{
	m_proptype = PROPTYPE_FONT;
}


CPropTypeColor::CPropTypeColor()
{
	m_proptype = PROPTYPE_COLOR;
}

int CPropTypeColor::GetColor(CString color)
{
	int iColor = ::CStringToInt(color);
	if (colorType)
	{
		iColor = RGB(GetBValue(iColor), GetGValue(iColor), GetRValue(iColor));
	}
	return iColor;
}

CStringW CPropTypeColor::GetLuaName(int index)
{
	if (index >= 0 && index < typeLuaName.size())
		return typeLuaName[index];

	return L"";
}

CStringW CPropTypeColor::GetColor(int color)
{
	if (colorType)
	{
		color = RGB(GetBValue(color), GetGValue(color), GetRValue(color));
	}
	CStringW str;
	str.Format(L"0x6X",color);
	return str;
}

CStringW CPropTypeColor::GetLuaColor(int color)
{
	int r = GetRValue(color);
	int g = GetGValue(color);
	int b = GetBValue(color);
	CStringW str;
	if (colorType)
	{
		str.Format(L"%s=%d,%s=%d,%s=%d", GetLuaName(0), b, GetLuaName(1), g, GetLuaName(2), r);
	}
	else
	{
		str.Format(L"%s=%d,%s=%d,%s=%d", GetLuaName(0), r, GetLuaName(1), g, GetLuaName(2), b);
	}
	return str;
}


#define XML_BASE			"Base"
#define XML_CURSOR			"cursor"

//Properties
#define XML_PROPERTIES		"Properties"
#define XML_TYPE			"type"
#define XML_TYPE_VIEW_NAME	"typeViewName"
#define XML_TYPE_VALUE_NAME	"typeValueName"
#define XML_TYPE_LUA_NAME	"typeLuaName"
#define XML_DEFAULT_VALUE	"defaultValue"
#define XML_VALUE_VIEW_NAME	"valueViewName"
#define XML_VALUE_LUA_NAME	"valueLuaName"
#define XML_RES				"res";
#define XML_COLOR_TYPE		"colorType"
//data type
#define XML_INT				"int"
#define XML_DOUBLE			"double"
#define XML_DATA			"data"
#define XML_STRING			"string"
#define XML_ENUM			"enum"
#define XML_BOOL			"bool"
#define XML_IMAGE			"image"
#define XML_PACKFILE		"packfile"
#define XML_TEXT			"text"
#define XML_FONT			"font"
#define XML_COLOR			"color"

#define TAG_Name			"name"
#define TAG_Type			"type"
#define TAG_TypeName		"typeName"
#define TAG_Time			"time"

#include <libxml/parser.h>
#include <libxml/tree.h>


void NextNode(xmlNodePtr pXmlNode)
{
	if(pXmlNode == NULL)
		return;

	xmlNodePtr pChildXmlNode = pXmlNode->xmlChildrenNode;
	while(pChildXmlNode != NULL)
	{
		NextNode(pChildXmlNode);
		pChildXmlNode = pChildXmlNode->next;
	}
}

bool LoadEditorXML(string xmlPath,UIControl &uiControl)
{
	xmlDocPtr pDoc = 0;
	xmlNodePtr pRoot=0;

	xmlKeepBlanksDefault(0);
	pDoc = xmlReadFile(xmlPath.c_str() ,"UTF-8",XML_PARSE_RECOVER);
	if( 0 == pDoc )
		return false;

	pRoot = xmlDocGetRootElement(pDoc);

	NextNode(pRoot);

	xmlFreeDoc(pDoc);
	xmlCleanupParser();

/*
    XmlDocument root = new XmlDocument();
    try
    {
        root.Load(xmlPath);

        _uiControl.UIProperties = new Dictionary<string, UIProperties>();
        foreach (XmlElement childElement in root.DocumentElement.ChildNodes)
        {
            string uiName = childElement.Name;
            string cursor = childElement.GetAttribute(XML_CURSOR);

            UIProperties uiProperties = new UIProperties();
            uiProperties.cursor = cursor;
            uiProperties.Properties = new Dictionary<string, PropType>();

            XmlElement Properties = childElement[XML_PROPERTIES];
            if (Properties != null)
            {
                foreach (XmlElement property in Properties.ChildNodes)
                {
                    string propertyName = property.Name;
                    string typeName = property.GetAttribute(XML_TYPE);
                    string typeViewName = property.GetAttribute(XML_TYPE_VIEW_NAME);

                    PropType type = null;
                    switch (typeName)
                    {
                        case XML_INT:
                            {
                                type = new PropTypeInt();
                            }
                            break;
                        case XML_DOUBLE:
                            {
                                type = new PropTypeDouble();
                            }
                            break;
                        case XML_DATA:
                            {
                                type = new PropTypeData();
                            }
                            break;
                        case XML_STRING:
                            {
                                type = new PropTypeString();
                            }
                            break;
                        case XML_ENUM:
                            {
                                string defaultValue = property.GetAttribute(XML_DEFAULT_VALUE);
                                string valueViewName = property.GetAttribute(XML_VALUE_VIEW_NAME);
                                string valueLuaName = property.GetAttribute(XML_VALUE_LUA_NAME);

                                PropTypeEnum typeEnum = new PropTypeEnum();
                                typeEnum.defaultValue = StringToInt(defaultValue);
                                typeEnum.valueViewName = valueViewName.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                typeEnum.valueLuaName = valueLuaName.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                type = typeEnum;
                            }
                            break;
                        case XML_BOOL:
                            {
                                string defaultValue = property.GetAttribute(XML_DEFAULT_VALUE);
                                string typeValueName = property.GetAttribute(XML_TYPE_VALUE_NAME);
                                string valueLuaName = property.GetAttribute(XML_VALUE_LUA_NAME);

                                PropTypeBool typeBool = new PropTypeBool();
                                typeBool.defaultValue = StringToBool(defaultValue);
                                typeBool.typeValueName = typeValueName.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                typeBool.valueLuaName = valueLuaName.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                type = typeBool;
                            }
                            break;
                        case XML_IMAGE:
                            {
                                string defaultValue = property.GetAttribute(XML_DEFAULT_VALUE);
                                string res = property.GetAttribute(XML_RES);

                                PropTypeImage typeImage = new PropTypeImage();
                                typeImage.defaultValue = defaultValue;
                                typeImage.res = res;
                                type = typeImage;
                            }
                            break;
                        case XML_PACKFILE:
                            {
                                type = new PropTypePackfile();
                            }
                            break;
                        case XML_TEXT:
                            {
                                type = new PropTypeText();
                            }
                            break;
                        case XML_FONT:
                            {
                                type = new PropTypeFont();
                            }
                            break;
                        case XML_COLOR:
                            {
                                string colorType = property.GetAttribute(XML_COLOR_TYPE);
                                string defaultValue = property.GetAttribute(XML_DEFAULT_VALUE);
                                string typeLuaName = property.GetAttribute(XML_TYPE_LUA_NAME);

                                PropTypeColor typeColor = new PropTypeColor();
                                typeColor.colorType = (colorType == "BGR");
                                typeColor.defaultValue = StringToInt(defaultValue);
                                typeColor.typeLuaName = typeLuaName.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                                type = typeColor;
                            }
                            break;
                        default:
                            break;
                    }

                    if (type != null)
                    {
                        uiProperties.Properties.Add(propertyName, type);
                    }
                }
            }

            if (uiName == XML_BASE)
            {
                _uiControl.Base = uiProperties;
            }
            else
            {
                _uiControl.UIProperties.Add(uiName, uiProperties);
            }
        }
    }
    catch (Exception)
    {
        return false;
    }*/
    return true;
}