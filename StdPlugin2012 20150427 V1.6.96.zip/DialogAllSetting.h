#pragma once
#include "afxwin.h"


// CDialogAllSetting �Ի���

class CDialogAllSetting : public CDialogEx
{
	DECLARE_DYNAMIC(CDialogAllSetting)

public:
	CDialogAllSetting(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDialogAllSetting();

// �Ի�������
	enum { IDD = IDD_DIALOG_ALL_SETTING };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	afx_msg void OnBnClickedOk();
public:
	int m_H;
	int m_V;
	CComboBox m_fontComboBox;
};
