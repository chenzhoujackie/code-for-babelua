#pragma once

#include "LeftDialog.h"


// CLeftDockablePane

class CLeftDockablePane : public CDockablePane
{
public:
	void LoadXml(const CString &csSelDirectoryName,const CString &csSelFileName);
	CString GetSelDirectoryName() const;
	CString GetSelFileName() const;
	CString GetXmlPath() const;
	CString GetLuaPath() const;
	int SaveXml();
	int GenLua();
	int GenConfigLua(const CString &csFilePath,const CArray <EM_DRAWING_TYPE,EM_DRAWING_TYPE> &emDrawingTypeArr,BOOL bLeafNode);
	void ChangeEditorDrawingId();
	int GetTreeSelectItemDrawingId() const;
	void ChangeEditorDrawingSeat(double dX,double dY,double dWidth,double dHeight,BOOL bLButtonUp);
	void ChangeUIProp(const CDrawingBase *pDrawingBase,WPARAM wParam,LPARAM lParam,BOOL bAddHistory);
	int AddNewNode(EM_DRAWING_TYPE type,CString csDrawingTypeName,BOOL bControl,int x,int y);
	void Cut();
	void Copy();
	void Paste();
	void Undo();
	void Redo();
	void Delete();
	BOOL IsCanCut();
	BOOL IsCanCopy();
	BOOL IsCanPaste();
	BOOL IsCanUndo();
	BOOL IsCanRedo();
	BOOL IsCanDelete();
	void SetHistory(int iCommandHistoryPos);
	BOOL IsModifyData();
	void ReleaseAllData();
	const CDrawingBase* GetSelDrawingBase();
	bool GetTreeTimeMap(map<long,bool> &lTimeMap);
private:
	CLeftDialog m_leftDialog;

	DECLARE_DYNAMIC(CLeftDockablePane)

public:
	CLeftDockablePane();
	virtual ~CLeftDockablePane();

protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
};


