// RenderBase.h
//
//////////////////////////////////////////////////////////////////////

#ifndef _BOYAA_RENDER_BASE_H_
#define _BOYAA_RENDER_BASE_H_

class CRenderBase
{
public:
	virtual bool IsSupportNPOT() = 0;
	virtual bool IsSupportDrawTex() = 0;
	virtual void EnableTrace(bool bEnable ) = 0;

	virtual void Setup( int w,int h ,int screenW,int screenH,bool bFullScreen) = 0;
	virtual void GetViewOffset(int& ix,int& iy,float& wfactor,float& hfactor) = 0;

	virtual void SetCamera ( int x,int y ) = 0;
	virtual void ApplyCamera ( float& x,float& y ) = 0;
	virtual void GetCameraRect ( int& x,int& y,int& w,int& h ) = 0;

	virtual void Reset() = 0;
	virtual void DrawBegin() = 0;
	virtual void DrawEnd() = 0;

	virtual void SetPointSize ( float fPointSize ) = 0;
	virtual void SetLineWidth(float fLineWidth) = 0;

	virtual void Clear( bool bClearColor) = 0;
	virtual void SetClearColor ( float r,float g,float b ) = 0;
	virtual void SetColor ( float r,float g,float b,float a) = 0;
	virtual void ForceColor ( float r,float g,float b,float a) = 0;
	virtual void ResetColor() = 0;
	virtual void PushColor() = 0;
	virtual void PopColor() = 0;
	virtual void EnableBlend(bool bEnable) = 0;
	virtual void BlendFunc ( int sFactor, int dFactor ) = 0;
	virtual void SetBitmapTransparent(bool bTransparent) = 0;
	virtual void SetStencilClip( int iPass ) = 0;

	virtual void SetClipRect ( int x,int y ,int width,int height) = 0;
	virtual void ForceClip ( int x,int y ,int width,int height) = 0;
	virtual void ResetClip() = 0;
	virtual void PushClip() = 0;
	virtual void PopClip() = 0;
	
	virtual void LoadMatrix(float m[]) = 0;
	virtual void SetTranslate(float x,float y) = 0;
	virtual void SetRotate(float angle) = 0;
	virtual void SetScale(float x,float y) = 0;
	
	virtual bool PrepareBitmap ( const void *pData, unsigned char ucPixelFormat, unsigned int iHeight, unsigned int iWidth,unsigned int& uName, unsigned char ucFilter) = 0;
	virtual bool DeleteBitmap ( unsigned int uName) = 0;
	virtual void DrawBitmap ( unsigned int uName,float x,float y,float fHeight,float fWidth) = 0;
	virtual void DrawBitmap ( unsigned int uName,float x,float y,float fWidth,float fHeight,float fU1,float fV1,float fU2,float fV2) = 0;
	virtual void DrawBitmap9Slices ( unsigned int uName,float* vtx,int iVtxNum,float* tex,int iTexNum) = 0;
	virtual void DrawElements ( unsigned char ucRenderType, unsigned char ucUseData,int iCount,unsigned short* pIndices,float* pVertex,unsigned int uName,float* pTexCoord,float* pColors) = 0;

	virtual void DrawPoints(float* pXY, int iStart,int iPointNum) = 0;
	virtual void DrawLines ( float* pXY, int iStart,int iPointNum) = 0;
	virtual void DrawPolygon ( float* pXY, int iStart,int iPointNum, bool bFill) = 0;

};

#endif // _BOYAA_RENDER_BASE_H_
